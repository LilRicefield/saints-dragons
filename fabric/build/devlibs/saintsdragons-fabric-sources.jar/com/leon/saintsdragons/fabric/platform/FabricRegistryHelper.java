package com.leon.saintsdragons.fabric.platform;

import com.leon.saintsdragons.platform.RegistryHelper;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

import java.util.function.Supplier;

public class FabricRegistryHelper implements RegistryHelper {

    public static final FabricRegistryHelper INSTANCE = new FabricRegistryHelper();

    private FabricRegistryHelper() {}

    @Override
    public <T> RegistryWrapper<T> create(ResourceKey<? extends Registry<T>> registryKey, String modId) {
        return new FabricRegistryWrapper<>(registryKey, modId);
    }

    private static class FabricRegistryWrapper<T> implements RegistryWrapper<T> {
        private final Registry<T> registry;
        private final String modId;

        @SuppressWarnings("unchecked")
        public FabricRegistryWrapper(ResourceKey<? extends Registry<T>> registryKey, String modId) {
            this.registry = (Registry<T>) BuiltInRegistries.REGISTRY.get(registryKey.location());
            this.modId = modId;
        }

        @Override
        public <I extends T> Supplier<I> register(String name, Supplier<I> supplier) {
            I registered = Registry.register(registry, new ResourceLocation(modId, name), supplier.get());
            return () -> registered;
        }

        @Override
        public void register() {
            // No-op on Fabric - registration happens immediately
        }
    }
}
