package com.leon.saintsdragons.fabric.platform;

import com.leon.saintsdragons.platform.NetworkHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class FabricNetworkHelper implements NetworkHelper {

    public static final FabricNetworkHelper INSTANCE = new FabricNetworkHelper();

    private final Map<Class<?>, ResourceLocation> messageChannels = new HashMap<>();
    private final Map<Class<?>, BiConsumer<?, FriendlyByteBuf>> encoders = new HashMap<>();

    private FabricNetworkHelper() {}

    @Override
    public <T> void registerClientToServer(
        Class<T> messageClass,
        BiConsumer<T, FriendlyByteBuf> encoder,
        Function<FriendlyByteBuf, T> decoder,
        BiConsumer<T, ServerPlayer> handler
    ) {
        ResourceLocation channel = getOrCreateChannel(messageClass);
        encoders.put(messageClass, encoder);

        ServerPlayNetworking.registerGlobalReceiver(channel, (server, player, handler1, buf, responseSender) -> {
            T message = decoder.apply(buf);
            server.execute(() -> handler.accept(message, player));
        });
    }

    @Override
    public <T> void registerServerToClient(
        Class<T> messageClass,
        BiConsumer<T, FriendlyByteBuf> encoder,
        Function<FriendlyByteBuf, T> decoder,
        BiConsumer<T, Void> handler
    ) {
        ResourceLocation channel = getOrCreateChannel(messageClass);
        encoders.put(messageClass, encoder);

        // Client-side registration happens in client init
        // Store the decoder/handler for later use
    }

    @Override
    public void sendToServer(Object message) {
        ResourceLocation channel = messageChannels.get(message.getClass());
        if (channel == null) {
            throw new IllegalStateException("Message not registered: " + message.getClass());
        }

        BiConsumer<Object, FriendlyByteBuf> encoder =
            (BiConsumer<Object, FriendlyByteBuf>) encoders.get(message.getClass());

        FriendlyByteBuf buf = PacketByteBufs.create();
        encoder.accept(message, buf);

        ClientPlayNetworking.send(channel, buf);
    }

    @Override
    public void sendToPlayer(ServerPlayer player, Object message) {
        ResourceLocation channel = messageChannels.get(message.getClass());
        if (channel == null) {
            throw new IllegalStateException("Message not registered: " + message.getClass());
        }

        BiConsumer<Object, FriendlyByteBuf> encoder =
            (BiConsumer<Object, FriendlyByteBuf>) encoders.get(message.getClass());

        FriendlyByteBuf buf = PacketByteBufs.create();
        encoder.accept(message, buf);

        ServerPlayNetworking.send(player, channel, buf);
    }

    @Override
    public void sendToAllTracking(net.minecraft.world.entity.Entity entity, Object message) {
        ResourceLocation channel = messageChannels.get(message.getClass());
        if (channel == null) {
            throw new IllegalStateException("Message not registered: " + message.getClass());
        }

        BiConsumer<Object, FriendlyByteBuf> encoder =
            (BiConsumer<Object, FriendlyByteBuf>) encoders.get(message.getClass());

        FriendlyByteBuf buf = PacketByteBufs.create();
        encoder.accept(message, buf);

        for (ServerPlayer player : PlayerLookup.tracking(entity)) {
            ServerPlayNetworking.send(player, channel, buf);
        }
    }

    private ResourceLocation getOrCreateChannel(Class<?> messageClass) {
        return messageChannels.computeIfAbsent(messageClass, clazz -> {
            String name = clazz.getSimpleName().toLowerCase();
            return new ResourceLocation("saintsdragons", name);
        });
    }
}
