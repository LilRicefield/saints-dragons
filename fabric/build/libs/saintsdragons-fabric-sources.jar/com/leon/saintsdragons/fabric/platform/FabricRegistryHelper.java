package com.leon.saintsdragons.fabric.platform;

import RegistryWrapper;
import com.leon.saintsdragons.platform.RegistryHelper;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class FabricRegistryHelper implements RegistryHelper {

    public static final FabricRegistryHelper INSTANCE = new FabricRegistryHelper();

    private FabricRegistryHelper() {}

    @Override
    public <T> RegistryWrapper<T> create(class_5321<? extends class_2378<T>> registryKey, String modId) {
        return new FabricRegistryWrapper<>(registryKey, modId);
    }

    private static class FabricRegistryWrapper<T> implements RegistryWrapper<T> {
        private final class_2378<T> registry;
        private final String modId;

        @SuppressWarnings("unchecked")
        public FabricRegistryWrapper(class_5321<? extends class_2378<T>> registryKey, String modId) {
            this.registry = (class_2378<T>) class_7923.field_41167.method_10223(registryKey.method_29177());
            this.modId = modId;
        }

        @Override
        public <I extends T> Supplier<I> register(String name, Supplier<I> supplier) {
            I registered = class_2378.method_10230(registry, new class_2960(modId, name), supplier.get());
            return () -> registered;
        }

        @Override
        public void register() {
            // No-op on Fabric - registration happens immediately
        }
    }
}
