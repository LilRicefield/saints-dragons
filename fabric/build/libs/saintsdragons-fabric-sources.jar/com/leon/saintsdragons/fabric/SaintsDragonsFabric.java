package com.leon.saintsdragons.fabric;

import net.fabricmc.api.ModInitializer;

/**
 * Temporary Fabric entry point used while the common code is still under the
 * legacy Forge project. The real initialization logic will be plugged in once
 * the shared sources move into the common module.
 */
public final class SaintsDragonsFabric implements ModInitializer {

    @Override
    public void onInitialize() {
        System.out.println("[Saint's Dragons] Fabric loader detected – port in progress.");
    }
}
