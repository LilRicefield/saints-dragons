package com.leon.saintsdragons.fabric.platform;

import com.leon.saintsdragons.platform.ConfigHelper;

public class FabricConfigHelper implements ConfigHelper {

    public static final FabricConfigHelper INSTANCE = new FabricConfigHelper();

    private FabricConfigHelper() {}

    @Override
    public void registerConfig() {
        // Will implement with Fabric config library
        // For now, placeholder
    }

    @Override
    public <T> T getValue(String path, Class<T> type) {
        // Will implement with Fabric config
        // For now, placeholder
        return null;
    }
}
