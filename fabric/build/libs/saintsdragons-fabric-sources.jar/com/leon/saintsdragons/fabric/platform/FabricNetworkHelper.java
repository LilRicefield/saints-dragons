package com.leon.saintsdragons.fabric.platform;

import com.leon.saintsdragons.platform.NetworkHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class FabricNetworkHelper implements NetworkHelper {

    public static final FabricNetworkHelper INSTANCE = new FabricNetworkHelper();

    private final Map<Class<?>, class_2960> messageChannels = new HashMap<>();
    private final Map<Class<?>, BiConsumer<?, class_2540>> encoders = new HashMap<>();

    private FabricNetworkHelper() {}

    @Override
    public <T> void registerClientToServer(
        Class<T> messageClass,
        BiConsumer<T, class_2540> encoder,
        Function<class_2540, T> decoder,
        BiConsumer<T, class_3222> handler
    ) {
        class_2960 channel = getOrCreateChannel(messageClass);
        encoders.put(messageClass, encoder);

        ServerPlayNetworking.registerGlobalReceiver(channel, (server, player, handler1, buf, responseSender) -> {
            T message = decoder.apply(buf);
            server.execute(() -> handler.accept(message, player));
        });
    }

    @Override
    public <T> void registerServerToClient(
        Class<T> messageClass,
        BiConsumer<T, class_2540> encoder,
        Function<class_2540, T> decoder,
        BiConsumer<T, Void> handler
    ) {
        class_2960 channel = getOrCreateChannel(messageClass);
        encoders.put(messageClass, encoder);

        // Client-side registration happens in client init
        // Store the decoder/handler for later use
    }

    @Override
    public void sendToServer(Object message) {
        class_2960 channel = messageChannels.get(message.getClass());
        if (channel == null) {
            throw new IllegalStateException("Message not registered: " + message.getClass());
        }

        BiConsumer<Object, class_2540> encoder =
            (BiConsumer<Object, class_2540>) encoders.get(message.getClass());

        class_2540 buf = PacketByteBufs.create();
        encoder.accept(message, buf);

        ClientPlayNetworking.send(channel, buf);
    }

    @Override
    public void sendToPlayer(class_3222 player, Object message) {
        class_2960 channel = messageChannels.get(message.getClass());
        if (channel == null) {
            throw new IllegalStateException("Message not registered: " + message.getClass());
        }

        BiConsumer<Object, class_2540> encoder =
            (BiConsumer<Object, class_2540>) encoders.get(message.getClass());

        class_2540 buf = PacketByteBufs.create();
        encoder.accept(message, buf);

        ServerPlayNetworking.send(player, channel, buf);
    }

    @Override
    public void sendToAllTracking(net.minecraft.class_1297 entity, Object message) {
        class_2960 channel = messageChannels.get(message.getClass());
        if (channel == null) {
            throw new IllegalStateException("Message not registered: " + message.getClass());
        }

        BiConsumer<Object, class_2540> encoder =
            (BiConsumer<Object, class_2540>) encoders.get(message.getClass());

        class_2540 buf = PacketByteBufs.create();
        encoder.accept(message, buf);

        for (class_3222 player : PlayerLookup.tracking(entity)) {
            ServerPlayNetworking.send(player, channel, buf);
        }
    }

    private class_2960 getOrCreateChannel(Class<?> messageClass) {
        return messageChannels.computeIfAbsent(messageClass, clazz -> {
            String name = clazz.getSimpleName().toLowerCase();
            return new class_2960("saintsdragons", name);
        });
    }
}
