package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Simple ground wandering for Lightning Dragon when not flying
 */
public class RaevyxGroundWanderGoal extends RandomStrollGoal {

    private final Raevyx wyvern;

    public RaevyxGroundWanderGoal(Raevyx wyvern, double speed, int interval) {
        // Fixed interval wandering
        super(wyvern, speed, interval);
        this.wyvern = wyvern;
    }

    @Override
    public boolean canUse() {
        // Only wander on ground when not flying
        if (wyvern.isFlying()) {
            return false;
        }

        // Don't interfere with important behaviors
        if (wyvern.isOrderedToSit() || wyvern.isVehicle() || wyvern.isPassenger() || wyvern.isSleepLocked()) {
            return false;
        }

        // Don't wander during combat
        if (wyvern.getTarget() != null && wyvern.getTarget().isAlive()) {
            return false;
        }

        // Hook up to command system - only wander when command is 2 (Wander) or when untamed
        if (wyvern.isTame()) {
            int command = wyvern.getCommand();
            if (command != 2) { // 0=Follow, 1=Sit, 2=Wander
                return false;
            }
        }

        return super.canUse();
    }

    @Override
    public boolean canContinueToUse() {
        // Stop if we start flying
        if (wyvern.isFlying()) {
            return false;
        }

        // Stop if combat starts
        if (wyvern.getTarget() != null && wyvern.getTarget().isAlive()) {
            return false;
        }

        // Stop if ordered to sit
        if (wyvern.isOrderedToSit() || wyvern.isSleepLocked()) {
            return false;
        }

        return super.canContinueToUse();
    }

    @Nullable
    @Override
    protected Vec3 getPosition() {
        // If tamed and owner is far, bias movement towards owner
        if (wyvern.isTame()) {
            var owner = wyvern.getOwner();
            if (owner != null && wyvern.distanceToSqr(owner) > 20.0 * 20.0) {
                // Move generally towards owner but not directly (maintain some independence)
                return DefaultRandomPos.getPosTowards(
                        this.mob,
                        16, // range
                        7,  // vertical range
                        owner.position(),
                        (float) Math.PI / 3F // 60-degree cone towards owner
                );
            }
        }

        // Default random wandering
        return DefaultRandomPos.getPos(this.mob, 20, 8); // Slightly larger range for a wyvern
    }
}
