package com.leon.saintsdragons.client.particle.raevyx;

import com.leon.saintsdragons.common.particle.raevyx.RaevyxLightningStormData;
import com.leon.saintsdragons.common.particle.raevyx.RaevyxLightningArcData;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import javax.annotation.Nonnull;

import org.jetbrains.annotations.NotNull;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class RaevyxLightningParticle extends TextureSheetParticle {
    private final TextureAtlasSprite[] frames;

    protected RaevyxLightningParticle(ClientLevel level, double x, double y, double z,
                                      double xSpeed, double ySpeed, double zSpeed,
                                      float size, SpriteSet spriteSet, boolean female) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        TextureAtlasSprite[] resolved = RaevyxParticleSprites.storm(female);
        if (resolved.length == 0) {
            resolved = new TextureAtlasSprite[]{spriteSet.m_5819_(0, 1)};
        }
        this.frames = resolved;
        this.m_108337_(this.frames[0]);
        this.f_107215_ = xSpeed;
        this.f_107216_ = ySpeed;
        this.f_107217_ = zSpeed;
        this.f_107663_ = size;
        this.f_107225_ = Math.max(this.frames.length, 1); // Match texture sequence
        this.m_107250_(size * 1.5F, size * 1.5F);
    }

    @Override
    public void m_5989_() {
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;

        if (this.f_107224_++ >= this.f_107225_) {
            this.m_107274_();
        } else {
            updateSprite();
        }
    }

    private void updateSprite() {
        int frameIndex = RaevyxParticleSprites.frameIndexByProgress(this.frames, (float) this.f_107224_ / (float) this.f_107225_);
        this.m_108337_(this.frames[frameIndex]);
    }

    @Override
    public void m_5744_(@Nonnull VertexConsumer buffer, @Nonnull Camera camera, float partialTicks) {
        Vec3 cam = camera.m_90583_();
        float cx = (float)(Mth.m_14139_(partialTicks, this.f_107209_, this.f_107212_) - cam.m_7096_());
        float cy = (float)(Mth.m_14139_(partialTicks, this.f_107210_, this.f_107213_) - cam.m_7098_());
        float cz = (float)(Mth.m_14139_(partialTicks, this.f_107211_, this.f_107214_) - cam.m_7094_());
        
        Quaternionf camQ = new Quaternionf();
        camQ.rotateY((float) Math.toRadians(-camera.m_90590_()));
        
        Vector3f[] corners = new Vector3f[] {
            new Vector3f(-1.0F, -1.0F, 0.0F),
            new Vector3f(-1.0F,  1.0F, 0.0F),
            new Vector3f( 1.0F,  1.0F, 0.0F),
            new Vector3f( 1.0F, -1.0F, 0.0F)
        };
        
        float size = this.m_5902_(partialTicks);
        
        for (int i = 0; i < 4; ++i) {
            Vector3f v = corners[i];
            v.rotate(camQ);
            v.mul(size);
            v.add(cx, cy, cz);
        }

        float u0 = this.m_5970_();
        float u1 = this.m_5952_();
        float v0 = this.m_5951_();
        float v1 = this.m_5950_();
        int light = this.m_6355_(partialTicks);

        buffer.m_5483_(corners[0].x(), corners[0].y(), corners[0].z()).m_7421_(u1, v1).m_85950_(this.f_107227_, this.f_107228_, this.f_107229_, this.f_107230_).m_85969_(light).m_5752_();
        buffer.m_5483_(corners[1].x(), corners[1].y(), corners[1].z()).m_7421_(u1, v0).m_85950_(this.f_107227_, this.f_107228_, this.f_107229_, this.f_107230_).m_85969_(light).m_5752_();
        buffer.m_5483_(corners[2].x(), corners[2].y(), corners[2].z()).m_7421_(u0, v0).m_85950_(this.f_107227_, this.f_107228_, this.f_107229_, this.f_107230_).m_85969_(light).m_5752_();
        buffer.m_5483_(corners[3].x(), corners[3].y(), corners[3].z()).m_7421_(u0, v1).m_85950_(this.f_107227_, this.f_107228_, this.f_107229_, this.f_107230_).m_85969_(light).m_5752_();
    }

    @Override
    public int m_6355_(float partialTicks) {
        return 240; // Fullbright
    }

    @Override
    public @NotNull ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107431_;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<RaevyxLightningStormData> {
        private final SpriteSet spriteSet;
        public Factory(SpriteSet spriteSet) { this.spriteSet = spriteSet; }
        @Override
        public Particle createParticle(@Nonnull RaevyxLightningStormData data, @Nonnull ClientLevel world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new RaevyxLightningParticle(world, x, y, z, xSpeed, ySpeed, zSpeed, data.size(), spriteSet, data.female());
        }
    }

    // Secondary factory to reuse the same renderer with a different ParticleOptions type
    public static class FactoryArc implements ParticleProvider<RaevyxLightningArcData> {
        private final SpriteSet spriteSet;
        public FactoryArc(SpriteSet spriteSet) { this.spriteSet = spriteSet; }
        @Override
        public Particle createParticle(@Nonnull RaevyxLightningArcData data, @Nonnull ClientLevel world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            return new RaevyxLightningParticle(world, x, y, z, xSpeed, ySpeed, zSpeed, data.size(), spriteSet, data.female());
        }
    }
}
