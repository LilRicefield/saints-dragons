package com.leon.saintsdragons.client.screen;

import com.leon.saintsdragons.SaintsDragons;
import com.leon.saintsdragons.common.network.MessageDragonAllyManagement;
import com.leon.saintsdragons.common.network.MessageDragonAllyRequest;
import com.leon.saintsdragons.common.network.ModNetworkHandler;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * GUI screen for managing wyvern allies.
 * Allows adding/removing allies by username with validation.
 */
public class DragonAllyScreen extends Screen {
    private final DragonEntity dragon;

    // GUI dimensions - adjust to match Minecraft's GUI scaling
    private static final int GUI_WIDTH = 256;
    private static final int GUI_HEIGHT = 200;
    
    // Calculate actual GUI size based on screen scaling
    private int getActualGuiWidth() {
        return Math.min(GUI_WIDTH, this.f_96543_ - 40); // Leave 20px margin on each side
    }
    
    private int getActualGuiHeight() {
        return Math.min(GUI_HEIGHT, this.f_96544_ - 40); // Leave 20px margin on top/bottom
    }
    private int leftPos;
    private int topPos;
    
    // Components
    private EditBox usernameInput;

    // Ally list display
    private List<String> allyList;
    private int scrollOffset = 0;
    private static final int MAX_VISIBLE_ALLIES = 8;
    
    public DragonAllyScreen(DragonEntity dragon) {
        super(Component.m_237115_("saintsdragons.gui.dragon_ally.title"));
        this.dragon = dragon;
        this.allyList = new java.util.ArrayList<>(); // Start empty, will be populated by server
    }
    
    @Override
    protected void m_7856_() {
        super.m_7856_();
        
        // Center the GUI, but ensure it fits on screen
        int actualWidth = getActualGuiWidth();
        int actualHeight = getActualGuiHeight();
        
        this.leftPos = Math.max(0, (this.f_96543_ - actualWidth) / 2);
        this.topPos = Math.max(0, (this.f_96544_ - actualHeight) / 2);
        
        // Ensure GUI doesn't go off the bottom of the screen
        if (this.topPos + actualHeight > this.f_96544_ - 20) { // Leave 20px margin from bottom
            this.topPos = this.f_96544_ - actualHeight - 20; // Leave 20px margin from bottom
        }
        
        // Debug: Log GUI positioning (only once)
        SaintsDragons.LOGGER.info("GUI positioning - Screen: {}x{}, GUI: {}x{}, Position: ({}, {})", 
            this.f_96543_, this.f_96544_, GUI_WIDTH, GUI_HEIGHT, this.leftPos, this.topPos);
        
        // Request current ally list from server
        requestAllyListFromServer();
        
        // Username input field
        this.usernameInput = new EditBox(this.f_96547_, leftPos + 20, topPos + 30, 150, 20, 
            Component.m_237115_("saintsdragons.gui.dragon_ally.username_input"));
        this.usernameInput.m_94199_(16); // Minecraft username limit
        this.m_142416_(usernameInput);
        
        // Add ally button
        Button addButton = Button.m_253074_(
                Component.m_237115_("saintsdragons.gui.dragon_ally.add"),
                button -> addAlly()
        ).m_252987_(leftPos + 180, topPos + 30, 60, 20).m_253136_();
        this.m_142416_(addButton);
        
        // Remove ally button
        Button removeButton = Button.m_253074_(
                Component.m_237115_("saintsdragons.gui.dragon_ally.remove"),
                button -> removeAlly()
        ).m_252987_(leftPos + 180, topPos + 55, 60, 20).m_253136_();
        this.m_142416_(removeButton);
        
        // Close button - moved up to avoid covering inner border
        Button closeButton = Button.m_253074_(
                Component.m_237115_("gui.cancel"),
                button -> m_7379_()
        ).m_252987_(leftPos + GUI_WIDTH - 60, topPos + GUI_HEIGHT - 50, 50, 20).m_253136_();
        this.m_142416_(closeButton);
        
        // Set initial focus
        this.m_264313_(usernameInput);
    }
    
    @Override
    public void m_88315_(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.m_280273_(guiGraphics);
        
        // Use the reliable programmatic drawing system - it works perfectly!
        int actualWidth = getActualGuiWidth();
        int actualHeight = getActualGuiHeight();
        
        // Draw beautiful gold-bordered GUI
        guiGraphics.m_280509_(leftPos, topPos, leftPos + actualWidth, topPos + actualHeight, 0x80000000); // Semi-transparent black background
        guiGraphics.m_280509_(leftPos, topPos, leftPos + actualWidth, topPos + 1, 0xFFD4AF37); // Top border (gold)
        guiGraphics.m_280509_(leftPos, topPos, leftPos + 1, topPos + actualHeight, 0xFFD4AF37); // Left border (gold)
        guiGraphics.m_280509_(leftPos + actualWidth - 1, topPos, leftPos + actualWidth, topPos + actualHeight, 0xFFD4AF37); // Right border (gold)
        guiGraphics.m_280509_(leftPos, topPos + actualHeight - 1, leftPos + actualWidth, topPos + actualHeight, 0xFFD4AF37); // Bottom border (gold)
        
        // Add some decorative elements to make it look more medieval/fantasy
        guiGraphics.m_280509_(leftPos + 10, topPos + 10, leftPos + actualWidth - 10, topPos + 12, 0xFFB8860B); // Inner top border (darker gold)
        guiGraphics.m_280509_(leftPos + 10, topPos + actualHeight - 12, leftPos + actualWidth - 10, topPos + actualHeight - 10, 0xFFB8860B); // Inner bottom border (darker gold)
        
        // Draw title
        guiGraphics.m_280653_(this.f_96547_, this.f_96539_, 
            leftPos + GUI_WIDTH / 2, topPos + 16, 0x404040);
        
        // Draw ally count
        String allyCountText = Component.m_237110_("saintsdragons.gui.dragon_ally.count", 
            allyList.size(), dragon.allyManager.getMaxAllies()).getString();
        guiGraphics.m_280488_(this.f_96547_, allyCountText, leftPos + 20, topPos + 80, 0x404040);
        
        // Draw ally list
        drawAllyList(guiGraphics);
        
        super.m_88315_(guiGraphics, mouseX, mouseY, partialTick);
    }
    
    private void drawAllyList(GuiGraphics guiGraphics) {
        int startY = topPos + 100;
        int endY = topPos + GUI_HEIGHT - 40;
        int visibleCount = Math.min(MAX_VISIBLE_ALLIES, allyList.size() - scrollOffset);
        
        // Draw ally entries
        for (int i = 0; i < visibleCount; i++) {
            int index = i + scrollOffset;
            if (index >= allyList.size()) break;
            
            String allyName = allyList.get(index);
            int y = startY + (i * 12);
            
            // Highlight if mouse is over this entry (mouseX and mouseY are parameters from render method)
            // TODO: Implement mouse hover detection

            int color = 0x404040;
            guiGraphics.m_280488_(this.f_96547_, allyName, leftPos + 20, y, color);
        }
        
        // Draw scroll indicators if needed
        if (allyList.size() > MAX_VISIBLE_ALLIES) {
            if (scrollOffset > 0) {
                guiGraphics.m_280488_(this.f_96547_, "↑", leftPos + GUI_WIDTH - 20, startY, 0x404040);
            }
            if (scrollOffset + MAX_VISIBLE_ALLIES < allyList.size()) {
                guiGraphics.m_280488_(this.f_96547_, "↓", leftPos + GUI_WIDTH - 20, endY - 12, 0x404040);
            }
        }
    }
    
    @Override
    public boolean m_6050_(double mouseX, double mouseY, double delta) {
        if (allyList.size() > MAX_VISIBLE_ALLIES) {
            if (delta < 0 && scrollOffset < allyList.size() - MAX_VISIBLE_ALLIES) {
                scrollOffset++;
            } else if (delta > 0 && scrollOffset > 0) {
                scrollOffset--;
            }
            return true;
        }
        return false;
    }
    
    @Override
    public boolean m_6375_(double mouseX, double mouseY, int button) {
        // Handle ally list clicking for removal
        if (button == 0) { // Left click
            int startY = topPos + 100;
            for (int i = 0; i < Math.min(MAX_VISIBLE_ALLIES, allyList.size() - scrollOffset); i++) {
                int index = i + scrollOffset;
                if (index >= allyList.size()) break;
                
                int y = startY + (i * 12);
                if (mouseX >= leftPos + 20 && mouseX <= leftPos + GUI_WIDTH - 40 &&
                    mouseY >= y && mouseY < y + 12) {
                    
                    String allyName = allyList.get(index);
                    usernameInput.m_94144_(allyName);
                    return true;
                }
            }
        }
        return super.m_6375_(mouseX, mouseY, button);
    }
    
    private void addAlly() {
        String username = usernameInput.m_94155_().trim();
        if (username.isEmpty()) {
            return;
        }
        
        // Send add ally message to server
        ModNetworkHandler.sendToServer(new MessageDragonAllyManagement(
            dragon.m_19879_(), MessageDragonAllyManagement.Action.ADD, username));
        
        usernameInput.m_94144_("");
    }
    
    private void removeAlly() {
        String username = usernameInput.m_94155_().trim();
        if (username.isEmpty()) {
            return;
        }
        
        // Send remove ally message to server
        ModNetworkHandler.sendToServer(new MessageDragonAllyManagement(
            dragon.m_19879_(), MessageDragonAllyManagement.Action.REMOVE, username));
        
        usernameInput.m_94144_("");
    }
    
    @Override
    public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
        if (super.m_7933_(keyCode, scanCode, modifiers)) {
            return true;
        }
        
        // Enter key to add ally
        if (keyCode == 257) { // Enter
            addAlly();
            return true;
        }
        
        return false;
    }
    
    @Override
    public boolean m_7043_() {
        return false;
    }
    
    /**
     * Request the current ally list from the server
     */
    private void requestAllyListFromServer() {
        // Send a request to get the current ally list
        ModNetworkHandler.sendToServer(new MessageDragonAllyRequest(dragon.m_19879_()));
    }
    
    /**
     * Update the ally list (called from network handler when GUI is first opened)
     */
    public void updateAllyList(List<String> newAllyList) {
        this.allyList = newAllyList;
        this.scrollOffset = Math.min(scrollOffset, Math.max(0, allyList.size() - MAX_VISIBLE_ALLIES));
    }

    /**
     * Add a single ally to the list (delta update - optimized)
     * Called from network handler when an ally is added
     */
    public void addAlly(String username) {
        if (!this.allyList.contains(username)) {
            this.allyList.add(username);
            this.scrollOffset = Math.min(scrollOffset, Math.max(0, allyList.size() - MAX_VISIBLE_ALLIES));
        }
    }

    /**
     * Remove a single ally from the list (delta update - optimized)
     * Called from network handler when an ally is removed
     */
    public void removeAlly(String username) {
        this.allyList.remove(username);
        this.scrollOffset = Math.min(scrollOffset, Math.max(0, allyList.size() - MAX_VISIBLE_ALLIES));
    }
}
