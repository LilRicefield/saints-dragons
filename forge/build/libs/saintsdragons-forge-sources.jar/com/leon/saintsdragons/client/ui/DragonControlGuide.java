package com.leon.saintsdragons.client.ui;

import com.leon.saintsdragons.client.DragonRideKeybinds;
import com.leon.saintsdragons.common.registry.AbilityRegistry;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.base.RideableDragonBase;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Control guide UI element for dragons.
 * Shows current keybinds and their functions, updates dynamically.
 */
public class DragonControlGuide extends DragonUIElement {
    private static final int BASE_WIDTH = 150;
    private static final int TITLE_COLOR = 0xFFFFFFFF;
    private static final int KEY_BG_DARK = 0xFF333333;
    private static final int KEY_BG_LIGHT = 0xFF666666;
    private static final int COLOR_ATTACK = 0xFFFF5A5A;
    private static final int COLOR_MOVEMENT = 0xFF00FFFF;
    private static final int COLOR_ABILITY = 0xFFFFC845;

    private DragonEntity dragon;
    private final List<ControlEntry> controls = new ArrayList<>();

    public DragonControlGuide(int x, int y) {
        super(x, y, BASE_WIDTH, 80);
    }

    public void setDragon(DragonEntity dragon) {
        this.dragon = dragon;
        updateControls();
    }

    private void updateControls() {
        controls.clear();
        if (dragon == null) {
            this.height = 0;
            this.width = BASE_WIDTH;
            return;
        }

        Minecraft mc = Minecraft.m_91087_();
        Options options = mc.f_91066_;
        Font font = mc.f_91062_;

        RideableDragonBase rideable = dragon instanceof RideableDragonBase base ? base : null;
        boolean attackHandledByAbility = false;

        if (rideable != null) {
            attackHandledByAbility = addAbilityEntry(rideable.getAttackRiderAbility(), options.f_92096_, "saintsdragons.ui.control.attack", COLOR_ATTACK);
        }
        if (!attackHandledByAbility) {
            controls.add(ControlEntry.forKey(options.f_92096_, Component.m_237115_("saintsdragons.ui.control.attack"), COLOR_ATTACK));
        }

        controls.add(ControlEntry.forKey(DragonRideKeybinds.DRAGON_ASCEND, Component.m_237115_("saintsdragons.ui.control.ascend"), COLOR_MOVEMENT));
        controls.add(ControlEntry.forKey(DragonRideKeybinds.DRAGON_DESCEND, Component.m_237115_("saintsdragons.ui.control.descend"), COLOR_MOVEMENT));
        controls.add(ControlEntry.forKey(DragonRideKeybinds.DRAGON_ACCELERATE, Component.m_237115_("saintsdragons.ui.control.accelerate"), COLOR_MOVEMENT));

        if (rideable != null) {
            addAbilityEntry(rideable.getPrimaryRiderAbility(), DragonRideKeybinds.DRAGON_PRIMARY_ABILITY, "saintsdragons.ui.control.ability_primary", COLOR_ABILITY);
            addAbilityEntry(rideable.getSecondaryRiderAbility(), DragonRideKeybinds.DRAGON_SECONDARY_ABILITY, "saintsdragons.ui.control.ability_secondary", COLOR_ABILITY);
            addAbilityEntry(rideable.getTertiaryRiderAbility(), DragonRideKeybinds.DRAGON_TERTIARY_ABILITY, "saintsdragons.ui.control.ability_tertiary", COLOR_ABILITY);
            // Add toggle melee entry
            controls.add(ControlEntry.forKey(DragonRideKeybinds.DRAGON_TOGGLE_MELEE, Component.m_237115_("saintsdragons.ui.control.toggle_melee"), COLOR_ATTACK));
        }

        int lineSpacing = font.f_92710_ + 2;
        int contentHeight = 14 + controls.size() * lineSpacing + 4;
        this.height = Math.max(40, contentHeight);

        int maxWidth = BASE_WIDTH;
        for (ControlEntry control : controls) {
            Component key = control.getKeyComponent();
            if (key.getString().isEmpty()) {
                continue;
            }
            int keyWidth = control.getKeyWidth(font);
            int functionWidth = control.getFunctionWidth(font);
            maxWidth = Math.max(maxWidth, keyWidth + functionWidth + 14);
        }
        this.width = maxWidth;
    }

    private boolean addAbilityEntry(@Nullable RideableDragonBase.RiderAbilityBinding binding,
                                    KeyMapping keyMapping,
                                    String slotTranslationKey,
                                    int color) {
        if (binding == null || binding.abilityId() == null || binding.abilityId().isEmpty()) {
            return false;
        }
        Component label = buildAbilityLabel(slotTranslationKey, binding.abilityId());
        controls.add(ControlEntry.forKey(keyMapping, label, color));
        return true;
    }

    private Component buildAbilityLabel(String slotTranslationKey, String abilityId) {
        Component slot = Component.m_237115_(slotTranslationKey);
        DragonAbilityType<?, ?> abilityType = AbilityRegistry.get(abilityId);
        Component abilityName = abilityType != null
                ? Component.m_237115_("saintsdragons.ability." + abilityType.getName())
                : Component.m_237115_("saintsdragons.ability." + abilityId);
        return Component.m_237110_("saintsdragons.ui.control.ability_with_name", slot, abilityName);
    }

    // Cached title component and width
    private Component cachedTitle = null;
    private int cachedTitleWidth = -1;

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        if (!visible || dragon == null || dragon.m_21224_() || controls.isEmpty()) {
            return;
        }

        Font font = Minecraft.m_91087_().f_91062_;

        // Cache title component and width
        if (cachedTitle == null) {
            cachedTitle = Component.m_237115_("saintsdragons.ui.control.title");
            cachedTitleWidth = font.m_92852_(cachedTitle);
        }

        guiGraphics.m_280430_(font, cachedTitle, x + (width - cachedTitleWidth) / 2, y + 2, TITLE_COLOR);

        int startY = y + 14;
        int lineSpacing = font.f_92710_ + 2;

        for (int i = 0; i < controls.size(); i++) {
            ControlEntry control = controls.get(i);
            Component keyComponent = control.getKeyComponent();
            if (keyComponent.getString().isEmpty()) {
                continue;
            }

            int keyWidth = control.getKeyWidth(font);
            int entryY = startY + i * lineSpacing;

            guiGraphics.m_280509_(x + 2, entryY, x + 2 + keyWidth, entryY + font.f_92710_ + 1, KEY_BG_DARK);
            guiGraphics.m_280509_(x + 3, entryY + 1, x + 1 + keyWidth, entryY + font.f_92710_, KEY_BG_LIGHT);

            guiGraphics.m_280430_(font, keyComponent, x + 4, entryY + 1, 0xFFFFFFFF);
            guiGraphics.m_280430_(font, control.functionText, x + 2 + keyWidth + 4, entryY + 1, control.color);
        }

        if (isMouseOver(mouseX, mouseY)) {
            renderDragHandle(guiGraphics);
        }
    }

    private void renderDragHandle(GuiGraphics guiGraphics) {
        int handleSize = 4;
        int handleX = x + width - handleSize - 2;
        int handleY = y + 2;

        guiGraphics.m_280509_(handleX, handleY, handleX + handleSize, handleY + handleSize, 0xFFFFFFFF);
        guiGraphics.m_280509_(handleX + 1, handleY + 1, handleX + handleSize - 1, handleY + handleSize - 1, 0xFF000000);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int handleSize = 4;
        int handleX = x + width - handleSize - 2;
        int handleY = y + 2;

        if (button == 0 && mouseX >= handleX && mouseX <= handleX + handleSize &&
            mouseY >= handleY && mouseY <= handleY + handleSize) {
            startDragging(mouseX, mouseY);
            return true;
        }
        return false;
    }

    private static class ControlEntry {
        private final KeyMapping keyMapping;
        private final Component functionText;
        private final int color;

        // Cached rendering values
        private Component cachedKeyComponent = null;
        private int cachedKeyWidth = -1;
        private int cachedFunctionWidth = -1;

        private ControlEntry(KeyMapping keyMapping, Component functionText, int color) {
            this.keyMapping = keyMapping;
            this.functionText = functionText;
            this.color = color;
        }

        static ControlEntry forKey(KeyMapping keyMapping, Component functionText, int color) {
            return new ControlEntry(keyMapping, functionText, color);
        }

        Component getKeyComponent() {
            if (cachedKeyComponent == null) {
                cachedKeyComponent = keyMapping != null ? keyMapping.m_90863_() : Component.m_237119_();
            }
            return cachedKeyComponent;
        }

        int getKeyWidth(Font font) {
            if (cachedKeyWidth == -1) {
                cachedKeyWidth = font.m_92852_(getKeyComponent()) + 6;
            }
            return cachedKeyWidth;
        }

        int getFunctionWidth(Font font) {
            if (cachedFunctionWidth == -1) {
                cachedFunctionWidth = font.m_92852_(functionText);
            }
            return cachedFunctionWidth;
        }
    }
}
