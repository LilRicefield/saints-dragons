package com.leon.saintsdragons.client.particle.cindervane;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class FireBreathFlameParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private float prevAlpha = 0.0F;
    private boolean spinning;
    private float spinIncrement;

    protected FireBreathFlameParticle(ClientLevel world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, SpriteSet spriteSet, boolean spinning) {
        super(world, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = spriteSet;
        this.m_108339_(this.sprites);
        this.f_107215_ = xSpeed;
        this.f_107216_ = ySpeed;
        this.f_107217_ = zSpeed;
        this.m_107250_(0.3F, 0.3F);
        this.f_107663_ = 0.5F + world.f_46441_.m_188501_() * 0.3F;
        this.f_107225_ = 15 + world.f_46441_.m_188503_(15);
        this.f_172258_ = 0.98F;
        this.spinning = spinning;
        if (spinning) {
            this.f_107231_ = (float) Math.toRadians(360F * f_107223_.m_188501_());
            this.f_107204_ = f_107231_;
            spinIncrement = (f_107223_.m_188499_() ? -1 : 1) * f_107223_.m_188501_() * 0.3F;
        }
        
        // Fire colors - bright orange to red
        this.f_107227_ = 1.0F;
        this.f_107228_ = 0.6F + f_107223_.m_188501_() * 0.3F;
        this.f_107229_ = 0.1F + f_107223_.m_188501_() * 0.2F;
    }

    public void m_5989_() {
        this.m_108339_(this.sprites);
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        float ageProgress = this.f_107224_ / (float) f_107225_;
        float f = ageProgress - 0.3F;
        float f1 = 1.0F - f * 1.5F;
        
        // Fade out in the last 70% of lifetime
        if (ageProgress > 0.3F) {
            prevAlpha = f_107230_;
            this.m_107271_(prevAlpha + (f1 - prevAlpha) * 0.1F); // Use fixed partial tick
        }
        
        if (this.f_107224_++ >= this.f_107225_) {
            this.m_107274_();
        } else {
            this.m_6257_(this.f_107215_, this.f_107216_, this.f_107217_);
            this.f_107215_ *= (double) this.f_172258_;
            this.f_107216_ *= (double) this.f_172258_;
            this.f_107217_ *= (double) this.f_172258_;
            
            // Add some upward drift
            this.f_107216_ += 0.01D;
        }
        
        if (spinning) {
            this.f_107204_ = f_107231_;
            this.f_107231_ += f1 * spinIncrement;
        }
    }

    @Override
    public ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107431_;
    }

    public int m_6355_(float partialTicks) {
        return 240; // Full brightness for fire
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet spriteSet;

        public Factory(SpriteSet spriteSet) {
            this.spriteSet = spriteSet;
        }

        public Particle createParticle(@org.jetbrains.annotations.NotNull SimpleParticleType typeIn, @org.jetbrains.annotations.NotNull ClientLevel worldIn, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
            FireBreathFlameParticle particle = new FireBreathFlameParticle(worldIn, x, y, z, xSpeed, ySpeed, zSpeed, spriteSet, true);
            return particle;
        }
    }
}
