package com.leon.saintsdragons.common.item;

import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

/**
 * Item used to bind a Lightning Dragon for portable convenience.
 * Right-click on a tamed lightning wyvern to bind it to this item.
 * While carrying a bound lightning wyvern binder, the player can release the wyvern.
 */
public class RaevyxBinderItem extends Item {
    
    // NBT keys for storing bound wyvern data
    private static final String BOUND_DRAGON_UUID = "BoundDragonUUID";
    private static final String BOUND_DRAGON_NAME = "BoundDragonName";
    private static final String BOUND_OWNER_UUID = "BoundOwnerUUID";
    private static final String BOUND_OWNER_NAME = "BoundOwnerName";
    private static final String IS_BOUND = "IsBound";
    
    public RaevyxBinderItem(Properties properties) {
        super(properties);
    }
    
    @Override
    public @NotNull InteractionResult m_6880_(@NotNull ItemStack stack, @NotNull Player player, @NotNull LivingEntity target, @NotNull InteractionHand hand) {
        if (target instanceof Raevyx wyvern) {
            // Check if player owns the wyvern
            if (!wyvern.m_21824_() || !wyvern.m_21830_(player)) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.not_dragon_owner"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Check if wyvern can be captured (not playing dead, not sleeping, etc.)
            if (!wyvern.canBeBound()) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.dragon_cannot_be_captured"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Check if binder is already occupied
            if (isBound(stack)) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.raevyx_already_occupied"),
                    true);
                return InteractionResult.FAIL;
            }
            
            // Capture the wyvern into the binder
            ItemStack newStack = captureDragon(stack, wyvern, player);
            
            // Replace the item in the player's hand
            if (hand == InteractionHand.MAIN_HAND) {
                player.m_150109_().m_6836_(player.m_150109_().f_35977_, newStack);
            } else {
                player.m_150109_().m_6836_(40, newStack); // Off-hand slot
            }
            
            return InteractionResult.SUCCESS;
        }
        
        return InteractionResult.PASS;
    }
    
    @Override
    public @NotNull InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        
        if (isBound(stack)) {
            return InteractionResultHolder.m_19098_(stack);
        }
        return super.m_7203_(level, player, hand);
    }

    @Override
    public @NotNull InteractionResult m_6225_(@NotNull UseOnContext context) {
        Player player = context.m_43723_();
        ItemStack stack = context.m_43722_();
        
        if (player != null && isBound(stack)) {
            return releaseDragon(stack, player, context.m_8083_())
                ? InteractionResult.SUCCESS
                : InteractionResult.FAIL;
        }
        return super.m_6225_(context);
    }
    
    /**
     * Capture a wyvern into this binder (Pokeball style)
     */
    private ItemStack captureDragon(ItemStack stack, Raevyx dragon, Player player) {
        // Create a new item stack with the modified data
        ItemStack newStack = stack.m_41777_();
        CompoundTag tag = newStack.m_41784_();
        
        // Store wyvern data
        tag.m_128362_(BOUND_DRAGON_UUID, dragon.m_20148_());
        tag.m_128359_(BOUND_DRAGON_NAME, dragon.m_7755_().getString());
        if (dragon.m_8077_()) {
            Component customName = dragon.m_7770_();
            if (customName != null) {
                tag.m_128359_("BoundCustomName", net.minecraft.network.chat.Component.Serializer.m_130703_(customName));
            } else {
                tag.m_128473_("BoundCustomName");
            }
        } else {
            tag.m_128473_("BoundCustomName");
        }
        tag.m_128379_(IS_BOUND, true);

        // Store owner data
        LivingEntity owner = dragon.m_269323_();
        if (owner instanceof Player ownerPlayer) {
            tag.m_128362_(BOUND_OWNER_UUID, ownerPlayer.m_20148_());
            tag.m_128359_(BOUND_OWNER_NAME, ownerPlayer.m_7755_().getString());
        } else {
            tag.m_128473_(BOUND_OWNER_UUID);
            tag.m_128473_(BOUND_OWNER_NAME);
        }

        // Store wyvern's current state
        CompoundTag dragonData = new CompoundTag();
        dragon.m_7380_(dragonData);
        tag.m_128365_("DragonData", dragonData);
        
        // Set the tag on the new stack
        newStack.m_41751_(tag);
        
        // Replace the old stack with the new one in the player's inventory
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            // Find the slot containing the old stack and replace it
            for (int i = 0; i < serverPlayer.m_150109_().m_6643_(); i++) {
                if (serverPlayer.m_150109_().m_8020_(i) == stack) {
                    serverPlayer.m_150109_().m_6836_(i, newStack);
                    break;
                }
            }
        }
        
        // Remove the wyvern from the world
        dragon.m_142687_(net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);
        
        // Send success message
        player.m_5661_(
            Component.m_237110_("saintsdragons.message.raevyx_captured", dragon.m_7755_().getString()),
            true
        );
        
        return newStack;
    }
    
    /**
     * Release the bound wyvern from this binder
     */
    private boolean releaseDragon(ItemStack stack, Player player, BlockPos pos) {
        CompoundTag tag = stack.m_41783_();
        if (tag == null || !tag.m_128441_(BOUND_DRAGON_UUID)) {
            return false;
        }

        UUID ownerUUID = tag.m_128441_(BOUND_OWNER_UUID) ? tag.m_128342_(BOUND_OWNER_UUID) : null;
        if (ownerUUID != null && !player.m_20148_().equals(ownerUUID)) {
            player.m_5661_(
                Component.m_237115_("saintsdragons.message.cannot_release_others_dragon"),
                true
            );
            return false;
        }

        if (!(player.m_9236_() instanceof ServerLevel serverLevel)) {
            return true;
        }

        String dragonName = tag.m_128461_(BOUND_DRAGON_NAME);

        Raevyx newDragon = new Raevyx(
            ModEntities.RAEVYX.get(),
            serverLevel
        );

        if (tag.m_128441_("DragonData")) {
            CompoundTag dragonData = tag.m_128469_("DragonData");
            newDragon.m_7378_(dragonData);
        }

        // Ensure newly released dragons default to follow command so they don't stay in previous wander state
        newDragon.m_6034_(pos.m_123341_() + 0.5, pos.m_123342_() + 1, pos.m_123343_() + 0.5);

        if (ownerUUID != null) {
            Player owner = serverLevel.m_46003_(ownerUUID);
            if (owner != null) {
                newDragon.m_21828_(owner);
            }
        } else {
            newDragon.m_21828_(player);
        }

        if (tag.m_128441_("BoundCustomName")) {
            net.minecraft.network.chat.Component customName = net.minecraft.network.chat.Component.Serializer.m_130701_(tag.m_128461_("BoundCustomName"));
            if (customName != null) {
                newDragon.m_6593_(customName);
            }
        }

        serverLevel.m_7967_(newDragon);

        tag.m_128473_(BOUND_DRAGON_UUID);
        tag.m_128473_(BOUND_DRAGON_NAME);
        tag.m_128473_(BOUND_OWNER_UUID);
        tag.m_128473_(BOUND_OWNER_NAME);
        tag.m_128473_("BoundCustomName");
        tag.m_128473_("DragonData");
        tag.m_128379_(IS_BOUND, false);

        player.m_5661_(
            Component.m_237110_("saintsdragons.message.raevyx_released", dragonName),
            true
        );
        return true;
    }
    
    /**
     * Check if this binder has a wyvern bound to it
     */
    public static boolean isBound(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        return tag != null && tag.m_128471_(IS_BOUND);
    }
    
    /**
     * Get the UUID of the bound wyvern
     */
    @Nullable
    public static UUID getBoundDragonUUID(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        if (tag != null && tag.m_128441_(BOUND_DRAGON_UUID)) {
            return tag.m_128342_(BOUND_DRAGON_UUID);
        }
        return null;
    }
    
    /**
     * Get the name of the bound wyvern
     */
    @Nullable
    public static String getBoundRaevyxName(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        if (tag != null && tag.m_128441_(BOUND_DRAGON_NAME)) {
            return tag.m_128461_(BOUND_DRAGON_NAME);
        }
        return null;
    }
    
    @Override
    @OnlyIn(Dist.CLIENT)
    public void m_7373_(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> tooltip, @NotNull TooltipFlag flag) {
        tooltip.add(Component.m_237115_("saintsdragons.tooltip.raevyx_binder.description"));
        if (isBound(stack)) {
            String wyvernName = getBoundRaevyxName(stack);
            if (wyvernName != null) {
                tooltip.add(Component.m_237110_("saintsdragons.tooltip.raevyx_binder.bound", wyvernName));
            }
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.raevyx_binder.right_click_to_release"));
        } else {
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.raevyx_binder.empty"));
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.raevyx_binder.right_click_dragon_to_bind"));
        }
    }

    @Override
    public boolean m_5812_(@NotNull ItemStack stack) {
        return isBound(stack);
    }

}
