package com.leon.saintsdragons.common.registry;

import com.leon.saintsdragons.SaintsDragons;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import com.leon.saintsdragons.server.entity.effect.raevyx.RaevyxLightningChainEntity;
import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import com.leon.saintsdragons.server.entity.effect.cindervane.CindervaneMagmaBlockEntity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Central registry for all wyvern entities.
 * Organized by wyvern type for easy management and expansion.
 */
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> REGISTER =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SaintsDragons.MOD_ID);

    // ===== LIGHTNING DRAGON =====
    public static final RegistryObject<EntityType<Raevyx>> RAEVYX =
            REGISTER.register("raevyx", () -> EntityType.Builder.m_20704_(Raevyx::new, MobCategory.CREATURE)
                    .m_20699_(3.5F, 3.0F)
                    .m_20702_(64)
                    .m_20717_(1)
                    .m_20712_("raevyx"));

    // ===== STEGONAUT =====
    public static final RegistryObject<EntityType<Stegonaut>> STEGONAUT =
            REGISTER.register("stegonaut", () -> EntityType.Builder.m_20704_(Stegonaut::new, MobCategory.CREATURE)
                    .m_20699_(1.5F, 1.0F)  // Smaller than lightning wyvern, cute little drake!
                    .m_20702_(32)
                    .m_20717_(1)
                    .m_20712_("stegonaut"));

    // ===== AMPHITHERE =====
    public static final RegistryObject<EntityType<Cindervane>> CINDERVANE =
            REGISTER.register("cindervane", () -> EntityType.Builder.m_20704_(Cindervane::new, MobCategory.CREATURE)
                    .m_20699_(4.5F, 6.5F)
                    .m_20702_(48)
                    .m_20717_(1)
                    .m_20712_("cindervane"));

    // ===== RIFT DRAKE =====
    public static final RegistryObject<EntityType<Nulljaw>> NULLJAW =
            REGISTER.register("nulljaw", () -> EntityType.Builder.m_20704_(Nulljaw::new, MobCategory.CREATURE)
                    .m_20699_(4.5F, 5.0F)
                    .m_20702_(48)
                    .m_20717_(1)
                    .m_20712_("nulljaw"));

    // ===== EFFECT ENTITIES =====
    public static final RegistryObject<EntityType<RaevyxLightningChainEntity>> RAEVYX_LIGHTNING_CHAIN =
            REGISTER.register("raevyx_lightning_chain", () -> EntityType.Builder.<RaevyxLightningChainEntity>m_20704_(RaevyxLightningChainEntity::new, MobCategory.MISC)
                    .m_20699_(1.0F, 1.0F)
                    .m_20702_(64)
                    .m_20717_(1)
                    .m_20712_("raevyx_lightning_chain"));

    public static final RegistryObject<EntityType<CindervaneMagmaBlockEntity>> CINDERVANE_MAGMA_BLOCK =
            REGISTER.register("cindervane_magma_block", () -> EntityType.Builder.<CindervaneMagmaBlockEntity>m_20704_(CindervaneMagmaBlockEntity::new, MobCategory.MISC)
                    .m_20699_(0.98F, 0.98F)
                    .m_20702_(32)
                    .m_20717_(1)
                    .m_20719_()
                    .m_20698_()
                    .m_20712_("cindervane_magma_block"));
}
