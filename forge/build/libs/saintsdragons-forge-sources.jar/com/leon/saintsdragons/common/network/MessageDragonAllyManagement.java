package com.leon.saintsdragons.common.network;

import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.handler.DragonAllyManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Network message for managing wyvern allies.
 * Handles adding/removing allies and syncing ally lists.
 */
public class MessageDragonAllyManagement {
    private final int dragonId;
    private final Action action;
    private final String username;
    
    public MessageDragonAllyManagement(int dragonId, Action action, String username) {
        this.dragonId = dragonId;
        this.action = action;
        this.username = username;
    }
    
    public MessageDragonAllyManagement(FriendlyByteBuf buffer) {
        this.dragonId = buffer.readInt();
        this.action = buffer.m_130066_(Action.class);
        this.username = buffer.m_130136_(16);
    }
    
    public void encode(FriendlyByteBuf buffer) {
        buffer.writeInt(dragonId);
        buffer.m_130068_(action);
        buffer.m_130072_(username, 16);
    }
    
    public static void handle(MessageDragonAllyManagement message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;
            
            // Find the wyvern entity
            Entity entity = player.m_9236_().m_6815_(message.dragonId);
            if (!(entity instanceof DragonEntity dragon)) {
                player.m_213846_(Component.m_237115_("saintsdragons.message.dragon_not_found"));
                return;
            }
            
            // Check if player owns the wyvern
            if (!dragon.m_21824_() || !dragon.m_21830_(player)) {
                player.m_213846_(Component.m_237115_("saintsdragons.message.not_dragon_owner"));
                return;
            }
            
            DragonAllyManager allyManager = dragon.allyManager;
            DragonAllyManager.AllyResult result;
            
            switch (message.action) {
                case ADD:
                    result = allyManager.addAlly(message.username);
                    break;
                case REMOVE:
                    result = allyManager.removeAlly(message.username);
                    break;
                default:
                    result = DragonAllyManager.AllyResult.INVALID_USERNAME;
                    break;
            }
            
            // Send result message to player
            Component resultMessage;
            if (result == DragonAllyManager.AllyResult.EASTER_EGG) {
                // Special easter egg messages
                switch (message.username.toLowerCase()) {
                    case "notch":
                        resultMessage = Component.m_237115_("saintsdragons.message.easter_egg.notch");
                        break;
                    case "jeb_":
                        resultMessage = Component.m_237115_("saintsdragons.message.easter_egg.jeb_");
                        break;
                    case "dinnerbone":
                        resultMessage = Component.m_237115_("saintsdragons.message.easter_egg.dinnerbone");
                        break;
                    case "grumm":
                        resultMessage = Component.m_237115_("saintsdragons.message.easter_egg.grumm");
                        break;
                    case "herobrine":
                        resultMessage = Component.m_237115_("saintsdragons.message.easter_egg.herobrine");
                        break;
                    default:
                        resultMessage = Component.m_237115_("saintsdragons.message.ally.easter_egg");
                        break;
                }
            } else {
                resultMessage = Component.m_237110_("saintsdragons.message.ally." + result.name().toLowerCase(), message.username);
            }
            player.m_213846_(resultMessage);

            // Send delta update to client (only the add/remove operation, not entire list)
            // This is much more efficient than sending the entire ally list on every change
            if (result == DragonAllyManager.AllyResult.SUCCESS) {
                boolean isAdd = (message.action == Action.ADD);
                ModNetworkHandler.sendToPlayer(player, new MessageDragonAllyDelta(dragon.m_19879_(), message.username, isAdd));
            }
        });
        context.setPacketHandled(true);
    }
    
    public enum Action {
        ADD,
        REMOVE
    }
}
