package com.leon.saintsdragons.common.item;

import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

/**
 * Item used to bind an Amphithere for portable convenience.
 * Right-click on a tamed amphithere to bind it to this item.
 * While carrying a bound amphithere binder, the player can release the amphithere.
 */
public class CindervaneBinderItem extends Item {
    
    // NBT keys for storing bound dragon data
    private static final String BOUND_DRAGON_UUID = "BoundDragonUUID";
    private static final String BOUND_DRAGON_NAME = "BoundDragonName";
    private static final String BOUND_OWNER_UUID = "BoundOwnerUUID";
    private static final String BOUND_OWNER_NAME = "BoundOwnerName";
    private static final String IS_BOUND = "IsBound";
    
    public CindervaneBinderItem(Properties properties) {
        super(properties);
    }
    
    @Override
    public @NotNull InteractionResult m_6880_(@NotNull ItemStack stack, @NotNull Player player, @NotNull LivingEntity target, @NotNull InteractionHand hand) {
        if (target instanceof Cindervane amphithere) {
            // Check if player owns the amphithere
            if (!amphithere.m_21824_() || !amphithere.m_21830_(player)) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.not_dragon_owner"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Check if amphithere can be captured (not flying, not dying, etc.)
            if (!amphithere.canBeBound()) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.dragon_cannot_be_captured"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Check if binder is already occupied
            if (isBound(stack)) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.binder_already_occupied"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Capture the amphithere into the binder
            ItemStack newStack = captureAmphithere(stack, amphithere, player);
            
            // Replace the item in the player's hand
            if (hand == InteractionHand.MAIN_HAND) {
                player.m_150109_().m_6836_(player.m_150109_().f_35977_, newStack);
            } else {
                player.m_150109_().m_6836_(40, newStack); // Off-hand slot
            }
            
            return InteractionResult.SUCCESS;
        }
        
        return InteractionResult.PASS;
    }
    
    @Override
    public @NotNull InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        
        if (isBound(stack)) {
            return InteractionResultHolder.m_19098_(stack);
        }
        
        return super.m_7203_(level, player, hand);
    }

    @Override
    public @NotNull InteractionResult m_6225_(@NotNull UseOnContext context) {
        Player player = context.m_43723_();
        ItemStack stack = context.m_43722_();
        
        if (player != null && isBound(stack)) {
            return releaseAmphithere(stack, player, context.m_8083_())
                ? InteractionResult.SUCCESS
                : InteractionResult.FAIL;
        }

        return super.m_6225_(context);
    }
    
    /**
     * Capture an amphithere into this binder (Pokeball style)
     */
    private ItemStack captureAmphithere(ItemStack stack, Cindervane amphithere, Player player) {
        // Create a new item stack with the modified data
        ItemStack newStack = stack.m_41777_();
        CompoundTag tag = newStack.m_41784_();
        
        // Store amphithere data
        tag.m_128362_(BOUND_DRAGON_UUID, amphithere.m_20148_());
        tag.m_128359_(BOUND_DRAGON_NAME, amphithere.m_7755_().getString());
        if (amphithere.m_8077_()) {
            Component customName = amphithere.m_7770_();
            if (customName != null) {
                tag.m_128359_("BoundCustomName", net.minecraft.network.chat.Component.Serializer.m_130703_(customName));
            } else {
                tag.m_128473_("BoundCustomName");
            }
        } else {
            tag.m_128473_("BoundCustomName");
        }
        tag.m_128379_(IS_BOUND, true);

        // Store owner data
        LivingEntity owner = amphithere.m_269323_();
        if (owner instanceof Player ownerPlayer) {
            tag.m_128362_(BOUND_OWNER_UUID, ownerPlayer.m_20148_());
            tag.m_128359_(BOUND_OWNER_NAME, ownerPlayer.m_7755_().getString());
        } else {
            tag.m_128473_(BOUND_OWNER_UUID);
            tag.m_128473_(BOUND_OWNER_NAME);
        }

        // Store amphithere's current state
        CompoundTag amphithereData = new CompoundTag();
        amphithere.m_7380_(amphithereData);
        tag.m_128365_("AmphithereData", amphithereData);
        
        // Set the tag on the new stack
        newStack.m_41751_(tag);
        
        // Replace the old stack with the new one in the player's inventory
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            // Find the slot containing the old stack and replace it
            for (int i = 0; i < serverPlayer.m_150109_().m_6643_(); i++) {
                if (serverPlayer.m_150109_().m_8020_(i) == stack) {
                    serverPlayer.m_150109_().m_6836_(i, newStack);
                    break;
                }
            }
        }
        
        // Remove the amphithere from the world
        amphithere.m_142687_(net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);
        
        // Send success message
        player.m_5661_(
            Component.m_237110_("saintsdragons.message.amphithere_captured", amphithere.m_7755_().getString()),
            true
        );
        
        return newStack;
    }
    
    /**
     * Release the bound amphithere from this binder
     */
    private boolean releaseAmphithere(ItemStack stack, Player player, BlockPos pos) {
        CompoundTag tag = stack.m_41783_();
        if (tag == null || !tag.m_128441_(BOUND_DRAGON_UUID)) {
            return false;
        }

        UUID ownerUUID = tag.m_128441_(BOUND_OWNER_UUID) ? tag.m_128342_(BOUND_OWNER_UUID) : null;
        if (ownerUUID != null && !player.m_20148_().equals(ownerUUID)) {
            player.m_5661_(
                Component.m_237115_("saintsdragons.message.cannot_release_others_dragon"),
                true
            );
            return false;
        }

        if (!(player.m_9236_() instanceof ServerLevel serverLevel)) {
            return true;
        }

        String amphithereName = tag.m_128461_(BOUND_DRAGON_NAME);

        Cindervane newAmphithere = new Cindervane(
            ModEntities.CINDERVANE.get(),
            serverLevel
        );

        if (tag.m_128441_("AmphithereData")) {
            CompoundTag amphithereData = tag.m_128469_("AmphithereData");
            newAmphithere.m_7378_(amphithereData);
        }

        newAmphithere.m_6034_(pos.m_123341_() + 0.5, pos.m_123342_() + 1, pos.m_123343_() + 0.5);

        if (ownerUUID != null) {
            Player owner = serverLevel.m_46003_(ownerUUID);
            if (owner != null) {
                newAmphithere.m_21828_(owner);
            }
        } else {
            newAmphithere.m_21828_(player);
        }

        if (tag.m_128441_("BoundCustomName")) {
            net.minecraft.network.chat.Component customName = net.minecraft.network.chat.Component.Serializer.m_130701_(tag.m_128461_("BoundCustomName"));
            if (customName != null) {
                newAmphithere.m_6593_(customName);
            }
        }

        serverLevel.m_7967_(newAmphithere);

        tag.m_128473_(BOUND_DRAGON_UUID);
        tag.m_128473_(BOUND_DRAGON_NAME);
        tag.m_128473_(BOUND_OWNER_UUID);
        tag.m_128473_(BOUND_OWNER_NAME);
        tag.m_128473_("BoundCustomName");
        tag.m_128473_("AmphithereData");
        tag.m_128379_(IS_BOUND, false);

        player.m_5661_(
            Component.m_237110_("saintsdragons.message.cindervane_released", amphithereName),
            true
        );
        return true;
    }
    
    /**
     * Check if this binder has an amphithere bound to it
     */
    public static boolean isBound(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        return tag != null && tag.m_128471_(IS_BOUND);
    }
    
    /**
     * Get the UUID of the bound amphithere
     */
    @Nullable
    public static UUID getBoundAmphithereUUID(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        if (tag != null && tag.m_128441_(BOUND_DRAGON_UUID)) {
            return tag.m_128342_(BOUND_DRAGON_UUID);
        }
        return null;
    }
    
    /**
     * Get the name of the bound amphithere
     */
    @Nullable
    public static String getBoundAmphithereName(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        if (tag != null && tag.m_128441_(BOUND_DRAGON_NAME)) {
            return tag.m_128461_(BOUND_DRAGON_NAME);
        }
        return null;
    }
    
    @Override
    @OnlyIn(Dist.CLIENT)
    public void m_7373_(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> tooltip, @NotNull TooltipFlag flag) {
        tooltip.add(Component.m_237115_("saintsdragons.tooltip.cindervane_binder.description"));
        if (isBound(stack)) {
            String amphithereName = getBoundAmphithereName(stack);
            if (amphithereName != null) {
                tooltip.add(Component.m_237110_("saintsdragons.tooltip.cindervane_binder.bound", amphithereName));
            }
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.cindervane_binder.right_click_to_release"));
        } else {
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.cindervane_binder.empty"));
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.cindervane_binder.right_click_cindervane_to_bind"));
        }
    }

    @Override
    public boolean m_5812_(@NotNull ItemStack stack) {
        return isBound(stack);
    }
}
