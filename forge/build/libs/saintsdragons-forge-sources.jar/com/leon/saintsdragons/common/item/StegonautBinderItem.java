package com.leon.saintsdragons.common.item;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

/**
 * Item used to bind a Primitive Drake for portable resistance buff.
 * Right-click on a tamed primitive drake to bind it to this item.
 * While carrying a bound drake binder, the player gets resistance buff.
 */
public class StegonautBinderItem extends Item {
    
    // NBT keys for storing bound drake data
    private static final String BOUND_DRAGON_UUID = "BoundDragonUUID";
    private static final String BOUND_DRAGON_NAME = "BoundDragonName";
    private static final String BOUND_OWNER_UUID = "BoundOwnerUUID";
    private static final String BOUND_OWNER_NAME = "BoundOwnerName";
    private static final String IS_BOUND = "IsBound";
    
    public StegonautBinderItem(Properties properties) {
        super(properties);
    }
    
    @Override
    public @NotNull InteractionResult m_6880_(@NotNull ItemStack stack, @NotNull Player player, @NotNull LivingEntity target, @NotNull InteractionHand hand) {
        if (target instanceof Stegonaut drake) {
            // Check if player owns the drake
            if (!drake.m_21824_() || !drake.m_21830_(player)) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.not_dragon_owner"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Check if drake can be captured (not playing dead, not sleeping, etc.)
            if (!drake.canBeBound()) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.stegonaut_cannot_be_captured"),
                    true);
                return InteractionResult.FAIL;
            }
            
            // Check if binder is already occupied
            if (isBound(stack)) {
                player.m_5661_(
                    Component.m_237115_("saintsdragons.message.binder_already_occupied"), 
                    true);
                return InteractionResult.FAIL;
            }
            
            // Capture the drake into the binder
            ItemStack newStack = captureDrake(stack, drake, player);
            
            // Replace the item in the player's hand
            if (hand == InteractionHand.MAIN_HAND) {
                player.m_150109_().m_6836_(player.m_150109_().f_35977_, newStack);
            } else {
                player.m_150109_().f_35976_.set(0, newStack);
            }
            
            return InteractionResult.SUCCESS;
        }
        
        return super.m_6880_(stack, player, target, hand);
    }
    
    @Override
    public @NotNull InteractionResult m_6225_(net.minecraft.world.item.context.UseOnContext context) {
        Player player = context.m_43723_();
        ItemStack stack = context.m_43722_();
        
        if (player != null && isBound(stack)) {
            // Release the drake at the clicked location
            return releaseDrake(stack, player, context.m_8083_())
                    ? InteractionResult.SUCCESS
                    : InteractionResult.FAIL;
        }
        
        return super.m_6225_(context);
    }
    
    @Override
    public net.minecraft.world.@NotNull InteractionResultHolder<ItemStack> m_7203_(@NotNull Level level, Player player, @NotNull InteractionHand hand) {
        ItemStack stack = player.m_21120_(hand);
        
        if (isBound(stack)) {
            // Don't allow releasing drakes by right-clicking in air
            // Only allow release via useOn (right-clicking on blocks)
            return net.minecraft.world.InteractionResultHolder.m_19098_(stack);
        }
        
        return super.m_7203_(level, player, hand);
    }
    
    /**
     * Capture a drake into this binder (Pokeball style)
     */
    private ItemStack captureDrake(ItemStack stack, Stegonaut drake, Player player) {
        // Create a new item stack with the modified data
        ItemStack newStack = stack.m_41777_();
        CompoundTag tag = newStack.m_41784_();
        
        // Store drake data
        tag.m_128362_(BOUND_DRAGON_UUID, drake.m_20148_());
        tag.m_128359_(BOUND_DRAGON_NAME, drake.m_7755_().getString());
        if (drake.m_8077_()) {
            tag.m_128359_("BoundCustomName", net.minecraft.network.chat.Component.Serializer.m_130703_(drake.m_7770_()));
        } else {
            tag.m_128473_("BoundCustomName");
        }
        tag.m_128379_(IS_BOUND, true);

        // Store owner data
        LivingEntity owner = drake.m_269323_();
        if (owner instanceof Player ownerPlayer) {
            tag.m_128362_(BOUND_OWNER_UUID, ownerPlayer.m_20148_());
            tag.m_128359_(BOUND_OWNER_NAME, ownerPlayer.m_7755_().getString());
        } else {
            tag.m_128473_(BOUND_OWNER_UUID);
            tag.m_128473_(BOUND_OWNER_NAME);
        }

        // Store drake's current state
        CompoundTag drakeData = new CompoundTag();
        drake.m_7380_(drakeData);
        tag.m_128365_("DrakeData", drakeData);
        
        // Set the tag on the new stack
        newStack.m_41751_(tag);
        
        // Replace the old stack with the new one in the player's inventory
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            // Find the slot containing the old stack and replace it
            for (int i = 0; i < serverPlayer.m_150109_().m_6643_(); i++) {
                if (serverPlayer.m_150109_().m_8020_(i) == stack) {
                    serverPlayer.m_150109_().m_6836_(i, newStack);
                    break;
                }
            }
        }
        
        
        // Remove the drake from the world
        drake.m_142687_(net.minecraft.world.entity.Entity.RemovalReason.DISCARDED);
        
        // Send success message
        player.m_5661_(
            Component.m_237110_("saintsdragons.message.stegonaut_captured", drake.m_7755_().getString()),
            true
        );
        
        return newStack;
    }
    
    /**
     * Release the drake from this binder (Pokeball style)
     */
    private boolean releaseDrake(ItemStack stack, Player player, net.minecraft.core.BlockPos pos) {
        CompoundTag tag = stack.m_41783_();
        if (tag == null || !tag.m_128441_(BOUND_DRAGON_UUID)) {
            return false;
        }
        
        String drakeName = tag.m_128461_(BOUND_DRAGON_NAME);
        CompoundTag drakeData = tag.m_128469_("DrakeData");
        UUID ownerUUID = tag.m_128403_(BOUND_OWNER_UUID) ? tag.m_128342_(BOUND_OWNER_UUID) : null;
        
        if (ownerUUID != null && !player.m_20148_().equals(ownerUUID)) {
            player.m_5661_(
                Component.m_237115_("saintsdragons.message.not_dragon_owner"),
                true
            );
            return false;
        }
        
        if (!(player.m_9236_() instanceof ServerLevel serverLevel)) {
            return true;
        }

        Stegonaut newDrake = new Stegonaut(
            com.leon.saintsdragons.common.registry.ModEntities.STEGONAUT.get(),
            serverLevel
        );

        // Set position
        newDrake.m_6034_(pos.m_123341_() + 0.5, pos.m_123342_() + 1, pos.m_123343_() + 0.5);

        // Restore drake data
        newDrake.m_7378_(drakeData);

        if (ownerUUID != null) {
            newDrake.m_7105_(true);
            newDrake.m_21816_(ownerUUID);
        } else {
            newDrake.m_21828_(player);
        }

        if (tag.m_128441_("BoundCustomName")) {
            net.minecraft.network.chat.Component customName = net.minecraft.network.chat.Component.Serializer.m_130701_(tag.m_128461_("BoundCustomName"));
            if (customName != null) {
                newDrake.m_6593_(customName);
            }
        }

        // Spawn the drake
        serverLevel.m_7967_(newDrake);

        // Clear binder data
        tag.m_128473_(BOUND_DRAGON_UUID);
        tag.m_128473_(BOUND_DRAGON_NAME);
        tag.m_128473_(BOUND_OWNER_UUID);
        tag.m_128473_(BOUND_OWNER_NAME);
        tag.m_128473_("BoundCustomName");
        tag.m_128473_("DrakeData");
        tag.m_128379_(IS_BOUND, false);

        // Send success message
        player.m_5661_(
            Component.m_237110_("saintsdragons.message.stegonaut_released", drakeName),
            true
        );
        return true;
    }
    
    /**
     * Check if this binder has a drake bound to it
     */
    public static boolean isBound(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        return tag != null && tag.m_128471_(IS_BOUND);
    }
    
    /**
     * Get the UUID of the bound drake
     */
    @Nullable
    public static UUID getBoundDrakeUUID(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        if (tag != null && tag.m_128441_(BOUND_DRAGON_UUID)) {
            return tag.m_128342_(BOUND_DRAGON_UUID);
        }
        return null;
    }
    
    /**
     * Get the name of the bound drake
     */
    @Nullable
    public static String getBoundDrakeName(ItemStack stack) {
        CompoundTag tag = stack.m_41783_();
        if (tag != null && tag.m_128441_(BOUND_DRAGON_NAME)) {
            return tag.m_128461_(BOUND_DRAGON_NAME);
        }
        return null;
    }
    
    
    @Override
    @OnlyIn(Dist.CLIENT)
    public void m_7373_(@NotNull ItemStack stack, @Nullable Level level, @NotNull List<Component> tooltip, @NotNull TooltipFlag flag) {
        tooltip.add(Component.m_237115_("saintsdragons.tooltip.stegonaut_binder.description"));
        if (isBound(stack)) {
            String drakeName = getBoundDrakeName(stack);
            if (drakeName != null) {
                tooltip.add(Component.m_237110_("saintsdragons.tooltip.stegonaut_binder.bound", drakeName));
                tooltip.add(Component.m_237115_("saintsdragons.tooltip.stegonaut_binder.bound_desc"));
            }
        } else {
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.stegonaut_binder.empty"));
            tooltip.add(Component.m_237115_("saintsdragons.tooltip.stegonaut_binder.right_click_to_release"));
        }
    }
    
    @Override
    public boolean m_5812_(@NotNull ItemStack stack) {
        // Make bound binders have enchantment glint
        return isBound(stack);
    }
}
