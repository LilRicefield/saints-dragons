package com.leon.saintsdragons.mixin.client;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class EntityRendererMixin {
    
    // Smooth FOV transition state
    @Unique
    private static double saint_sDragons$currentFOVMultiplier = 1.0;
    @Unique
    private static final double FOV_TRANSITION_SPEED = 0.05; // How fast FOV changes (0.01 = very slow, 0.1 = fast)

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void modifyFOV(Camera camera, float partialTicks, boolean useFOVSetting, CallbackInfoReturnable<Double> cir) {
        Minecraft mc = Minecraft.m_91087_();
        double targetFOVMultiplier = 1.0;
        if (mc.f_91074_ != null && (mc.f_91074_.m_20202_() instanceof Raevyx raevyx || mc.f_91074_.m_20202_() instanceof Cindervane amphithere || mc.f_91074_.m_20202_() instanceof Nulljaw nulljaw)) {
            boolean isAccelerating = false;
            boolean isFlying = false;
            double currentSpeed = 0;
            double maxSpeed = 0;
            
            if (mc.f_91074_.m_20202_() instanceof Raevyx raevyx) {
                isAccelerating = raevyx.isAccelerating();
                isFlying = raevyx.m_29443_();
                
                if (isAccelerating) {
                    if (isFlying) {
                        // Flying sprint - use flying speed attributes
                        currentSpeed = raevyx.m_20184_().m_165924_();
                        maxSpeed = raevyx.m_21133_(net.minecraft.world.entity.ai.attributes.Attributes.f_22280_) * 50.0; // SPRINT_MAX_MULT
                    } else {
                        // Ground sprint - use movement speed attributes
                        currentSpeed = raevyx.m_20184_().m_165924_();
                        maxSpeed = raevyx.m_21133_(net.minecraft.world.entity.ai.attributes.Attributes.f_22279_) * 0.7; // Ground sprint multiplier
                    }
                }
            } else if (mc.f_91074_.m_20202_() instanceof Cindervane amphithereDragon) {
                isAccelerating = amphithereDragon.isAccelerating();
                isFlying = amphithereDragon.m_29443_();
                
                if (isAccelerating) {
                    if (isFlying) {
                        // Flying sprint - use flying speed attributes
                        currentSpeed = amphithereDragon.m_20184_().m_165924_();
                        maxSpeed = amphithereDragon.m_21133_(net.minecraft.world.entity.ai.attributes.Attributes.f_22280_) * 20.0; // SPRINT_MAX_MULT
                    } else {
                        // Ground sprint - use movement speed attributes
                        currentSpeed = amphithereDragon.m_20184_().m_165924_();
                        maxSpeed = amphithereDragon.m_21133_(net.minecraft.world.entity.ai.attributes.Attributes.f_22279_) * 0.6; // Ground sprint multiplier
                    }
                }
            } else if (mc.f_91074_.m_20202_() instanceof Nulljaw nulljaw) {
                isAccelerating = nulljaw.isAccelerating();
                isFlying = false; // Rift Drake doesn't fly
                
                if (isAccelerating) {
                    // Ground sprint - use movement speed attributes
                    currentSpeed = nulljaw.m_20184_().m_165924_();
                    maxSpeed = nulljaw.m_21133_(net.minecraft.world.entity.ai.attributes.Attributes.f_22279_) * 1.0; // Ground sprint multiplier
                }
            }
            
            if (isAccelerating && maxSpeed > 0) {
                double speedRatio = Math.min(1.0, currentSpeed / maxSpeed);
                
                // Different FOV multipliers for flying vs ground sprinting
                if (isFlying) {
                    // Flying sprint - dramatic but cinematic FOV effect
                    targetFOVMultiplier = 1.0 + (speedRatio); // Up to 100% wider FOV at max speed
                } else {
                    // Ground sprint - more subtle FOV effect (ground running is already fast enough!)
                    targetFOVMultiplier = 1.0 + (0.15 * speedRatio); // Up to 15% wider FOV at max speed
                }
            }
            
            // Smooth interpolation between current and target FOV multiplier
            double diff = targetFOVMultiplier - saint_sDragons$currentFOVMultiplier;
            if (Math.abs(diff) > 0.001) { // Only interpolate if there's a meaningful difference
                saint_sDragons$currentFOVMultiplier += diff * FOV_TRANSITION_SPEED;
            } else {
                saint_sDragons$currentFOVMultiplier = targetFOVMultiplier; // Snap to target if very close
            }
            
            // Apply the smoothly interpolated FOV multiplier
            double baseFOV = cir.getReturnValue();
            double newFOV = baseFOV * saint_sDragons$currentFOVMultiplier;
            
            cir.setReturnValue(newFOV);
        } else {
            saint_sDragons$currentFOVMultiplier = 1.0;
        }
    }
}