package com.leon.saintsdragons.forge.platform;

import com.leon.saintsdragons.platform.NetworkHelper;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class ForgeNetworkHelper implements NetworkHelper {

    public static final ForgeNetworkHelper INSTANCE = new ForgeNetworkHelper();

    private static final String PROTOCOL_VERSION = "1";
    private SimpleChannel channel;
    private int messageId = 0;
    private final Map<Class<?>, Integer> messageIds = new HashMap<>();

    private ForgeNetworkHelper() {}

    public void init(ResourceLocation channelName) {
        this.channel = NetworkRegistry.newSimpleChannel(
            channelName,
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
        );
    }

    @Override
    public <T> void registerClientToServer(
        Class<T> messageClass,
        BiConsumer<T, FriendlyByteBuf> encoder,
        Function<FriendlyByteBuf, T> decoder,
        BiConsumer<T, ServerPlayer> handler
    ) {
        int id = messageId++;
        messageIds.put(messageClass, id);

        channel.messageBuilder(messageClass, id, NetworkDirection.PLAY_TO_SERVER)
            .encoder(encoder)
            .decoder(decoder)
            .consumerNetworkThread((msg, ctx) -> {
                ctx.get().enqueueWork(() -> {
                    ServerPlayer player = ctx.get().getSender();
                    if (player != null) {
                        handler.accept(msg, player);
                    }
                });
                ctx.get().setPacketHandled(true);
            })
            .add();
    }

    @Override
    public <T> void registerServerToClient(
        Class<T> messageClass,
        BiConsumer<T, FriendlyByteBuf> encoder,
        Function<FriendlyByteBuf, T> decoder,
        BiConsumer<T, Void> handler
    ) {
        int id = messageId++;
        messageIds.put(messageClass, id);

        channel.messageBuilder(messageClass, id, NetworkDirection.PLAY_TO_CLIENT)
            .encoder(encoder)
            .decoder(decoder)
            .consumerNetworkThread((msg, ctx) -> {
                ctx.get().enqueueWork(() -> handler.accept(msg, null));
                ctx.get().setPacketHandled(true);
            })
            .add();
    }

    @Override
    public void sendToServer(Object message) {
        channel.sendToServer(message);
    }

    @Override
    public void sendToPlayer(ServerPlayer player, Object message) {
        channel.send(PacketDistributor.PLAYER.with(() -> player), message);
    }

    @Override
    public void sendToAllTracking(net.minecraft.world.entity.Entity entity, Object message) {
        channel.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity), message);
    }
}
