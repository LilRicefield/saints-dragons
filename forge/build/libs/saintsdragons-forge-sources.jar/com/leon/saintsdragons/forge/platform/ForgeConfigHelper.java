package com.leon.saintsdragons.forge.platform;

import com.leon.saintsdragons.platform.ConfigHelper;

public class 



ForgeConfigHelper implements ConfigHelper {

    public static final ForgeConfigHelper INSTANCE = new ForgeConfigHelper();

    private ForgeConfigHelper() {}

    @Override
    public void registerConfig() {
        // Will implement with existing ForgeConfigSpec
        // For now, placeholder
    }

    @Override
    public <T> T getValue(String path, Class<T> type) {
        // Will implement with existing config values
        // For now, placeholder
        return null;
    }
}
