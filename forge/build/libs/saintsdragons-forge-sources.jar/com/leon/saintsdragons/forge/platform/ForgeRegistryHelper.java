package com.leon.saintsdragons.forge.platform;

import com.leon.saintsdragons.platform.RegistryHelper;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class 


ForgeRegistryHelper implements RegistryHelper {

    public static final ForgeRegistryHelper INSTANCE = new ForgeRegistryHelper();

    private ForgeRegistryHelper() {}

    @Override
    public <T> RegistryWrapper<T> create(ResourceKey<? extends Registry<T>> registry, String modId) {
        return new ForgeRegistryWrapper<>(DeferredRegister.create(registry, modId));
    }

    private static class ForgeRegistryWrapper<T> implements RegistryWrapper<T> {
        private final DeferredRegister<T> deferredRegister;

        public ForgeRegistryWrapper(DeferredRegister<T> deferredRegister) {
            this.deferredRegister = deferredRegister;
        }

        @Override
        public <I extends T> Supplier<I> register(String name, Supplier<I> supplier) {
            RegistryObject<I> registryObject = deferredRegister.register(name, supplier);
            return registryObject;
        }

        @Override
        public void register() {
            IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
            deferredRegister.register(modBus);
        }
    }
}
