package com.leon.saintsdragons.util;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Math utilities for wyvern movement and behavior
 */
public class DragonMathUtil {

    /**
     * Smoothly approach a target value with acceleration/deceleration curves
     */
    public static float approachSmooth(float current, float previous, float desired, float desiredSpeed, float deltaSpeed) {
        float prevSpeed = current - previous;
        desiredSpeed = Math.abs(desiredSpeed);
        desiredSpeed = current < desired ? desiredSpeed : -desiredSpeed;
        float speed = Mth.m_14121_(prevSpeed, desiredSpeed, deltaSpeed);

        // Extra math to make speed smaller when current is close to desired
        float speedApproachReduction = (float) (1.0f - Math.pow(
                Mth.m_14036_(-Math.abs(current - desired) / Math.abs(2 * desiredSpeed / deltaSpeed) + 1.0f, 0, 1), 4
        ));
        speed *= speedApproachReduction;

        return current < desired ?
                Mth.m_14036_(current + speed, current, desired) :
                Mth.m_14036_(current + speed, desired, current);
    }

    public static float approachDegreesSmooth(float current, float previous, float desired, float desiredSpeed, float deltaSpeed) {
        float desiredDifference = Mth.m_14118_(current, desired);
        float previousDifference = Mth.m_14118_(current, previous);
        return approachSmooth(current, current + previousDifference, current + desiredDifference, desiredSpeed, deltaSpeed);
    }

    /**
     * Calculate angle between two entities in degrees
     */
    public static double getAngleBetweenEntities(Entity first, Entity second) {
        return Math.atan2(second.m_20189_() - first.m_20189_(), second.m_20185_() - first.m_20185_()) * (180 / Math.PI) + 90;
    }

    /**
     * Get dot product between entity's facing direction and target
     */
    public static double getDotProductBodyFacingEntity(Entity entity, Entity target) {
        Vec3 vecBetween = target.m_20182_().m_82546_(entity.m_20182_()).m_82541_();
        return vecBetween.m_82526_(Vec3.m_82498_(0, entity.m_146908_()).m_82541_());
    }

    /**
     * Calculate circular position around a target
     */
    public static Vec3 circleEntityPosition(Entity target, float radius, float speed, boolean clockwise, int frame, float offset) {
        int direction = clockwise ? 1 : -1;
        double t = direction * frame * 0.5 * speed / radius + offset;
        return target.m_20182_().m_82520_(radius * Math.cos(t), 0, radius * Math.sin(t));
    }

    /**
     * Get entities nearby with filtering
     */
    public static <T extends Entity> List<T> getEntitiesNearby(Entity entity, Class<T> entityClass, double radius) {
        return entity.m_9236_().m_6443_(entityClass,
                entity.m_20191_().m_82377_(radius, radius, radius),
                e -> e != entity && entity.m_20270_(e) <= radius + e.m_20205_() / 2f);
    }

    /**
     * Get attackable living entities nearby
     */
    public static List<LivingEntity> getAttackableEntitiesNearby(Entity entity, double radius) {
        List<Entity> nearbyEntities = entity.m_9236_().m_45933_(entity,
                entity.m_20191_().m_82377_(radius, radius, radius));

        return nearbyEntities.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(LivingEntity::m_5789_)
                .filter(e -> entity.m_20270_(e) <= radius + e.m_20205_() / 2f)
                .collect(Collectors.toList());
    }


    /**
     * Calculate flight vector towards target with smooth acceleration
     */
    public static Vec3 calculateFlightVector(Entity entity, Vec3 target, double speed, double acceleration) {
        Vec3 direction = target.m_82546_(entity.m_20182_()).m_82541_();
        Vec3 currentVel = entity.m_20184_();
        Vec3 targetVel = direction.m_82490_(speed);

        // Smooth acceleration towards target velocity
        return currentVel.m_82549_(targetVel.m_82546_(currentVel).m_82490_(acceleration));
    }

    /**
     * Apply smooth look rotation towards target
     */
    public static void smoothLookAt(LivingEntity entity, Entity target, float maxYawChange, float maxPitchChange) {
        double dx = target.m_20185_() - entity.m_20185_();
        double dy = target.m_20188_() - entity.m_20188_();
        double dz = target.m_20189_() - entity.m_20189_();

        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float)(Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        float targetPitch = (float)(-(Math.atan2(dy, horizontalDist) * (180.0 / Math.PI)));

        // Use smooth angular approach that eases near the target to reduce jitter
        float currentYaw = entity.m_146908_();
        float prevYaw = entity.f_19859_;
        float newYaw = approachDegreesSmooth(currentYaw, prevYaw, targetYaw, maxYawChange, Math.max(1.0f, maxYawChange * 0.5f));
        entity.m_146922_(newYaw);

        float currentPitch = entity.m_146909_();
        float prevPitch = entity.f_19860_;
        float newPitch = approachDegreesSmooth(currentPitch, prevPitch, targetPitch, maxPitchChange, Math.max(1.0f, maxPitchChange * 0.5f));
        entity.m_146926_(newPitch);
        entity.f_20883_ = entity.m_146908_();
    }

    /**
     * Check if an entity can see another entity (line of sight)
     */
    public static boolean hasLineOfSight(LivingEntity entity, Entity target) {
        if (entity instanceof net.minecraft.world.entity.Mob mob) {
            return mob.m_21574_().m_148306_(target);
        }
        // Fallback: simple distance check if not a Mob
        return entity.m_20270_(target) < Objects.requireNonNull(entity.m_21051_(Attributes.f_22277_)).m_22135_();
    }

    /**
     * Calculate optimal dodge direction from projectile
     */
    public static Vec3 calculateDodgeDirection(Entity entity, Entity projectile) {
        Vec3 projectileVel = new Vec3(
                projectile.m_20185_() - projectile.f_19854_,
                projectile.m_20186_() - projectile.f_19855_,
                projectile.m_20189_() - projectile.f_19856_
        );

        if (projectileVel.m_82556_() < 0.001) {
            return Vec3.f_82478_;
        }

        // Calculate perpendicular dodge direction
        Vec3 lateral = projectileVel.m_82541_().m_82537_(new Vec3(0, 1, 0));
        if (lateral.m_82556_() < 1.0e-6) {
            return Vec3.f_82478_; // Can't dodge straight up/down projectiles effectively
        }

        lateral = lateral.m_82541_();

        // Choose the side that moves away from the projectile's predicted impact
        Vec3 entityPos = entity.m_20182_();
        Vec3 predictedImpact = projectile.m_20182_().m_82549_(projectileVel.m_82490_(20)); // Predict 20 ticks ahead

        Vec3 leftPos = entityPos.m_82549_(lateral);
        Vec3 rightPos = entityPos.m_82549_(lateral.m_82490_(-1));

        // Choose the side further from predicted impact
        if (rightPos.m_82546_(predictedImpact).m_82556_() > leftPos.m_82546_(predictedImpact).m_82556_()) {
            lateral = lateral.m_82490_(-1);
        }

        return lateral;
    }

    /**
     * Apply smooth easing to a value (ease-in-out cubic)
     */
    public static float easeInOutCubic(float t) {
        return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;
    }

    /**
     * Apply smooth easing to a value (ease-out sine)
     */
    public static float easeOutSine(float t) {
        return (float) Math.sin((t * Math.PI) / 2);
    }

    /**
     * Linear interpolation with easing
     */
    public static float lerpSmooth(float start, float end, float progress, EasingFunction easing) {
        float easedProgress = switch (easing) {
            case LINEAR -> progress;
            case EASE_IN_OUT_CUBIC -> easeInOutCubic(progress);
            case EASE_OUT_SINE -> easeOutSine(progress);
        };
        return Mth.m_14179_(easedProgress, start, end);
    }

    public enum EasingFunction {
        LINEAR,
        EASE_IN_OUT_CUBIC,
        EASE_OUT_SINE
    }

    /**
     * Clamp a vector's length to a maximum value
     */
    public static Vec3 clampVectorLength(Vec3 vector, double maxLength) {
        double lengthSq = vector.m_82556_();
        if (lengthSq > maxLength * maxLength) {
            return vector.m_82541_().m_82490_(maxLength);
        }
        return vector;
    }

    /**
     * Add horizontal movement only (preserve Y component)
     */
    public static Vec3 addHorizontalMovement(Vec3 currentVel, Vec3 addedVel) {
        return new Vec3(
                currentVel.f_82479_ + addedVel.f_82479_,
                currentVel.f_82480_,
                currentVel.f_82481_ + addedVel.f_82481_
        );
    }

    /**
     * Calculate repulsion force between entities
     */
    public static Vec3 calculateRepulsionForce(Entity center, Entity target, double radius, double strength) {
        Vec3 direction = target.m_20182_().m_82546_(center.m_20182_());
        double distance = direction.m_82553_();

        if (distance >= radius || distance == 0) {
            return Vec3.f_82478_;
        }

        // Inverse square falloff
        double force = strength * (1.0 - distance / radius) * (1.0 - distance / radius);
        return direction.m_82541_().m_82490_(force);
    }

    /**
     * Create quaternion from XYZ rotation (for rendering)
     */
    public static Quaternionf quatFromRotationXYZ(float x, float y, float z, boolean degrees) {
        if (degrees) {
            x = (float) Math.toRadians(x);
            y = (float) Math.toRadians(y);
            z = (float) Math.toRadians(z);
        }
        return new Quaternionf().rotationXYZ(x, y, z);
    }
    
    /**
     * Clamp altitude within reasonable bounds above ground
     */
    public static double clampAltitude(double currentY, double groundY, double minAbove, double maxAbove) {
        return Mth.m_14008_(currentY, groundY + minAbove, groundY + maxAbove);
    }
    
    /**
     * Calculate yaw error from current entity to target
     */
    public static float yawErrorToTarget(Entity self, Entity target) {
        float wantedYaw = (float) (Math.atan2(target.m_20189_() - self.m_20189_(), target.m_20185_() - self.m_20185_()) * 180 / Math.PI) - 90f;
        return Math.abs(Mth.m_14118_(self.m_146908_(), wantedYaw));
    }
}
