package com.leon.saintsdragons.server.entity.dragons.cindervane.handlers;

import com.leon.saintsdragons.SaintsDragons;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import java.util.List;
import net.minecraft.advancements.Advancement;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Handles all interactions with Amphithere entities
 * Adapted from Lightning Dragon interaction handler
 */
public class CindervaneInteractionHandler {
    private final Cindervane dragon;

    public CindervaneInteractionHandler(Cindervane dragon) {
        this.dragon = dragon;
    }

    /**
     * Main interaction entry point - called from mobInteract
     */
    public InteractionResult handleInteraction(Player player, InteractionHand hand) {
        ItemStack heldItem = player.m_21120_(hand);

        if (!dragon.m_21824_()) {
            return handleUntamedInteraction(player, hand, heldItem);
        } else {
            return handleTamedInteraction(player, hand, heldItem);
        }
    }

    /**
     * Handle interactions with untamed amphitheres (taming)
     */
    private InteractionResult handleUntamedInteraction(Player player, InteractionHand hand, ItemStack heldItem) {
        if (!dragon.m_6898_(heldItem)) {
            return InteractionResult.PASS;
        }

        if (!dragon.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                heldItem.m_41774_(1);
            }

            // Trigger eat animation
            dragon.triggerAnim("actions", "eat");

            if (dragon.m_217043_().m_188503_(5) == 0) {
                dragon.m_21828_(player);
                dragon.m_21573_().m_26573_();
                dragon.m_21839_(true);
                dragon.setCommand(1); // Set command to Sit (1) to match the sitting state
                dragon.m_6710_(null);
                dragon.m_9236_().m_7605_(dragon, (byte) 7);

                triggerTamingAdvancement(player);
            } else {
                dragon.m_9236_().m_7605_(dragon, (byte) 6);
            }
            return InteractionResult.m_19078_(false);
        }

        return InteractionResult.SUCCESS;
    }

    /**
     * Handle interactions with tamed amphitheres (feeding, commands, mounting)
     */
    private InteractionResult handleTamedInteraction(Player player, InteractionHand hand, ItemStack heldItem) {
        boolean isOwner = dragon.m_21830_(player);

        // Owner-only interactions
        if (isOwner) {
            // Handle feeding for healing
            if (dragon.m_6898_(heldItem) && dragon.m_21223_() < dragon.m_21233_()) {
                return handleFeeding(player, heldItem);
            }

            // Handle owner commands - Shift+Right-click cycles through commands
            if (dragon.canOwnerCommand(player) && heldItem.m_41619_() && hand == InteractionHand.MAIN_HAND) {
                return handleCommandCycling(player);
            }
        }

        // Handle mounting - both owner and non-owners can mount
        if (hand == InteractionHand.MAIN_HAND && heldItem.m_41619_() && !player.m_6047_()) {
            return handleMounting(player, isOwner);
        }

        return InteractionResult.PASS;
    }

    /**
     * Handle mounting logic for both owner and passengers
     */
    private InteractionResult handleMounting(Player player, boolean isOwner) {
        var passengers = dragon.m_20197_();

        if (isOwner) {
            // Owner can mount if seat 0 is empty (or no passengers at all)
            if (passengers.isEmpty() && dragon.canOwnerMount(player)) {
                if (!dragon.m_9236_().f_46443_) {
                    dragon.prepareForMounting();
                    player.m_20329_(dragon);
                }
                return InteractionResult.m_19078_(dragon.m_9236_().f_46443_);
            } else if (!passengers.isEmpty() && passengers.get(0) != player) {
                // Owner tried to mount but someone else is in seat 0 (shouldn't happen normally)
                if (!dragon.m_9236_().f_46443_) {
                    player.m_5661_(
                        Component.m_237115_("entity.saintsdragons.cindervane.mount_occupied"),
                        true
                    );
                }
                return InteractionResult.FAIL;
            }
        } else {
            // Non-owner can mount as passenger if:
            // 1. Seat 0 is occupied by the owner
            // 2. Seat 1 is empty (less than 2 passengers)
            // 3. Dragon is not sitting or doing something that would prevent riding

            if (passengers.isEmpty()) {
                // No one is riding - non-owners can't mount without owner
                if (!dragon.m_9236_().f_46443_) {
                    player.m_5661_(
                        Component.m_237115_("entity.saintsdragons.cindervane.passenger_needs_owner"),
                        true
                    );
                }
                return InteractionResult.FAIL;
            }

            if (passengers.size() >= 2) {
                // Both seats are full
                if (!dragon.m_9236_().f_46443_) {
                    player.m_5661_(
                        Component.m_237115_("entity.saintsdragons.cindervane.seats_full"),
                        true
                    );
                }
                return InteractionResult.FAIL;
            }

            // Check if owner is in seat 0
            if (passengers.get(0) instanceof Player firstPlayer && dragon.m_21830_(firstPlayer)) {
                // Owner is driving, non-owner can mount as passenger
                if (!dragon.m_9236_().f_46443_) {
                    player.m_20329_(dragon);
                }
                return InteractionResult.m_19078_(dragon.m_9236_().f_46443_);
            } else {
                // Seat 0 is occupied by non-owner (shouldn't happen, but handle it)
                if (!dragon.m_9236_().f_46443_) {
                    player.m_5661_(
                        Component.m_237115_("entity.saintsdragons.cindervane.passenger_needs_owner"),
                        true
                    );
                }
                return InteractionResult.FAIL;
            }
        }

        return InteractionResult.PASS;
    }

    /**
     * Handle feeding the dragon for healing
     */
    private InteractionResult handleFeeding(Player player, ItemStack food) {
        if (!dragon.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                food.m_41774_(1);
            }

            // Trigger eat animation
            dragon.triggerAnim("actions", "eat");

            float healAmount = 5.0F;
            float newHealth = Math.min(dragon.m_21223_() + healAmount, dragon.m_21233_());
            boolean fullyHealed = newHealth >= dragon.m_21233_();

            dragon.m_5634_(healAmount);
            dragon.m_9236_().m_7605_(dragon, (byte) 7);

            // Send appropriate message
            if (fullyHealed) {
                player.m_5661_(
                    Component.m_237110_("entity.saintsdragons.cindervane.fed", dragon.m_7755_()),
                    true
                );
            } else {
                player.m_5661_(
                    Component.m_237110_("entity.saintsdragons.cindervane.fed_partial", dragon.m_7755_()),
                    true
                );
            }
            return InteractionResult.CONSUME;
        }

        return InteractionResult.m_19078_(true);
    }

    /**
     * Handle command cycling (Follow/Sit/Wander).
     */
    private InteractionResult handleCommandCycling(Player player) {
        // Get current command and cycle to next
        int currentCommand = dragon.getCommand();
        int nextCommand = (currentCommand + 1) % 3; // 0=Follow, 1=Sit, 2=Wander

        // Apply the new command
        dragon.setCommand(nextCommand);
        applyCommandState(nextCommand);

        // Send feedback message to player (action bar), server-side only to avoid duplicates
        if (!dragon.m_9236_().f_46443_) {
            player.m_5661_(
                Component.m_237110_(
                    "entity.saintsdragons.all.command_" + nextCommand,
                    dragon.m_7755_()
                ),
                true
            );
        }

        return InteractionResult.SUCCESS;
    }
    
    /**
     * Apply the command state to the dragon.
     */
    private void applyCommandState(int command) {
        switch (command) {
            case 0: // Follow
                dragon.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
            case 1: // Sit
                dragon.m_21839_(true);
                break;
            case 2: // Wander
                dragon.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
        }
    }

    private void triggerTamingAdvancement(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            var advancement = serverPlayer.f_8924_.m_129889_()
                    .m_136041_(SaintsDragons.rl("tame_cindervane"));
            if (advancement != null) {
                serverPlayer.m_8960_().m_135988_(advancement, "tame_cindervane");
            }
        }
    }
}
