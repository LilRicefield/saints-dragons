package com.leon.saintsdragons.server.entity.dragons.raevyx.handlers;

import com.leon.saintsdragons.SaintsDragons;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.advancements.Advancement;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Handles all player interactions with Lightning Dragons.
 * Extracted from LightningDragonEntity to improve maintainability and reduce class size.
 */
public record RaevyxInteractionHandler(Raevyx wyvern) {
    
    /**
     * Main interaction entry point.
     * Delegates to specific handlers based on wyvern state and interaction type.
     */
    public InteractionResult handleInteraction(Player player, InteractionHand hand) {
        if (wyvern.isDying()) {
            return InteractionResult.PASS;
        }
        
        ItemStack itemstack = player.m_21120_(hand);
        
        if (!wyvern.m_21824_()) {
            return handleUntamedInteraction(player, itemstack);
        } else {
            return handleTamedInteraction(player, itemstack, hand);
        }
    }
    
    /**
     * Handle interactions with untamed dragons (taming attempts).
     */
    private InteractionResult handleUntamedInteraction(Player player, ItemStack itemstack) {
        if (!wyvern.m_6898_(itemstack)) {
            return InteractionResult.PASS;
        }
        
        // Taming logic must be server-only to avoid client-only visual state changes
        if (!wyvern.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                itemstack.m_41774_(1);
            }

            // Trigger eat animation
            wyvern.triggerAnim("action", "eat");

            if (wyvern.m_217043_().m_188503_(10) == 0) {
                // Successful taming
                wyvern.m_21828_(player);
                wyvern.m_21839_(true);
                wyvern.setCommandManual(1); // Set command to Sit (1) to match the sitting state
                wyvern.m_9236_().m_7605_(wyvern, (byte) 7);
                
                // Trigger advancement for taming Lightning Dragon
                triggerTamingAdvancement(player);
            } else {
                // Failed taming attempt
                wyvern.m_9236_().m_7605_(wyvern, (byte) 6);
            }
        }
        
        return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
    }
    
    /**
     * Handle interactions with tamed dragons (feeding, commands, mounting).
     */
    private InteractionResult handleTamedInteraction(Player player, ItemStack itemstack, InteractionHand hand) {
        boolean isOwner = player.equals(wyvern.m_269323_());

        // Handle feeding for healing
        if (wyvern.m_6898_(itemstack)) {
            if (player.m_6047_() && isOwner) {
                return handleBreeding(player, itemstack);
            }
            return handleFeeding(player, itemstack);
        }
        
        // Handle owner commands and mounting
        if (isOwner) {
            boolean isSleeping = wyvern.m_5803_() || wyvern.isSleepTransitioning();
            // Command cycling - Shift+Right-click cycles through commands
            if (canOwnerCommand(player) && itemstack.m_41619_() && hand == InteractionHand.MAIN_HAND) {
                if (isSleeping) {
                    if (!wyvern.m_9236_().f_46443_ && player instanceof ServerPlayer serverPlayer) {
                        serverPlayer.m_5661_(
                            Component.m_237110_("entity.saintsdragons.raevyx.sleeping", wyvern.m_7755_()),
                            true
                        );
                    }
                    return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
                }
                return handleCommandCycling(player);
            }
            // Mounting - Right-click without shift
            else if (!player.m_6047_() && itemstack.m_41619_() && hand == InteractionHand.MAIN_HAND && canOwnerMount(player)) {
                return handleMounting(player);
            }
        }
        
        return InteractionResult.PASS;
    }
    
    /**
     * Handle initiating breeding when crouching with food.
     */
    private InteractionResult handleBreeding(Player player, ItemStack itemstack) {
        boolean client = wyvern.m_9236_().f_46443_;

        if (wyvern.m_6162_()) {
            sendStatusMessage(player, "entity.saintsdragons.raevyx.breeding_too_young");
            return InteractionResult.m_19078_(client);
        }

        if (wyvern.m_146764_() != 0) { // still on cooldown from previous breeding
            sendStatusMessage(player, "entity.saintsdragons.raevyx.breeding_cooling_down");
            return InteractionResult.m_19078_(client);
        }

        if (wyvern.m_27593_()) {
            sendStatusMessage(player, "entity.saintsdragons.raevyx.breeding_already_ready");
            return InteractionResult.m_19078_(client);
        }

        if (!client) {
            if (!player.m_150110_().f_35937_) {
                itemstack.m_41774_(1);
            }

            // Trigger eat animation
            wyvern.triggerAnim("action", "eat");

            wyvern.m_27595_(player);
            sendStatusMessage(player, "entity.saintsdragons.raevyx.breeding_ready");
        }

        return InteractionResult.m_19078_(client);
    }
    
    /**
     * Handle feeding tamed dragons for healing or growth.
     */
    private InteractionResult handleFeeding(Player player, ItemStack itemstack) {
        if (!wyvern.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                itemstack.m_41774_(1);
            }

            // Trigger eat animation
            wyvern.triggerAnim("action", "eat");

            // Babies: speed up growth instead of healing
            if (wyvern.m_6162_()) {
                // Age baby by a fixed amount per feeding (same as vanilla animals)
                // 10% of base growth time = 2400 ticks = 2 minutes saved per fish
                int currentAge = wyvern.m_146764_();
                int newAge = Math.min(0, currentAge + 2400); // Cap at 0 (adult)
                wyvern.m_146762_(newAge);

                // Play eating sound and particles
                wyvern.m_9236_().m_7605_(wyvern, (byte) 6); // Eating sound
                wyvern.m_9236_().m_7605_(wyvern, (byte) 7); // Hearts particles

                // Send feedback message with remaining time
                if (player instanceof ServerPlayer serverPlayer) {
                    int remainingTicks = Math.abs(newAge);
                    int remainingMinutes = remainingTicks / 1200; // 1200 ticks = 1 minute
                    String messageKey = (newAge == 0)
                        ? "entity.saintsdragons.raevyx.baby_grown"
                        : "entity.saintsdragons.raevyx.baby_fed";
                    serverPlayer.m_5661_(
                        Component.m_237110_(messageKey, wyvern.m_7755_()),
                        true
                    );
                }
            } else {
                // Adults: heal when fed
                float healAmount = 10.0f; // Heal 5 hearts per fish
                float oldHealth = wyvern.m_21223_();
                float newHealth = Math.min(oldHealth + healAmount, wyvern.m_21233_());
                wyvern.m_21153_(newHealth);

                // Play eating sound and particles
                wyvern.m_9236_().m_7605_(wyvern, (byte) 6); // Eating sound
                wyvern.m_9236_().m_7605_(wyvern, (byte) 7); // Hearts particles

                // Send appropriate feedback message
                sendFeedingMessage(player, newHealth);
            }
        }

        return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
    }
    
    /**
     * Handle command cycling (Follow/Sit/Wander).
     */
    private InteractionResult handleCommandCycling(Player player) {
        // Prevent command changes during sit transitions (sitting down or standing up)
        boolean isTransitioning = wyvern.isInSitTransition();

        if (isTransitioning) {
            // Dragon is in the middle of sitting down or standing up - ignore command spam
            if (!wyvern.m_9236_().f_46443_ && player instanceof ServerPlayer serverPlayer) {
                // Determine which transition is happening
                boolean sittingDown = wyvern.isSittingDownAnimation();
                String messageKey = sittingDown
                    ? "entity.saintsdragons.raevyx.sitting_down"
                    : "entity.saintsdragons.raevyx.standing_up";

                serverPlayer.m_5661_(
                    Component.m_237110_(messageKey, wyvern.m_7755_()),
                    true
                );
            }
            return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
        }

        // Get current command and cycle to next
        int currentCommand = wyvern.getCommand();
        int nextCommand = (currentCommand + 1) % 3; // 0=Follow, 1=Sit, 2=Wander

        // Apply the new command
        wyvern.setCommandManual(nextCommand);
        applyCommandState(nextCommand);

        // Send feedback message to player (action bar), server-side only to avoid duplicates
        if (!wyvern.m_9236_().f_46443_) {
            player.m_5661_(
                Component.m_237110_(
                    "entity.saintsdragons.all.command_" + nextCommand,
                        wyvern.m_7755_()
                ),
                true
            );
        }

        return InteractionResult.SUCCESS;
    }
    
    /**
     * Apply the command state to the wyvern.
     */
    private void applyCommandState(int command) {
        switch (command) {
            case 0: // Follow
                wyvern.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
            case 1: // Sit
                wyvern.m_21839_(true);
                break;
            case 2: // Wander
                wyvern.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
        }
    }
    
    private void sendStatusMessage(Player player, String key) {
        if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.m_5661_(Component.m_237110_(key, wyvern.m_7755_()), true);
        }
    }
    
    /**
     * Handle mounting the wyvern.
     */
    private InteractionResult handleMounting(Player player) {
        if (wyvern.m_20160_()) {
            return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
        }
        
        // Force the wyvern to stand if sitting
        if (wyvern.m_21827_()) {
            wyvern.m_21839_(false);
        }
        
        // Wake up immediately when mounting (bypass transitions/animations)
        if (wyvern.m_5803_() || wyvern.isSleepTransitioning()) {
            wyvern.wakeUpImmediately();
            wyvern.suppressSleep(300);
        }
        
        // Clear all combat and AI states when mounting
        wyvern.clearAllStatesForMounting();
        
        // Start riding
        if (player.m_20329_(wyvern)) {
            // Play excited sound when mounting
            wyvern.playExcitedSound();
            return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
        }
        
        return InteractionResult.m_19078_(wyvern.m_9236_().f_46443_);
    }
    
    /**
     * Trigger the taming advancement for the player.
     * Awards different advancements based on dragon gender.
     */
    private void triggerTamingAdvancement(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            if (wyvern.isFemale()) {
                // Female-specific advancement
                var femaleAdvancement = serverPlayer.f_8924_.m_129889_()
                    .m_136041_(SaintsDragons.rl("tame_raevyx_female"));
                if (femaleAdvancement != null) {
                    serverPlayer.m_8960_().m_135988_(femaleAdvancement, "tame_raevyx_female");
                }
            } else {
                // Male-specific advancement
                var advancement = serverPlayer.f_8924_.m_129889_()
                    .m_136041_(SaintsDragons.rl("tame_raevyx"));
                if (advancement != null) {
                    serverPlayer.m_8960_().m_135988_(advancement, "tame_raevyx");
                }
            }
        }
    }
    
    /**
     * Send appropriate feeding message based on healing result.
     */
    private void sendFeedingMessage(Player player, float newHealth) {
        if (player instanceof ServerPlayer serverPlayer) {
            String messageKey = (newHealth >= wyvern.m_21233_())
                ? "entity.saintsdragons.raevyx.fed"
                : "entity.saintsdragons.raevyx.fed_partial";
                
            serverPlayer.m_5661_(
                Component.m_237110_(messageKey, wyvern.m_7755_()),
                true
            );
        }
    }
    
    /**
     * Check if the player can command the wyvern (owner check).
     */
    private boolean canOwnerCommand(Player player) {
        return wyvern.canOwnerCommand(player);
    }
    
    /**
     * Check if the player can mount the wyvern (owner check).
     */
    private boolean canOwnerMount(Player player) {
        return wyvern.canOwnerMount(player);
    }
}
