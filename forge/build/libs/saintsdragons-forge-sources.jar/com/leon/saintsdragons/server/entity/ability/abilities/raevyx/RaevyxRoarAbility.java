package com.leon.saintsdragons.server.entity.ability.abilities.raevyx;

import com.leon.saintsdragons.common.particle.raevyx.RaevyxLightningArcData;
import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.*;

/**
 * Simple one-shot roar ability: plays a roar vocal and triggers the matching
 * action animation. No damage/effects here; purely audiovisual.
 */
public class RaevyxRoarAbility extends DragonAbility<Raevyx> {

    // Brief startup to sync with animation pose, a short active window
    // so the ability keeps itself alive while the clip plays, then recover.
    private static final DragonAbilitySection[] TRACK = new DragonAbilitySection[] {
            new AbilitySectionDuration(AbilitySectionType.STARTUP, 6),
            new AbilitySectionDuration(AbilitySectionType.ACTIVE, 28),
            new AbilitySectionDuration(AbilitySectionType.RECOVERY, 12)
    };

    private boolean roarQueued = false;
    private static final int ROAR_DELAY_TICKS = 3;   // ~0.15s (closest to 0.17s at 20 TPS)
    private static final int ROAR_TOTAL_TICKS = 69;  // ~3.45s (animation length ~3.4167s)
    private int strikesLeft = 0;
    private int strikeCooldown = 0;
    private java.util.List<Integer> targetIds = java.util.Collections.emptyList();
    private int targetCursor = 0;

    public RaevyxRoarAbility(DragonAbilityType<Raevyx, RaevyxRoarAbility> type, Raevyx user) {
        super(type, user, TRACK, 40);
    }

    @Override
    protected void beginSection(DragonAbilitySection section) {
        if (section == null) return;
        if (section.sectionType == AbilitySectionType.STARTUP) {
            // Choose variant based on flight state
            boolean flying = getUser().m_29443_();
            String trigger = flying ? "roar_air" : "roar_ground";
            // Trigger the action animation immediately
            getUser().triggerAnim("action", trigger);
            // Queue the roar sound slightly delayed to sync with mouth opening
            roarQueued = true;
            // Screen shake is now handled by the animation predicate
            // Lock takeoff only on ground, but allow running and other controls.
            // While flying, allow normal controls (including ascend/descend) during roar.
            if (!getUser().m_29443_()) {
                getUser().lockTakeoff(ROAR_TOTAL_TICKS);
            }
            // Preselect targets and number of strikes
            selectLightningTargets();
            // If multiple targets, cover more with extra strikes; else 2-3 strikes on single target
            int count = targetIds.size();
            boolean isSupercharged = getUser().isSupercharged();
            
            if (count > 1) {
                strikesLeft = Math.min(6, Math.max(3, count * 2));
            } else {
                strikesLeft = 2 + getUser().m_217043_().m_188503_(2); // 2-3 strikes
            }
            
            // Double the strikes when supercharged
            if (isSupercharged) {
                strikesLeft *= 2;
            }
            
            strikeCooldown = 0; // strike asap when ACTIVE begins
        }
    }

    @Override
    public void tickUsing() {
        var section = getCurrentSection();
        if (section == null) return;

        // Play the roar sound after a tiny delay from animation start
        if (section.sectionType == AbilitySectionType.STARTUP && roarQueued) {
            if (getTicksInSection() >= ROAR_DELAY_TICKS && !getUser().m_9236_().f_46443_) {
                // Play only the sound (avoid retriggering the animation)
                var dragon = getUser();
                float pitch = 0.9f + dragon.m_217043_().m_188501_() * 0.15f;
                dragon.m_5496_(com.leon.saintsdragons.common.registry.ModSounds.RAEVYX_ROAR.get(), 1.4f, pitch);
                roarQueued = false;
            }
        }

        // Continuously trigger screen shake during the entire ability
        if (!getUser().m_9236_().f_46443_) {
            getUser().triggerScreenShake(1.0F); // Reduced intensity for Roar
        }

        // During ACTIVE section, spawn lightning strikes at the selected target
        if (section.sectionType == AbilitySectionType.ACTIVE && strikesLeft > 0 && !getUser().m_9236_().f_46443_) {
            if (strikeCooldown > 0) {
                strikeCooldown--;
            } else {
                spawnLightningStrike();
                strikesLeft--;
                strikeCooldown = 6 + getUser().m_217043_().m_188503_(6); // 0.3s to 0.6s between strikes
            }
        }
    }

    private void selectLightningTargets() {
        Raevyx dragon = getUser();
        net.minecraft.world.entity.LivingEntity rider = dragon.m_6688_();

        java.util.Set<Integer> ids = new java.util.LinkedHashSet<>();
        if (dragon.m_9236_() instanceof net.minecraft.server.level.ServerLevel server) {
            var box = dragon.m_20191_().m_82400_(24.0);
            var chasers = server.m_6443_(net.minecraft.world.entity.Mob.class, box, m -> {
                var t = m.m_5448_();
                return m.m_6084_() && (t == dragon || (rider != null && t == rider));
            });
            // Sort by distance ascending
            chasers.sort(java.util.Comparator.comparingDouble(m -> m.m_20280_(dragon)));
            for (var m : chasers) ids.add(m.m_19879_());
        }

        // Add recent aggro and current target as fallbacks
        if (dragon.m_9236_() instanceof net.minecraft.server.level.ServerLevel) {
            java.util.List<net.minecraft.world.entity.LivingEntity> recent = dragon.getRecentAggro();
            recent.sort(java.util.Comparator.comparingDouble(e -> e.m_20280_(dragon)));
            for (var le : recent) if (le != null && le.m_6084_()) ids.add(le.m_19879_());
            var ct = dragon.m_5448_();
            if (ct != null && ct.m_6084_()) ids.add(ct.m_19879_());
        }

        // Cap list size for performance
        this.targetIds = new java.util.ArrayList<>();
        int added = 0;
        for (Integer id : ids) {
            this.targetIds.add(id);
            if (++added >= 6) break; // up to 6 targets
        }
        this.targetCursor = 0;
    }

    private void spawnLightningStrike() {
        Raevyx dragon = getUser();
        if (!(dragon.m_9236_() instanceof net.minecraft.server.level.ServerLevel server)) return;
        net.minecraft.world.entity.LivingEntity target = nextValidTarget(server);
        if (target == null) return;

        double ox = (dragon.m_217043_().m_188500_() - 0.5) * 2.0; // slight scatter
        double oz = (dragon.m_217043_().m_188500_() - 0.5) * 2.0;
        double x = target.m_20185_() + ox;
        double z = target.m_20189_() + oz;
        double y = target.m_20186_();

        // Spawn the vanilla lightning bolt entity for visuals + damage
        var bolt = net.minecraft.world.entity.EntityType.f_20465_.m_20615_(server);
        if (bolt != null) {
            bolt.m_6027_(x, y, z);
            var owner = dragon.m_269323_();
            if (owner instanceof net.minecraft.server.level.ServerPlayer sp) {
                bolt.m_20879_(sp);
            }
            server.m_7967_(bolt);
        }

        // Electrocute visuals: spawn several short arcs around the target itself
        spawnElectrocuteArcs(server, target);
        // Apply a brief stun-like debuff to the struck target
        applyStun(target); // ~1.5s
    }


    private void spawnElectrocuteArcs(ServerLevel server, net.minecraft.world.entity.LivingEntity target) {
        Raevyx dragon = getUser();
        java.util.Random rnd = new java.util.Random(dragon.m_217043_().m_188505_());
        boolean female = dragon.isFemale();
        Vec3 center = target.m_20182_().m_82520_(0, target.m_20206_() * 0.5, 0);
        double radius = Math.max(target.m_20191_().m_82362_(), target.m_20191_().m_82385_()) * 0.6;
        int count = 6 + dragon.m_217043_().m_188503_(5); // 6-10 short arcs
        for (int i = 0; i < count; i++) {
            // Pick two random directions on a sphere and radii within the body radius
            Vec3 a = randomUnit(rnd).m_82490_(radius * (0.4 + rnd.nextDouble() * 0.6));
            Vec3 b = randomUnit(rnd).m_82490_(radius * (0.4 + rnd.nextDouble() * 0.6));
            Vec3 from = center.m_82549_(a);
            Vec3 to = center.m_82549_(b);
            spawnRoarArc(server, from, to, female);
        }
    }

    private void spawnRoarArc(ServerLevel server, Vec3 from, Vec3 to, boolean female) {
        // Spawn simpler lightning arc impact effects (less layered)
        Vec3 delta = to.m_82546_(from);
        int steps = Math.max(2, (int) (delta.m_82553_() * 4)); // Fewer steps
        Vec3 step = delta.m_82490_(1.0 / steps);
        Vec3 pos = from;
        Vec3 dir = step.m_82541_();
        float size = 0.8f; // Smaller base size
        
        // Spawn single particle at each position (no layering)
        for (int i = 0; i <= steps; i++) {
            server.m_8767_(new RaevyxLightningArcData(size, female),
                    pos.f_82479_, pos.f_82480_, pos.f_82481_,
                    1, dir.f_82479_, dir.f_82480_, dir.f_82481_, 0.0);
            pos = pos.m_82549_(step);
        }
    }

    private static Vec3 randomUnit(java.util.Random rnd) {
        // Uniform random unit vector
        double u = rnd.nextDouble();
        double v = rnd.nextDouble();
        double theta = 2 * Math.PI * u;
        double z = 2 * v - 1; // [-1,1]
        double r = Math.sqrt(1 - z * z);
        return new Vec3(r * Math.cos(theta), z, r * Math.sin(theta));
    }

private static void applyStun(net.minecraft.world.entity.LivingEntity target) {
    final int durationTicks = 30; // ~1.5s
        // Movement slowdown (amplifier 5 ≈ -73% speed), brief weakness to sell stun
        target.m_7292_(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.f_19597_, durationTicks, 5, false, true));
        target.m_7292_(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.f_19613_, durationTicks, 0, false, true));
        // Optional: mild blindness to disorient
        target.m_7292_(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.f_19610_, Math.min(durationTicks, 20), 0, false, true));
    }

    private net.minecraft.world.entity.LivingEntity nextValidTarget(net.minecraft.server.level.ServerLevel server) {
        // Cycle through list to find a live target
        int n = targetIds != null ? targetIds.size() : 0;
        for (int i = 0; i < n; i++) {
            int idx = (targetCursor + i) % n;
            net.minecraft.world.entity.Entity e = server.m_6815_(targetIds.get(idx));
            if (e instanceof net.minecraft.world.entity.LivingEntity le && le.m_6084_()) {
                targetCursor = (idx + 1) % n;
                return le;
            }
        }
        return null;
    }
}
