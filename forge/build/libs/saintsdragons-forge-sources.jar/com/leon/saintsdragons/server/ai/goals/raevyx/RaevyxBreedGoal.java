package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;

/**
 * Custom breed goal for Raevyx dragons that handles their unique requirements.
 * Based on vanilla BreedGoal but adapted for flying tamed dragons.
 */
public class RaevyxBreedGoal extends Goal {
    private static final TargetingConditions PARTNER_TARGETING = TargetingConditions.m_148353_().m_26883_(8.0D).m_148355_();
    private final Raevyx dragon;
    private final Level level;
    private final double speedModifier;
    @Nullable
    private Raevyx partner;
    private int loveTime;

    public RaevyxBreedGoal(Raevyx dragon, double speedModifier) {
        this.dragon = dragon;
        this.level = dragon.m_9236_();
        this.speedModifier = speedModifier;
        this.m_7021_(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        // Don't breed if not in love
        if (!this.dragon.m_27593_()) {
            return false;
        }
        // Don't breed while flying
        if (this.dragon.m_29443_()) {
            return false;
        }
        // Don't breed while sitting
        if (this.dragon.m_21827_()) {
            return false;
        }
        // Find a partner
        this.partner = this.findMate();
        return this.partner != null;
    }

    @Override
    public boolean m_8045_() {
        return this.partner.m_6084_()
            && this.partner.m_27593_()
            && this.loveTime < 60
            && !this.dragon.m_29443_()
            && !this.dragon.m_21827_();
    }

    @Override
    public void m_8041_() {
        this.partner = null;
        this.loveTime = 0;
    }

    @Override
    public void m_8037_() {
        this.dragon.m_21563_().m_24960_(this.partner, 10.0F, (float)this.dragon.m_8132_());

        // Move towards partner if on ground
        if (!this.dragon.m_29443_()) {
            this.dragon.m_21573_().m_5624_(this.partner, this.speedModifier);
        }

        ++this.loveTime;

        // Breed when close enough - dragons are large, so use bigger radius
        if (this.loveTime >= 60 && this.dragon.m_20280_(this.partner) < 600.0D) {
            this.breed();
        }
    }

    @Nullable
    private Raevyx findMate() {
        List<Raevyx> list = this.level.m_45971_(
            Raevyx.class,
            PARTNER_TARGETING,
            this.dragon,
            this.dragon.m_20191_().m_82400_(8.0D)
        );

        double closestDist = Double.MAX_VALUE;
        Raevyx closestMate = null;

        for (Raevyx candidate : list) {
            if (this.dragon.m_7848_(candidate)) {
                double dist = this.dragon.m_20280_(candidate);
                if (dist < closestDist) {
                    closestMate = candidate;
                    closestDist = dist;
                }
            }
        }

        return closestMate;
    }

    private void breed() {
        ServerLevel serverlevel = (ServerLevel)this.level;
        Raevyx baby = (Raevyx) this.dragon.m_142606_(serverlevel, this.partner);

        if (baby == null) {
            return;
        }

        // Reset love state
        this.dragon.m_27594_();
        this.partner.m_27594_();

        // Set baby position between parents
        baby.m_6863_(true);
        baby.m_7678_(
            (this.dragon.m_20185_() + this.partner.m_20185_()) / 2.0D,
            this.dragon.m_20186_(),
            (this.dragon.m_20189_() + this.partner.m_20189_()) / 2.0D,
            0.0F, 0.0F
        );

        // Add baby to world
        serverlevel.m_7967_(baby);

        // Spawn experience and trigger advancements
        this.level.m_7605_(this.dragon, (byte)18);
        if (this.level.m_46469_().m_46207_(net.minecraft.world.level.GameRules.f_46135_)) {
            this.level.m_7967_(new ExperienceOrb(
                this.level,
                this.dragon.m_20185_(),
                this.dragon.m_20186_(),
                this.dragon.m_20189_(),
                this.dragon.m_217043_().m_188503_(7) + 1
            ));
        }

        // Trigger advancement for breeding
        ServerPlayer serverplayer = this.dragon.m_27592_();
        if (serverplayer == null && this.partner.m_27592_() != null) {
            serverplayer = this.partner.m_27592_();
        }

        if (serverplayer != null) {
            serverplayer.m_36220_(Stats.f_12937_);
            CriteriaTriggers.f_10581_.m_147278_(serverplayer, this.dragon, this.partner, baby);
        }
    }
}
