package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

/**
 * Sleep goal for Raevyx - ONLY for tamed dragons when owner sleeps.
 * Wild dragons use RaevyxRestGoal for ambient resting behavior instead.
 */
public class RaevyxSleepGoal extends Goal {

    private final Raevyx wyvern;
    private int retryCooldown;

    public RaevyxSleepGoal(Raevyx wyvern) {
        this.wyvern = wyvern;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (retryCooldown > 0) retryCooldown--;
        if (retryCooldown > 0) return false;
        if (wyvern.isSleepLocked()) return false;
        if (!wyvern.canSleepNow() || wyvern.isSleepSuppressed()) return false;
        if (wyvern.m_20072_() || wyvern.m_20077_()) return false;
        if (wyvern.isDying() || wyvern.m_20160_() || wyvern.m_5448_() != null || wyvern.m_5912_()) return false;
        if (wyvern.m_9236_().m_46470_()) return false;

        // ONLY tamed dragons sleep (when owner sleeps). Wild dragons use RestGoal instead.
        return wyvern.m_21824_() && ownerAsleep();
    }

    @Override
    public boolean m_8045_() {
        return wyvern.isSleepLocked();
    }

    @Override
    public void m_8056_() {
        wyvern.startSleepEnter();
    }

    @Override
    public void m_8037_() {
        if (wyvern.m_9236_().f_46443_) return;
        if (wyvern.isSleepLocked() && !shouldRemainAsleep()) {
            if (!wyvern.isSleepTransitioning()) {
                wyvern.startSleepExit();
            }
        }
    }

    @Override
    public void m_8041_() {
        if (!wyvern.isSleepLocked()) {
            retryCooldown = 100;
        }
    }

    @Override
    public boolean m_6767_() {
        return false;
    }

    private boolean ownerAsleep() {
        LivingEntity owner = wyvern.m_269323_();
        if (!(owner instanceof Player player)) {
            return false;
        }
        if (!player.m_5803_() || !player.m_6084_()) {
            return false;
        }
        if (player.m_9236_() != wyvern.m_9236_()) {
            return false;
        }
        return true;
    }

    private boolean shouldRemainAsleep() {
        // Only tamed dragons sleep, so only check owner status
        return ownerAsleep();
    }
}
