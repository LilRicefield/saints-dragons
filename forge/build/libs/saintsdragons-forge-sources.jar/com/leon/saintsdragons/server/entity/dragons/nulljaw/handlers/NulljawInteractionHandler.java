package com.leon.saintsdragons.server.entity.dragons.nulljaw.handlers;

import com.leon.saintsdragons.SaintsDragons;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.advancements.Advancement;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Handles all player interactions with Rift Drakes.
 * Extracted from RiftDrakeEntity to improve maintainability and reduce class size.
 */
public record NulljawInteractionHandler(Nulljaw drake) {

    public InteractionResult handleInteraction(Player player, InteractionHand hand) {
        ItemStack heldItem = player.m_21120_(hand);

        if (!drake.m_21824_()) {
            return handleUntamedInteraction(player, hand, heldItem);
        } else {
            return handleTamedInteraction(player, hand, heldItem);
        }
    }

    private InteractionResult handleTamedInteraction(Player player, InteractionHand hand, ItemStack heldItem) {
        if (!drake.m_21830_(player)) {
            return InteractionResult.PASS;
        }

        // Handle feeding for healing
        if (drake.m_6898_(heldItem) && drake.m_21223_() < drake.m_21233_()) {
            return handleFeeding(player, heldItem);
        }

        // Handle owner commands - Shift+Right-click cycles through commands
        if (drake.canOwnerCommand(player) && heldItem.m_41619_() && hand == InteractionHand.MAIN_HAND) {
            return handleCommandCycling(player);
        }

        // Handle mounting
        if (hand == InteractionHand.MAIN_HAND && heldItem.m_41619_() && !player.m_6047_()) {
            if (drake.canOwnerMount(player) && !drake.m_20160_()) {
                if (!drake.m_9236_().f_46443_) {
                    if (drake.m_21827_()) {
                        drake.m_21839_(false);
                    }
                    drake.m_6710_(null);
                    player.m_20329_(drake);
                }
                return InteractionResult.m_19078_(drake.m_9236_().f_46443_);
            }
        }
        return InteractionResult.PASS;
    }

    private InteractionResult handleFeeding(Player player, ItemStack food) {
        if (!drake.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                food.m_41774_(1);
            }

            // Trigger eat animation
            drake.triggerAnim("action", "eat");

            float healAmount = 5.0F;
            float newHealth = Math.min(drake.m_21223_() + healAmount, drake.m_21233_());
            boolean fullyHealed = newHealth >= drake.m_21233_();

            drake.m_5634_(healAmount);
            drake.m_9236_().m_7605_(drake, (byte) 7);

            // Send appropriate message
            if (fullyHealed) {
                player.m_5661_(
                        Component.m_237110_("entity.saintsdragons.nulljaw.fed", drake.m_7755_()),
                        true
                );
            } else {
                player.m_5661_(
                        Component.m_237110_("entity.saintsdragons.nulljaw.fed_partial", drake.m_7755_()),
                        true
                );
            }
        }

        return InteractionResult.m_19078_(drake.m_9236_().f_46443_);
    }
    
    /**
     * Handle interactions with untamed Rift Drakes (taming attempts).
     */
    private InteractionResult handleUntamedInteraction(Player player, InteractionHand hand, ItemStack itemstack) {
        if (!drake.m_6898_(itemstack)) {
            return InteractionResult.PASS;
        }
        
        // Taming logic must be server-only to avoid client-only visual state changes
        if (!drake.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                itemstack.m_41774_(1);
            }

            // Trigger eat animation
            drake.triggerAnim("action", "eat");

            // Rift Drakes have a 1 in 8 chance of taming (easier than Lightning Dragons)
            if (drake.m_217043_().m_188503_(8) == 0) {
                // Successful taming
                drake.m_21828_(player);
                drake.m_21839_(true);
                drake.setCommand(1); // Set command to Sit (1) to match the sitting state
                drake.m_9236_().m_7605_(drake, (byte) 7); // Success particles
                
                // Trigger advancement for taming Rift Drake
                triggerTamingAdvancement(player);
            } else {
                // Failed taming attempt
                drake.m_9236_().m_7605_(drake, (byte) 6); // Smoke particles
            }
        }
        
        return InteractionResult.m_19078_(drake.m_9236_().f_46443_);
    }
    
    /**
     * Handle interactions with tamed Rift Drakes (feeding, commands, mounting).
     */
    private InteractionResult handleTamedInteraction(Player player, ItemStack itemstack, InteractionHand hand) {
        if (drake.m_6898_(itemstack) && drake.m_21223_() < drake.m_21233_()) {
            // Feed the drake to heal it
            if (!drake.m_9236_().f_46443_) {
                if (!player.m_150110_().f_35937_) {
                    itemstack.m_41774_(1);
                }
                
                float healAmount = 10.0f; // Heal 5 hearts per fish
                float oldHealth = drake.m_21223_();
                float newHealth = Math.min(oldHealth + healAmount, drake.m_21233_());
                drake.m_21153_(newHealth);
                
                // Show healing particles (green hearts)
                drake.m_9236_().m_7605_(drake, (byte) 7);
            }
            return InteractionResult.m_19078_(drake.m_9236_().f_46443_);
        }
        
        // Handle mounting for tamed dragons
        if (hand == InteractionHand.MAIN_HAND && player.m_21120_(hand).m_41619_()) {
            if (!player.m_6144_()) {
                return handleMounting(player);
            }
        }
        
        // Fall back to base implementation for command cycling
        return drake.superMobInteract(player, hand);
    }
    
    /**
     * Handle mounting the drake.
     */
    private InteractionResult handleMounting(Player player) {
        // Check if player can mount (owner check) and drake isn't already being ridden
        if (!canPlayerMount(player) || drake.m_20160_()) {
            return InteractionResult.PASS;
        }
        
        // Clear any AI states that might interfere with mounting
        if (!drake.m_9236_().f_46443_) {
            if (drake.m_21827_()) {
                drake.m_21839_(false);
            }
            drake.m_6710_(null);
            drake.m_21573_().m_26573_();
            
            // Start riding
            player.m_20329_(drake);
        }
        
        return InteractionResult.m_19078_(drake.m_9236_().f_46443_);
    }


    private InteractionResult handleCommandCycling(Player player) {
        // Get current command and cycle to next
        int currentCommand = drake.getCommand();
        int nextCommand = (currentCommand + 1) % 3; // 0=Follow, 1=Sit, 2=Wander

        // Apply the new command
        drake.setCommand(nextCommand);
        applyCommandState(nextCommand);

        // Send feedback message to player (action bar), server-side only to avoid duplicates
        if (!drake.m_9236_().f_46443_) {
            player.m_5661_(
                    Component.m_237110_(
                            "entity.saintsdragons.all.command_" + nextCommand,
                            drake.m_7755_()
                    ),
                    true
            );
        }
        return InteractionResult.SUCCESS;
    }

    private void applyCommandState(int command) {
        switch (command) {
            case 0: // Follow
                drake.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
            case 1: // Sit
                drake.m_21839_(true);
                break;
            case 2: // Wander
                drake.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
        }
    }
    
    /**
     * Check if the player can mount the drake (owner check).
     */
    private boolean canPlayerMount(Player player) {
        return drake.m_21824_() && drake.m_21830_(player);
    }
    
    /**
     * Trigger taming advancement for the player
     */
    private void triggerTamingAdvancement(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            var advancement = serverPlayer.f_8924_.m_129889_()
                .m_136041_(SaintsDragons.rl("tame_nulljaw"));
            if (advancement != null) {
                serverPlayer.m_8960_().m_135988_(advancement, "tame_nulljaw");
            }
        }
    }
}
