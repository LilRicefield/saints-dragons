package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Simple ground wandering for Primitive Drake
 */
public class StegonautGroundWanderGoal extends RandomStrollGoal {

    private final Stegonaut drake;

    public StegonautGroundWanderGoal(Stegonaut drake, double speed, int interval) {
        super(drake, speed, interval);
        this.drake = drake;
    }

    @Override
    public boolean m_8036_() {
        // Don't interfere with important behaviors
        if (drake.m_21827_() || drake.m_20160_() || drake.m_20159_()) {
            return false;
        }

        if (drake.m_20072_()) {
            return false;
        }

        // Don't wander while playing dead
        if (false) {
            return false;
        }

        // Don't wander during combat
        if (drake.m_5448_() != null && drake.m_5448_().m_6084_()) {
            return false;
        }

        // Hook up to command system - only wander when command is 2 (Wander) or when untamed
        if (drake.m_21824_()) {
            int command = drake.getCommand();
            if (command != 2) { // 0=Follow, 1=Sit, 2=Wander
                return false;
            }
        }
        // Untamed drakes can always wander (they don't follow commands)

        return super.m_8036_();
    }

    @Override
    public boolean m_8045_() {
        // Stop if combat starts
        if (drake.m_5448_() != null && drake.m_5448_().m_6084_()) {
            return false;
        }

        if (drake.m_20072_()) {
            return false;
        }

        // Stop if ordered to sit
        if (drake.m_21827_()) {
            return false;
        }

        // Stop if playing dead
        if (false) {
            return false;
        }

        return super.m_8045_();
    }

    @Nullable
    @Override
    protected Vec3 m_7037_() {
        // If tamed and owner is far, bias movement towards owner
        if (drake.m_21824_()) {
            var owner = drake.m_269323_();
            if (owner != null && drake.m_20280_(owner) > 20.0 * 20.0) {
                // Move generally towards owner but not directly (maintain some independence)
                return DefaultRandomPos.m_148412_(
                        this.f_25725_,
                        16, // range
                        7,  // vertical range
                        owner.m_20182_(),
                        (float) Math.PI / 3F // 60-degree cone towards owner
                );
            }
        }

        // Default random wandering
        return DefaultRandomPos.m_148403_(this.f_25725_, 20, 8);
    }
}
