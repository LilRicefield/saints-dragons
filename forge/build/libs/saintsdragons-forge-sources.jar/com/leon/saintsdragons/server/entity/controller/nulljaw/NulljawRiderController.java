package com.leon.saintsdragons.server.entity.controller.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.DismountHelper;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * Handles all riding mechanics for the Rift Drake
 * Ground-based drake with aquatic capabilities
 */
public record NulljawRiderController(Nulljaw drake) {
    // ===== SEAT TUNING CONSTANTS =====
    // Baseline vertical offset relative to drake height (FALLBACK ONLY - bone positioning is preferred)
    private static final double SEAT_BASE_FACTOR = 0.45D; // 0.0..1.0 of bbHeight
    // Additional vertical lift to avoid clipping (FALLBACK ONLY)
    private static final double SEAT_LIFT = 0.75D;
    // Forward/back relative to body (blocks). +forward = toward head, - = toward tail (FALLBACK ONLY)
    private static final double SEAT_FORWARD = 3.0D;
    // Sideways relative to body (blocks). +side = to the drake's right, - = left (FALLBACK ONLY)
    private static final double SEAT_SIDE = 0.00D;

    // ===== GROUND MOVEMENT TUNING =====
    private static final double GROUND_SPEED_MULT = 0.50D;  // Base ground speed multiplier
    private static final double WATER_SPEED_MULT = 1.2D;  // Enhanced speed in water

    // ===== RIDING UTILITIES =====

    @Nullable
    public Player getRidingPlayer() {
        if (drake.m_146895_() instanceof Player player) {
            return player;
        }
        return null;
    }
    
    // ===== RIDER INPUT PROCESSING =====

    /**
     * Processes rider input and converts to movement vector
     */
    public Vec3 getRiddenInput(Player player, @SuppressWarnings("unused") Vec3 deltaIn) {
        float f = player.f_20902_ < 0.0F ? 0.5F : 1.0F;

        if (drake.m_20069_()) {
            // Aquatic movement - enhanced responsiveness in water
            return new Vec3(player.f_20900_ * 0.6F, 0.0F, player.f_20902_ * 1.0F * f);
        } else {
            // Ground movement - standard responsiveness
            return new Vec3(player.f_20900_ * 0.5F, 0.0D, player.f_20902_ * 0.9F * f);
        }
    }

    /**
     * Main rider tick method - handles rotation and movement state
     */
    public void tickRidden(Player player, @SuppressWarnings("unused") Vec3 travelVector) {
        // Prevent accidental rider fall damage while mounted
        player.f_19789_ = 0.0F;
        drake.f_19789_ = 0.0F;
        
        // Clear target when being ridden to prevent AI interference
        drake.m_6710_(null);
        
        // Make drake responsive to player look direction
        // Smooth turning handled by DragonBodyControl + bodyRotDeviation system
        float yawDiff = Math.abs(player.m_146908_() - drake.m_146908_());
        if (player.f_20902_ != 0 || player.f_20900_ != 0 || yawDiff > 5.0f) {
            float currentYaw = drake.m_146908_();
            float targetYaw = player.m_146908_();
            float rawDiff = Mth.m_14177_(targetYaw - currentYaw);
            float blend = 0.28f;
            float newYaw = currentYaw + (rawDiff * blend);
            
            // Set rotation
            drake.m_146922_(newYaw);
            drake.m_146926_(0.0F);
            
            // Force entity to be dirty for network sync
            drake.m_20256_(drake.m_20184_());
            
            // Update body and head rotation
            drake.f_20883_ = newYaw;
            drake.f_20885_ = newYaw;
        }
    }

    /**
     * Handle rider movement - NOT USED for ground-based dragons
     * Ground movement is handled directly in travel() method using super.travel()
     */
    public void handleRiderMovement(Player player, Vec3 motion) {
        // This method should not be called for ground-based dragons
        // Ground movement is handled directly in the travel() method
        throw new UnsupportedOperationException("handleRiderMovement should not be called for ground-based dragons");
    }

    /**
     * Get the speed for ridden movement
     */
    public float getRiddenSpeed(Player player) {
        float baseSpeed = (float) drake.m_21133_(Attributes.f_22279_);
        
        if (drake.m_20069_()) {
            // Enhanced speed in water
            float swimSpeed = (float) drake.getSwimSpeed();
            return drake.isAccelerating() ? swimSpeed * (float)WATER_SPEED_MULT : swimSpeed;
        } else {
            // Ground movement with sprint capability
            return drake.isAccelerating() ? baseSpeed * 1.0F : baseSpeed * (float)GROUND_SPEED_MULT;
        }
    }

    /**
     * Get the riding offset for passengers (FALLBACK ONLY)
     */
    public double getPassengersRidingOffset() {
        return (drake.m_20206_() * SEAT_BASE_FACTOR) + SEAT_LIFT;
    }

    /**
     * Position a rider on the drake using bone-based positioning
     */
    public void positionRider(Entity passenger, Entity.MoveFunction moveFunction) {
        if (passenger == null) return;

        // Get the bone position from the renderer's cache (updated each render frame)
        Vec3 passengerLoc = drake.getClientLocatorPosition("passengerLocator");

        if (passengerLoc != null) {
            // The cached position is in world-space but may be from the previous frame
            // We need to convert to drake-local space to handle both movement AND rotation

            // Get drake's old position and rotation (from when bone was sampled)
            Vec3 drakeOldPos = new Vec3(drake.f_19854_, drake.f_19855_, drake.f_19856_);
            float oldYaw = drake.f_19859_;

            // Calculate offset in world space
            Vec3 worldOffset = passengerLoc.m_82546_(drakeOldPos);

            // Convert world offset to drake-local space (relative to old rotation)
            double oldYawRad = Math.toRadians(-oldYaw); // Negative because Minecraft yaw is inverted
            double cosOld = Math.cos(oldYawRad);
            double sinOld = Math.sin(oldYawRad);

            // Rotate world offset back to local space
            double localX = worldOffset.f_82479_ * cosOld - worldOffset.f_82481_ * sinOld;
            double localY = worldOffset.f_82480_;
            double localZ = worldOffset.f_82479_ * sinOld + worldOffset.f_82481_ * cosOld;

            // Now rotate local offset to current rotation
            float currentYaw = drake.m_146908_();
            double currentYawRad = Math.toRadians(-currentYaw);
            double cosCurrent = Math.cos(currentYawRad);
            double sinCurrent = Math.sin(currentYawRad);

            double currentWorldX = localX * cosCurrent + localZ * sinCurrent;
            double currentWorldZ = -localX * sinCurrent + localZ * cosCurrent;

            // Apply to current drake position
            Vec3 drakeCurrentPos = drake.m_20182_();
            Vec3 passengerCurrentPos = drakeCurrentPos.m_82520_(currentWorldX, localY, currentWorldZ);

            moveFunction.m_20372_(passenger, passengerCurrentPos.f_82479_, passengerCurrentPos.f_82480_, passengerCurrentPos.f_82481_);
        } else {
            // Fallback to vanilla positioning if bone position not available yet
            // This handles server-side and initial frames before renderer updates the cache
            double seatY = getPassengersRidingOffset();
            Vec3 forward = Vec3.m_82498_(0.0F, drake.m_146908_());
            Vec3 right = new Vec3(forward.f_82481_, 0.0D, -forward.f_82479_);
            Vec3 offset = forward.m_82490_(SEAT_FORWARD)
                    .m_82549_(right.m_82490_(SEAT_SIDE))
                    .m_82520_(0.0D, seatY, 0.0D);

            moveFunction.m_20372_(passenger, drake.m_20185_() + offset.f_82479_, drake.m_20186_() + offset.f_82480_, drake.m_20189_() + offset.f_82481_);
        }
    }

    /**
     * Get dismount location for a passenger - finds safe ground position
     * Based on vanilla AbstractHorse dismount logic
     */
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        // Try right side first (based on passenger's main hand)
        Vec3 vec3 = getCollisionHorizontalEscapeVector(
            drake.m_20205_(),
            passenger.m_20205_(),
            drake.m_146908_() + (passenger.m_5737_() == HumanoidArm.RIGHT ? 90.0F : -90.0F)
        );
        Vec3 rightSide = getDismountLocationInDirection(vec3, passenger);
        if (rightSide != null) {
            return rightSide;
        }

        // Try left side if right side failed
        Vec3 vec32 = getCollisionHorizontalEscapeVector(
            drake.m_20205_(),
            passenger.m_20205_(),
            drake.m_146908_() + (passenger.m_5737_() == HumanoidArm.LEFT ? 90.0F : -90.0F)
        );
        Vec3 leftSide = getDismountLocationInDirection(vec32, passenger);
        return leftSide != null ? leftSide : drake.m_20182_();
    }

    /**
     * Calculate horizontal escape vector for dismounting
     * Reimplementation of Entity.getCollisionHorizontalEscapeVector (which is protected)
     */
    private static Vec3 getCollisionHorizontalEscapeVector(double entityWidth, double passengerWidth, float yaw) {
        double d0 = (entityWidth + passengerWidth + 1.0E-5F) / 2.0D;
        float f = -Mth.m_14031_(yaw * ((float)Math.PI / 180F));
        float f1 = Mth.m_14089_(yaw * ((float)Math.PI / 180F));
        float f2 = Math.max(Math.abs(f), Math.abs(f1));
        return new Vec3((double)f * d0 / (double)f2, 0.0D, (double)f1 * d0 / (double)f2);
    }

    /**
     * Finds a safe dismount location in the given direction by scanning upward for valid ground
     * Based on vanilla AbstractHorse.getDismountLocationInDirection
     */
    @Nullable
    private Vec3 getDismountLocationInDirection(Vec3 offset, LivingEntity passenger) {
        double targetX = drake.m_20185_() + offset.f_82479_;
        double minY = drake.m_20191_().f_82289_;
        double targetZ = drake.m_20189_() + offset.f_82481_;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        // Try all possible poses (standing, crouching, etc.)
        for (Pose pose : passenger.m_7431_()) {
            pos.m_122169_(targetX, minY, targetZ);
            double maxY = drake.m_20191_().f_82292_ + 0.75D;

            // Scan upward to find valid ground
            while (true) {
                double floorHeight = drake.m_9236_().m_45573_(pos);
                if ((double)pos.m_123342_() + floorHeight > maxY) {
                    break;
                }

                if (DismountHelper.m_38439_(floorHeight)) {
                    AABB aabb = passenger.m_21270_(pose);
                    Vec3 dismountPos = new Vec3(targetX, (double)pos.m_123342_() + floorHeight, targetZ);
                    if (DismountHelper.m_38456_(drake.m_9236_(), passenger, aabb.m_82383_(dismountPos))) {
                        passenger.m_20124_(pose);
                        return dismountPos;
                    }
                }

                pos.m_122173_(Direction.UP);
                if (!((double)pos.m_123342_() < maxY)) {
                    break;
                }
            }
        }

        return null;
    }

    /**
     * Get the controlling passenger (rider)
     */
    @Nullable
    public Player getControllingPassenger() {
        return getRidingPlayer();
    }
}
