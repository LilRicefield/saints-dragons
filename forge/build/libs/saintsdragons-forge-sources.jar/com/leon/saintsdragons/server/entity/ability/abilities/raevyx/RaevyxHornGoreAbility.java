package com.leon.saintsdragons.server.entity.ability.abilities.raevyx;

import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.*;

/**
 * Simple horn gore melee: modest damage + strong knockback in front of head.
 */
public class RaevyxHornGoreAbility extends DragonAbility<Raevyx> {
    private static final float GORE_DAMAGE = 15.0f;
    private static final double GORE_RANGE = 6.5; // Increased from 3.8
    private static final double GORE_RANGE_RIDDEN = 8.0; // Increased from 5.2
    private static final double GORE_ANGLE_DEG = 90.0; // half-angle, increased from 75

    private static final DragonAbilitySection[] TRACK = new DragonAbilitySection[] {
            new AbilitySectionDuration(AbilitySectionType.STARTUP, 3),
            new AbilitySectionDuration(AbilitySectionType.ACTIVE, 2),
            new AbilitySectionDuration(AbilitySectionType.RECOVERY, 3)
    };

    // Track entities already hit during the ACTIVE window so we don't double hit in multi-tick ACTIVE
    private final java.util.Set<Integer> hitIdsThisUse = new java.util.HashSet<>();
    private boolean playedSoundThisUse = false;

    public RaevyxHornGoreAbility(DragonAbilityType<Raevyx, RaevyxHornGoreAbility> type, Raevyx user) {
        super(type, user, TRACK, 3);
    }

    @Override
    protected void beginSection(DragonAbilitySection section) {
        if (section == null) return;
        if (section.sectionType == AbilitySectionType.STARTUP) {
            // Trigger gore animation via normal GeckoLib action trigger
            getUser().triggerAnim("action", "horn_gore");
            hitIdsThisUse.clear();
            playedSoundThisUse = false;
        } else if (section.sectionType == AbilitySectionType.ACTIVE) {
            // Sound is handled by animation keyframe in horn_gore animation
            hitIdsThisUse.clear(); // Reset hit tracking for this strike window
        }
    }

    @Override
    public void tickUsing() {
        DragonAbilitySection section = getCurrentSection();
        if (section == null) return;
        if (section.sectionType != AbilitySectionType.ACTIVE) return;

        // Multi-target horn gore: hit all valid entities in cone that haven't been hit yet
        java.util.List<LivingEntity> candidates = findTargets();
        java.util.List<LivingEntity> newHits = new java.util.ArrayList<>();
        for (LivingEntity le : candidates) {
            if (hitIdsThisUse.add(le.m_19879_())) {
                newHits.add(le);
            }
        }
        if (!newHits.isEmpty()) {
            for (LivingEntity le : newHits) {
                applyGore(le);
            }
        }
    }

    private java.util.List<LivingEntity> findTargets() {
        Raevyx wyvern = getUser();
        Vec3 head = wyvern.getHeadPosition();
        Vec3 look = wyvern.m_20154_().m_82541_();

        boolean ridden = wyvern.m_6688_() != null;
        double range = ridden ? GORE_RANGE_RIDDEN : GORE_RANGE;

        // Use wyvern body bounding box inflated by range as broadphase
        AABB broad = wyvern.m_20191_().m_82377_(range, range, range);
        List<LivingEntity> candidates = wyvern.m_9236_().m_6443_(LivingEntity.class, broad,
                e -> e != wyvern && e.m_6084_() && e.m_5789_() && !isAllied(wyvern, e));

        double cosLimit = Math.cos(Math.toRadians(GORE_ANGLE_DEG));
        java.util.List<LivingEntity> hits = new java.util.ArrayList<>();

        for (LivingEntity e : candidates) {
            // Distance from head to target AABB
            double dist = distancePointToAABB(head, e.m_20191_());
            if (dist > range + 0.4) continue;

            // Angle test from head toward target center
            Vec3 toward = e.m_20191_().m_82399_().m_82546_(head);
            double len = toward.m_82553_();
            if (len < 1.0e-4) continue;
            double dot = toward.m_82541_().m_82526_(look);

            boolean close = dist < (range * 0.6);
            boolean angleOk = dot >= cosLimit;
            if (ridden) {
                // More lenient while ridden or accept within body range
                double bodyDist = distancePointToAABB(e.m_20182_(), wyvern.m_20191_());
                angleOk = angleOk || dot >= (cosLimit * 0.7) || bodyDist <= range;
            }
            if (!(close || angleOk)) continue;
            hits.add(e);
        }
        return hits;
    }

    private void applyGore(LivingEntity target) {
        Raevyx wyvern = getUser();
        DamageSource src = wyvern.m_9236_().m_269111_().m_269333_(wyvern);

        float mult = wyvern.getDamageMultiplier();
        boolean isSupercharged = wyvern.isSupercharged();

        // Armor penetration: ignore 2 armor points when calculating effective damage
        // When supercharged, ignore 4 armor points (2x enhancement)
        float armorPenetration = isSupercharged ? 4.0f : 2.0f;
        float armor = (float) target.m_21133_(Attributes.f_22284_);
        float toughness = (float) target.m_21133_(Attributes.f_22285_);
        float desiredPostArmor = damageAfterArmor(GORE_DAMAGE * mult, Math.max(0f, armor - armorPenetration), toughness);

        // Find a raw damage value which, after the target's ACTUAL armor/toughness, equals desiredPostArmor
        float rawToDeal = solveRawDamageForPostArmor(desiredPostArmor, armor, toughness);
        target.m_6469_(src, rawToDeal);
        wyvern.noteAggroFrom(target);

        // Strong directional knockback away from wyvern head
        Vec3 look = wyvern.m_20154_().m_82541_();
        double strength = isSupercharged ? 2.8 : 1.4; // 2x knockback when supercharged
        // knockback(strength, x, z): applies horizontal knockback opposite to (x,z)
        target.m_147240_((float) strength, -look.f_82479_, -look.f_82481_);

        // Small vertical lift - enhanced when supercharged
        Vec3 dv = target.m_20184_();
        float verticalLift = isSupercharged ? 0.7f : 0.35f; // 2x vertical lift when supercharged
        target.m_20334_(dv.f_82479_, Math.max(dv.f_82480_, verticalLift), dv.f_82481_);

    }

    // ===== helpers =====
    private static float damageAfterArmor(float damage, float armor, float toughness) {
        // Mirrors vanilla CombatRules.getDamageAfterAbsorb
        float f = 2.0F + toughness / 4.0F;
        float reduction = Mth.m_14036_(armor - damage / f, armor * 0.2F, 20.0F);
        return damage * (1.0F - reduction / 25.0F);
    }

    private static float solveRawDamageForPostArmor(float desiredPostArmor, float armor, float toughness) {
        // Binary search a raw damage amount such that after-armor equals desiredPostArmor
        // Monotonic increasing, so safe to search
        float lo = 0.0f;
        float hi = Math.max(desiredPostArmor + 16.0f, 16.0f); // reasonable starting upper bound
        // Ensure upper bound is sufficient
        for (int i = 0; i < 8 && damageAfterArmor(hi, armor, toughness) < desiredPostArmor; i++) {
            hi *= 2.0f;
        }
        // Binary search
        for (int it = 0; it < 20; it++) { // ~1e-6 relative precision typically
            float mid = (lo + hi) * 0.5f;
            float val = damageAfterArmor(mid, armor, toughness);
            if (val < desiredPostArmor) lo = mid; else hi = mid;
        }
        return (lo + hi) * 0.5f;
    }

    private static double distancePointToAABB(Vec3 p, AABB box) {
        double dx = Math.max(Math.max(box.f_82288_ - p.f_82479_, 0.0), p.f_82479_ - box.f_82291_);
        double dy = Math.max(Math.max(box.f_82289_ - p.f_82480_, 0.0), p.f_82480_ - box.f_82292_);
        double dz = Math.max(Math.max(box.f_82290_ - p.f_82481_, 0.0), p.f_82481_ - box.f_82293_);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean isAllied(Raevyx wyvern, Entity other) {
        // Use the comprehensive ally system from DragonEntity
        return wyvern.isAlly(other);
    }
}
