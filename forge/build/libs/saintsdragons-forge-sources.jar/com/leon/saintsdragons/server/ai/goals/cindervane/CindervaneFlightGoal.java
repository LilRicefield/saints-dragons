package com.leon.saintsdragons.server.ai.goals.cindervane;

import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.util.EnumSet;

/**
 * Amphithere flight goal for high-soaring glider behavior
 * Gliders soar high in clear weather but avoid storms and rain
 * Features large flight ranges (80-200 blocks) and high altitudes (25-60 blocks above ground)
 */
public class CindervaneFlightGoal extends Goal {
    private final Cindervane amphithere;
    private Vec3 targetPosition;
    private int stuckCounter = 0;
    private int timeSinceTargetChange = 0;

    // Landing cooldown to prevent immediate takeoff after landing
    private static final int LANDING_COOLDOWN_TICKS = 40; // 2 seconds minimum on ground (gliders want to fly!)
    private long lastLandingTime = 0;
    
    // Flight decision cooldown (slower than lightning amphithere)
    private int flightDecisionCooldown = 0;
    
    // Weather state tracking for immediate response
    private boolean wasThundering = false;
    private boolean wasRaining = false;

    public CindervaneFlightGoal(Cindervane amphithere) {
        this.amphithere = amphithere;
        this.m_7021_(EnumSet.of(Flag.MOVE));
        
        // Start with no offset
        this.flightDecisionCooldown = 0;
    }

    @Override
    public boolean m_8036_() {
        // Don't interfere with landing sequence
        if (amphithere.isLanding()) {
            return false;
        }

        // Don't interfere with important behaviors
        if (amphithere.m_20160_() || amphithere.m_20159_() || amphithere.m_21827_()) {
            return false;
        }

        // Prevent autonomous flight when tamed - amphitheres should stay grounded
        if (amphithere.m_21824_() && amphithere.m_269323_() != null) {
            // Only allow flight when over danger (void, lava, water)
            if (!isOverDanger()) {
                return false;
            }
        }

        // Weather state snapshot for this decision
        boolean thundering = amphithere.m_9236_().m_46470_();
        boolean raining = !thundering && amphithere.m_9236_().m_46471_();
        
        // Check for weather changes that should trigger immediate takeoff
        boolean weatherChangedToStorm = (thundering && !wasThundering) || (raining && !wasRaining);
        boolean weatherChangedToThunder = thundering && !wasThundering;
        
        // Update weather state tracking
        wasThundering = thundering;
        wasRaining = raining;

        // Tamed amphitheres stay grounded (already handled above)
        // This check is redundant but kept for clarity

        // Use server game time for landing cooldown checks
        long currentTime = amphithere.m_9236_().m_46467_();
        int cooldown = LANDING_COOLDOWN_TICKS; // fixed
        if (thundering) cooldown = 0;            // no cooldown in thunder - gliders avoid storms
        else if (raining) cooldown = cooldown / 4; // shorter cooldown in rain - gliders prefer clear weather
        
        // Override cooldown if weather just changed to storm conditions
        if (weatherChangedToStorm) {
            cooldown = 0;
        }
        
        if (!amphithere.m_29443_() && (currentTime - lastLandingTime) < cooldown) {
            return false;
        }

        // Use desynced cooldown to prevent all dragons making flight decisions same tick
        int decisionInterval = flightDecisionInterval(thundering, raining);
        if (flightDecisionCooldown > 0) {
            flightDecisionCooldown--;
            if (flightDecisionCooldown > 0) {
                // Override cooldown if weather just changed to thunder for immediate response
                if (weatherChangedToThunder) {
                    flightDecisionCooldown = 0;
                } else if ((thundering || raining) && flightDecisionCooldown > decisionInterval) {
                    flightDecisionCooldown = decisionInterval;
                }
                if (flightDecisionCooldown > 0) {
                    return false;
                }
            }
        }

        // Must fly if over danger
        boolean isFlying;
        if (isOverDanger()) {
            isFlying = true;
        } else {
            // Weather-based flight decisions
            if (amphithere.m_29443_()) {
                isFlying = shouldKeepFlying(thundering, raining);
            } else {
                isFlying = shouldTakeOff(thundering, raining);
            }
        }

        if (isFlying) {
            this.targetPosition = findFlightTarget();
            // Reset cooldown for next decision
            this.flightDecisionCooldown = nextDecisionCooldown(decisionInterval);
            return true;
        }

        // Reset cooldown even when not flying
        this.flightDecisionCooldown = nextDecisionCooldown(decisionInterval);
        return false;
    }

    @Override
    public boolean m_8045_() {
        // Let landing system take over
        if (amphithere.isLanding()) {
            return false;
        }

        // Stop if ordered to sit or something important comes up
        if (amphithere.m_21827_() || amphithere.m_20160_()) {
            return false;
        }

        // Tamed amphitheres only fly autonomously when over danger
        if (amphithere.m_21824_() && amphithere.m_269323_() != null) {
            if (!isOverDanger()) {
                amphithere.setGoingUp(false);
                amphithere.setGoingDown(false);
                amphithere.setLanding(true);
                amphithere.setFlying(false);
                amphithere.setHovering(false);
                amphithere.setTakeoff(false);
                return false;
            }
        }

        // Stop if combat starts
        var target = amphithere.m_5448_();
        if (target != null && target.m_6084_()) {
            return false;
        }

        // Check if amphithere wants to land naturally (only for wild/untamed dragons)
        if (!amphithere.m_21824_()) {
            boolean thundering = amphithere.m_9236_().m_46470_();
            boolean raining = !thundering && amphithere.m_9236_().m_46471_();
            if (amphithere.m_29443_() && !shouldKeepFlying(thundering, raining)) {
                // Dragon wants to land - trigger landing sequence
                amphithere.setLanding(true);
                amphithere.setFlying(false);
                amphithere.setTakeoff(false);
                amphithere.setHovering(false);
                return false;
            }
        }

        // Continue if we're flying and have a target
        // CRITICAL: Only continue if actually airborne (not on ground)
        // Allow brief grace period for takeoff (5 ticks = 0.25 seconds)
        if (amphithere.m_29443_() && amphithere.m_20096_()) {
            if (timeSinceTargetChange > 5) { // Grace period for takeoff
                return false;
            }
        }
        
        return amphithere.m_29443_() && targetPosition != null && amphithere.m_20238_(targetPosition) > 9.0;
    }

    @Override
    public void m_8056_() {
        amphithere.setFlying(true);
        amphithere.setLanding(false);
        amphithere.setHovering(false);
        if (targetPosition != null) {
            amphithere.m_21566_().m_6849_(targetPosition.f_82479_, targetPosition.f_82480_, targetPosition.f_82481_, amphithere.getFlightSpeed());
        }
    }

    @Override
    public void m_8037_() {
        timeSinceTargetChange++;
        
        // If amphithere wants to land, let it handle that
        if (amphithere.isLanding()) {
            return;
        }

        // CRITICAL: Handle stuck state where isFlying=true but onGround=true
        // Allow brief grace period for takeoff (5 ticks = 0.25 seconds)
        if (amphithere.m_29443_() && amphithere.m_20096_()) {
            if (timeSinceTargetChange > 5) { // Grace period for takeoff
                // Properly land the amphithere instead of just resetting states
                amphithere.setLanding(true);
                amphithere.setFlying(false);
                amphithere.setTakeoff(false);
                amphithere.setHovering(false);
                amphithere.markLandedNow();
                return;
            }
        }

        if (amphithere.m_21824_() && amphithere.m_269323_() != null && !isOverDanger()) {
            amphithere.setLanding(true);
            amphithere.setFlying(false);
            amphithere.setHovering(false);
            amphithere.setTakeoff(false);
            return;
        }

        // Check if we need a new target
        boolean needNewTarget = false;

        if (targetPosition == null) {
            needNewTarget = true;
        } else {
            double distanceToTarget = amphithere.m_20238_(targetPosition);

            // Reached target - large completion distance for glider soaring
            if (distanceToTarget < 100.0) { // 100 blocks for long glider flights
                needNewTarget = true;
            }

            // Check if move controller gave up (collision handling)
            if (amphithere.f_19862_ && distanceToTarget > 25.0) {
                needNewTarget = true;
                stuckCounter = 0;
            }

            // Better stuck detection
            if (amphithere.f_19862_ && timeSinceTargetChange % 5 == 0) {
                stuckCounter++;
                if (stuckCounter > 2) {
                    needNewTarget = true;
                    stuckCounter = 0;
                }
            } else if (!amphithere.f_19862_) {
                stuckCounter = Math.max(0, stuckCounter - 1);
            }

            // Periodic path validation
            if (amphithere.f_19797_ % 20 == 0) {
                if (!isValidFlightTarget(targetPosition)) {
                    needNewTarget = true;
                }
            }

            // Been going to same target for too long
            if (timeSinceTargetChange > 300) {
                needNewTarget = true;
            }
        }

        if (needNewTarget) {
            targetPosition = findFlightTarget();
            timeSinceTargetChange = 0;
            amphithere.m_21566_().m_6849_(targetPosition.f_82479_, targetPosition.f_82480_, targetPosition.f_82481_, amphithere.getFlightSpeed());
        }
    }

    @Override
    public void m_8041_() {
        targetPosition = null;
        stuckCounter = 0;
        timeSinceTargetChange = 0;
        amphithere.m_21573_().m_26573_();

        // NEW: Record landing time for cooldown
        if (!amphithere.m_29443_()) {
            lastLandingTime = amphithere.m_9236_().m_46467_();
        }
    }

    // ===== FLIGHT TARGET FINDING =====

    private Vec3 findFlightTarget() {
        Vec3 dragonPos = amphithere.m_20182_();
        Vec3 anchor = getFlightAnchor();

        // Try multiple attempts with progressively more desperate searching
        for (int attempts = 0; attempts < 16; attempts++) {
            Vec3 candidate = generateFlightCandidate(anchor, dragonPos, attempts);

            if (isValidFlightTarget(candidate)) {
                return candidate;
            }
        }

        // Fallback: safe position above anchor
        return new Vec3(anchor.f_82479_, findSafeFlightHeight(anchor.f_82479_, anchor.f_82481_, true), anchor.f_82481_);
    }

    private Vec3 generateFlightCandidate(Vec3 anchor, Vec3 dragonPos, int attempt) {
        boolean isStuck = amphithere.f_19862_ || stuckCounter > 0;

        boolean tethered = isTamedWander();
        float range;
        Vec3 candidate;

        if (tethered) {
            double min = 10.0 + amphithere.m_217043_().m_188500_() * 6.0;
            double max = 24.0 + amphithere.m_217043_().m_188500_() * 6.0;
            double angle = amphithere.m_217043_().m_188500_() * Math.PI * 2.0;
            double radius = min + amphithere.m_217043_().m_188500_() * (max - min);
            double cx = anchor.f_82479_ + Math.cos(angle) * radius;
            double cz = anchor.f_82481_ + Math.sin(angle) * radius;
            double targetY = findSafeFlightHeight(cx, cz, true);
            candidate = new Vec3(cx, targetY, cz);
        } else {
            float maxRot = isStuck ? 360 : 180;
            range = isStuck ? 40.0f + amphithere.m_217043_().m_188501_() * 60.0f :
                    80.0f + amphithere.m_217043_().m_188501_() * 120.0f;

            float yRotOffset;
            if (isStuck && attempt < 8) {
                yRotOffset = (float) Math.toRadians(180 + amphithere.m_217043_().m_188501_() * 120 - 60);
            } else {
                yRotOffset = (float) Math.toRadians(amphithere.m_217043_().m_188501_() * maxRot - (maxRot / 2));
            }

            float xRotOffset = (float) Math.toRadians((amphithere.m_217043_().m_188501_() - 0.5f) * 20);

            Vec3 lookVec = amphithere.m_20154_();
            Vec3 targetVec = lookVec.m_82490_(range).m_82524_(yRotOffset).m_82496_(xRotOffset);
            Vec3 raw = dragonPos.m_82549_(targetVec);
            double targetY = findSafeFlightHeight(raw.f_82479_, raw.f_82481_, false);
            candidate = new Vec3(raw.f_82479_, targetY, raw.f_82481_);
        }

        if (!amphithere.m_9236_().m_46749_(BlockPos.m_274446_(candidate))) {
            return null;
        }

        return candidate;
    }

    private double findSafeFlightHeight(double x, double z, boolean tethered) {
        int ix = (int) x;
        int iz = (int) z;
        int groundY = amphithere.m_9236_().m_6924_(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ix, iz);

        double base;
        if (tethered) {
            base = 12.0 + amphithere.m_217043_().m_188500_() * 12.0;
        } else {
            base = 25.0 + amphithere.m_217043_().m_188500_() * 35.0;
        }

        // Weather-based cap above ground - gliders avoid storms
        boolean thundering = amphithere.m_9236_().m_46470_();
        boolean raining = !thundering && amphithere.m_9236_().m_46471_();
        double capAboveGround;
        if (tethered) {
            capAboveGround = thundering ? 12.0 : (raining ? 18.0 : 32.0);
        } else {
            capAboveGround = thundering ? 20.0 : (raining ? 30.0 : 80.0);
        }

        double target = groundY + base;
        double cap = groundY + capAboveGround;
        double worldCap = amphithere.m_9236_().m_151558_() - 10.0;

        return Math.min(Math.min(target, cap), worldCap);
    }

    private Vec3 getFlightAnchor() {
        if (isTamedWander()) {
            LivingEntity owner = amphithere.m_269323_();
            if (owner != null) {
                return owner.m_20182_();
            }
        }
        return amphithere.m_20182_();
    }

    private boolean isTamedWander() {
        return amphithere.m_21824_() && amphithere.getCommand() == 2 && amphithere.m_269323_() != null;
    }

    private boolean isValidFlightTarget(Vec3 target) {
        if (target == null) return false;

        BlockHitResult result = amphithere.m_9236_().m_45547_(new ClipContext(
                amphithere.m_146892_(),
                target,
                ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE,
                amphithere
        ));

        if (result.m_6662_() == HitResult.Type.MISS) {
            return true;
        }

        double distanceToHit = result.m_82450_().m_82554_(amphithere.m_20182_());
        double distanceToTarget = target.m_82554_(amphithere.m_20182_());

        return distanceToHit > distanceToTarget * 0.95;
    }

    // ===== DECISION MAKING (SLOWER THAN LIGHTNING DRAGON) =====

    private int flightDecisionInterval(boolean thundering, boolean raining) {
        if (thundering) {
            return 2; // Fast decisions in storms to land quickly
        }
        if (raining) {
            return 5; // Quick decisions in rain to land
        }
        return 8; // Frequent decisions in clear weather - gliders want to soar!
    }

    private int nextDecisionCooldown(int baseInterval) {
        int jitter = Math.max(1, baseInterval / 2);
        return baseInterval + amphithere.m_217043_().m_188503_(jitter);
    }

    private boolean shouldTakeOff(boolean thundering, boolean raining) {
        if (isOverDanger()) {
            return true;
        }

        // NIGHT-TIME: Wild Cindervanes don't take off at night (they sleep)
        // Tamed dragons can still fly at night with owner
        if (!amphithere.m_21824_()) {
            long dayTime = amphithere.m_9236_().m_46468_() % 24000;
            boolean isNight = dayTime >= 13000 && dayTime < 23000;
            if (isNight) {
                return false; // Stay grounded at night for RestGoal to activate
            }
        }

        if (thundering) {
            // Gliders avoid thunderstorms - very rare takeoff
            return amphithere.m_217043_().m_188503_(200) == 0; // 0.5% chance - gliders avoid storms
        } else if (raining) {
            // Gliders avoid rain - rare takeoff
            return amphithere.m_217043_().m_188503_(100) == 0; // 1% chance - gliders prefer clear weather
        } else {
            // Clear weather - gliders love to soar
            return amphithere.m_217043_().m_188503_(40) == 0; // 2.5% chance - frequent soaring in clear weather
        }
    }

    private boolean shouldKeepFlying(boolean thundering, boolean raining) {
        if (isOverDanger()) {
            return true;
        }

        // NIGHT-TIME: Wild Cindervanes land quickly at night (they sleep)
        // Tamed dragons can still fly at night with owner
        if (!amphithere.m_21824_()) {
            long dayTime = amphithere.m_9236_().m_46468_() % 24000;
            boolean isNight = dayTime >= 13000 && dayTime < 23000;
            if (isNight) {
                // Land quickly at night (~5 sec average) to find a safe spot to sleep
                return amphithere.m_217043_().m_188503_(100) != 0;
            }
        }

        // Weather-weighted patrol durations - gliders avoid storms
        if (thundering) {
            // Thunder: gliders land quickly in storms (~10 sec average)
            return amphithere.m_217043_().m_188503_(200) != 0;
        } else if (raining) {
            // Rain: gliders land quickly in rain (~20 sec average)
            return amphithere.m_217043_().m_188503_(400) != 0;
        } else {
            // Clear: gliders soar for long periods (~3 min average)
            return amphithere.m_217043_().m_188503_(3600) != 0;
        }
    }

    // ===== UTILITY METHODS =====

    private boolean isOverDanger() {
        BlockPos dragonPos = amphithere.m_20183_();
        boolean foundSolid = false;
        boolean nearFluid = false;

        for (int i = 1; i <= 25; i++) {
            BlockPos checkPos = dragonPos.m_6625_(i);

            var state = amphithere.m_9236_().m_8055_(checkPos);
            // Treat as solid ground if the block has a collision shape or sturdy top face
            if (!state.m_60812_(amphithere.m_9236_(), checkPos).m_83281_() ||
                    state.m_60783_(amphithere.m_9236_(), checkPos, net.minecraft.core.Direction.UP)) {
                foundSolid = true;
                break;
            }

            // Consider fluids within 10 blocks below as dangerous (avoid landing in water/lava)
            if (i <= 10 && !amphithere.m_9236_().m_6425_(checkPos).m_76178_()) {
                nearFluid = true;
                // No break: still continue to see if solid exists even closer
            }
        }

        // Dangerous if over fluid nearby, or no solid ground found and we're near world bottom (void-like)
        if (nearFluid) return true;
        return !foundSolid && dragonPos.m_123342_() < amphithere.m_9236_().m_141937_() + 20;
    }
}
