package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Simple follow-owner goal tailored for the ground-based Rift Drake.
 */
public class NulljawFollowOwnerGoal extends Goal {
    private static final double START_DISTANCE = 7.0D;
    private static final double STOP_DISTANCE = 7.0D;
    private static final double RUN_DISTANCE = 9.0D;
    private static final double TELEPORT_DISTANCE = 64.0D;

    private final Nulljaw drake;
    private int pathRecalcCooldown;
    private double lastOwnerX = Double.NaN;
    private double lastOwnerY = Double.NaN;
    private double lastOwnerZ = Double.NaN;

    public NulljawFollowOwnerGoal(Nulljaw drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        if (!drake.m_21824_() || drake.m_21827_() || drake.m_20160_()) {
            return false;
        }

        LivingEntity owner = drake.m_269323_();
        if (owner == null || !owner.m_6084_() || owner.m_9236_() != drake.m_9236_()) {
            return false;
        }

        // Do not interfere while actively targeting something
        if (drake.m_5448_() != null) {
            return false;
        }

        return drake.m_20280_(owner) > START_DISTANCE * START_DISTANCE;
    }

    @Override
    public boolean m_8045_() {
        if (!drake.m_21824_() || drake.m_21827_() || drake.m_20160_()) {
            return false;
        }

        LivingEntity owner = drake.m_269323_();
        if (owner == null || !owner.m_6084_() || owner.m_9236_() != drake.m_9236_()) {
            return false;
        }

        if (drake.m_5448_() != null) {
            return false;
        }

        return drake.m_20280_(owner) > STOP_DISTANCE * STOP_DISTANCE;
    }

    @Override
    public void m_8056_() {
        resetPathTracking();
        drake.setAccelerating(false);
    }

    @Override
    public void m_8041_() {
        drake.m_21573_().m_26573_();
        drake.setAccelerating(false);
        resetPathTracking();
    }

    @Override
    public void m_8037_() {
        LivingEntity owner = drake.m_269323_();
        if (owner == null) {
            return;
        }

        double distance = drake.m_20270_(owner);

        // Emergency teleport when extremely far (e.g., after dimension travel glitches)
        if (distance > TELEPORT_DISTANCE) {
            drake.m_6021_(owner.m_20185_(), owner.m_20186_(), owner.m_20189_());
            drake.m_21573_().m_26573_();
            drake.setAccelerating(false);
            resetPathTracking();
            return;
        }

        // Keep eyes on the owner for a responsive feel
        drake.m_21563_().m_24960_(owner, 10.0F, drake.m_8132_());

        if (distance <= STOP_DISTANCE) {
            drake.m_21573_().m_26573_();
            drake.setAccelerating(false);
            return;
        }

        boolean shouldRun = distance > RUN_DISTANCE;
        drake.setAccelerating(shouldRun);

        double speed = shouldRun ? 1.35D : 0.85D;
        updateGroundPath(owner, speed, distance, shouldRun);
    }

    private void updateGroundPath(LivingEntity owner, double speed, double distance, boolean running) {
        if (pathRecalcCooldown > 0) {
            pathRecalcCooldown--;
        }

        boolean ownerMoved = ownerMovedSignificantly(owner);
        boolean navIdle = drake.m_21573_().m_26571_() || !drake.m_21573_().m_26572_();

        if (navIdle || ownerMoved || pathRecalcCooldown <= 0) {
            // Boost speed in water for amphibious movement
            double effectiveSpeed = drake.m_20069_() ? speed * 1.3D : speed;
            if (!drake.m_21573_().m_5624_(owner, effectiveSpeed)) {
                drake.m_21573_().m_26519_(owner.m_20185_(), owner.m_20186_(), owner.m_20189_(), effectiveSpeed);
            }
            rememberOwnerPosition(owner);
            pathRecalcCooldown = computeRepathCooldown(distance, running);
        }
    }

    private int computeRepathCooldown(double distance, boolean running) {
        int base = (int) Math.ceil(distance * (running ? 0.4 : 0.55));
        return Mth.m_14045_(base, running ? 4 : 6, running ? 16 : 24);
    }

    private void rememberOwnerPosition(LivingEntity owner) {
        this.lastOwnerX = owner.m_20185_();
        this.lastOwnerY = owner.m_20186_();
        this.lastOwnerZ = owner.m_20189_();
    }

    private boolean ownerMovedSignificantly(LivingEntity owner) {
        if (Double.isNaN(lastOwnerX)) {
            return true;
        }
        double dx = owner.m_20185_() - this.lastOwnerX;
        double dy = owner.m_20186_() - this.lastOwnerY;
        double dz = owner.m_20189_() - this.lastOwnerZ;
        return dx * dx + dy * dy + dz * dz > 1.0D;
    }

    private void resetPathTracking() {
        this.pathRecalcCooldown = 0;
        this.lastOwnerX = Double.NaN;
        this.lastOwnerY = Double.NaN;
        this.lastOwnerZ = Double.NaN;
    }
}
