package com.leon.saintsdragons.server.command;

import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.handler.DragonAllyManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import java.util.Collection;
import java.util.List;

/**
 * Server commands for managing drake allies.
 * Provides /dragonally add/remove/list commands for administrators and drake owners.
 */
public class DragonAllyCommand {
    
    private static final SuggestionProvider<CommandSourceStack> DRAGON_SUGGESTIONS = (context, builder) -> {
        CommandSourceStack source = context.getSource();
        return SharedSuggestionProvider.m_82981_(
            source.m_81372_().m_45976_(DragonEntity.class, 
                source.m_81373_() != null ? source.m_81373_().m_20191_().m_82400_(50) : 
                net.minecraft.world.phys.AABB.m_165882_(source.m_81371_(), 100, 100, 100))
                .stream()
                .filter(dragon -> dragon.m_21824_() && source.m_81373_() instanceof Player && dragon.m_21830_((Player) source.m_81373_()))
                .map(dragon -> String.valueOf(dragon.m_19879_())),
            builder
        );
    };
    
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.m_82127_("dragonally")
            .requires(source -> source.m_6761_(2)) // OP level 2 required
            .then(Commands.m_82127_("add")
                .then(Commands.m_82129_("drake", EntityArgument.m_91449_())
                    .then(Commands.m_82129_("username", StringArgumentType.string())
                        .executes(DragonAllyCommand::addAlly))))
            .then(Commands.m_82127_("remove")
                .then(Commands.m_82129_("drake", EntityArgument.m_91449_())
                    .then(Commands.m_82129_("username", StringArgumentType.string())
                        .executes(DragonAllyCommand::removeAlly))))
            .then(Commands.m_82127_("list")
                .then(Commands.m_82129_("drake", EntityArgument.m_91449_())
                    .executes(DragonAllyCommand::listAllies)))
            .then(Commands.m_82127_("clear")
                .then(Commands.m_82129_("drake", EntityArgument.m_91449_())
                    .executes(DragonAllyCommand::clearAllies))));
    }
    
    private static int addAlly(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        Collection<? extends Entity> entities = EntityArgument.m_91461_(context, "drake");
        String username = StringArgumentType.getString(context, "username");
        
        int successCount = 0;
        for (Entity entity : entities) {
            if (entity instanceof DragonEntity dragon) {
                DragonAllyManager.AllyResult result = dragon.allyManager.addAlly(username);
                Component message = Component.m_237110_("saintsdragons.command.ally.add.result", 
                    dragon.m_5446_(), username, result.getMessage());
                source.m_288197_(() -> message, false);
                
                if (result.isSuccess()) {
                    successCount++;
                }
            } else {
                source.m_81352_(Component.m_237110_("saintsdragons.command.ally.not_dragon", entity.m_5446_()));
            }
        }
        
        return successCount;
    }
    
    private static int removeAlly(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        Collection<? extends Entity> entities = EntityArgument.m_91461_(context, "drake");
        String username = StringArgumentType.getString(context, "username");
        
        int successCount = 0;
        for (Entity entity : entities) {
            if (entity instanceof DragonEntity dragon) {
                DragonAllyManager.AllyResult result = dragon.allyManager.removeAlly(username);
                Component message = Component.m_237110_("saintsdragons.command.ally.remove.result", 
                    dragon.m_5446_(), username, result.getMessage());
                source.m_288197_(() -> message, false);
                
                if (result.isSuccess()) {
                    successCount++;
                }
            } else {
                source.m_81352_(Component.m_237110_("saintsdragons.command.ally.not_dragon", entity.m_5446_()));
            }
        }
        
        return successCount;
    }
    
    private static int listAllies(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        Collection<? extends Entity> entities = EntityArgument.m_91461_(context, "drake");
        
        for (Entity entity : entities) {
            if (entity instanceof DragonEntity dragon) {
                List<String> allies = dragon.allyManager.getAllyUsernames();
                Component header = Component.m_237110_("saintsdragons.command.ally.list.header", 
                    dragon.m_5446_(), allies.size(), dragon.allyManager.getMaxAllies());
                source.m_288197_(() -> header, false);
                
                if (allies.isEmpty()) {
                    source.m_288197_(() -> Component.m_237115_("saintsdragons.command.ally.list.empty"), false);
                } else {
                    for (String ally : allies) {
                        source.m_288197_(() -> Component.m_237113_("  - " + ally), false);
                    }
                }
            } else {
                source.m_81352_(Component.m_237110_("saintsdragons.command.ally.not_dragon", entity.m_5446_()));
            }
        }
        
        return entities.size();
    }
    
    private static int clearAllies(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        Collection<? extends Entity> entities = EntityArgument.m_91461_(context, "drake");
        
        int successCount = 0;
        for (Entity entity : entities) {
            if (entity instanceof DragonEntity dragon) {
                dragon.allyManager.clearAllies();
                Component message = Component.m_237110_("saintsdragons.command.ally.clear.success", 
                    dragon.m_5446_());
                source.m_288197_(() -> message, false);
                successCount++;
            } else {
                source.m_81352_(Component.m_237110_("saintsdragons.command.ally.not_dragon", entity.m_5446_()));
            }
        }
        
        return successCount;
    }
}
