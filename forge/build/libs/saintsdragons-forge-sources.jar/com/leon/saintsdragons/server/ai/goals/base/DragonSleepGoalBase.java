package com.leon.saintsdragons.server.ai.goals.base;

import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import com.leon.saintsdragons.server.entity.interfaces.DragonSleepCapable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import java.util.EnumSet;

/**
 * Base class for wyvern sleep goals.
 * Works with any wyvern that implements DragonSleepCapable.
 */
public abstract class DragonSleepGoalBase extends Goal {
    protected final DragonEntity dragon;
    protected final DragonSleepCapable sleepCapable;
    
    public DragonSleepGoalBase(DragonEntity dragon) {
        this.dragon = dragon;
        this.sleepCapable = (DragonSleepCapable) dragon;
        this.m_7021_(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
    }
    
    @Override
    public boolean m_8036_() {
        if (agitated()) return false;
        if (sleepCapable.isSleepSuppressed()) return false;
        
        // Use interface method to check if wyvern can sleep
        if (!sleepCapable.canSleepNow()) return false;
        
        if (dragon.m_21824_()) {
            return canTamedDragonSleep();
        } else {
            return canWildDragonSleep();
        }
    }
    
    @Override
    public boolean m_8045_() {
        // If agitated, stop sleeping immediately
        if (agitated()) return false;

        // Check if we should continue sleeping based on current conditions
        if (sleepCapable.isSleepSuppressed()) return false;
        
        if (dragon.m_21824_()) {
            return canTamedDragonSleep();
        } else {
            // For wild dragons, check if they should wake up due to day/night transition
            DragonSleepCapable.SleepPreferences prefs = sleepCapable.getSleepPreferences();
            
            // If wyvern is sleeping at night and it becomes day, they should wake up
            if (prefs.canSleepAtNight() && !prefs.canSleepDuringDay() && isDay()) {
                return false; // Wake up when day comes
            }
            
            // If wyvern is sleeping during day and it becomes night, they should wake up
            if (prefs.canSleepDuringDay() && !prefs.canSleepAtNight() && isNight()) {
                return false; // Wake up when night comes
            }
            
            // Otherwise, continue sleeping if conditions are still met
            return canWildDragonSleep();
        }
    }
    
    @Override
    public void m_8056_() {
        sleepCapable.startSleepEnter();
    }
    
    @Override
    public void m_8041_() {
        sleepCapable.startSleepExit();
    }
    
    protected boolean agitated() {
        // Do not allow sleeping in fluids or lava, or while panicking/aggro/etc.
        if (dragon.m_20072_() || dragon.m_20077_()) return true;
        return dragon.m_21224_() || dragon.m_20160_() || dragon.m_5448_() != null || dragon.m_5912_();
    }
    
    protected boolean canTamedDragonSleep() {
        DragonSleepCapable.SleepPreferences prefs = sleepCapable.getSleepPreferences();
        
        // Check weather conditions first - tamed dragons should respect weather like wild dragons
        if (prefs.avoidsThunderstorms() && dragon.m_9236_().m_46470_()) {
            return false; // Don't sleep during thunderstorms
        }
        
        // Check if owner is sleeping
        if (ownerSleeping()) return true;
        
        // Check night sleeping near owner
        if (prefs.sleepsNearOwner() && isNight() && nearOwner()) return true;
        
        // Tamed dragons should NOT sleep during day unless owner is sleeping
        // This allows them to wake up naturally when morning comes
        return false;
    }
    
    protected boolean canWildDragonSleep() {
        DragonSleepCapable.SleepPreferences prefs = sleepCapable.getSleepPreferences();
        
        // Check day sleeping
        if (prefs.canSleepDuringDay() && isDay() && isSheltered()) {
            // Check weather conditions
            if (prefs.avoidsThunderstorms() && dragon.m_9236_().m_46470_()) {
                return false;
            }
            return true;
        }
        
        // Check night sleeping
        if (prefs.canSleepAtNight() && isNight() && isSheltered()) {
            // Check weather conditions
            if (prefs.avoidsThunderstorms() && dragon.m_9236_().m_46470_()) {
                return false;
            }
            return true;
        }
        
        return false;
    }
    
    protected boolean isDay() { 
        return dragon.m_9236_().m_46461_(); 
    }
    
    protected boolean isNight() { 
        return !dragon.m_9236_().m_46461_(); 
    }
    
    protected boolean ownerSleeping() {
        LivingEntity owner = dragon.m_269323_();
        return owner instanceof Player p && p.m_5803_();
    }
    
    protected boolean nearOwner() {
        LivingEntity owner = dragon.m_269323_();
        return owner != null && dragon.m_20280_(owner) <= (double) 14 * (double) 14;
    }
    
    protected boolean isSheltered() {
        var level = dragon.m_9236_();
        var pos = dragon.m_20183_();
        boolean noSky = !level.m_45527_(pos);
        int light = level.m_46803_(pos);
        return noSky || light < 7;
    }
}
