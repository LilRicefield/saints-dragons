package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.common.registry.nulljaw.NulljawAbilities;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.EnumSet;

/**
 * Ground combat coordinator for the Rift Drake.
 * Keeps the drake neutral until provoked, then selects the appropriate melee ability.
 */
public class NulljawCombatGoal extends Goal {
    private static final double CHASE_SPEED = 1.5D;
    private static final double BITE_RANGE = 3.5D;
    private static final double HORN_RANGE = 4.5D;
    private static final int MIN_ATTACK_COOLDOWN_TICKS = 10;

    private final Nulljaw drake;
    private int attackCooldown;

    public NulljawCombatGoal(Nulljaw drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        LivingEntity target = drake.m_5448_();
        if (target == null || !target.m_6084_()) {
            return false;
        }
        if (drake.m_20160_() || drake.m_21827_()) {
            return false;
        }
        return isWithinAggroRange(target);
    }

    @Override
    public boolean m_8045_() {
        LivingEntity target = drake.m_5448_();
        if (target == null || !target.m_6084_()) {
            return false;
        }
        if (drake.m_20160_() || drake.m_21827_()) {
            return false;
        }
        return isWithinAggroRange(target);
    }

    @Override
    public void m_8056_() {
        this.attackCooldown = 0;
        drake.m_21561_(true);

        LivingEntity target = drake.m_5448_();
        if (target != null) {
            drake.m_21573_().m_5624_(target, CHASE_SPEED);
        }
    }

    @Override
    public void m_8041_() {
        drake.m_21573_().m_26573_();
        drake.m_21561_(false);
    }

    @Override
    public boolean m_183429_() {
        return true;
    }

    @Override
    public void m_8037_() {
        if (attackCooldown > 0) {
            attackCooldown--;
        }

        LivingEntity target = drake.m_5448_();
        if (target == null) {
            return;
        }

        drake.m_21563_().m_24960_(target, 35.0F, 35.0F);

        double distanceSq = drake.m_20280_(target);
        double attackReachSq = getAttackReachSqr(target);
        boolean inRange = distanceSq <= attackReachSq;
        boolean hasLineOfSight = drake.m_21574_().m_148306_(target);

        if (!inRange || !hasLineOfSight) {
            if (!isPerformingAttack()) {
                drake.m_21573_().m_5624_(target, CHASE_SPEED);
            }
            return;
        }

        drake.m_21573_().m_26573_();
        tryPerformAttacks(target);
    }

    private void tryPerformAttacks(LivingEntity target) {
        if (attackCooldown > 0) {
            return;
        }

        DragonAbilityType<Nulljaw, ?> ability = choosePrimaryAttack(target);
        if (ability != null && drake.combatManager.canStart(ability)) {
            drake.combatManager.tryUseAbility(ability);
            attackCooldown = MIN_ATTACK_COOLDOWN_TICKS;
        }
    }

    private DragonAbilityType<Nulljaw, ?> choosePrimaryAttack(LivingEntity target) {
        double gap = getGapToTarget(target);
        boolean phaseTwo = drake.isPhaseTwoActive();

        if (gap <= BITE_RANGE) {
            // Phase 2: alternate between bite2 and claw
            if (phaseTwo && drake.m_217043_().m_188499_()) {
                return NulljawAbilities.NULLJAW_CLAW;
            }
            return phaseTwo ? NulljawAbilities.NULLJAW_BITE2 : NulljawAbilities.NULLJAW_BITE;
        }
        if (gap <= HORN_RANGE) {
            // Phase 2: alternate between horn gore and claw
            if (phaseTwo && drake.m_217043_().m_188499_()) {
                return NulljawAbilities.NULLJAW_CLAW;
            }
            return NulljawAbilities.NULLJAW_HORN_GORE;
        }
        return null;
    }

    private boolean isPerformingAttack() {
        return drake.getActiveAbility() != null
                || drake.combatManager.isAbilityActive(NulljawAbilities.NULLJAW_CLAW);
    }

    private boolean isWithinAggroRange(LivingEntity target) {
        double followRange = drake.m_21133_(Attributes.f_22277_);
        if (followRange <= 0.0D) {
            followRange = 16.0D;
        }
        double maxDistanceSq = followRange * followRange;
        return drake.m_20280_(target) <= maxDistanceSq;
    }

    private double getAttackReachSqr(LivingEntity target) {
        double combinedRadii = (drake.m_20205_() + target.m_20205_()) * 0.5;
        double reach = HORN_RANGE + combinedRadii;
        return reach * reach;
    }

    private double getGapToTarget(LivingEntity target) {
        double distance = drake.m_20270_(target);
        double combinedRadii = (drake.m_20205_() + target.m_20205_()) * 0.5;
        return Math.max(0.0D, distance - combinedRadii);
    }
}
