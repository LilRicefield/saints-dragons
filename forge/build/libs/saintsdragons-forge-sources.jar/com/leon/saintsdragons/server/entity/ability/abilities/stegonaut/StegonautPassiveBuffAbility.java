package com.leon.saintsdragons.server.entity.ability.abilities.stegonaut;

import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Provides the Primitive Drake's passive aura: Resistance and Absorption to allies.
 */
public class StegonautPassiveBuffAbility {
    private static final double BUFF_RANGE = 8.0;
    private static final int UPDATE_INTERVAL = 20;
    private static final int BUFF_DURATION_TICKS = 40;
    private static final int RESISTANCE_AMPLIFIER = 0;
    private static final int ABSORPTION_AMPLIFIER = 0;

    private final Stegonaut drake;
    private final Level level;

    private int tickCounter = 0;
    private Set<UUID> buffedEntityIds = new HashSet<>();

    public StegonautPassiveBuffAbility(Stegonaut drake) {
        this.drake = drake;
        this.level = drake.m_9236_();
    }

    public void tick() {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }

        if (++tickCounter < UPDATE_INTERVAL) {
            return;
        }
        tickCounter = 0;

        if (!drake.m_6084_()) {
            clearTrackedBuffs(serverLevel);
            return;
        }

        applyBuffs(serverLevel);
    }

    private void applyBuffs(ServerLevel serverLevel) {
        List<LivingEntity> nearbyEntities = serverLevel.m_6443_(
            LivingEntity.class,
            drake.m_20191_().m_82400_(BUFF_RANGE),
            this::isEligibleForBuff
        );

        Set<UUID> currentNearby = new HashSet<>();

        for (LivingEntity entity : nearbyEntities) {
            applyResistance(entity);
            applyAbsorption(entity);
            currentNearby.add(entity.m_20148_());
        }

        if (!buffedEntityIds.isEmpty()) {
            for (UUID uuid : new HashSet<>(buffedEntityIds)) {
                if (!currentNearby.contains(uuid)) {
                    Entity entity = serverLevel.m_8791_(uuid);
                    if (entity instanceof LivingEntity livingEntity) {
                        livingEntity.m_21195_(MobEffects.f_19606_);
                        livingEntity.m_21195_(MobEffects.f_19617_);
                    }
                }
            }
        }

        buffedEntityIds = currentNearby;
    }

    private boolean isEligibleForBuff(LivingEntity entity) {
        if (entity == drake || !entity.m_6084_()) {
            return false;
        }

        if (entity instanceof Player player) {
            return isPlayerEligible(player);
        }

        if (entity instanceof DragonEntity dragon) {
            return isDragonEligible(dragon);
        }

        if (entity instanceof OwnableEntity ownable) {
            LivingEntity owner = ownable.m_269323_();
            if (owner instanceof Player ownerPlayer) {
                if (!drake.m_21824_()) {
                    return false;
                }
                LivingEntity drakeOwner = drake.m_269323_();
                if (drakeOwner instanceof Player drakeOwnerPlayer) {
                    if (drakeOwnerPlayer.m_20148_().equals(ownerPlayer.m_20148_())) {
                        return true;
                    }
                    return drake.allyManager.isAlly(ownerPlayer);
                }
            }
        }

        return false;
    }

    private boolean isPlayerEligible(Player player) {
        if (!drake.m_21824_()) {
            return false;
        }

        LivingEntity owner = drake.m_269323_();
        if (!(owner instanceof Player ownerPlayer)) {
            return false;
        }

        if (ownerPlayer.m_20148_().equals(player.m_20148_())) {
            return true;
        }

        return drake.allyManager.isAlly(player);
    }

    private boolean isDragonEligible(DragonEntity dragon) {
        if (!drake.m_21824_()) {
            return false;
        }

        LivingEntity owner = drake.m_269323_();
        if (!(owner instanceof Player ownerPlayer)) {
            return false;
        }

        if (dragon.m_21830_(ownerPlayer)) {
            return true;
        }

        return dragon instanceof Stegonaut alliedDrake && alliedDrake.allyManager.isAlly(ownerPlayer);
    }

    private void applyResistance(LivingEntity entity) {
        entity.m_7292_(new MobEffectInstance(
            MobEffects.f_19606_,
            BUFF_DURATION_TICKS,
            RESISTANCE_AMPLIFIER,
            false,
            false,
            true
        ));
    }

    private void applyAbsorption(LivingEntity entity) {
        entity.m_7292_(new MobEffectInstance(
            MobEffects.f_19617_,
            BUFF_DURATION_TICKS,
            ABSORPTION_AMPLIFIER,
            false,
            false,
            true
        ));
    }

    public void cleanup() {
        if (level instanceof ServerLevel serverLevel) {
            clearTrackedBuffs(serverLevel);
        } else {
            buffedEntityIds.clear();
        }
    }

    private void clearTrackedBuffs(ServerLevel serverLevel) {
        for (UUID uuid : buffedEntityIds) {
            Entity entity = serverLevel.m_8791_(uuid);
            if (entity instanceof LivingEntity livingEntity) {
                livingEntity.m_21195_(MobEffects.f_19606_);
                livingEntity.m_21195_(MobEffects.f_19617_);
            }
        }
        buffedEntityIds.clear();
    }

    public static double getBuffRange() {
        return BUFF_RANGE;
    }

    public static int getResistanceAmplifier() {
        return RESISTANCE_AMPLIFIER;
    }

    public static int getAbsorptionAmplifier() {
        return ABSORPTION_AMPLIFIER;
    }
}

