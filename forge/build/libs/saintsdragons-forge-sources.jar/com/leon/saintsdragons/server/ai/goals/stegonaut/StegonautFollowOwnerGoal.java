package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Simple follow owner goal for Primitive Drake.
 * Ground-based following with teleportation for extreme distances.
 */
public class StegonautFollowOwnerGoal extends Goal {
    private final Stegonaut drake;

    // Distance constants - tuned for ground-based following
    private static final double START_FOLLOW_DIST = 12.0;
    private static final double STOP_FOLLOW_DIST = 8.0;
    private static final double TELEPORT_DIST = 2000.0;

    // Performance optimization - don't re-path constantly
    private int pathRecalcCooldown = 0;
    private double lastOwnerX = Double.NaN;
    private double lastOwnerY = Double.NaN;
    private double lastOwnerZ = Double.NaN;

    public StegonautFollowOwnerGoal(Stegonaut drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        // Basic requirements
        if (!drake.m_21824_() || drake.m_21827_()) {
            return false;
        }

        // Never follow while playing dead
        if (false) {
            return false;
        }

        // Never follow while actively targeting an enemy
        LivingEntity target = drake.m_5448_();
        if (target != null && target.m_6084_()) {
            return false;
        }

        LivingEntity owner = drake.m_269323_();
        if (owner == null || !owner.m_6084_()) {
            return false;
        }

        // Must be in same dimension
        if (owner.m_9236_() != drake.m_9236_()) {
            return false;
        }

        // Only follow if owner is far enough away
        double ownerDist = drake.m_20280_(owner);
        return ownerDist > START_FOLLOW_DIST * START_FOLLOW_DIST;
    }

    @Override
    public boolean m_8045_() {
        LivingEntity owner = drake.m_269323_();
        if (owner == null || !owner.m_6084_() || drake.m_21827_()) {
            return false;
        }

        // Suspend following while playing dead
        if (false) {
            return false;
        }

        // Suspend following while fighting
        LivingEntity target = drake.m_5448_();
        if (target != null && target.m_6084_()) {
            return false;
        }

        if (owner.m_9236_() != drake.m_9236_()) {
            return false;
        }

        // Keep following until we're close enough
        double dist = drake.m_20280_(owner);
        return dist > STOP_FOLLOW_DIST * STOP_FOLLOW_DIST;
    }

    @Override
    public void m_8056_() {
        // Reset tracking
        resetPathTracking();
    }

    @Override
    public void m_8037_() {
        LivingEntity owner = drake.m_269323_();
        if (owner == null) return;

        double distance = drake.m_20270_(owner);

        // Emergency teleport if owner gets stupidly far away
        if (distance > TELEPORT_DIST) {
            drake.m_6021_(owner.m_20185_(), owner.m_20186_() + 1, owner.m_20189_());
            resetPathTracking();
            return;
        }

        // Always look at owner while following
        drake.m_21563_().m_24960_(owner, 10.0f, 10.0f);

        // Handle ground following
        handleGroundFollowing(owner, distance);
    }

    /**
     * Handle following on ground
     */
    private void handleGroundFollowing(LivingEntity owner, double distance) {
        // Check if we should stop moving
        if (distance <= STOP_FOLLOW_DIST) {
            drake.m_21573_().m_26573_();
            pathRecalcCooldown = 0;
            return;
        }

        double baseSpeed = 0.8;
        double speed = baseSpeed * (1.0 + (distance / 100.0));
        speed = Math.min(speed, 1.0); // Cap at walking speed

        updateGroundPath(owner, speed, distance);
        
        // If stuck, try to jump or find alternative path
        if (drake.m_21573_().m_26577_()) {
            drake.m_21569_().m_24901_();
            drake.m_21573_().m_26573_();
            pathRecalcCooldown = 0; // Force repath next tick
        }
    }

    @Override
    public void m_8041_() {
        drake.m_21573_().m_26573_();
        resetPathTracking();
    }

    private void updateGroundPath(LivingEntity owner, double speed, double distance) {
        if (pathRecalcCooldown > 0) {
            pathRecalcCooldown--;
        }

        boolean ownerMoved = ownerMovedSignificantly(owner);
        boolean navIdle = drake.m_21573_().m_26571_() || !drake.m_21573_().m_26572_();

        if (navIdle || ownerMoved || pathRecalcCooldown <= 0) {
            if (!drake.m_21573_().m_5624_(owner, speed)) {
                drake.m_21573_().m_26519_(owner.m_20185_(), owner.m_20186_(), owner.m_20189_(), speed);
            }
            rememberOwnerPosition(owner);
            pathRecalcCooldown = computeRepathCooldown(distance);
        }
    }

    private int computeRepathCooldown(double distance) {
        int base = (int) Math.ceil(distance * 0.45);
        return Mth.m_14045_(base, 6, 24);
    }

    private boolean ownerMovedSignificantly(LivingEntity owner) {
        if (Double.isNaN(lastOwnerX)) {
            return true;
        }
        double dx = owner.m_20185_() - this.lastOwnerX;
        double dy = owner.m_20186_() - this.lastOwnerY;
        double dz = owner.m_20189_() - this.lastOwnerZ;
        return dx * dx + dy * dy + dz * dz > 1.0D;
    }

    private void rememberOwnerPosition(LivingEntity owner) {
        this.lastOwnerX = owner.m_20185_();
        this.lastOwnerY = owner.m_20186_();
        this.lastOwnerZ = owner.m_20189_();
    }

    private void resetPathTracking() {
        this.pathRecalcCooldown = 0;
        this.lastOwnerX = Double.NaN;
        this.lastOwnerY = Double.NaN;
        this.lastOwnerZ = Double.NaN;
    }
}
