package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

/**
 * Simple flee behavior for Stegonaut - runs away from Raevyx and other Stegonauts.
 * Replaces the problematic play-dead mechanic with straightforward avoidance.
 */
public class StegonautFleeFromPredatorsGoal extends Goal {
    private final Stegonaut stegonaut;
    private final double fleeSpeed;
    private final double detectionRange;
    private LivingEntity threatEntity;
    private Path fleePath;
    private int fleeTimer;
    private static final int FLEE_DURATION = 100; // 5 seconds
    private static final double MIN_FLEE_DISTANCE = 16.0D; // Stop fleeing when 16 blocks away

    public StegonautFleeFromPredatorsGoal(Stegonaut stegonaut, double fleeSpeed, double detectionRange) {
        this.stegonaut = stegonaut;
        this.fleeSpeed = fleeSpeed;
        this.detectionRange = detectionRange;
        this.m_7021_(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean m_8036_() {
        // Don't flee if sleeping, dying, or in water (they hate water already)
        if (stegonaut.m_5803_() || stegonaut.isDying() || stegonaut.m_20072_()) {
            return false;
        }

        // Don't flee if ordered to sit
        if (stegonaut.m_21827_()) {
            return false;
        }

        // Look for threatening entities nearby
        List<LivingEntity> nearbyEntities = stegonaut.m_9236_().m_6443_(
                LivingEntity.class,
                stegonaut.m_20191_().m_82400_(detectionRange),
                entity -> entity.m_6084_() && isThreateningEntity(entity)
        );

        if (nearbyEntities.isEmpty()) {
            return false;
        }

        // Find the closest threat
        LivingEntity closestThreat = null;
        double closestDistSq = Double.MAX_VALUE;

        for (LivingEntity entity : nearbyEntities) {
            double distSq = stegonaut.m_20280_(entity);
            if (distSq < closestDistSq) {
                closestDistSq = distSq;
                closestThreat = entity;
            }
        }

        if (closestThreat == null) {
            return false;
        }

        // Try to find a flee path away from the threat
        Vec3 fleePos = DefaultRandomPos.m_148407_(stegonaut, 16, 7, closestThreat.m_20182_());
        if (fleePos == null) {
            return false;
        }

        // Check if the flee position is actually farther from the threat
        if (closestThreat.m_20275_(fleePos.f_82479_, fleePos.f_82480_, fleePos.f_82481_) < closestDistSq) {
            return false;
        }

        PathNavigation navigation = stegonaut.m_21573_();
        Path path = navigation.m_26524_(fleePos.f_82479_, fleePos.f_82480_, fleePos.f_82481_, 0);

        if (path == null || !path.m_77403_()) {
            return false;
        }

        this.threatEntity = closestThreat;
        this.fleePath = path;
        return true;
    }

    @Override
    public boolean m_8045_() {
        // Stop fleeing if conditions change
        if (stegonaut.m_5803_() || stegonaut.m_20072_()) {
            return false;
        }

        // Stop if we've fled far enough
        if (threatEntity != null && stegonaut.m_20280_(threatEntity) > MIN_FLEE_DISTANCE * MIN_FLEE_DISTANCE) {
            return false;
        }

        // Stop if the threat is gone
        if (threatEntity == null || !threatEntity.m_6084_() || threatEntity.m_213877_()) {
            return false;
        }

        // Stop if we've been fleeing too long
        if (fleeTimer > FLEE_DURATION) {
            return false;
        }

        return true;
    }

    @Override
    public void m_8056_() {
        if (fleePath != null) {
            stegonaut.m_21573_().m_26536_(fleePath, fleeSpeed);
        }
        fleeTimer = 0;
    }

    @Override
    public void m_8041_() {
        threatEntity = null;
        fleePath = null;
        fleeTimer = 0;
        stegonaut.m_21573_().m_26573_();
    }

    @Override
    public void m_8037_() {
        fleeTimer++;

        // Continue fleeing away from the threat
        if (threatEntity != null && threatEntity.m_6084_()) {
            // Occasionally recalculate flee path
            if (fleeTimer % 20 == 0) {
                Vec3 fleePos = DefaultRandomPos.m_148407_(stegonaut, 16, 7, threatEntity.m_20182_());
                if (fleePos != null) {
                    stegonaut.m_21573_().m_26519_(fleePos.f_82479_, fleePos.f_82480_, fleePos.f_82481_, fleeSpeed);
                }
            }
        }
    }

    /**
     * Check if an entity is threatening to the Stegonaut
     */
    private boolean isThreateningEntity(LivingEntity entity) {
        // Flee from Raevyx (dangerous predator)
        if (entity instanceof Raevyx raevyx) {
            // If tamed, only flee from wild Raevyx
            if (stegonaut.m_21824_()) {
                return !raevyx.m_21824_();
            }
            return true;
        }

        // Flee from other Stegonauts (territorial behavior)
        if (entity instanceof Stegonaut otherStegonaut) {
            // Don't flee from self or if both are tamed
            if (otherStegonaut == stegonaut) {
                return false;
            }
            // If tamed, don't flee from other tamed stegonauts
            if (stegonaut.m_21824_() && otherStegonaut.m_21824_()) {
                return false;
            }
            return true;
        }

        return false;
    }
}
