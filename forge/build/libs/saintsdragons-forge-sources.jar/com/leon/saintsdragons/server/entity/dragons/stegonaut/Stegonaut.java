package com.leon.saintsdragons.server.entity.dragons.stegonaut;

import com.leon.saintsdragons.server.ai.goals.stegonaut.*;
import com.leon.saintsdragons.server.entity.ability.abilities.stegonaut.StegonautPassiveBuffAbility;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.handlers.StegonautAnimationHandler;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.handlers.StegonautSoundProfile;
import com.leon.saintsdragons.server.entity.handler.DragonSoundHandler;
import com.leon.saintsdragons.server.entity.interfaces.DragonSoundProfile;
import com.leon.saintsdragons.server.entity.interfaces.DragonSleepCapable;
import com.leon.saintsdragons.server.entity.interfaces.SoundHandledDragon;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.common.registry.ModSounds;
import com.leon.saintsdragons.common.registry.stegonaut.StegonautAbilities;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import javax.annotation.Nonnull;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.keyframe.event.SoundKeyframeEvent;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Primitive Drake - A simple ground drake that wanders around and flees from threats.
 * No complex abilities, just basic AI and cute behavior.
 * Features:
 * - Sleep behavior: Sleeps at night, awake during day. Simple nap system for short rests.
 * - Flee behavior: Runs away from Raevyx and other Stegonauts when threatened
 * - Protective aura: Grants resistance and absorption to nearby players and allies
 * - NOT rideable: Too small and simple to be a mount
 */
public class Stegonaut extends DragonEntity implements DragonSleepCapable, SoundHandledDragon {
    
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final StegonautAnimationHandler animationController = new StegonautAnimationHandler(this);
    private final DragonSoundHandler soundHandler = new DragonSoundHandler(this);
    private final com.leon.saintsdragons.server.entity.sleep.DragonRestManager restManager = new com.leon.saintsdragons.server.entity.sleep.DragonRestManager(this);
    // Passive aura that applies resistance and absorption to allies
    private final StegonautPassiveBuffAbility passiveBuffAbility =
            new StegonautPassiveBuffAbility(this);

    // ===== CLIENT LOCATOR CACHE (client-side only) =====
    private final Map<String, Vec3> clientLocatorCache = new ConcurrentHashMap<>();

    // ===== AMBIENT SOUND SYSTEM =====
    private int ambientSoundTimer;
    private int nextAmbientSoundDelay;
    private static final int MIN_AMBIENT_DELAY = 200;  // 10 seconds
    private static final int MAX_AMBIENT_DELAY = 600;  // 30 seconds

    // ===== VOCAL ENTRIES =====
    // IMPORTANT: Keys MUST match animation trigger names registered in StegonautAnimationHandler
    private static final Map<String, VocalEntry> VOCAL_ENTRIES = new VocalEntryBuilder()
            .add("grumble1", "action", "animation.stegonaut.grumble1", ModSounds.STEGONAUT_GRUMBLE_1, 0.6f, 1.1f, 0.2f, false, false, true)
            .add("grumble2", "action", "animation.stegonaut.grumble2", ModSounds.STEGONAUT_GRUMBLE_2, 0.6f, 1.1f, 0.2f, false, false, true)
            .add("grumble3", "action", "animation.stegonaut.grumble3", ModSounds.STEGONAUT_GRUMBLE_3, 0.6f, 1.1f, 0.2f, false, false, true)
            .add("hurt", "action", "animation.stegonaut.hurt", ModSounds.STEGONAUT_HURT, 1.0f, 0.95f, 0.1f, false, true, true)
            .add("die", "action", "animation.stegonaut.die", ModSounds.STEGONAUT_DIE, 1.2f, 1.0f, 0.0f, false, true, true)
            .build();

    @Override
    public Map<String, VocalEntry> getVocalEntries() {
        return VOCAL_ENTRIES;
    }

    @Override
    public DragonSoundProfile getSoundProfile() {
        return StegonautSoundProfile.INSTANCE;
    }

    // Sleep system fields
    private boolean sleeping = false;
    private boolean sleepTransitioning = false;
    private int napTicks = 0; // For short naps
    private int napCooldown = 0; // Cooldown between naps
    private boolean dayNapQueued = false;
    
    // Synced sleep state for client-side animation
    private static final net.minecraft.network.syncher.EntityDataAccessor<Boolean> DATA_SLEEPING = 
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Stegonaut.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);
    
    
    // Synced ground movement state for reliable animation
    private static final net.minecraft.network.syncher.EntityDataAccessor<Integer> DATA_GROUND_MOVE_STATE = 
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Stegonaut.class, net.minecraft.network.syncher.EntityDataSerializers.f_135028_);
    
    // Binding state for Drake Binder
    private boolean boundToBinder = false;

    // Client-side smoothing for ground movement states to avoid animation flicker when idle
    private static final int CLIENT_GROUND_STATE_STABLE_TICKS = 3;
    private int clientGroundMoveState = 0;
    private int clientGroundMoveTarget = 0;
    private int clientGroundMoveHold = 0;

    // Server-side hold timer to prevent flickering when stopping
    private int walkAnimationHoldTicks = 0;
    
    public Stegonaut(EntityType<? extends Stegonaut> entityType, Level level) {
        super(entityType, level);
        // Initialize animation state
        animationController.initializeAnimation();

        // Desynchronize ambient system across instances to avoid synchronized vocals/animations
        RandomSource rng = this.m_217043_();
        this.ambientSoundTimer = rng.m_188503_(80); // small random offset
        this.nextAmbientSoundDelay = MIN_AMBIENT_DELAY + rng.m_188503_(MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY);
    }
    
    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(DATA_SLEEPING, false);
        this.f_19804_.m_135372_(DATA_GROUND_MOVE_STATE, 0); // 0=idle, 1=walking, 2=running
    }
    
    @Override
    protected void m_8099_() {
        // Basic AI goals - simple and cute!
        this.f_21345_.m_25352_(0, new FloatGoal(this));
        this.f_21345_.m_25352_(0, new StegonautSleepGoal(this)); // Highest priority - nighttime sleep only
        this.f_21345_.m_25352_(1, new StegonautLeaveWaterGoal(this, 1.15D)); // Emergency priority - get out of water fast
        this.f_21345_.m_25352_(2, new StegonautFleeFromPredatorsGoal(this, 0.6D, 12.0D)); // Flee from Raevyx and other Stegonauts
        this.f_21345_.m_25352_(3, new StegonautFollowOwnerGoal(this));
        this.f_21345_.m_25352_(4, new StegonautNapGoal(this)); // Daytime napping - separate from sleep
        this.f_21345_.m_25352_(5, new StegonautGroundWanderGoal(this, 0.35D, 120));
        this.f_21345_.m_25352_(6, new StegonautLookAtPlayerGoal(this, Player.class, 8.0F));
        this.f_21345_.m_25352_(7, new StegonautRandomLookAroundGoal(this));
    }
    
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.m_21552_()
                .m_22268_(Attributes.f_22276_, 100.0D)
                .m_22268_(Attributes.f_22279_, 0.40D)
                .m_22268_(Attributes.f_22281_, 2.0D)
                .m_22268_(Attributes.f_22284_, 15.0D)
                .m_22268_(Attributes.f_22277_, 16.0D);
    }
    
    // Ground drake, no flying!
    public boolean isFlying() {
        return false;
    }
    
    /**
     * Check if the wyvern is in a muted state (sitting/staying)
     * Used by sound system to prevent ambient sounds
     */
    public boolean isStayOrSitMuted() {
        return this.m_21827_() || this.m_21825_();
    }
    
    /**
     * Primitive Drakes are NOT rideable - they're too small and simple
     */
    
    @Override
    public boolean canOwnerCommand(Player player) {
        // Primitive Drakes respond to commands from their owner without requiring crouching
        return player != null && player.equals(this.m_269323_());
    }
    
    public boolean isTameable() {
        return true; // Can be tamed like other dragons
    }
    
    @Override
    public boolean m_6898_(@Nonnull net.minecraft.world.item.ItemStack stack) {
        // Simple food - maybe raw meat or fish?
        return stack.m_150930_(net.minecraft.world.item.Items.f_42579_) || 
               stack.m_150930_(net.minecraft.world.item.Items.f_42485_) ||
               stack.m_150930_(net.minecraft.world.item.Items.f_42581_) ||
               stack.m_150930_(net.minecraft.world.item.Items.f_42658_) ||
               stack.m_150930_(net.minecraft.world.item.Items.f_42526_) ||
               stack.m_150930_(net.minecraft.world.item.Items.f_42527_);
    }
    
    @Override
    public Vec3 getHeadPosition() {
        // Use eye position - more reliable than bone positions
        return this.m_146892_();
    }
    
    @Override
    public Vec3 getMouthPosition() {
        // Simple mouth position - just the head area
        return this.m_20182_().m_82520_(0, this.m_20206_() * 0.8, 0);
    }
    
    @Override
    public DragonAbilityType<?, ?> getPrimaryAttackAbility() {
        // Simple drake has no abilities - just runs away!
        return null;
    }

    @Override
    protected DragonAbilityType<?, ?> getHurtAbilityType() {
        return StegonautAbilities.STEGONAUT_HURT;
    }

    @Override
    public int getDeathAnimationDurationTicks() {
        return 75; // 3.75s - matches primitive drake death animation length
    }

    @Override
    public boolean m_6469_(@NotNull DamageSource source, float amount) {
        // During dying sequence, ignore all damage except the final generic kill used by DieAbility
        if (isDying()) {
            if (source.m_276093_(DamageTypes.f_286979_)) {
                return super.m_6469_(source, amount);
            }
            return false;
        }

        // Intercept lethal damage to play custom death ability first
        if (handleLethalDamage(source, amount, StegonautAbilities.STEGONAUT_DIE)) {
            return true;
        }

        return super.m_6469_(source, amount);
    }

    @Override
    protected void m_6153_() {
        // Override vanilla death animation to prevent rotation/flop
        // Just increment death time without the rotation animation
        ++this.f_20919_;
        if (this.f_20919_ >= 20) {
            this.m_142687_(net.minecraft.world.entity.Entity.RemovalReason.KILLED);
            this.m_21226_();
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Use the new smooth animation controller
        AnimationController<Stegonaut> movementController = new AnimationController<>(this, "movement", 1, animationController::handleMovementAnimation);
        movementController.setSoundKeyframeHandler(this::onAnimationSound);
        controllers.add(movementController);
        
        // Add action controller for grumble animations
        AnimationController<Stegonaut> actionController = new AnimationController<>(this, "action", 1, animationController::actionPredicate);
        animationController.setupActionController(actionController);
        actionController.setSoundKeyframeHandler(this::onAnimationSound);
        controllers.add(actionController);
    }
    
    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
    
    @Override
    public AgeableMob m_142606_(@Nonnull ServerLevel level, @Nonnull AgeableMob other) {
        // Simple breeding - just spawn a new Primitive Drake
        return ModEntities.STEGONAUT.get().m_20615_(level);
    }

    public static boolean canSpawnHere(EntityType<? extends Stegonaut> type,
                                       LevelAccessor level,
                                       MobSpawnType spawnType,
                                       BlockPos pos,
                                       RandomSource random) {
        if (!Animal.m_218104_(type, level, spawnType, pos, random)) {
            return false;
        }

        // Reject waterlogged blocks or fluid directly around the spawn
        if (!level.m_6425_(pos).m_76178_()) {
            return false;
        }
        if (!level.m_6425_(pos.m_7495_()).m_76178_()) {
            return false;
        }

        // Optional: enforce a sturdy block underneath
        return level.m_8055_(pos.m_7495_()).m_60783_(level, pos.m_7495_(), Direction.UP);
    }
    
    // ===== INTERACTION HANDLING =====
    
    @Override
    public @NotNull InteractionResult m_6071_(@NotNull Player player, @NotNull InteractionHand hand) {
        // Prevent any mounting attempts - Primitive Drakes are NOT rideable
        if (hand == InteractionHand.MAIN_HAND && player.m_21120_(hand).m_41619_()) {
            // If player is trying to mount (shift+right-click), deny it
            if (player.m_6144_()) {
                return InteractionResult.PASS; // Don't allow mounting
            }
        }
        
        if (!this.m_21824_()) {
            return handleUntamedInteraction(player, hand);
        } else {
            return handleTamedInteraction(player, hand);
        }
    }
    
    /**
     * Handle interactions with untamed drakes (100% success taming)
     */
    private InteractionResult handleUntamedInteraction(Player player, InteractionHand hand) {
        ItemStack itemstack = player.m_21120_(hand);
        
        if (!this.m_6898_(itemstack)) {
            return InteractionResult.PASS;
        }
        
        // Taming logic must be server-only to avoid client-only visual state changes
        if (!this.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                itemstack.m_41774_(1);
            }

            // Trigger eat animation
            this.triggerAnim("action", "eat");

            // 100% success chance for Primitive Drake!
            this.m_21828_(player);
            this.m_21839_(true);
            this.setCommand(1); // Set command to Sit (1) to match the sitting state

            this.m_9236_().m_7605_(this, (byte) 7); // Hearts particles
            
            // Send taming success message
            player.m_5661_(
                Component.m_237110_("entity.saintsdragons.stegonaut.tamed", this.m_7755_()),
                true
            );
            
            // Trigger advancement for taming Primitive Drake
            if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
                var advancement = serverPlayer.f_8924_.m_129889_()
                    .m_136041_(com.leon.saintsdragons.SaintsDragons.rl("tame_stegonaut"));
                if (advancement != null) {
                    serverPlayer.m_8960_().m_135988_(advancement, "tame_stegonaut");
                }
            }
        }
        
        return InteractionResult.m_19078_(this.m_9236_().f_46443_);
    }
    
    /**
     * Handle interactions with tamed drakes (feeding, commands)
     */
    private InteractionResult handleTamedInteraction(Player player, InteractionHand hand) {
        ItemStack itemstack = player.m_21120_(hand);
        
        // Handle feeding for healing
        if (this.m_6898_(itemstack)) {
            return handleFeeding(player, itemstack);
        }
        
        // Handle owner commands
        if (player.equals(this.m_269323_())) {
            // Command cycling - Shift+Right-click cycles through commands
            if (this.canOwnerCommand(player) && itemstack.m_41619_() && hand == InteractionHand.MAIN_HAND) {
                return handleCommandCycling(player);
            }
        }
        
        // Fall back to base implementation for other interactions
        return super.m_6071_(player, hand);
    }
    
    /**
     * Handle feeding tamed drakes for healing
     */
    private InteractionResult handleFeeding(Player player, ItemStack itemstack) {
        if (!this.m_9236_().f_46443_) {
            if (!player.m_150110_().f_35937_) {
                itemstack.m_41774_(1);
            }

            // Trigger eat animation
            this.triggerAnim("action", "eat");

            // Heal the drake when fed
            float healAmount = 8.0f; // Heal 4 hearts per food item
            float oldHealth = this.m_21223_();
            float newHealth = Math.min(oldHealth + healAmount, this.m_21233_());
            this.m_21153_(newHealth);
            
            // Play eating sound and particles
            this.m_9236_().m_7605_(this, (byte) 6); // Eating sound
            this.m_9236_().m_7605_(this, (byte) 7); // Hearts particles
            
            // Send appropriate feedback message
            String messageKey = (newHealth >= this.m_21233_()) 
                ? "entity.saintsdragons.stegonaut.fed"
                : "entity.saintsdragons.stegonaut.fed_partial";
                
            player.m_5661_(
                Component.m_237110_(messageKey, this.m_7755_()),
                true
            );
        }
        
        return InteractionResult.m_19078_(this.m_9236_().f_46443_);
    }
    
    /**
     * Handle command cycling (Follow/Sit/Wander)
     */
    private InteractionResult handleCommandCycling(Player player) {
        // Get current command and cycle to next
        int currentCommand = this.getCommand();
        int nextCommand = (currentCommand + 1) % 3; // 0=Follow, 1=Sit, 2=Wander

        // Apply the new command
        this.setCommand(nextCommand);
        applyCommandState(nextCommand);

        // Send feedback message to player (action bar), server-side only to avoid duplicates
        if (!this.m_9236_().f_46443_) {
            player.m_5661_(
                Component.m_237110_(
                    "entity.saintsdragons.all.command_" + nextCommand,
                    this.m_7755_()
                ),
                true
            );
        }

        return InteractionResult.SUCCESS;
    }
    
    /**
     * Apply the command state to the drake
     */
    private void applyCommandState(int command) {
        switch (command) {
            case 0: // Follow
                this.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
            case 1: // Sit
                this.m_21839_(true);
                break;
            case 2: // Wander
                this.m_21839_(false);
                // Let updateSittingProgress() handle the "up" animation transition naturally
                break;
        }
    }

    public void refreshCommandState() {
        applyCommandState(this.getCommand());
    }
    
    // ===== SOUND SYSTEM =====
    
    private int grumbleCooldown = 0;
    
    /**
     * Get the sound handler for this drake
     */
    public DragonSoundHandler getSoundHandler() {
        return soundHandler;
    }

    public com.leon.saintsdragons.server.entity.sleep.DragonRestManager getRestManager() {
        return restManager;
    }


    /**
     * Play random grumble sounds for personality
     */
    public void playRandomGrumble() {
        if (m_9236_().f_46443_ || isDying()) return;

        float grumbleChance = m_217043_().m_188501_();
        String vocalKey;

        if (grumbleChance < 0.4f) {
            vocalKey = "grumble1";
        } else if (grumbleChance < 0.7f) {
            vocalKey = "grumble2";
        } else {
            vocalKey = "grumble3";
        }

        // Play the grumble sound (this will trigger the animation automatically)
        getSoundHandler().playVocal(vocalKey);
    }

    /**
     * Plays appropriate ambient sound based on drake's current mood and state
     */
    private void playCustomAmbientSound() {
        RandomSource random = m_217043_();

        // Don't make ambient sounds if we're in combat or dying
        if (isDying() || m_5448_() != null) {
            return;
        }

        String vocalKey = null;

        // Simple drake has simple moods - mostly just grumbles
        float moodRoll = random.m_188501_();

        if (moodRoll < 0.4f) {
            vocalKey = "grumble1";
        } else if (moodRoll < 0.7f) {
            vocalKey = "grumble2";
        } else {
            vocalKey = "grumble3";
        }

        // Play/animate if we chose one
        if (vocalKey != null) {
            this.getSoundHandler().playVocal(vocalKey);
        }
    }

    /**
     * Handles all the ambient grumbling and personality sounds
     * Because a silent drake is a boring drake
     */
    private void handleAmbientSounds() {
        if (isDying() || m_5803_() || isSleepTransitioning()) {
            return;
        }

        ambientSoundTimer++;

        // Time to make some noise?
        if (ambientSoundTimer >= nextAmbientSoundDelay) {
            playCustomAmbientSound();
            resetAmbientSoundTimer();
        }
    }

    /**
     * Resets the ambient sound timer with some randomness
     */
    private void resetAmbientSoundTimer() {
        RandomSource random = m_217043_();
        ambientSoundTimer = 0;
        nextAmbientSoundDelay = MIN_AMBIENT_DELAY + random.m_188503_(MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY);
    }
    
    @Override
    public void m_8107_() {
        super.m_8107_();
        if (!this.m_9236_().f_46443_) {
            tickAnimationStates();
        }
    }

    // ===== SLEEP SYSTEM IMPLEMENTATION =====
    
    @Override
    public boolean m_5803_() {
        // Use synced data for client-side animation detection
        return m_9236_().f_46443_ ? this.f_19804_.m_135370_(DATA_SLEEPING) : sleeping;
    }
    
    @Override
    public boolean isSleepTransitioning() {
        return sleepTransitioning;
    }
    
    @Override
    public boolean isSleepSuppressed() {
        // Don't sleep while in combat, in water, or while being ridden
        return m_5448_() != null || m_20072_() || m_20160_();
    }
    
    @Override
    public void startSleepEnter() {
        if (!sleeping && !sleepTransitioning) {
            sleepTransitioning = true;
            sleeping = true;
            // Sync sleep state to client
            this.f_19804_.m_135381_(DATA_SLEEPING, true);
            // Simple sleep - just lie down, no complex transitions
            m_21839_(true);
        }
    }
    
    @Override
    public void startSleepExit() {
        if (sleeping && !sleepTransitioning) {
            sleepTransitioning = true;
            sleeping = false;
            // Sync sleep state to client
            this.f_19804_.m_135381_(DATA_SLEEPING, false);
            // Wake up - restore pose based on current command
            refreshCommandState();
        }
    }
    
    @Override
    public SleepPreferences getSleepPreferences() {
        // Simple sleep preferences: sleep at night, awake during day
        return new SleepPreferences(
            true,  // canSleepAtNight
            true,  // canSleepDuringDay (for occasional naps)
            false, // requiresShelter (simple drake doesn't need shelter)
            false, // avoidsThunderstorms (not afraid of storms)
            false  // sleepsNearOwner (independent)
        );
    }
    
    @Override
    public boolean canSleepNow() {
        // Can sleep at night or take a nap during day
        if (m_9236_().m_46461_()) {
            // During day, only allow short naps if not on cooldown
            if (napCooldown <= 0 && m_217043_().m_188501_() < 0.01f) {
                dayNapQueued = true;
                return true;
            }
            dayNapQueued = false;
            return false;
        } else {
            dayNapQueued = false;
            // At night, always allow sleep
            return true;
        }
    }
    
    @Override
    public void m_8119_() {
        super.m_8119_();

        // Tick sound handler
        soundHandler.tick();

        // Handle ambient sounds (server-side only)
        if (!m_9236_().f_46443_) {
            handleAmbientSounds();
        }

        // Tick passive buff ability (only if alive)
        if (this.m_6084_()) {
            passiveBuffAbility.tick();
        } else {
            // Clean up resistance buffs when dead
            passiveBuffAbility.cleanup();
        }

        // Handle sleep transition completion
        if (sleepTransitioning) {
            sleepTransitioning = false;
        }

        // Handle nap system
        if (napTicks > 0) {
            napTicks--;
            if (napTicks <= 0) {
                // Nap finished, wake up
                if (sleeping) {
                    startSleepExit();
                }
                napCooldown = 1200 + m_217043_().m_188503_(1800); // 1-2.5 minute cooldown
            }
        }

        // Handle nap cooldown
        if (napCooldown > 0) {
            napCooldown--;
        }

        // Handle grumble cooldown (now deprecated - replaced by handleAmbientSounds)
        if (grumbleCooldown > 0) {
            grumbleCooldown--;
        }

        // Handle sit progress animation
        if (!m_9236_().f_46443_) {
            if (this.m_21827_()) {
                if (sitProgress < maxSitTicks()) {
                    sitProgress++;
                    this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
                }
            } else if (sitProgress > 0f) {
                sitProgress--;
                if (sitProgress < 0f) sitProgress = 0f;
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        }

        // Update client-side sit progress from synchronized data
        if (m_9236_().f_46443_) {
            prevSitProgress = sitProgress;
            sitProgress = this.f_19804_.m_135370_(DATA_SIT_PROGRESS);
        }
    }
    
    /**
     * Start a short nap (1-2 minutes)
     */
    public void startNap() {
        if (!sleeping && napCooldown <= 0) {
            napTicks = 1200 + m_217043_().m_188503_(1200); // 1-2 minutes
        }
    }

    public boolean isDayNapQueued() {
        return dayNapQueued;
    }

    public boolean consumeDayNapQueued() {
        boolean queued = dayNapQueued;
        dayNapQueued = false;
        return queued;
    }

    
    // ===== SOUND KEYFRAME HANDLING =====
    
    /**
     * Handle sound keyframes from animations (for grumble sounds)
     */
    public void onAnimationSound(SoundKeyframeEvent<Stegonaut> event) {
        // Delegate all keyframed sounds to the sound handler
        this.getSoundHandler().handleAnimationSound(this, event.getKeyframeData(), event.getController());
    }
    
    // ===== CLIENT LOCATOR CACHE METHODS =====
    
    /**
     * Client-only: stash per-frame sampled locator world positions
     */
    public void setClientLocatorPosition(String name, Vec3 pos) {
        if (m_9236_().f_46443_) {
            this.clientLocatorCache.put(name, pos);
        }
    }
    
    /**
     * Client-only: retrieve cached locator world position
     */
    public Vec3 getClientLocatorPosition(String name) {
        return this.clientLocatorCache.get(name);
    }
    
    
    // ===== MOVEMENT STATE METHODS =====
    
    /**
     * Check if the drake is currently walking
     */
    public boolean isWalking() {
        if (m_9236_().f_46443_) {
            int s = getEffectiveGroundState();
            return s == 1; // walking state
        }
        int s = this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);
        return s == 1; // walking state
    }
    
    /**
     * Check if the drake is currently running
     */
    public boolean isRunning() {
        if (m_9236_().f_46443_) {
            int s = getEffectiveGroundState();
            return s == 2; // running state
        }
        int s = this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);
        return s == 2; // running state
    }
    
    /**
     * Get the effective ground movement state (with client-side prediction)
     */
    public int getEffectiveGroundState() {
        if (m_9236_().f_46443_) {
            int syncedState = this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);

            if (clientGroundMoveTarget != syncedState) {
                clientGroundMoveTarget = syncedState;
                clientGroundMoveHold = 0;
            } else if (clientGroundMoveState != clientGroundMoveTarget) {
                clientGroundMoveHold++;
                if (clientGroundMoveHold >= CLIENT_GROUND_STATE_STABLE_TICKS) {
                    clientGroundMoveState = clientGroundMoveTarget;
                    clientGroundMoveHold = 0;
                }
            } else {
                clientGroundMoveHold = 0;
            }

            if (m_5803_() || m_21827_()) {
                clientGroundMoveState = 0;
                clientGroundMoveTarget = 0;
                clientGroundMoveHold = 0;
            }

            return clientGroundMoveState;
        }
        return this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);
    }
    
    /**
     * Update animation states based on current movement
     */
    private void tickAnimationStates() {
        int moveState = 0; // Default to idle

        if (!m_5803_() && !m_21827_()) {
            // Simple logic: If navigation is active OR entity is moving, play walk animation
            boolean hasActivePath = this.m_21573_().m_26572_();
            boolean isActuallyMoving = this.m_20184_().m_165925_() > 0.001;

            if (hasActivePath || isActuallyMoving) {
                moveState = 1; // Walking
                walkAnimationHoldTicks = 8; // Hold walk animation for 8 ticks after stopping
            } else if (walkAnimationHoldTicks > 0) {
                // Keep playing walk animation while decelerating
                moveState = 1;
                walkAnimationHoldTicks--;
            }
        } else {
            // Force reset hold timer when sleeping/sitting
            walkAnimationHoldTicks = 0;
        }

        // Update state only if changed to reduce network traffic
        if (this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE) != moveState) {
            this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, moveState);
        }
    }
    
    // ===== SAVE/LOAD DATA =====
    
    @Override
    public void m_7380_(net.minecraft.nbt.@NotNull CompoundTag tag) {
        super.m_7380_(tag);

        tag.m_128405_("StegonautCommand", this.getCommand());
        tag.m_128379_("StegonautOrderedSit", this.m_21827_());

        // Save sleep state
        tag.m_128379_("Sleeping", sleeping);
        tag.m_128379_("SleepTransitioning", sleepTransitioning);
        tag.m_128405_("NapTicks", napTicks);
        tag.m_128405_("NapCooldown", napCooldown);

        // Save grumble cooldown
        tag.m_128405_("GrumbleCooldown", grumbleCooldown);

        // Save binding state
        tag.m_128379_("BoundToBinder", boundToBinder);

        // Save sit progress for animation state
        tag.m_128350_("SitProgress", sitProgress);

        // Save rest state manager
        restManager.save(tag);
    }
    
    @Override
    public void m_7378_(net.minecraft.nbt.@NotNull CompoundTag tag) {
        super.m_7378_(tag);

        int restoredCommand = this.getCommand();
        if (tag.m_128441_("StegonautCommand")) {
            restoredCommand = tag.m_128451_("StegonautCommand");
            this.setCommand(restoredCommand);
        }
        boolean restoredOrderedSit = tag.m_128441_("StegonautOrderedSit")
                ? tag.m_128471_("StegonautOrderedSit")
                : restoredCommand == 1;

        // Load sleep state
        sleeping = tag.m_128471_("Sleeping");
        sleepTransitioning = tag.m_128471_("SleepTransitioning");
        napTicks = tag.m_128451_("NapTicks");
        napCooldown = tag.m_128451_("NapCooldown");

        // Load grumble cooldown
        grumbleCooldown = tag.m_128451_("GrumbleCooldown");

        // Load binding state
        boundToBinder = tag.m_128471_("BoundToBinder");

        // Sync sleep state to client
        this.f_19804_.m_135381_(DATA_SLEEPING, sleeping);

        // Load sit progress for animation state prior to command refresh so poses align immediately
        if (tag.m_128441_("SitProgress")) {
            sitProgress = tag.m_128457_("SitProgress");
            this.f_19804_.m_135381_(DragonEntity.DATA_SIT_PROGRESS, sitProgress);
        }

        // Align baseline command state before restoring extra behaviors
        refreshCommandState();
        this.m_21839_(restoredOrderedSit);

        // Restore rest state manager (animation restoration not needed yet - Stegonaut doesn't have animation state system)
        restManager.load(tag);
    }
    
    // ===== DRAKE BINDER FUNCTIONALITY =====
    
    /**
     * Check if this drake is bound to a Drake Binder
     */
    public boolean isBoundToBinder() {
        return boundToBinder;
    }
    
    /**
     * Set the binding state for Drake Binder
     */
    public void setBoundToBinder(boolean bound) {
        this.boundToBinder = bound;
    }
    
    /**
     * Check if this drake can be bound (not sleeping, not dying, etc.)
     */
    public boolean canBeBound() {
        return !m_5803_() && !isDying();
    }
}

