package com.leon.saintsdragons.server.ai.goals.cindervane;

import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Follow-owner behaviour tuned for Amphitheres.
 * Mirrors the Lightning dragon implementation but with glider-friendly constants.
 */
public class CindervaneFollowOwnerGoal extends Goal {
    private final Cindervane amphithere;

    private static final double START_FOLLOW_DIST = 8.8;
    private static final double STOP_FOLLOW_DIST = 8.0;
    private static final double TELEPORT_DIST = 500.0;
    private static final double RUN_DIST = 10.0;
    private static final double FLIGHT_TRIGGER_DIST = 24.0;
    private static final double FLIGHT_HEIGHT_DIFF = 6.0;
    private static final double LANDING_DISTANCE = 10.0;
    private static final double HOVER_HEIGHT = 2.5;

    private int pathRecalcCooldown;
    private double lastOwnerX = Double.NaN;
    private double lastOwnerY = Double.NaN;
    private double lastOwnerZ = Double.NaN;

    public CindervaneFollowOwnerGoal(Cindervane dragon) {
        this.amphithere = dragon;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        if (!amphithere.m_21824_() || amphithere.m_21827_()) {
            return false;
        }

        // Don't start following while sitting down (but standing up is OK)
        if (amphithere.isSittingDownAnimation()) {
            return false;
        }

        // Only disable for Sit command (1), allow for both Follow (0) and Wander (2)
        if (amphithere.getCommand() == 1) {
            return false;
        }

        if (amphithere.m_5448_() != null && amphithere.m_5448_().m_6084_()) {
            return false;
        }

        LivingEntity owner = amphithere.m_269323_();
        if (owner == null || !owner.m_6084_()) {
            return false;
        }

        if (owner.m_9236_() != amphithere.m_9236_()) {
            return false;
        }

        double distSq = amphithere.m_20280_(owner);
        return distSq > START_FOLLOW_DIST * START_FOLLOW_DIST;
    }

    @Override
    public boolean m_8045_() {
        LivingEntity owner = amphithere.m_269323_();
        if (owner == null || !owner.m_6084_()) {
            return false;
        }

        // Stop following while sitting down (but standing up is OK)
        // Only disable for Sit command (1), allow for both Follow (0) and Wander (2)
        if (amphithere.m_21827_() || amphithere.isSittingDownAnimation() || amphithere.getCommand() == 1) {
            return false;
        }

        if (amphithere.m_5448_() != null && amphithere.m_5448_().m_6084_()) {
            return false;
        }

        if (owner.m_9236_() != amphithere.m_9236_()) {
            return false;
        }

        double distSq = amphithere.m_20280_(owner);
        return distSq > STOP_FOLLOW_DIST * STOP_FOLLOW_DIST;
    }

    @Override
    public void m_8056_() {
        resetPathTracking();
    }

    @Override
    public void m_8041_() {
        amphithere.setRunning(false);
        amphithere.m_21573_().m_26573_();
        amphithere.setGroundMoveStateFromAI(0);
        resetPathTracking();
    }

    @Override
    public void m_8037_() {
        LivingEntity owner = amphithere.m_269323_();
        if (owner == null) {
            return;
        }

        double distance = amphithere.m_20270_(owner);

        if (distance > TELEPORT_DIST) {
            amphithere.m_6021_(owner.m_20185_(), owner.m_20186_() + 2.0, owner.m_20189_());
            amphithere.setFlying(true);
            amphithere.setTakeoff(false);
            amphithere.setLanding(false);
            amphithere.setHovering(false);
            resetPathTracking();
            return;
        }

        amphithere.m_21563_().m_24960_(owner, 10.0f, 10.0f);

        boolean shouldFly = shouldTriggerFlight(owner, distance);
        if (shouldFly && !amphithere.m_29443_()) {
            amphithere.setFlying(true);
            amphithere.setTakeoff(true);
            amphithere.setLanding(false);
            amphithere.setHovering(false);
            resetPathTracking();
        } else if (amphithere.m_29443_() && distance < STOP_FOLLOW_DIST * 1.5) {
            // Properly land the dragon instead of making it hover in mid-air
            amphithere.setLanding(true);
            amphithere.setFlying(false);
            amphithere.setHovering(false);
            amphithere.setTakeoff(false);
            pathRecalcCooldown = 0;
        }

        if (amphithere.m_29443_()) {
            handleFlightFollowing(owner);
        } else {
            handleGroundFollowing(owner, distance);
        }
    }

    private void handleFlightFollowing(LivingEntity owner) {
        double targetY = owner.m_20186_() + owner.m_20206_() + HOVER_HEIGHT;
        Vec3 ownerLook = owner.m_20154_();
        double offsetX = -ownerLook.f_82479_ * 2.5;
        double offsetZ = -ownerLook.f_82481_ * 2.5;
        double verticalOffset = Math.sin(amphithere.f_19797_ * 0.2) * 0.25;

        double targetX = owner.m_20185_() + offsetX;
        double targetZ = owner.m_20189_() + offsetZ;

        double distanceToTargetSq = amphithere.m_20275_(targetX, targetY, targetZ);
        if (distanceToTargetSq > 1.0) {
            amphithere.m_21566_().m_6849_(
                    targetX,
                    targetY + verticalOffset,
                    targetZ,
                    amphithere.getFlightSpeed()
            );
        } else {
            amphithere.m_21573_().m_26573_();
        }
    }

    private void handleGroundFollowing(LivingEntity owner, double distance) {
        // Check if we should stop moving
        if (distance <= STOP_FOLLOW_DIST) {
            // Only update state if we were moving before
            if (amphithere.getGroundMoveState() > 0) {
                amphithere.m_21573_().m_26573_();
                amphithere.setRunning(false);
                amphithere.setGroundMoveStateFromAI(0);
            }
            pathRecalcCooldown = 0;
            return;
        }

        boolean shouldRun = distance > RUN_DIST;
        amphithere.setRunning(shouldRun);

        // Set appropriate animation state (0=idle, 1=walking, 2=running)
        int moveState = shouldRun ? 2 : 1;
        amphithere.setGroundMoveStateFromAI(moveState);

        // Adjust speed based on movement style and distance
        double baseSpeed = shouldRun ? 1.1 : 0.7;
        double speed = baseSpeed * (1.0 + (distance / 40.0));
        speed = Math.min(speed, shouldRun ? 1.6 : 1.0); // Cap max speed

        updateGroundPath(owner, speed, distance, shouldRun);

        // Handle getting stuck
        if (amphithere.m_21573_().m_26577_()) {
            amphithere.m_21569_().m_24901_();
            amphithere.m_21573_().m_26573_();
            pathRecalcCooldown = 0;
        }
    }

    private boolean shouldTriggerFlight(LivingEntity owner, double distance) {
        if (amphithere.m_29443_()) {
            return !(distance < LANDING_DISTANCE && (owner.m_20186_() - amphithere.m_20186_()) < FLIGHT_HEIGHT_DIFF);
        }

        if (amphithere.isHovering() || !canTriggerFlight()) {
            return false;
        }

        if (distance < STOP_FOLLOW_DIST * 1.5) {
            return false;
        }

        boolean farAway = distance > FLIGHT_TRIGGER_DIST;
        boolean ownerAbove = (owner.m_20186_() - amphithere.m_20186_()) > FLIGHT_HEIGHT_DIFF;
        return farAway || ownerAbove;
    }

    private boolean canTriggerFlight() {
        return !amphithere.m_21827_()
                && !amphithere.m_6162_()
                && (amphithere.m_20096_() || amphithere.m_20069_())
                && amphithere.m_20197_().isEmpty()
                && amphithere.m_6688_() == null
                && !amphithere.m_20159_();
    }

    private void updateGroundPath(LivingEntity owner, double speed, double distance, boolean running) {
        if (pathRecalcCooldown > 0) {
            pathRecalcCooldown--;
        }

        boolean ownerMoved = ownerMovedSignificantly(owner);
        boolean navIdle = amphithere.m_21573_().m_26571_() || !amphithere.m_21573_().m_26572_();

        if (navIdle || ownerMoved || pathRecalcCooldown <= 0) {
            if (!amphithere.m_21573_().m_5624_(owner, speed)) {
                amphithere.m_21573_().m_26519_(owner.m_20185_(), owner.m_20186_(), owner.m_20189_(), speed);
            }
            rememberOwnerPosition(owner);
            pathRecalcCooldown = computeRepathCooldown(distance, running);
        }
    }

    private int computeRepathCooldown(double distance, boolean running) {
        int base = (int) Math.ceil(distance * (running ? 0.35 : 0.45));
        return Mth.m_14045_(base, running ? 4 : 6, running ? 16 : 22);
    }

    private void rememberOwnerPosition(LivingEntity owner) {
        this.lastOwnerX = owner.m_20185_();
        this.lastOwnerY = owner.m_20186_();
        this.lastOwnerZ = owner.m_20189_();
    }

    private boolean ownerMovedSignificantly(LivingEntity owner) {
        if (Double.isNaN(lastOwnerX)) {
            return true;
        }
        double dx = owner.m_20185_() - this.lastOwnerX;
        double dy = owner.m_20186_() - this.lastOwnerY;
        double dz = owner.m_20189_() - this.lastOwnerZ;
        return dx * dx + dy * dy + dz * dz > 1.2D;
    }

    private void resetPathTracking() {
        this.pathRecalcCooldown = 0;
        this.lastOwnerX = Double.NaN;
        this.lastOwnerY = Double.NaN;
        this.lastOwnerZ = Double.NaN;
    }
}
