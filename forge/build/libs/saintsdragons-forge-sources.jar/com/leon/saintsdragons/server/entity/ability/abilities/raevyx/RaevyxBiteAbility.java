package com.leon.saintsdragons.server.entity.ability.abilities.raevyx;

import com.leon.saintsdragons.server.entity.effect.raevyx.RaevyxLightningChainEntity;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.conductivity.ElectricalConductivityState;
import com.leon.saintsdragons.util.DragonMathUtil;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;

import java.util.*;

import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.*;

/**
 * Bite + chain lightning ability for LightningDragon.
 */
public class RaevyxBiteAbility extends DragonAbility<Raevyx> {
    // Tuning knobs
    private static final float BITE_DAMAGE = 15.0f;
    // Slightly larger reach to match large model scale and AI stop distance
    private static final double BITE_RANGE = 4.6;
    // Extra range when ridden to be more forgiving for small mobs
    private static final double BITE_RANGE_RIDDEN = 8.0; // match horn gore forgiveness while ridden
    // More forgiving cone; widen to reduce whiffs while steering
    private static final double BITE_ANGLE_DEG = 85.0; // half-angle of cone
    // Forward bite sweep extents
    private static final double BITE_SWIPE_HORIZONTAL = 2.5;
    private static final double BITE_SWIPE_HORIZONTAL_RIDDEN = 2.5;
    private static final double BITE_SWIPE_VERTICAL = 2.5;


    private static final float CHAIN_DAMAGE_BASE = 10.0f;
    private static final double CHAIN_RADIUS = 7.0;
    private static final int CHAIN_JUMPS = 5;
    private static final float CHAIN_FALLOFF = 0.75f;

    // Sections: startup (windup), active (hit frame), recovery
    private static final DragonAbilitySection[] TRACK = new DragonAbilitySection[] {
            new AbilitySectionDuration(AbilitySectionType.STARTUP, 3),
            new AbilitySectionDuration(AbilitySectionType.ACTIVE, 2),
            new AbilitySectionDuration(AbilitySectionType.RECOVERY, 3)
    };

    private boolean didHitThisActive = false;

    public RaevyxBiteAbility(DragonAbilityType<Raevyx, RaevyxBiteAbility> type, Raevyx user) {
        super(type, user, TRACK, 3);
    }

    @Override
    protected void beginSection(DragonAbilitySection section) {
        if (section == null) return;
        if (section.sectionType == AbilitySectionType.STARTUP) {
            // Trigger bite animation via GeckoLib action controller (one-shot)
            getUser().triggerAnim("action", "lightning_bite");
            didHitThisActive = false;
        }
    }

    @Override
    public void tickUsing() {
        DragonAbilitySection section = getCurrentSection();
        if (section == null) return;


        if (section.sectionType == AbilitySectionType.ACTIVE && !didHitThisActive) {
            // Sound is handled by animation keyframe in lightning_bite animation
            // Apply bite and chain once at the start of ACTIVE
            LivingEntity primary = findPrimaryTarget();
            // Fallback: use current target if within generous melee range
            if (primary == null) {
                LivingEntity t = getUser().m_5448_();
                if (t != null && t.m_6084_()) {
                    double d = t.m_20270_(getUser());
                    if (d <= 5.2) {
                        primary = t;
                    }
                }
            }
            // Fallback 2: short raycast from mouth along look to help during riding fly-bys
            if (primary == null) {
                boolean ridden = getUser().m_6688_() != null;
                primary = raycastTargetAlongMouth(ridden ? 7.5 : 5.5, ridden ? 2.0 : 1.0);
            }
            if (primary != null) {
                bitePrimary(primary);
                chainFrom(primary);
            }
            didHitThisActive = true;
        }
    }

    // ===== Core mechanics =====

    private LivingEntity findPrimaryTarget() {
        Raevyx wyvern = getUser();
        Vec3 mouth = wyvern.getMouthPosition();
        Vec3 look = wyvern.m_20154_().m_82541_();

        // Use a larger effective range when ridden to accommodate height/offset while mounted
        boolean ridden = wyvern.m_6688_() != null;
        double effectiveRange = ridden ? BITE_RANGE_RIDDEN : BITE_RANGE;

        // Forward sweep out from the mouth so hits originate ahead of the head
        double horizontalInflate = ridden ? BITE_SWIPE_HORIZONTAL_RIDDEN : BITE_SWIPE_HORIZONTAL;
        AABB forwardSweep = new AABB(mouth, mouth.m_82549_(look.m_82490_(effectiveRange)))
                .m_82377_(horizontalInflate, BITE_SWIPE_VERTICAL, horizontalInflate);
        List<LivingEntity> candidates = wyvern.m_9236_().m_6443_(LivingEntity.class, forwardSweep,
                e -> e != wyvern && e.m_6084_() && e.m_5789_() && !isAllied(wyvern, e));

        double cosLimit = Math.cos(Math.toRadians(BITE_ANGLE_DEG));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (LivingEntity e : candidates) {
            // Compute closest point on target's AABB to the mouth
            double distToAabb = distancePointToAABB(mouth, e.m_20191_());
            if (distToAabb > effectiveRange + 0.4) continue;

            // Direction toward the closest point for angle test
            Vec3 toward = closestPointOnAABB(mouth, e.m_20191_()).m_82546_(mouth);
            double len = toward.m_82553_();
            if (len <= 0.0001) continue;
            Vec3 dir = toward.m_82490_(1.0 / len);
            double dot = dir.m_82526_(look);

            // Require the bite to project forward from the head
            if (dot <= 0.0) continue;

            // Be forgiving with angle when very close; otherwise enforce cone
            boolean veryClose = distToAabb < (effectiveRange * 0.35);
            boolean goodAngle = dot >= cosLimit;
            if (ridden) {
                // Slightly relax the cone while ridden but keep hits forward
                goodAngle = goodAngle || dot >= (cosLimit * 0.75);
            }
            if (!(veryClose || goodAngle)) continue;

            if (distToAabb < bestDist) {
                bestDist = distToAabb;
                best = e;
            }
        }
        return best;
    }

    private void bitePrimary(LivingEntity primary) {
        Raevyx wyvern = getUser();
        DamageSource src = wyvern.m_9236_().m_269111_().m_269333_(wyvern);
        float mult = wyvern.getDamageMultiplier();
        primary.m_6469_(src, BITE_DAMAGE * mult);
        wyvern.noteAggroFrom(primary);
    }

    private void chainFrom(LivingEntity start) {
        Raevyx wyvern = getUser();
        ElectricalConductivityState conductivity = wyvern.getConductivityState();
        Set<LivingEntity> hit = new HashSet<>();
        hit.add(start);

        LivingEntity current = start;
        float damage = CHAIN_DAMAGE_BASE;

        for (int i = 0; i < CHAIN_JUMPS; i++) {
            LivingEntity next = findNearestChainTarget(current, hit, conductivity);
            if (next == null) break;

            // Damage and VFX
            float mult = wyvern.getDamageMultiplier();
            next.m_6469_(wyvern.m_9236_().m_269111_().m_269548_(), damage * mult * conductivity.damageMultiplier());
            wyvern.noteAggroFrom(next);
            spawnArc(current.m_20182_().m_82520_(0, current.m_20206_() * 0.5, 0),
                    next.m_20182_().m_82520_(0, next.m_20206_() * 0.5, 0), conductivity);

            hit.add(next);
            current = next;
            damage *= CHAIN_FALLOFF;
        }
    }

    // ===== Geometry helpers =====
    private static double distancePointToAABB(Vec3 p, AABB box) {
        double dx = Math.max(Math.max(box.f_82288_ - p.f_82479_, 0.0), p.f_82479_ - box.f_82291_);
        double dy = Math.max(Math.max(box.f_82289_ - p.f_82480_, 0.0), p.f_82480_ - box.f_82292_);
        double dz = Math.max(Math.max(box.f_82290_ - p.f_82481_, 0.0), p.f_82481_ - box.f_82293_);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static Vec3 closestPointOnAABB(Vec3 p, AABB box) {
        double cx = Mth.m_14008_(p.f_82479_, box.f_82288_, box.f_82291_);
        double cy = Mth.m_14008_(p.f_82480_, box.f_82289_, box.f_82292_);
        double cz = Mth.m_14008_(p.f_82481_, box.f_82290_, box.f_82293_);
        return new Vec3(cx, cy, cz);
    }

    private LivingEntity raycastTargetAlongMouth(double maxDistance, double inflateRadius) {
        Raevyx wyvern = getUser();
        Vec3 start = wyvern.getMouthPosition();
        Vec3 look = wyvern.m_20154_().m_82541_();
        Vec3 end = start.m_82549_(look.m_82490_(maxDistance));

        AABB sweep = new AABB(start, end).m_82400_(inflateRadius);
        var hit = ProjectileUtil.m_150175_(wyvern.m_9236_(), wyvern, start, end, sweep,
                e -> e instanceof LivingEntity le && e != wyvern && e.m_6084_() && le.m_5789_() && !isAllied(wyvern, e),
                (float)(maxDistance * maxDistance));
        if (hit != null && hit.m_82443_() instanceof LivingEntity le) {
            return le;
        }
        return null;
    }

    private LivingEntity findNearestChainTarget(LivingEntity origin, Set<LivingEntity> exclude, ElectricalConductivityState conductivity) {
        Raevyx wyvern = getUser();
        double rangeMult = conductivity.rangeMultiplier();
        List<LivingEntity> nearby = DragonMathUtil.getEntitiesNearby(origin, LivingEntity.class, CHAIN_RADIUS * rangeMult);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : nearby) {
            if (e == wyvern || exclude.contains(e) || !e.m_6084_() || !e.m_5789_() || isAllied(wyvern, e)) continue;
            double d = e.m_20280_(origin);
            if (d < bestDist) {
                // Optional LOS check for coherence
                if (!wyvern.m_21574_().m_148306_(e)) continue;
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private boolean isAllied(Raevyx wyvern, Entity other) {
        // Use the comprehensive ally system from DragonEntity
        return wyvern.isAlly(other);
    }

    private void spawnArc(Vec3 from, Vec3 to, ElectricalConductivityState conductivity) {
        if (!(getLevel() instanceof ServerLevel server)) return;
        
        // Create a single lightning chain entity instead of multiple particles
        Raevyx wyvern = getUser();
        float damage = CHAIN_DAMAGE_BASE * wyvern.getDamageMultiplier() * conductivity.damageMultiplier();
        
        RaevyxLightningChainEntity lightningEntity = new RaevyxLightningChainEntity(
            server, from, to, 
            damage, 1.2f,
                wyvern, false // Not a chain lightning, just a single strike
        );
        
        server.m_7967_(lightningEntity);
    }
}