package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;

import java.util.EnumSet;

public class NulljawLeaveWaterGoal extends Goal {

    private final Nulljaw drake;
    private Vec3 targetPos;
    private final int executionChance = 30;

    public NulljawLeaveWaterGoal(Nulljaw drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        // Only leave water when in water and should leave
        if (this.drake.m_9236_().m_6425_(this.drake.m_20183_()).m_205070_(FluidTags.f_13131_) && 
            (this.drake.m_5448_() != null || this.drake.m_217043_().m_188503_(executionChance) == 0)) {
            if (this.drake.shouldLeaveWater()) {
                targetPos = generateTarget();
                return targetPos != null;
            }
        }
        return false;
    }

    @Override
    public void m_8056_() {
        if (targetPos != null) {
            drake.m_21573_().m_26519_(targetPos.f_82479_, targetPos.f_82480_, targetPos.f_82481_, 1.0D);
        }
    }

    @Override
    public void m_8037_() {
        if (targetPos != null) {
            drake.m_21573_().m_26519_(targetPos.f_82479_, targetPos.f_82480_, targetPos.f_82481_, 1.0D);
        }
        // Help with getting out of water when hitting walls
        if (this.drake.f_19862_ && this.drake.m_20069_()) {
            final float yawRad = drake.m_146908_() * Mth.f_144833_;
            Vec3 current = drake.m_20184_();
            double pushX = -Mth.m_14031_(yawRad) * 0.3D;
            double pushZ = Mth.m_14089_(yawRad) * 0.3D;
            double upward = Mth.m_14008_(current.f_82480_ + 0.08D, 0.24D, 0.45D);
            drake.m_20334_(current.f_82479_ + pushX, upward, current.f_82481_ + pushZ);
        }
    }

    @Override
    public boolean m_8045_() {
        // Stop if we no longer should leave water
        if (!this.drake.shouldLeaveWater()) {
            this.drake.m_21573_().m_26573_();
            return false;
        }
        return !this.drake.m_21573_().m_26571_() && targetPos != null && !this.drake.m_9236_().m_6425_(BlockPos.m_274446_(targetPos)).m_205070_(FluidTags.f_13131_);
    }

    private Vec3 generateTarget() {
        Vec3 vector3d = LandRandomPos.m_148488_(drake, 23, 7);
        int tries = 0;
        while (vector3d != null && tries < 8) {
            boolean waterDetected = false;
            for (BlockPos blockpos1 : BlockPos.m_121940_(BlockPos.m_274446_(vector3d).m_7918_(-2, -1, -2), BlockPos.m_274446_(vector3d).m_7918_(2, 0, 2))) {
                if (drake.m_9236_().m_6425_(blockpos1).m_205070_(FluidTags.f_13131_)) {
                    waterDetected = true;
                    break;
                }
            }
            if (waterDetected) {
                vector3d = LandRandomPos.m_148488_(drake, 23, 7);
            } else {
                return vector3d;
            }
            tries++;
        }
        return null;
    }
}

