package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;

import java.util.EnumSet;
import java.util.List;

/**
 * Makes adult Raevyx attack entities that hurt nearby babies.
 * Protective parent behavior - mama dragon doesn't let you hurt her babies!
 */
public class RaevyxProtectBabiesGoal extends TargetGoal {
    private final Raevyx dragon;
    private LivingEntity attacker;
    private int timestamp;

    public RaevyxProtectBabiesGoal(Raevyx dragon) {
        super(dragon, false);
        this.dragon = dragon;
        this.m_7021_(EnumSet.of(Goal.Flag.TARGET));
    }

    @Override
    public boolean m_8036_() {
        // Only adults protect babies
        if (this.dragon.m_6162_()) {
            return false;
        }

        // Don't interfere if sitting or already has a target
        if (this.dragon.m_21827_()) {
            return false;
        }

        // Look for nearby babies that have been hurt recently
        List<Raevyx> nearbyBabies = this.dragon.m_9236_().m_6443_(
                Raevyx.class,
                this.dragon.m_20191_().m_82400_(16.0D),
                baby -> baby != null && baby.m_6162_() && baby.m_6084_()
        );

        // Check if any baby has a recent attacker
        for (Raevyx baby : nearbyBabies) {
            LivingEntity babyAttacker = baby.m_21188_();
            if (babyAttacker != null && babyAttacker.m_6084_()) {
                // Don't attack other Raevyx or the owner
                if (babyAttacker instanceof Raevyx) {
                    continue;
                }
                if (this.dragon.m_21824_() && babyAttacker == this.dragon.m_269323_()) {
                    continue;
                }

                // Found a valid threat!
                this.attacker = babyAttacker;
                this.timestamp = baby.m_21213_();
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean m_8045_() {
        // Stop if the attacker is dead or too far away
        if (this.attacker == null || !this.attacker.m_6084_()) {
            return false;
        }

        // Stop if too far away from the attacker
        if (this.dragon.m_20280_(this.attacker) > 256.0D) { // 16 blocks
            return false;
        }

        return true;
    }

    @Override
    public void m_8056_() {
        // Set the attacker as target
        this.dragon.m_6710_(this.attacker);
        super.m_8056_();
    }

    @Override
    public void m_8041_() {
        this.attacker = null;
    }
}
