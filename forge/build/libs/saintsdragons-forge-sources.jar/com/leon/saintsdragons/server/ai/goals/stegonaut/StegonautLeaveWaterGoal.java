package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Urges the Stegonaut to leave water as quickly as possible so it resumes ground behaviour.
 */
public class StegonautLeaveWaterGoal extends Goal {

    private static final int NEARBY_SEARCH_RADIUS = 6;
    private static final int RANDOM_SEARCH_ATTEMPTS = 12;
    private static final int PATH_RECHECK_DELAY = 20;

    private final Stegonaut drake;
    private final double moveSpeed;

    private Vec3 targetPosition;
    private int pathCooldown;
    private boolean forcedStandDuringEscape;

    public StegonautLeaveWaterGoal(Stegonaut drake, double moveSpeed) {
        this.drake = drake;
        this.moveSpeed = moveSpeed;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (!drake.m_20072_()) {
            return false;
        }

        targetPosition = findDryLand();
        return targetPosition != null;
    }

    @Override
    public boolean m_8045_() {
        if (!drake.m_20072_()) {
            return false;
        }

        if (targetPosition == null) {
            return false;
        }

        return !drake.m_21573_().m_26571_();
    }

    @Override
    public void m_8056_() {
        pathCooldown = 0;
        forcedStandDuringEscape = false;

        // Temporarily override sitting so the drake is free to walk out of water.
        if (drake.m_21827_()) {
            forcedStandDuringEscape = true;
            drake.m_21839_(false);
        }

        moveToTarget();
    }

    @Override
    public void m_8041_() {
        drake.m_21573_().m_26573_();
        targetPosition = null;

        if (forcedStandDuringEscape) {
            drake.refreshCommandState();
        }
    }

    @Override
    public void m_8037_() {
        if (targetPosition == null) {
            return;
        }

        drake.m_21563_().m_24950_(targetPosition.f_82479_, targetPosition.f_82480_, targetPosition.f_82481_, 45.0F, 45.0F);

        if (--pathCooldown <= 0) {
            // Try to stay focused on the same target. If pathing fails, look for a new shoreline.
            if (!drake.m_21573_().m_26519_(targetPosition.f_82479_, targetPosition.f_82480_, targetPosition.f_82481_, moveSpeed)) {
                targetPosition = findDryLand();
                if (targetPosition != null) {
                    drake.m_21573_().m_26519_(targetPosition.f_82479_, targetPosition.f_82480_, targetPosition.f_82481_, moveSpeed);
                }
            }
            pathCooldown = PATH_RECHECK_DELAY;
        }

        // Give a little upward nudge when colliding with blocks underwater.
        if (drake.f_19862_ && drake.m_20069_()) {
            drake.m_20256_(drake.m_20184_().m_82520_(0.0D, 0.08D, 0.0D));
        }
    }

    private void moveToTarget() {
        if (targetPosition != null) {
            drake.m_21573_().m_26519_(targetPosition.f_82479_, targetPosition.f_82480_, targetPosition.f_82481_, moveSpeed);
        }
    }

    private Vec3 findDryLand() {
        Vec3 nearby = searchNearbyDryLand();
        if (nearby != null) {
            return nearby;
        }

        return findRandomDryLand();
    }

    private Vec3 searchNearbyDryLand() {
        Level level = drake.m_9236_();
        BlockPos origin = drake.m_20183_();
        Vec3 originCenter = Vec3.m_82512_(origin);

        BlockPos bestCandidate = null;
        double bestDistance = Double.MAX_VALUE;

        for (int radius = 1; radius <= NEARBY_SEARCH_RADIUS; radius++) {
            int horizontalRadius = radius;
            for (BlockPos pos : BlockPos.m_121940_(
                    origin.m_7918_(-horizontalRadius, -1, -horizontalRadius),
                    origin.m_7918_(horizontalRadius, 2, horizontalRadius))) {

                int dx = Math.abs(pos.m_123341_() - origin.m_123341_());
                int dz = Math.abs(pos.m_123343_() - origin.m_123343_());
                if (dx > radius || dz > radius) {
                    continue;
                }

                if (!isDryDestination(level, pos)) {
                    continue;
                }

                double distance = pos.m_203198_(originCenter.f_82479_, originCenter.f_82480_, originCenter.f_82481_);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestCandidate = pos.m_7949_();
                }
            }

            if (bestCandidate != null) {
                return Vec3.m_82539_(bestCandidate);
            }
        }

        return null;
    }

    private Vec3 findRandomDryLand() {
        Level level = drake.m_9236_();
        Vec3 candidate = null;

        for (int attempts = 0; attempts < RANDOM_SEARCH_ATTEMPTS; attempts++) {
            candidate = LandRandomPos.m_148488_(drake, 24, 7);
            if (candidate == null) {
                continue;
            }

            BlockPos blockPos = BlockPos.m_274446_(candidate);
            if (isDryDestination(level, blockPos)) {
                return Vec3.m_82539_(blockPos);
            }
        }

        // As a last resort, try to step upward in the same column.
        BlockPos columnExit = climbColumnToFindAir();
        return columnExit != null ? Vec3.m_82539_(columnExit) : null;
    }

    private BlockPos climbColumnToFindAir() {
        Level level = drake.m_9236_();
        BlockPos.MutableBlockPos cursor = drake.m_20183_().m_122032_();

        // Move upwards until we leave water or hit the build height.
        while (level.m_6425_(cursor).m_205070_(FluidTags.f_13131_) && cursor.m_123342_() < level.m_151558_()) {
            cursor.m_122173_(Direction.UP);
        }

        if (level.m_6425_(cursor).m_205070_(FluidTags.f_13131_)) {
            return null;
        }

        if (!isDryDestination(level, cursor)) {
            cursor.m_122173_(Direction.UP);
            if (!isDryDestination(level, cursor)) {
                return null;
            }
        }

        return cursor.m_7949_();
    }

    private boolean isDryDestination(Level level, BlockPos pos) {
        if (!level.m_46749_(pos)) {
            return false;
        }

        if (!level.m_46859_(pos)) {
            return false;
        }

        if (!level.m_6425_(pos).m_76178_()) {
            return false;
        }

        BlockPos below = pos.m_7495_();
        BlockState belowState = level.m_8055_(below);

        if (!level.m_6425_(below).m_76178_()) {
            return false;
        }

        if (!belowState.m_60783_(level, below, Direction.UP)) {
            return false;
        }

        BlockPos above = pos.m_7494_();
        if (!level.m_46749_(above) || !level.m_46859_(above) || !level.m_6425_(above).m_76178_()) {
            return false;
        }

        BlockPos twoAbove = above.m_7494_();
        if (!level.m_46749_(twoAbove)) {
            return true;
        }

        return level.m_46859_(twoAbove) && level.m_6425_(twoAbove).m_76178_();
    }
}
