package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Simple ground wandering for Lightning Dragon when not flying
 */
public class RaevyxGroundWanderGoal extends RandomStrollGoal {

    private final Raevyx wyvern;

    public RaevyxGroundWanderGoal(Raevyx wyvern, double speed, int interval) {
        // Fixed interval wandering
        super(wyvern, speed, interval);
        this.wyvern = wyvern;
    }

    @Override
    public boolean m_8036_() {
        // Only wander on ground when not flying
        if (wyvern.m_29443_()) {
            return false;
        }

        // Don't interfere with important behaviors
        if (wyvern.m_21827_() || wyvern.m_20160_() || wyvern.m_20159_() || wyvern.isSleepLocked()) {
            return false;
        }

        // Don't wander during combat
        if (wyvern.m_5448_() != null && wyvern.m_5448_().m_6084_()) {
            return false;
        }

        // Hook up to command system - only wander when command is 2 (Wander) or when untamed
        if (wyvern.m_21824_()) {
            int command = wyvern.getCommand();
            if (command != 2) { // 0=Follow, 1=Sit, 2=Wander
                return false;
            }
        }

        return super.m_8036_();
    }

    @Override
    public boolean m_8045_() {
        // Stop if we start flying
        if (wyvern.m_29443_()) {
            return false;
        }

        // Stop if combat starts
        if (wyvern.m_5448_() != null && wyvern.m_5448_().m_6084_()) {
            return false;
        }

        // Stop if ordered to sit
        if (wyvern.m_21827_() || wyvern.isSleepLocked()) {
            return false;
        }

        return super.m_8045_();
    }

    @Nullable
    @Override
    protected Vec3 m_7037_() {
        // If tamed and owner is far, bias movement towards owner
        if (wyvern.m_21824_()) {
            var owner = wyvern.m_269323_();
            if (owner != null && wyvern.m_20280_(owner) > 20.0 * 20.0) {
                // Move generally towards owner but not directly (maintain some independence)
                return DefaultRandomPos.m_148412_(
                        this.f_25725_,
                        16, // range
                        7,  // vertical range
                        owner.m_20182_(),
                        (float) Math.PI / 3F // 60-degree cone towards owner
                );
            }
        }

        // Default random wandering
        return DefaultRandomPos.m_148403_(this.f_25725_, 20, 8); // Slightly larger range for a wyvern
    }
}
