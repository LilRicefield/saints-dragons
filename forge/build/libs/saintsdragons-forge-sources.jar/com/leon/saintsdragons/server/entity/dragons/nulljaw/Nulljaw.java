package com.leon.saintsdragons.server.entity.dragons.nulljaw;

import com.leon.saintsdragons.common.registry.nulljaw.NulljawAbilities;
import com.leon.saintsdragons.server.ai.navigation.DragonPathNavigateGround;
import com.leon.saintsdragons.server.ai.navigation.DragonAmphibiousNavigation;
import com.leon.saintsdragons.server.ai.navigation.DragonSwimMoveControl;
import com.leon.saintsdragons.server.ai.goals.base.DragonOwnerHurtByTargetGoal;
import com.leon.saintsdragons.server.ai.goals.base.DragonOwnerHurtTargetGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawCombatGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawFindWaterGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawFollowOwnerGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawLeaveWaterGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawGroundWanderGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawRandomSwimGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawRestGoal;
import com.leon.saintsdragons.server.ai.goals.nulljaw.NulljawSleepGoal;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.base.RideableDragonBase;
import com.leon.saintsdragons.server.entity.dragons.nulljaw.handlers.*;
import com.leon.saintsdragons.server.entity.handler.DragonSoundHandler;
import com.leon.saintsdragons.server.entity.interfaces.*;
import com.leon.saintsdragons.server.entity.sleep.DragonRestState;
import com.leon.saintsdragons.common.network.DragonRiderAction;
import com.leon.saintsdragons.common.registry.ModSounds;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import com.leon.saintsdragons.server.entity.controller.nulljaw.NulljawRiderController;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreathAirGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.control.LookControl;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import javax.annotation.Nonnull;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.keyframe.event.SoundKeyframeEvent;
import software.bernie.geckolib.util.GeckoLibUtil;
import com.leon.saintsdragons.server.entity.base.RideableDragonData;
import net.minecraft.world.entity.LivingEntity;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Nulljaw extends RideableDragonBase implements AquaticDragon, ShakesScreen, SoundHandledDragon, DragonSleepCapable {

    // Force-load abilities registry when this class is loaded
    static {
        // This triggers the static initializers in NulljawAbilities, registering all abilities
        try {
            Class.forName("com.leon.saintsdragons.common.registry.nulljaw.NulljawAbilities");
            System.out.println("[Nulljaw] Abilities loaded successfully in static initializer!");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load Nulljaw abilities!", e);
        }
    }

    // ===== VOCAL ENTRIES =====
    // IMPORTANT: Keys MUST match animation trigger names registered in NulljawAnimationHandler
    private static final Map<String, VocalEntry> VOCAL_ENTRIES = new VocalEntryBuilder()
            .add("grumble1", "action", "animation.nulljaw.grumble1", ModSounds.NULLJAW_GRUMBLE_1, 0.8f, 0.95f, 0.1f, false, false, true)
            .add("grumble2", "action", "animation.nulljaw.grumble2", ModSounds.NULLJAW_GRUMBLE_2, 0.8f, 0.95f, 0.1f, false, false, true)
            .add("grumble3", "action", "animation.nulljaw.grumble3", ModSounds.NULLJAW_GRUMBLE_3, 0.8f, 0.95f, 0.1f, false, false, true)
            .build();

    // ===== AMBIENT SOUND SYSTEM =====
    private int ambientSoundTimer;
    private int nextAmbientSoundDelay;
    private static final int MIN_AMBIENT_DELAY = 200;  // 10 seconds
    private static final int MAX_AMBIENT_DELAY = 600;  // 30 seconds

    private static final EntityDataAccessor<Integer> DATA_GROUND_MOVE_STATE = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Float> DATA_RIDER_FORWARD = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Float> DATA_RIDER_STRAFE = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Boolean> DATA_ACCELERATING = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_SWIMMING = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Integer> DATA_SWIM_TURN = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Integer> DATA_SWIM_PITCH = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Boolean> DATA_PHASE_TWO = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_RIDER_LOCKED = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Float> DATA_SCREEN_SHAKE_AMOUNT = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135029_);

    // Flight mode data accessor (not used for ground drake but required by interface)
    private static final EntityDataAccessor<Integer> DATA_FLIGHT_MODE = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Boolean> DATA_GOING_UP = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_GOING_DOWN = SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING =
            SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING_ENTERING =
            SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING_EXITING =
            SynchedEntityData.m_135353_(Nulljaw.class, EntityDataSerializers.f_135035_);

    private final AnimatableInstanceCache animCache = GeckoLibUtil.createInstanceCache(this);
    private final DragonSoundHandler soundHandler = new DragonSoundHandler(this);
    private final NulljawAnimationHandler animationHandler = new NulljawAnimationHandler(this);
    private final NulljawInteractionHandler interactionHandler = new NulljawInteractionHandler(this);
    private final com.leon.saintsdragons.server.entity.sleep.DragonRestManager restManager = new com.leon.saintsdragons.server.entity.sleep.DragonRestManager(this);
    private final NulljawRiderController riderController;
    private final PathNavigation groundNavigation;
    private final DragonAmphibiousNavigation waterNavigation;
    private final MoveControl landMoveControl;
    private final DragonSwimMoveControl swimMoveControl;
    private final RiftDrakeLookController landLookControl;
    private int riderControlLockTicks = 0;
    private NulljawRandomSwimGoal waterSwimGoal;
    private NulljawGroundWanderGoal groundWanderGoal;
    private boolean swimming;
    private int swimTicks;
    private int ticksInWater;
    private int ticksOutOfWater;
    private float swimTurnSmoothedYaw;
    private int swimTurnState;
    private int swimPitchStateTicks;
    // Continuous swim roll angle for smooth banking (like Raevyx's flight banking)
    private float swimRollAngle = 0f;
    private float prevSwimRollAngle = 0f;
    private boolean useLeftClawNext = true; // Toggles between left/right claw attacks
    // ===== SCREEN SHAKE SYSTEM =====
    private static final float SHAKE_DECAY_PER_TICK = 0.02F;
    private float prevScreenShakeAmount = 0.0F;
    private float screenShakeAmount = 0.0F;
    // ===== SIT / SLEEP STATE =====
    private boolean isSittingDown = false;
    private boolean isStandingUp = false;
    private int sitTransitionTicks = 0;
    private int sleepTransitionTicks = 0;
    private int sleepAmbientCooldownTicks = 0;
    private int sleepReentryCooldownTicks = 0;
    private int sleepCancelTicks = 0;
    private boolean sleepLocked = false;
    private int sleepCommandSnapshot = -1;
    private boolean wasVehicleLastTick = false;

    public Nulljaw(EntityType<? extends Nulljaw> type, Level level) {
        super(type, level);
        this.m_21441_(BlockPathTypes.WATER, 0.0F);
        this.m_21441_(BlockPathTypes.WATER_BORDER, 0.0F);
        this.m_274367_(1.4F);
        this.groundNavigation = new DragonPathNavigateGround(this, level);
        this.waterNavigation = new DragonAmphibiousNavigation(this, level);
        this.landMoveControl = new RiftDrakeMoveControl(this);
        this.swimMoveControl = new DragonSwimMoveControl(this, 6.0F, 0.08D, 0.12D);
        this.landLookControl = new RiftDrakeLookController(this);
        this.f_21344_ = this.groundNavigation;
        this.f_21342_ = this.landMoveControl;
        this.f_21365_ = this.landLookControl;
        this.riderController = new NulljawRiderController(this);
        this.setRideable();

        // Initialize ambient sound system with random offset
        RandomSource rng = this.m_217043_();
        this.ambientSoundTimer = rng.m_188503_(80);
        this.nextAmbientSoundDelay = MIN_AMBIENT_DELAY + rng.m_188503_(MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY);
    }

    private void tickRiderControlLock() {
        if (riderControlLockTicks > 0) {
            riderControlLockTicks--;
            if (riderControlLockTicks <= 0) {
                this.f_19804_.m_135381_(DATA_RIDER_LOCKED, false);
            }
        }
    }

    @Override
    protected float getRiderLockYawBlend() {
        return this.isPhaseTwoActive() ? 0.25F : 0.18F;
    }

    @Override
    protected float getRiderLockPitchBlend() {
        return this.isPhaseTwoActive() ? 0.25F : 0.18F;
    }

    public boolean areRiderControlsLocked() {
        return m_9236_().f_46443_ ? this.f_19804_.m_135370_(DATA_RIDER_LOCKED) : riderControlLockTicks > 0;
    }

    public void lockRiderControls(int ticks) {
        riderControlLockTicks = Math.max(riderControlLockTicks, Math.max(0, ticks));
        this.f_19804_.m_135381_(DATA_RIDER_LOCKED, true);
        this.setAccelerating(false);
        this.setLastRiderForward(0.0F);
        this.setLastRiderStrafe(0.0F);
        this.setGroundMoveStateFromRider(0);
        this.setGoingUp(false);
        this.setGoingDown(false);
        this.m_20256_(Vec3.f_82478_);
        if (!this.m_9236_().f_46443_) {
            this.m_21573_().m_26573_();
            this.m_6710_(null);
        }
    }

    public void lockAbilities(int ticks) {
        combatManager.lockGlobalCooldown(ticks);
    }

    @Override
    protected boolean isRiderInputLocked(Player player) {
        return areRiderControlsLocked();
    }

    @Override
    protected void applyRiderVerticalInput(Player player, boolean goingUp, boolean goingDown, boolean locked) {
        if (locked) {
            setGoingUp(false);
            setGoingDown(false);
            return;
        }
        boolean inWater = this.m_6069_() || this.m_20072_();
        setGoingUp(inWater && goingUp);
        setGoingDown(inWater && goingDown);
    }

    @Override
    protected void applyRiderMovementInput(Player player, float forward, float strafe, float yaw, boolean locked) {
        float fwd = locked ? 0f : applyInputDeadzone(forward);
        float str = locked ? 0f : applyInputDeadzone(strafe);
        setLastRiderForward(fwd);
        setLastRiderStrafe(str);
        int moveState = 0;
        float magnitude = Math.abs(fwd) + Math.abs(str);
        if (magnitude > 0.05f) {
            moveState = isAccelerating() ? 2 : 1;
        }
        setGroundMoveStateFromRider(moveState);
    }

    @Override
    protected void handleRiderAction(ServerPlayer player, DragonRiderAction action, String abilityName, boolean locked) {
        if (locked || action == null) {
            return;
        }
        switch (action) {
            case TAKEOFF_REQUEST -> handleJumpRequest();
            case ACCELERATE -> setAccelerating(true);
            case STOP_ACCELERATE -> setAccelerating(false);
            case ABILITY_USE -> {
                if (abilityName != null && !abilityName.isEmpty()) {
                    useRidingAbility(abilityName);
                }
            }
            case ABILITY_STOP -> {
                if (abilityName != null && !abilityName.isEmpty()) {
                    forceEndActiveAbility();
                }
            }
            case TOGGLE_MELEE -> {
                if (!locked) {
                    toggleMeleeMode();
                }
            }
            default -> { }
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return TamableAnimal.m_21183_()
                .m_22268_(Attributes.f_22276_, 250.0D)
                .m_22268_(Attributes.f_22279_, 0.28D)
                .m_22268_(Attributes.f_22277_, 40.0D)
                .m_22268_(Attributes.f_22278_, 0.5D)
                .m_22268_(Attributes.f_22284_, 8.0D)
                .m_22268_(Attributes.f_22281_, 10.0D);
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(DATA_SWIMMING, false);
        this.f_19804_.m_135372_(DATA_SWIM_TURN, 0);
        this.f_19804_.m_135372_(DATA_SWIM_PITCH, 0);
        this.f_19804_.m_135372_(DATA_PHASE_TWO, false);
        this.f_19804_.m_135372_(DATA_RIDER_LOCKED, false);
        this.f_19804_.m_135372_(DATA_SCREEN_SHAKE_AMOUNT, 0.0F);
        this.f_19804_.m_135372_(DATA_SLEEPING, false);
        this.f_19804_.m_135372_(DATA_SLEEPING_ENTERING, false);
        this.f_19804_.m_135372_(DATA_SLEEPING_EXITING, false);
    }
    
    @Override
    protected void defineRideableDragonData() {
        this.f_19804_.m_135372_(DATA_GROUND_MOVE_STATE, 0);
        this.f_19804_.m_135372_(DATA_RIDER_FORWARD, 0.0F);
        this.f_19804_.m_135372_(DATA_RIDER_STRAFE, 0.0F);
        this.f_19804_.m_135372_(DATA_ACCELERATING, false);
        this.f_19804_.m_135372_(DATA_FLIGHT_MODE, -1);
        this.f_19804_.m_135372_(DATA_GOING_UP, false);
        this.f_19804_.m_135372_(DATA_GOING_DOWN, false);
    }
    
    // ===== REQUIRED ABSTRACT METHODS FROM RIDEABLEDRAGONBASE =====
    
    @Override
    protected EntityDataAccessor<Float> getRiderForwardAccessor() {
        return DATA_RIDER_FORWARD;
    }
    
    @Override
    protected EntityDataAccessor<Float> getRiderStrafeAccessor() {
        return DATA_RIDER_STRAFE;
    }
    
    @Override
    protected EntityDataAccessor<Integer> getGroundMoveStateAccessor() {
        return DATA_GROUND_MOVE_STATE;
    }
    
    @Override
    protected EntityDataAccessor<Integer> getFlightModeAccessor() {
        return DATA_FLIGHT_MODE;
    }
    
    @Override
    protected EntityDataAccessor<Boolean> getGoingUpAccessor() {
        return DATA_GOING_UP;
    }
    
    @Override
    protected EntityDataAccessor<Boolean> getGoingDownAccessor() {
        return DATA_GOING_DOWN;
    }
    
    @Override
    protected EntityDataAccessor<Boolean> getAcceleratingAccessor() {
        return DATA_ACCELERATING;
    }

    @Override
    protected void m_8099_() {
        super.m_8099_();
        // Priority 0: Critical survival - air management
        this.f_21345_.m_25352_(0, new BreathAirGoal(this));
        // Priority 1: Sleep system (tamed dragons following owners)
        this.f_21345_.m_25352_(1, new NulljawSleepGoal(this));
        // Priority 2: Casual resting for wild dragons
        this.f_21345_.m_25352_(2, new NulljawRestGoal(this));

        // Priority 3: Combat abilities (CombatGoal handles both movement and attacks)
        this.f_21345_.m_25352_(3, new NulljawCombatGoal(this));

        // Priority 6-7: Amphibious behavior (semi-aquatic patrol pattern)
        this.f_21345_.m_25352_(6, new NulljawLeaveWaterGoal(this));
        this.f_21345_.m_25352_(7, new NulljawFindWaterGoal(this));

        // Priority 8: Social behavior (follow owner)
        this.f_21345_.m_25352_(8, new NulljawFollowOwnerGoal(this));

        // Priority 9: Idle swimming
        this.waterSwimGoal = new NulljawRandomSwimGoal(this, 1.2D, 30);
        this.f_21345_.m_25352_(9, waterSwimGoal);

        // Priority 10: Idle roaming on land
        this.groundWanderGoal = new NulljawGroundWanderGoal(this, 1.0D, 100);
        this.f_21345_.m_25352_(10, groundWanderGoal);

        // Priority 11: Ambient behaviors
        this.f_21345_.m_25352_(11, new RandomLookAroundGoal(this));
        this.f_21345_.m_25352_(11, new LookAtPlayerGoal(this, Player.class, 8.0F));

        // Target selectors (threat detection)
        this.f_21346_.m_25352_(1, new DragonOwnerHurtByTargetGoal(this));
        this.f_21346_.m_25352_(2, new DragonOwnerHurtTargetGoal(this));
        this.f_21346_.m_25352_(3, new HurtByTargetGoal(this));
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        AnimationController<Nulljaw> movementController =
                new AnimationController<>(this, "movement", 5, animationHandler::movementPredicate);
        AnimationController<Nulljaw> swimController =
                new AnimationController<>(this, "swim_direction", 4, animationHandler::swimDirectionPredicate);
        AnimationController<Nulljaw> actions =
                new AnimationController<>(this, "action", 10, animationHandler::actionPredicate);

        animationHandler.configureMovementBlend(movementController);
        animationHandler.configureSwimBlend(swimController);

        // Sound keyframes
        movementController.setSoundKeyframeHandler(this::onAnimationSound);
        swimController.setSoundKeyframeHandler(this::onAnimationSound);
        actions.setSoundKeyframeHandler(this::onAnimationSound);

        // Setup animation triggers
        animationHandler.setupActionController(actions);

        controllers.add(movementController);
        controllers.add(swimController);
        controllers.add(actions);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return animCache;
    }

    public DragonSoundHandler getSoundHandler() {
        return soundHandler;
    }

    @Override
    public DragonSoundProfile getSoundProfile() {
        return NulljawSoundProfile.INSTANCE;
    }

    @Override
    public Map<String, VocalEntry> getVocalEntries() {
        return VOCAL_ENTRIES;
    }

    @Override
    protected void m_7355_(@NotNull BlockPos pos, @NotNull BlockState state) {
        // Mute vanilla footsteps; custom sounds handled via GeckoLib keyframes
    }

    // ===== AMBIENT SOUND METHODS =====

    /**
     * Plays appropriate ambient sound based on drake's current mood and state
     */
    private void playCustomAmbientSound() {
        RandomSource random = m_217043_();

        // Don't make ambient sounds if dying, in combat, or using abilities
        if (isDying() || m_5448_() != null || getActiveAbility() != null) {
            return;
        }

        String vocalKey = null;

        // Simple grumbles for the amphibious drake
        float moodRoll = random.m_188501_();
        if (moodRoll < 0.4f) {
            vocalKey = "grumble1";
        } else if (moodRoll < 0.7f) {
            vocalKey = "grumble2";
        } else {
            vocalKey = "grumble3";
        }

        // Play/animate if we chose one
        if (vocalKey != null) {
            this.getSoundHandler().playVocal(vocalKey);
        }
    }

    /**
     * Handles all the ambient grumbling sounds
     */
    private void handleAmbientSounds() {
        // Suppress ambient sounds while transitioning or resting to prevent animation snapping
        if (m_6162_() || isDying() || m_21827_() || m_5803_() || isSleepTransitioning() || isInSitTransition() || sleepAmbientCooldownTicks > 0) {
            return;
        }

        ambientSoundTimer++;

        // Time to make some noise?
        if (ambientSoundTimer >= nextAmbientSoundDelay) {
            playCustomAmbientSound();
            resetAmbientSoundTimer();
        }
    }

    /**
     * Resets the ambient sound timer with some randomness
     */
    private void resetAmbientSoundTimer() {
        RandomSource random = m_217043_();
        ambientSoundTimer = 0;
        nextAmbientSoundDelay = MIN_AMBIENT_DELAY + random.m_188503_(MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY);
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        soundHandler.tick();
        tickSittingState();
        tickMountedState();
        tickScreenShake();
        updateSittingProgress();
        tickSleepTransition();
        tickSleepCooldowns();

        // Handle ambient sounds (server-side only)
        if (!m_9236_().f_46443_) {
            handleAmbientSounds();
            tickRiderControlLock();
            boolean inWater = this.m_20069_();
            if (inWater) {
                this.m_20301_(this.m_6062_());
                swimTicks = Math.min(swimTicks + 1, 200);
                ticksInWater = Math.min(ticksInWater + 1, 1200);
                ticksOutOfWater = 0;
            } else {
                swimTicks = Math.max(swimTicks - 1, 0);
                ticksOutOfWater = Math.min(ticksOutOfWater + 1, 1200);
                ticksInWater = 0;
            }

            if (inWater && !swimming) {
                enterSwimState();
            } else if (!inWater && swimming) {
                exitSwimState();
            }

            // Ensure proper look control when being ridden
            if (this.m_6688_() != null && this.f_21365_ != landLookControl) {
                this.f_21365_ = landLookControl;
            }

            if ((m_5803_() || isSleepingEntering() || isSleepingExiting())
                    && (this.m_5448_() != null || this.m_5912_() || this.m_20072_())) {
                wakeUpImmediately();
                suppressSleep(200);
            }

            this.tickAnimationStates();
            this.updateSwimOrientationState();
        }

        tickClientSideUpdates();
    }

    @Override
    public void m_7023_(@NotNull Vec3 motion) {
        if (this.m_20160_() && this.m_6688_() instanceof Player player) {
            if (areRiderControlsLocked()) {
                this.m_20256_(Vec3.f_82478_);
                return;
            }
            // Clear any AI navigation when being ridden
            if (this.m_21573_().m_26570_() != null) {
                this.m_21573_().m_26573_();
            }

            if (this.m_20072_()) {
                handleRiddenSwimming(motion);
            } else {
                setGoingUp(false);
                setGoingDown(false);
                // Use vanilla movement system for proper camera-relative movement
                // This will call getRiddenInput() and getRiddenSpeed() properly
                super.m_7023_(motion);
            }
        } else {
            // Normal AI movement
            super.m_7023_(motion);
        }
    }

    @Override
    public @NotNull PathNavigation m_21573_() {
        return swimming ? waterNavigation : groundNavigation;
    }

    @Override
    public PathNavigation getAquaticNavigation() {
        return waterNavigation;
    }

    @Override
    public double getSwimSpeed() {
        double baseSpeed = 1.45D; // Slightly faster baseline than default aquatic dragons
        if (this.m_20160_()) {
            baseSpeed += 0.2D; // Give riders a bit more responsiveness
        }
        return baseSpeed;
    }

    @Override
    public void onEnterWater() {
        this.m_20256_(this.m_20184_());
        this.tickAnimationStates();
    }

    @Override
    public void onExitWater() {
        this.m_20256_(this.m_20184_().m_82542_(1.0D, 0.6D, 1.0D));
        this.tickAnimationStates();
    }

    @Override
    public @NotNull InteractionResult m_6071_(@NotNull Player player, @NotNull InteractionHand hand) {
        InteractionResult handlerResult = interactionHandler.handleInteraction(player, hand);
        if (handlerResult != InteractionResult.PASS) {
            return handlerResult;
        }

        // Fall back to base implementation for any unhandled interactions
        return super.m_6071_(player, hand);
    }
    
    /**
     * Allow interaction handler to call super.mobInteract
     */
    public InteractionResult superMobInteract(Player player, InteractionHand hand) {
        return super.m_6071_(player, hand);
    }
    
    @Override
    public boolean m_6898_(@Nonnull net.minecraft.world.item.ItemStack stack) {
        // Rift Drakes prefer fish like other dragons
        return stack.m_150930_(net.minecraft.world.item.Items.f_42526_) || 
               stack.m_150930_(net.minecraft.world.item.Items.f_42527_) || 
               stack.m_150930_(net.minecraft.world.item.Items.f_42528_);
    }

    @Override
    public void setLastRiderForward(float forward) {
        this.f_19804_.m_135381_(DATA_RIDER_FORWARD, forward);
    }

    @Override
    public void setLastRiderStrafe(float strafe) {
        this.f_19804_.m_135381_(DATA_RIDER_STRAFE, strafe);
    }

    public float getLastRiderForward() {
        return this.f_19804_.m_135370_(DATA_RIDER_FORWARD);
    }

    public float getLastRiderStrafe() {
        return this.f_19804_.m_135370_(DATA_RIDER_STRAFE);
    }

    @Override
    public boolean isAccelerating() {
        return this.f_19804_.m_135370_(DATA_ACCELERATING);
    }

    @Override
    public void setAccelerating(boolean accelerating) {
        this.f_19804_.m_135381_(DATA_ACCELERATING, accelerating);
    }

    public void setGroundMoveStateFromRider(int state) {
        int s = Mth.m_14045_(state, 0, 2);
        if (this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE) != s) {
            this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, s);
        }
        this.syncAnimState(s, getSyncedFlightMode());
    }

    /**
     * Allow AI goals to set ground move state explicitly
     */
    public void setGroundMoveStateFromAI(int state) {
        if (!this.m_9236_().f_46443_) {
            int s = Mth.m_14045_(state, 0, 2);
            if (this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE) != s) {
                this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, s);
                this.syncAnimState(s, getSyncedFlightMode());
            }
        }
    }

    // ===== REQUIRED METHODS FROM RIDEABLEDRAGONBASE =====
    
    @Override
    public boolean isRunning() {
        return false; // Rift Drake doesn't have running state
    }
    
    @Override
    public void setRunning(boolean running) {
        // Rift Drake doesn't have running state
    }
    
    @Override
    public boolean isDragonFlying() {
        return false; // Rift Drake doesn't fly
    }
    
    @Override
    public boolean isHovering() {
        return false; // Rift Drake doesn't hover
    }
    
    @Override
    public boolean isTakeoff() {
        return false; // Rift Drake doesn't take off
    }
    
    @Override
    public boolean isLanding() {
        return false; // Rift Drake doesn't land
    }
    
    @Override
    public int getFlightMode() {
        return -1; // Ground mode
    }


    public void handleJumpRequest() {
        if (areRiderControlsLocked()) {
            return;
        }
        if (this.m_20069_()) {
            // Enhanced water jump - more powerful for aquatic creature
            Vec3 jump = new Vec3(0.0D, 0.6D, 0.0D);
            this.m_20256_(this.m_20184_().m_82549_(jump));
            this.f_19812_ = true;
        } else if (this.m_20096_()) {
            // Ground jump - standard jump height
            Vec3 movement = this.m_20184_();
            this.m_20334_(movement.f_82479_, 0.42D, movement.f_82481_);
            this.f_19812_ = true;
        }
    }

    @Override
    public @NotNull Vec3 m_274312_(@NotNull Player player, @NotNull Vec3 deltaIn) {
        if (areRiderControlsLocked()) {
            return Vec3.f_82478_;
        }
        Vec3 input = riderController.getRiddenInput(player, deltaIn);

        // Capture rider inputs for animation state
        if (!m_9236_().f_46443_) {
            float fwd = (float) Mth.m_14008_(input.f_82481_, -1.0D, 1.0D);
            float str = (float) Mth.m_14008_(input.f_82479_, -1.0D, 1.0D);
            setLastRiderForward(RideableDragonData.applyInputThreshold(fwd));
            setLastRiderStrafe(RideableDragonData.applyInputThreshold(str));
        }
        return input;
    }

    @Override
    protected float m_245547_(@Nonnull @NotNull Player rider) {
        if (areRiderControlsLocked()) {
            return 0.0F;
        }
        return riderController.getRiddenSpeed(rider);
    }

    @Override
    protected void m_274498_(@NotNull Player player, @NotNull Vec3 travelVector) {
        super.m_274498_(player, travelVector);
        if (areRiderControlsLocked()) {
            player.f_19789_ = 0.0F;
            this.f_19789_ = 0.0F;
            this.m_6710_(null);
            copyRiderLook(player);
            this.setAccelerating(false);
            this.setGoingUp(false);
            this.setGoingDown(false);
            this.m_20256_(Vec3.f_82478_);
            return;
        }
        riderController.tickRidden(player, travelVector);
    }

    @Override
    public void m_20351_(@NotNull Entity passenger) {
        super.m_20351_(passenger);
        if (!this.m_9236_().f_46443_) {
            this.setAccelerating(false);
            this.setLastRiderForward(0.0F);
            this.setLastRiderStrafe(0.0F);
            this.setGroundMoveStateFromRider(0);
        }
    }

    // Let RideableDragonBase handle tickAnimationStates() for proper networking

    @Override
    public void m_6135_() {
        super.m_6135_();
        this.setGroundMoveStateFromRider(1);
    }

    public void initializeRiderState() {
        if (!this.m_9236_().f_46443_) {
            this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, 0);
            this.f_19804_.m_135381_(DATA_RIDER_FORWARD, 0.0F);
            this.f_19804_.m_135381_(DATA_RIDER_STRAFE, 0.0F);
            this.setAccelerating(false);
        }
    }

    @Override
    public Vec3 getHeadPosition() {
        return this.m_146892_();
    }

    @Override
    public Vec3 getMouthPosition() {
        return this.m_20182_().m_82520_(0, this.m_20206_() * 0.8, 0);
    }

    public void useRidingAbility(String abilityName) {
        if (abilityName == null || abilityName.isEmpty()) {
            return;
        }
        if (areRiderControlsLocked()) {
            return;
        }
        Entity rider = this.m_6688_();
        if (!(rider instanceof LivingEntity)) {
            return;
        }
        if (this.m_21824_() && rider instanceof Player player && !this.m_21830_(player)) {
            return;
        }

        DragonAbilityType<?, ?> type = com.leon.saintsdragons.common.registry.AbilityRegistry.get(abilityName);
        if (type != null) {
            combatManager.tryUseAbility(type);
        } else {
            // Debug: log if ability type not found
            System.out.println("[Nulljaw Debug] Ability '" + abilityName + "' not found in registry!");
        }
    }

    public void forceEndActiveAbility() {
        combatManager.forceEndActiveAbility();
    }

    // ===== RIDING METHODS =====
    
    @Override
    public double m_6048_() {
        return riderController.getPassengersRidingOffset();
    }

    @Override
    protected void m_19956_(@Nonnull @NotNull Entity passenger, @Nonnull @NotNull Entity.MoveFunction moveFunction) {
        riderController.positionRider(passenger, moveFunction);
    }

    @Override
    public @Nullable net.minecraft.world.entity.LivingEntity m_6688_() {
        return riderController.getControllingPassenger();
    }

    @Override
    public @NotNull Vec3 m_7688_(@NotNull LivingEntity passenger) {
        return riderController.getDismountLocationForPassenger(passenger);
    }

    @Override
    public net.minecraft.world.entity.AgeableMob m_142606_(@Nonnull net.minecraft.server.level.ServerLevel level, @Nonnull net.minecraft.world.entity.AgeableMob other) {
        return null;
    }

    @Override
    public com.leon.saintsdragons.server.entity.ability.DragonAbilityType<?, ?> getPrimaryAttackAbility() {
        // Use melee mode to switch between bite and horn gore
        // Mode 0 = bite (primary), Mode 1 = horn gore (secondary)
        boolean useHornGore = getMeleeMode() == 1;

        // Phase 2 uses bite2 (faster bite) instead of normal bite
        if (isPhaseTwoActive()) {
            return useHornGore ? NulljawAbilities.NULLJAW_HORN_GORE : NulljawAbilities.NULLJAW_BITE2;
        }
        return useHornGore ? NulljawAbilities.NULLJAW_HORN_GORE : NulljawAbilities.NULLJAW_BITE;
    }

    public boolean isAbilityActive(DragonAbilityType<?, ?> abilityType) {
        return combatManager.isAbilityActive(abilityType);
    }

    public void forceEndAbility(DragonAbilityType<?, ?> abilityType) {
        combatManager.forceEndAbility(abilityType);
    }

    public static boolean canSpawn(EntityType<Nulljaw> type, LevelAccessor level, MobSpawnType reason, BlockPos pos, net.minecraft.util.RandomSource random) {
        return level.m_6425_(pos).m_76170_() || level.m_6425_(pos.m_7495_()).m_76170_();
    }

    private void enterSwimState() {
        swimming = true;
        this.f_21344_ = waterNavigation;
        this.f_21342_ = swimMoveControl;
        
        this.f_19804_.m_135381_(DATA_SWIMMING, true);
        if (waterSwimGoal != null) {
            waterSwimGoal.forceTrigger();
        }
    }

    private void exitSwimState() {
        swimming = false;
        this.f_21344_ = groundNavigation;
        this.f_21342_ = landMoveControl;
        this.f_21365_ = landLookControl; // Always use land look control when exiting water
        this.waterNavigation.m_26573_();
        Vec3 delta = this.m_20184_();
        this.m_20256_(new Vec3(delta.f_82479_, 0.0D, delta.f_82481_));
        if (groundWanderGoal != null) {
            groundWanderGoal.forceTrigger();
        }
        this.f_19804_.m_135381_(DATA_SWIMMING, false);
        this.f_19804_.m_135381_(DATA_SWIM_TURN, 0);
        this.f_19804_.m_135381_(DATA_SWIM_PITCH, 0);
        this.swimTurnSmoothedYaw = 0.0F;
        this.swimTurnState = 0;
        this.swimPitchStateTicks = 0;
        this.swimRollAngle = 0f;
        this.prevSwimRollAngle = 0f;
    }

    private void updateSwimOrientationState() {
        if (m_9236_().f_46443_) {
            return;
        }

        int desiredTurn = this.f_19804_.m_135370_(DATA_SWIM_TURN);
        int desiredPitchState = this.f_19804_.m_135370_(DATA_SWIM_PITCH);

        boolean riderControlled = this.m_21824_()
                && this.m_20160_()
                && this.m_6688_() instanceof Player player
                && this.m_21830_(player)
                && this.m_20072_();

        if (riderControlled) {
            float yawDelta = Mth.m_14177_(this.m_146908_() - this.f_19859_);
            swimTurnSmoothedYaw = swimTurnSmoothedYaw * 0.6F + yawDelta * 0.4F;
            float enter = 0.35F;
            float exit = 0.12F;

            int targetState = swimTurnState;
            if (swimTurnSmoothedYaw > enter) {
                targetState = -1;
            } else if (swimTurnSmoothedYaw < -enter) {
                targetState = 1;
            } else if (Math.abs(swimTurnSmoothedYaw) < exit) {
                targetState = 0;
            }

            swimTurnState = targetState;
            desiredTurn = swimTurnState;

            if (this.isGoingUp()) {
                desiredPitchState = -1;
                swimPitchStateTicks = 6;
            } else if (this.isGoingDown()) {
                desiredPitchState = 1;
                swimPitchStateTicks = 6;
            } else if (desiredPitchState != 0) {
                if (swimPitchStateTicks > 0) {
                    swimPitchStateTicks--;
                } else {
                    desiredPitchState = 0;
                }
            }
        } else {
            swimTurnSmoothedYaw *= 0.5F;
            if (Math.abs(swimTurnSmoothedYaw) < 0.05F) {
                swimTurnState = 0;
            }
            desiredTurn = swimTurnState;

            if (desiredPitchState != 0) {
                if (++swimPitchStateTicks > 4) {
                    desiredPitchState = 0;
                    swimPitchStateTicks = 0;
                }
            } else {
                swimPitchStateTicks = 0;
            }
        }

        if (this.f_19804_.m_135370_(DATA_SWIM_TURN) != desiredTurn) {
            this.f_19804_.m_135381_(DATA_SWIM_TURN, desiredTurn);
        }

        if (this.f_19804_.m_135370_(DATA_SWIM_PITCH) != desiredPitchState) {
            this.f_19804_.m_135381_(DATA_SWIM_PITCH, desiredPitchState);
        }

        // Calculate continuous swim roll angle (like Raevyx's banking)
        prevSwimRollAngle = swimRollAngle;

        // Reset when not swimming or controls locked
        if (!m_6069_() || areRiderControlsLocked()) {
            swimRollAngle = 0f;
            prevSwimRollAngle = 0f;
            return;
        }

        // Convert smoothed yaw delta into a roll angle
        float targetAngle = Mth.m_14036_(swimTurnSmoothedYaw * 40.0f, -60f, 60f); // More roll than Raevyx
        // Ease toward the new target
        swimRollAngle = Mth.m_14179_(0.25f, swimRollAngle, targetAngle);
        if (Math.abs(swimRollAngle) < 0.01f) {
            swimRollAngle = 0f;
        }
    }

    public boolean m_6069_() {
        if (m_9236_().f_46443_) {
            return this.f_19804_.m_135370_(DATA_SWIMMING);
        }
        return swimming;
    }

    public int getSwimTurnDirection() {
        return Mth.m_14045_(this.f_19804_.m_135370_(DATA_SWIM_TURN), -1, 1);
    }

    public boolean isSwimmingDown() {
        return this.m_6069_() && this.f_19804_.m_135370_(DATA_SWIM_PITCH) > 0;
    }

    public boolean isSwimmingUp() {
        return this.m_6069_() && this.f_19804_.m_135370_(DATA_SWIM_PITCH) < 0;
    }

    public boolean isSwimmingMoving() {
        if (!m_6069_()) {
            return false;
        }

        if (this.m_21573_().m_26572_() && this.m_21573_().m_26570_() != null) {
            return true;
        }

        if (this.m_20160_()) {
            float fwd = Math.abs(this.f_19804_.m_135370_(DATA_RIDER_FORWARD));
            float str = Math.abs(this.f_19804_.m_135370_(DATA_RIDER_STRAFE));
            if (fwd > 0.03F || str > 0.03F) {
                return true;
            }
        }

        return this.m_20184_().m_165925_() > 0.0025D;
    }

    /**
     * Get the swim roll angle in degrees (like Raevyx's banking)
     */
    public float getSwimRollAngleDegrees() {
        return swimRollAngle;
    }

    /**
     * Get interpolated swim roll angle for smooth rendering
     */
    public float getSwimRollAngleDegrees(float partialTick) {
        return Mth.m_14179_(partialTick, prevSwimRollAngle, swimRollAngle);
    }

    public boolean isPhaseTwoActive() {
        return this.f_19804_.m_135370_(DATA_PHASE_TWO);
    }

    public void setPhaseTwoActive(boolean active, boolean syncAnim) {
        this.f_19804_.m_135381_(DATA_PHASE_TWO, active);
        if (syncAnim) {
            this.syncAnimState(this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE), this.getSyncedFlightMode());
        }
    }

    // ===== CLAW ALTERNATION SYSTEM =====

    public boolean shouldUseLeftClaw() {
        return useLeftClawNext;
    }

    public void toggleClawSide() {
        useLeftClawNext = !useLeftClawNext;
    }


    @Override
    public RiderAbilityBinding getAttackRiderAbility() {
        // Use melee mode to switch between horn gore and bite/bite2
        // Mode 0 = bite (primary), Mode 1 = horn gore (secondary)
        if (getMeleeMode() == 1) {
            return new RiderAbilityBinding(NulljawAbilities.NULLJAW_HORN_GORE_ID, RiderAbilityBinding.Activation.PRESS);
        } else {
            // Phase 2 uses bite2, Phase 1 uses bite
            try {
                if (isPhaseTwoActive()) {
                    return new RiderAbilityBinding(NulljawAbilities.NULLJAW_BITE2_ID, RiderAbilityBinding.Activation.PRESS);
                }
            } catch (Exception e) {
                // Fallback to phase 1 bite if entity data isn't ready
            }
            return new RiderAbilityBinding(NulljawAbilities.NULLJAW_BITE_ID, RiderAbilityBinding.Activation.PRESS);
        }
    }

    @Override
    public RiderAbilityBinding getPrimaryRiderAbility() {
        // R key: Universal roar ability for all dragons (PRESS)
        return new RiderAbilityBinding(NulljawAbilities.NULLJAW_ROAR_ID, RiderAbilityBinding.Activation.PRESS);
    }

    @Override
    public RiderAbilityBinding getSecondaryRiderAbility() {
        return new RiderAbilityBinding(NulljawAbilities.NULLJAW_PHASE_SHIFT_ID, RiderAbilityBinding.Activation.PRESS);
    }

    @Override
    public RiderAbilityBinding getTertiaryRiderAbility() {
        // G key: Phase 2 gets claw attacks (PRESS, not HOLD like other dragons)
        if (isPhaseTwoActive()) {
            return new RiderAbilityBinding(NulljawAbilities.NULLJAW_CLAW_ID, RiderAbilityBinding.Activation.PRESS);
        }
        return null; // G key - not used in phase 1
    }

    @Override
    public DragonAbilityType<?, ?> getChannelingAbility() {
        return NulljawAbilities.NULLJAW_PHASE_SHIFT;
    }

    public void onAnimationSound(SoundKeyframeEvent<Nulljaw> event) {
        // Delegate all keyframed sounds to the sound handler
        this.getSoundHandler().handleAnimationSound(this, event.getKeyframeData(), event.getController());
    }

    private void handleRiddenSwimming(Vec3 input) {
        Vec3 velocity = this.m_20184_();

        double swimSpeed = getSwimSpeed();
        if (isAccelerating()) {
            swimSpeed *= 1.6D;
        }

        Vec3 desired = getVec3(input, swimSpeed, velocity);
        Vec3 blended = velocity.m_82549_(desired.m_82546_(velocity).m_82490_(0.28D));

        double dragFactor = this.m_6109_() ? 0.92D : 0.94D;
        blended = blended.m_82542_(dragFactor, 0.96D, dragFactor);

        if (!isGoingUp() && !isGoingDown() && m_6688_() != null) {
            blended = blended.m_82542_(1.0D, 0.0D, 1.0D);
        } else if (!isGoingUp() && !isGoingDown() && m_5448_() == null) {
            blended = blended.m_82520_(0.0D, -0.01D, 0.0D);
        }

        this.m_20256_(blended);
        this.m_6478_(MoverType.SELF, this.m_20184_());
    }

    private @NotNull Vec3 getVec3(Vec3 wishDir, double swimSpeed, Vec3 velocity) {
        double strafe = wishDir.f_82479_;
        double forward = wishDir.f_82481_;
        float yawRad = this.m_146908_() * ((float)Math.PI / 180F);
        double sin = Math.sin(yawRad);
        double cos = Math.cos(yawRad);

        double worldX = strafe * cos - forward * sin;
        double worldZ = forward * cos + strafe * sin;

        double dx = worldX * 0.85D * swimSpeed;
        double dz = worldZ * 0.85D * swimSpeed;

        double dy = velocity.f_82480_;
        if (isGoingUp()) {
            dy = Math.min(swimSpeed, dy + 0.12D * swimSpeed);
        } else if (isGoingDown()) {
            dy = Math.max(-swimSpeed, dy - 0.12D * swimSpeed);
        } else {
            dy *= 0.90D;
        }

        Vec3 desired = new Vec3(dx, dy, dz);
        return desired;
    }

    /**
     * Check if the drake is dying (health below 10%)
     */
    public boolean isDying() {
        return this.m_21223_() < this.m_21233_() * 0.1f;
    }
    
    // Required methods for RideableDragon interface
    @Override
    public boolean isGoingUp() {
        return this.f_19804_.m_135370_(DATA_GOING_UP);
    }
    
    @Override
    public void setGoingUp(boolean goingUp) {
        this.f_19804_.m_135381_(DATA_GOING_UP, goingUp);
    }
    
    @Override
    public boolean isGoingDown() {
        return this.f_19804_.m_135370_(DATA_GOING_DOWN);
    }
    
    @Override
    public void setGoingDown(boolean goingDown) {
        this.f_19804_.m_135381_(DATA_GOING_DOWN, goingDown);
    }

    private static class RiftDrakeMoveControl extends MoveControl {

        public RiftDrakeMoveControl(Nulljaw drake) {
            super(drake);
        }

        @Override
        public void m_8126_() {
            super.m_8126_();
        }
    }

    // ===== LOOK CONTROLLER =====
    public static class RiftDrakeLookController extends LookControl {
        private final Nulljaw dragon;

        public RiftDrakeLookController(Nulljaw dragon) {
            super(dragon);
            this.dragon = dragon;
        }

        @Override
        public void m_8128_() {
            if (!this.dragon.m_6084_()) {
                return;
            }

            LivingEntity rider = this.dragon.m_6688_();
            if (this.dragon.m_20160_() && rider != null) {
                if (this.dragon.m_6109_()) {
                    float bodyYaw = rider.m_146908_();
                    this.dragon.m_146922_(bodyYaw);
                    this.dragon.m_5616_(bodyYaw);
                    this.dragon.f_20886_ = bodyYaw;
                    this.dragon.f_20883_ = bodyYaw;
                    this.dragon.f_20884_ = bodyYaw;

                    boolean allowRiderPitch = !(this.dragon.isPhaseTwoActive() && this.dragon.areRiderControlsLocked());
                    if (allowRiderPitch) {
                        float pitch = Mth.m_14036_(rider.m_146909_(), -45.0F, 45.0F);
                        this.dragon.m_146926_(pitch);
                        this.dragon.f_19860_ = pitch;
                    } else {
                        float eased = Mth.m_14148_(this.dragon.m_146909_(), 0.0F, 6.0F);
                        this.dragon.m_146926_(eased);
                        this.dragon.f_19860_ = eased;
                    }
                } else {
                    float serverPitch = this.dragon.m_146909_();
                    this.dragon.f_19860_ = serverPitch;
                }
                return;
            }

            super.m_8128_();
        }
    }

    private void tickSittingState() {
        // Clear sitting state if the drake is being ridden
        if (!this.m_9236_().f_46443_ && this.m_20160_() && this.m_21827_()) {
            this.m_21839_(false);
        }
    }

    private void tickMountedState() {
        boolean mounted = this.m_20160_();

        if (mounted && !wasVehicleLastTick) {
            this.sitProgress = 0f;
            this.prevSitProgress = 0f;
            this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
            isSittingDown = false;
            isStandingUp = false;
            sitTransitionTicks = 0;

            if (this.m_21827_()) {
                this.m_21839_(false);
                if (this.getCommand() == 1) {
                    this.setCommand(0);
                }
            }

            if (m_5803_() || isSleepingEntering() || isSleepingExiting()) {
                wakeUpImmediately();
                suppressSleep(300);
            }
        }

        if (!mounted && wasVehicleLastTick) {
            this.sitProgress = 0f;
            this.prevSitProgress = 0f;
            this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
            isSittingDown = false;
            isStandingUp = false;
            sitTransitionTicks = 0;
        }

        wasVehicleLastTick = mounted;
    }

    private void updateSittingProgress() {
        if (m_9236_().f_46443_) {
            return;
        }

        if (sitTransitionTicks > 0) {
            sitTransitionTicks--;
            if (sitTransitionTicks == 0) {
                isSittingDown = false;
                isStandingUp = false;
            }
        }

        if (this.m_21827_()) {
            if ((sitProgress == 0f || isStandingUp) && !isSittingDown) {
                animationHandler.triggerSitDownAnimation();
                isSittingDown = true;
                isStandingUp = false;
                sitTransitionTicks = getSitDownAnimationTicks();
            }

            if (sitProgress < maxSitTicks()) {
                sitProgress++;
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        } else {
            if (m_20160_()) {
                if (sitProgress != 0f) {
                    sitProgress = 0f;
                    prevSitProgress = 0f;
                    this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
                    isSittingDown = false;
                    isStandingUp = false;
                    sitTransitionTicks = 0;
                }
            } else if (sitProgress > 0f) {
                if ((sitProgress >= maxSitTicks() || isSittingDown) && !isStandingUp) {
                    animationHandler.triggerSitUpAnimation();
                    isStandingUp = true;
                    isSittingDown = false;
                    sitTransitionTicks = getSitUpAnimationTicks();
                }

                float decrementRate = maxSitTicks() / (float) getSitUpAnimationTicks();
                sitProgress -= decrementRate;
                if (sitProgress < 0f) {
                    sitProgress = 0f;
                }
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        }
    }

    private void tickClientSideUpdates() {
        // Update client-side sit progress from synchronized data
        if (m_9236_().f_46443_) {
            prevSitProgress = sitProgress;
            sitProgress = this.f_19804_.m_135370_(DATA_SIT_PROGRESS);
        }
    }

    private void tickSleepTransition() {
        // Handle sleep enter transition: sit_down → fall_asleep → sleep loop
        if (isSleepingEntering() && !m_9236_().f_46443_) {
            // Check if sit_down animation is complete (sitProgress reached max)
            if (getSitProgress() >= maxSitTicks()) {
                // Sit down complete, now trigger fall_asleep if we haven't started the transition timer yet
                if (sleepTransitionTicks == getFallAsleepAnimationTicks()) {
                    // Just reached sitting position, trigger fall_asleep
                    animationHandler.triggerFallAsleepAnimation();
                }
            }
        }

        if (sleepTransitionTicks > 0) {
            sleepTransitionTicks--;

            // Trigger sleep animation 3 ticks BEFORE fall_asleep finishes for smooth blend
            if (sleepTransitionTicks == 3 && isSleepingEntering() && !m_9236_().f_46443_) {
                animationHandler.triggerSleepAnimation();
            }

            if (sleepTransitionTicks == 0) {
                if (isSleepingEntering()) {
                    // fall_asleep animation finishing - mark as sleeping (animation already triggered)
                    setSleeping(true);
                    setSleepingEntering(false);
                } else if (isSleepingExiting()) {
                    // wake_up finished: dragon is now sitting, will stand up via normal sit system
                    setSleepingExiting(false);
                    // Start small ambient cooldown buffer (~0.5s)
                    sleepAmbientCooldownTicks = Math.max(sleepAmbientCooldownTicks, 10);
                }
            }
        }
    }

    private void tickSleepCooldowns() {
        if (sleepAmbientCooldownTicks > 0) sleepAmbientCooldownTicks--;
        if (sleepReentryCooldownTicks > 0) sleepReentryCooldownTicks--;
        if (sleepCancelTicks > 0) sleepCancelTicks--;
    }

    // ===== SIT TRANSITION HELPERS =====

    public boolean isInSitTransition() {
        return isSittingDown || isStandingUp;
    }

    public boolean isSittingDownAnimation() {
        return isSittingDown;
    }

    public boolean isStandingUpAnimation() {
        return isStandingUp;
    }

    @Override
    public float maxSitTicks() {
        return 33.0F; // down animation is 1.6667s = 33 ticks
    }

    public int getSitDownAnimationTicks() {
        return 33; // down animation is 1.6667s ≈ 33 ticks
    }

    public int getSitUpAnimationTicks() {
        return 40; // up animation is 2.0s = 40 ticks
    }

    public int getFallAsleepAnimationTicks() {
        return 50; // fall_asleep animation is 2.5s = 50 ticks
    }

    public int getWakeUpAnimationTicks() {
        return 40; // wake_up animation is 2.0s = 40 ticks
    }

    /**
     * Get the persistent rest manager for save/load of rest state
     */
    public com.leon.saintsdragons.server.entity.sleep.DragonRestManager getRestManager() {
        return restManager;
    }

    // ===== SLEEP SYSTEM =====

    @Override
    public boolean m_5803_() {
        return this.f_19804_.m_135370_(DATA_SLEEPING);
    }

    public void setSleeping(boolean sleeping) {
        this.f_19804_.m_135381_(DATA_SLEEPING, sleeping);
    }

    @Override
    public boolean isSleepTransitioning() {
        return isSleepingEntering() || isSleepingExiting();
    }

    public boolean isSleepingEntering() {
        return this.f_19804_.m_135370_(DATA_SLEEPING_ENTERING);
    }

    public void setSleepingEntering(boolean entering) {
        this.f_19804_.m_135381_(DATA_SLEEPING_ENTERING, entering);
    }

    public boolean isSleepingExiting() {
        return this.f_19804_.m_135370_(DATA_SLEEPING_EXITING);
    }

    public void setSleepingExiting(boolean exiting) {
        this.f_19804_.m_135381_(DATA_SLEEPING_EXITING, exiting);
    }

    public boolean isSleepLocked() {
        return sleepLocked || m_5803_() || isSleepingEntering() || isSleepingExiting();
    }

    private void enterSleepLock() {
        if (m_9236_().f_46443_) {
            return;
        }
        if (!sleepLocked) {
            sleepLocked = true;
            sleepCommandSnapshot = this.getCommand();
        }
        this.m_21839_(true);
        this.m_21573_().m_26573_();
        this.m_6710_(null);
        this.m_20256_(Vec3.f_82478_);
        if (this.getCommand() != 1) {
            this.setCommand(1);
        }
    }

    private void releaseSleepLock() {
        if (m_9236_().f_46443_) {
            return;
        }
        if (sleepLocked) {
            int desired = sleepCommandSnapshot;
            sleepCommandSnapshot = -1;
            sleepLocked = false;
            if (desired >= 0 && desired != this.getCommand()) {
                this.setCommand(desired);
                this.m_21839_(desired == 1);
            }
        }
    }

    @Override
    public void startSleepEnter() {
        if (m_5803_() || isSleepingEntering() || isSleepingExiting()) return;
        setSleepingEntering(true);
        sleepTransitionTicks = getFallAsleepAnimationTicks(); // Set to exact animation length
        if (!m_9236_().f_46443_) {
            enterSleepLock();
        }
    }

    @Override
    public void startSleepExit() {
        if ((!m_5803_() && !isSleepingEntering()) || isSleepingExiting()) return;
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        setSleepingEntering(false);
        setSleepingExiting(true);
        sleepTransitionTicks = getWakeUpAnimationTicks();
        animationHandler.triggerWakeUpAnimation();
        if (!m_9236_().f_46443_) {
            suppressSleep(40);
            releaseSleepLock();
        }
    }

    public void wakeUpImmediately() {sleepAmbientCooldownTicks = Math.max(sleepAmbientCooldownTicks, 10);
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        setSleepingEntering(false);
        setSleepingExiting(false);
        sleepTransitionTicks = 0;
        sleepCancelTicks = 2;
        if (!m_9236_().f_46443_) {
            suppressSleep(40);
            releaseSleepLock();
        }
    }

    public void suppressSleep(int ticks) {
        sleepReentryCooldownTicks = Math.max(sleepReentryCooldownTicks, ticks);
    }

    @Override
    public boolean isSleepSuppressed() {
        return sleepReentryCooldownTicks > 0;
    }

    @Override
    public SleepPreferences getSleepPreferences() {
        return new SleepPreferences(
                true,   // canSleepAtNight
                false,  // canSleepDuringDay
                false,  // requiresShelter
                true,   // avoidsThunderstorms
                true    // sleepsNearOwner
        );
    }

    @Override
    public boolean canSleepNow() {
        return !m_20160_() && !this.m_20072_() && getActiveAbility() == null && !isPhaseTwoActive();
    }

    private void tickScreenShake() {
        if (m_9236_().f_46443_) {
            prevScreenShakeAmount = screenShakeAmount;
            screenShakeAmount = this.f_19804_.m_135370_(DATA_SCREEN_SHAKE_AMOUNT);
            return;
        }

        prevScreenShakeAmount = screenShakeAmount;
        if (screenShakeAmount > 0.0F) {
            float newAmount = Math.max(0.0F, screenShakeAmount - SHAKE_DECAY_PER_TICK);
            screenShakeAmount = newAmount;
            this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, newAmount);
        } else if (this.f_19804_.m_135370_(DATA_SCREEN_SHAKE_AMOUNT) != 0.0F) {
            this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, 0.0F);
        }
    }

    @Override
    public void m_7380_(@NotNull net.minecraft.nbt.CompoundTag tag) {
        super.m_7380_(tag);
        saveRideableData(tag);
        tag.m_128379_("PhaseTwo", isPhaseTwoActive());
        tag.m_128379_("Sleeping", m_5803_());
        tag.m_128379_("SleepingEntering", isSleepingEntering());
        tag.m_128379_("SleepingExiting", isSleepingExiting());
        tag.m_128379_("SleepLocked", sleepLocked);
        tag.m_128405_("SleepTransitionTicks", sleepTransitionTicks);
        tag.m_128405_("SleepAmbientCooldown", sleepAmbientCooldownTicks);
        tag.m_128405_("SleepReentryCooldown", sleepReentryCooldownTicks);

        // Save persistent rest state
        restManager.save(tag);
        tag.m_128405_("SleepCancelTicks", sleepCancelTicks);
        tag.m_128405_("SleepCommandSnapshot", sleepCommandSnapshot);
    }

    @Override
    public void m_7378_(@NotNull net.minecraft.nbt.CompoundTag tag) {
        super.m_7378_(tag);
        loadRideableData(tag);
        setSleeping(tag.m_128471_("Sleeping"));
        setSleepingEntering(tag.m_128471_("SleepingEntering"));
        setSleepingExiting(tag.m_128471_("SleepingExiting"));
        sleepLocked = tag.m_128471_("SleepLocked");
        sleepTransitionTicks = tag.m_128451_("SleepTransitionTicks");
        sleepAmbientCooldownTicks = tag.m_128451_("SleepAmbientCooldown");
        sleepReentryCooldownTicks = tag.m_128451_("SleepReentryCooldown");

        // Load persistent rest state
        restManager.load(tag);

        // Re-trigger animations based on loaded rest state
        if (!m_9236_().f_46443_) {
            var restState = restManager.getCurrentState();
            switch (restState) {
                case SITTING_DOWN, SITTING, SITTING_AFTER -> m_21839_(true);
                case FALLING_ASLEEP -> {
                    m_21839_(true);
                    // Don't re-trigger fall_asleep here, let the state machine handle it
                }
                case SLEEPING -> {
                    m_21839_(true);
                    // Re-trigger sleep loop animation
                    animationHandler.triggerSleepAnimation();
                }
                case WAKING_UP -> {
                    m_21839_(true);
                    // Don't re-trigger wake_up, let state machine handle it
                }
            }
        }

        sleepCancelTicks = tag.m_128451_("SleepCancelTicks");
        sleepCommandSnapshot = tag.m_128441_("SleepCommandSnapshot") ? tag.m_128451_("SleepCommandSnapshot") : -1;
        if (sleepLocked) {
            m_21839_(true);
        }
        if (tag.m_128441_("PhaseTwo")) {
            setPhaseTwoActive(tag.m_128471_("PhaseTwo"), false);
        }
    }

    @Override
    public void m_7822_(byte eventId) {
        if (eventId == 6) {
            // Failed taming - show smoke particles ONLY, no sitting behavior at all
            if (m_9236_().f_46443_) {
                // Show smoke particles for failed taming
                for (int i = 0; i < 7; ++i) {
                    double d0 = this.f_19796_.m_188583_() * 0.02D;
                    double d1 = this.f_19796_.m_188583_() * 0.02D;
                    double d2 = this.f_19796_.m_188583_() * 0.02D;
                    this.m_9236_().m_7106_(net.minecraft.core.particles.ParticleTypes.f_123762_,
                            this.m_20208_(1.0D), this.m_20187_() + 0.5D, this.m_20262_(1.0D), d0, d1, d2);
                }
            }
            // IMPORTANT: Don't call super for event 6 - it might trigger sitting behavior
        } else if (eventId == 7) {
            // Successful taming - show hearts only, sitting is handled separately
            if (m_9236_().f_46443_) {
                // Show heart particles for successful taming
                for (int i = 0; i < 7; ++i) {
                    double d0 = this.f_19796_.m_188583_() * 0.02D;
                    double d1 = this.f_19796_.m_188583_() * 0.02D;
                    double d2 = this.f_19796_.m_188583_() * 0.02D;
                    this.m_9236_().m_7106_(net.minecraft.core.particles.ParticleTypes.f_123750_,
                            this.m_20208_(1.0D), this.m_20187_() + 0.5D, this.m_20262_(1.0D), d0, d1, d2);
                }
            }
            // IMPORTANT: Don't call super for event 7 either - sitting is explicitly handled in mobInteract
        } else {
            // Call super for all other entity events (NOT 6 or 7)
            super.m_7822_(eventId);
        }
    }

    //LOCATOR
    private final Map<String, Vec3> clientLocatorCache = new ConcurrentHashMap<>();

    public void setClientLocatorPosition(String name, Vec3 pos) {
        if (name == null || pos == null) return;
        this.clientLocatorCache.put(name, pos);
    }

    public Vec3 getClientLocatorPosition(String name) {
        if (name == null) return null;
        return this.clientLocatorCache.get(name);
    }

    @Override
    public float getScreenShakeAmount(float partialTicks) {
        float currentAmount = this.f_19804_.m_135370_(DATA_SCREEN_SHAKE_AMOUNT);
        return prevScreenShakeAmount + (currentAmount - prevScreenShakeAmount) * partialTicks;
    }

    @Override
    public double getShakeDistance() {
        return 18.0;
    }

    @Override
    public boolean canFeelShake(Entity player) {
        return true;
    }

    public void triggerScreenShake(float intensity) {
        float clamped = Math.max(0.0F, intensity);
        if (clamped <= 0.0F) {
            return;
        }
        if (m_9236_().f_46443_) {
            return;
        }
        screenShakeAmount = Math.max(screenShakeAmount, clamped);
        this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, screenShakeAmount);
    }

    public boolean canBeBound() {
        return !isDying()
                && !isAccelerating()
                && !areRiderControlsLocked()
                && !isAbilityActive(NulljawAbilities.NULLJAW_PHASE_SHIFT);
    }

    // ===== AMPHIBIOUS BEHAVIOR =====

    @Override
    public boolean shouldEnterWater() {
        // Don't enter water if sitting or being ridden
        if (this.m_21827_() || this.m_20160_()) {
            return false;
        }

        // Emergency: Seek water when on fire or low health with a target
        if (this.m_6060_()) {
            return true;
        }
        if (this.m_21223_() < this.m_21233_() * 0.5F && this.m_5448_() != null) {
            return true;
        }

        // Natural patrol behavior - semi-aquatic predator rotates between environments
        // After ~50 seconds on land (1000 ticks), has 8% chance per check to enter water
        return ticksOutOfWater > 1000 && this.m_217043_().m_188501_() < 0.08F;
    }

    @Override
    public boolean shouldLeaveWater() {
        // Don't leave water if sitting
        if (this.m_21827_()) {
            return false;
        }

        // Follow tamed owner onto land if they're far away
        if (this.m_21824_() && this.m_269323_() != null) {
            LivingEntity owner = this.m_269323_();
            if (!owner.m_20069_() && this.m_20280_(owner) > 100.0D) { // 10 blocks
                return true;
            }
        }

        // Natural patrol behavior - after ~60 seconds in water (1200 ticks),
        // has 8% chance per check to leave for land patrol
        return ticksInWater > 1200 && this.m_217043_().m_188501_() < 0.08F;
    }
}
