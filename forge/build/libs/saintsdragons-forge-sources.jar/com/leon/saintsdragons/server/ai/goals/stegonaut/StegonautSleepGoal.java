package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import com.leon.saintsdragons.server.entity.sleep.DragonRestManager;
import com.leon.saintsdragons.server.entity.sleep.DragonRestState;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Primitive Drake specific sleep goal.
 * Now uses persistent DragonRestManager so state survives save/load.
 *
 * Simple sleep behavior:
 * - Sleeps at night, awake during day
 * - Takes short naps during the day (1-2 minutes)
 * - Simple animation cycle: down → sit → sleep → wake up → stand
 * - Same behavior for both wild and tamed drakes
 */
public class StegonautSleepGoal extends Goal {

    private final Stegonaut drake;
    private int retryCooldown;

    public StegonautSleepGoal(Stegonaut drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (retryCooldown > 0) {
            retryCooldown--;
            return false;
        }

        // If already in a rest cycle (e.g., loaded from save), continue it
        if (drake.getRestManager().isResting()) {
            return true;
        }

        if (drake.m_21827_()) return false;
        if (drake.isDying() || drake.m_20160_()) return false;
        if (drake.m_5448_() != null || drake.m_5912_()) return false;

        // Sleep at night
        long dayTime = drake.m_9236_().m_46468_() % 24000;
        boolean isNight = dayTime >= 13000 && dayTime < 23000;
        if (!isNight) return false;

        // Check if daytime nap was queued
        if (drake.consumeDayNapQueued()) {
            return true;
        }

        // Random chance to sleep at night
        return drake.m_217043_().m_188501_() < 0.001f;
    }

    @Override
    public boolean m_8045_() {
        boolean safeToRest = drake.m_5448_() == null && !drake.m_5912_();

        // Wake up if it becomes day
        long dayTime = drake.m_9236_().m_46468_() % 24000;
        boolean isNight = dayTime >= 13000 && dayTime < 23000;

        return drake.getRestManager().isResting() && safeToRest && isNight;
    }

    @Override
    public void m_8056_() {
        var restManager = drake.getRestManager();

        // If already resting (loaded from save), don't restart
        if (restManager.isResting()) {
            // Resume from saved state
            return;
        }

        // Check if this is a daytime nap
        if (drake.consumeDayNapQueued()) {
            // Start nap (1-2 minutes)
            int napDuration = 1200 + drake.m_217043_().m_188503_(1200);
            drake.startNap();
            restManager.startRest(napDuration);
        } else {
            // Start nighttime sleep - sleep until dawn
            restManager.startRest(Integer.MAX_VALUE);
        }

        drake.m_21839_(true); // Triggers down animation
        drake.m_21573_().m_26573_();
    }

    @Override
    public void m_8037_() {
        if (drake.m_9236_().f_46443_) return;

        var restManager = drake.getRestManager();
        DragonRestState state = restManager.getCurrentState();

        // Stop navigation and stay still
        drake.m_21573_().m_26573_();
        drake.m_20334_(0, drake.m_20184_().f_82480_, 0);

        // Ensure drake stays sitting during relevant states
        if (state == DragonRestState.SITTING_DOWN || state == DragonRestState.SITTING) {
            if (!drake.m_21827_()) {
                drake.m_21839_(true);
            }
        }

        // Check if it's time to wake up (became day)
        long dayTime = drake.m_9236_().m_46468_() % 24000;
        boolean isNight = dayTime >= 13000 && dayTime < 23000;

        // State machine for simple sleep cycle
        switch (state) {
            case SITTING_DOWN:
                // Wait for down → sit animation (simple, ~30 ticks)
                if (restManager.getStateTimer() > 35) {
                    restManager.advanceState();
                }
                break;

            case SITTING:
                // Brief pause before falling asleep
                if (restManager.getStateTimer() > 10) {
                    restManager.advanceState();
                    drake.startSleepEnter(); // Triggers fall_asleep animation
                }
                break;

            case FALLING_ASLEEP:
                // Wait for fall_asleep animation
                if ((drake.m_5803_() && !drake.isSleepTransitioning()) || restManager.getStateTimer() > 50) {
                    restManager.advanceState();
                }
                break;

            case SLEEPING:
                // Sleep until dawn (or until duration expires for naps, or interrupted by threats)
                restManager.incrementRestingTicks();
                boolean shouldWake = !isNight || (restManager.getRestingTicks() >= restManager.getRestDuration());

                if (shouldWake) {
                    restManager.advanceState();
                    drake.startSleepExit(); // Triggers wake_up animation
                    drake.m_21839_(true);
                }
                break;

            case WAKING_UP:
                // Wait for wake_up animation
                if (restManager.getStateTimer() > 45) {
                    restManager.advanceState();
                    drake.m_21839_(true);
                }
                break;

            case SITTING_AFTER:
                // Brief pause after waking
                if (restManager.getStateTimer() > 10) {
                    restManager.advanceState();
                    drake.m_21839_(false); // Trigger stand up animation
                }
                break;

            case STANDING_UP:
                // Wait for up animation
                if (restManager.getStateTimer() > 30) {
                    restManager.advanceState(); // Returns to IDLE
                }
                break;

            default:
                break;
        }

        // Tick the rest manager timer
        restManager.tick();
    }

    @Override
    public void m_8041_() {
        var restManager = drake.getRestManager();

        // Emergency cleanup - force stand up if interrupted mid-cycle
        if (restManager.isResting() && restManager.getCurrentState() != DragonRestState.STANDING_UP) {
            if (drake.m_5803_() || drake.isSleepTransitioning()) {
                drake.startSleepExit();
            }
            drake.m_21839_(false);
            restManager.stopRest(); // Clear rest state
        }

        // Set cooldown before next rest
        retryCooldown = 200 + drake.m_217043_().m_188503_(201);
    }

    @Override
    public boolean m_6767_() {
        return true; // Can be interrupted by threats
    }
}
