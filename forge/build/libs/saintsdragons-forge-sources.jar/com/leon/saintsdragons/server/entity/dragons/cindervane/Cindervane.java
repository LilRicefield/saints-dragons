package com.leon.saintsdragons.server.entity.dragons.cindervane;

import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.common.registry.AbilityRegistry;
import com.leon.saintsdragons.common.registry.ModSounds;
import com.leon.saintsdragons.common.registry.cindervane.CindervaneAbilities;
import com.leon.saintsdragons.server.ai.goals.cindervane.CindervaneCombatGoal;
import com.leon.saintsdragons.server.ai.goals.cindervane.CindervaneFlightGoal;
import com.leon.saintsdragons.server.ai.goals.cindervane.CindervaneFollowOwnerGoal;
import com.leon.saintsdragons.server.ai.goals.cindervane.CindervaneGroundWanderGoal;
import com.leon.saintsdragons.server.ai.goals.cindervane.CindervaneRestGoal;
import com.leon.saintsdragons.server.ai.goals.cindervane.CindervaneSleepGoal;
import com.leon.saintsdragons.server.ai.navigation.DragonFlightMoveHelper;
import com.leon.saintsdragons.server.ai.navigation.DragonPathNavigateGround;
import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.base.RideableDragonBase;
import com.leon.saintsdragons.server.entity.controller.cindervane.CindervaneRiderController;
import com.leon.saintsdragons.server.entity.controller.cindervane.CindervanePhysicsController;
import com.leon.saintsdragons.server.entity.dragons.cindervane.handlers.CindervaneAnimationHandler;
import com.leon.saintsdragons.server.entity.dragons.cindervane.handlers.CindervaneInteractionHandler;
import com.leon.saintsdragons.server.entity.dragons.cindervane.handlers.CindervaneSoundProfile;
import java.util.Map;
import com.leon.saintsdragons.server.entity.handler.DragonSoundHandler;
import com.leon.saintsdragons.server.entity.interfaces.DragonSoundProfile;
import com.leon.saintsdragons.server.entity.base.RideableDragonData;
import com.leon.saintsdragons.server.entity.interfaces.DragonFlightCapable;
import com.leon.saintsdragons.server.entity.interfaces.SoundHandledDragon;
import com.leon.saintsdragons.server.entity.interfaces.ShakesScreen;
import com.leon.saintsdragons.server.entity.interfaces.DragonSleepCapable;
import com.leon.saintsdragons.common.network.DragonRiderAction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.particles.ParticleTypes;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.keyframe.event.SoundKeyframeEvent;
import software.bernie.geckolib.util.GeckoLibUtil;
import javax.annotation.Nonnull;

public class Cindervane extends RideableDragonBase implements DragonFlightCapable, SoundHandledDragon, ShakesScreen, DragonSleepCapable {
    // Note: DATA_FIRE_BREATHING will be defined in defineSynchedData() using a unique ID
    private static final int LANDING_SETTLE_TICKS = 4;
    private static final double FIRE_BODY_CRASH_MIN_DROP = 7.0D;
    private static final float FIRE_BODY_EXPLOSION_RADIUS = 15.0F;
    private static final double FIRE_BODY_IMPRINT_RADIUS = 9.0D;
    private static final double FIRE_BODY_IMPRINT_DEPTH_FACTOR = 0.6D;
    private static final float FIRE_BODY_EXPLOSION_DAMAGE = 200.0F;

    private static final int MIN_AMBIENT_DELAY = 180;
    private static final int MAX_AMBIENT_DELAY = 420;

    private int ambientSoundTimer;
    private int nextAmbientSoundDelay;

    private static final Map<String, VocalEntry> VOCAL_ENTRIES =
        new VocalEntryBuilder()
            .add("grumble1", "actions", "animation.cindervane.grumble1", ModSounds.CINDERVANE_GRUMBLE_1, 1.1f, 0.98f, 0.06f, false, false, false)
            .add("grumble2", "actions", "animation.cindervane.grumble2", ModSounds.CINDERVANE_GRUMBLE_2, 1.2f, 0.96f, 0.08f, false, false, false)
            .add("grumble3", "actions", "animation.cindervane.grumble3", ModSounds.CINDERVANE_GRUMBLE_3, 1.0f, 1.0f, 0.05f, false, false, false)
            .add("roar", "actions", "animation.cindervane.roar", ModSounds.CINDERVANE_ROAR, 1.5f, 0.95f, 0.1f, false, false, false)
            .add("roar_ground", "actions", "animation.cindervane.roar_ground", ModSounds.CINDERVANE_ROAR, 1.5f, 0.9f, 0.05f, false, false, false)
            .add("roar_air", "actions", "animation.cindervane.roar_air", ModSounds.CINDERVANE_ROAR, 1.5f, 1.05f, 0.05f, false, false, false)
            .add("cindervane_hurt", "hurt", "animation.cindervane.hurt", ModSounds.CINDERVANE_HURT, 1.2f, 0.95f, 0.1f, false, false, false)
            .add("cindervane_die", "action", "animation.cindervane.die", ModSounds.CINDERVANE_DIE, 1.5f, 1.0f, 0.0f, false, false, false)
            .build();

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final CindervaneAnimationHandler animationHandler = new CindervaneAnimationHandler(this);
    private final CindervanePhysicsController physicsController = new CindervanePhysicsController(this);
    private final DragonSoundHandler soundHandler = new DragonSoundHandler(this);
    private final CindervaneInteractionHandler interactionHandler = new CindervaneInteractionHandler(this);
    private final CindervaneRiderController riderController;
    private final com.leon.saintsdragons.server.entity.sleep.DragonRestManager restManager = new com.leon.saintsdragons.server.entity.sleep.DragonRestManager(this);

    private final DragonPathNavigateGround groundNav;
    private final FlyingPathNavigation airNav;
    private boolean usingAirNav;

    private int targetCooldown;
    private int airTicks;
    public int groundTicks;
    public int timeFlying = 0;
    private int landingTicks;
    private int riderTakeoffTicks;
    private boolean wasVehicleLastTick;
    private boolean fireBodyCrashArmed;
    private double fireBodyCrashMaxHeight;

    // Banking smoothing state (mouse-sensitivity based, like Raevyx)
    private float bankSmoothedYaw = 0f;
    private int bankHoldTicks = 0;
    private int bankDir = 0; // -1 left, 0 none, 1 right
    private float bankAngle = 0f;
    private float prevBankAngle = 0f;

    private float pitchSmoothedPitch = 0f;
    private int pitchHoldTicks = 0;
    private int pitchDir = 0;

    private float prevScreenShakeAmount = 0f;
    private float screenShakeAmount = 0f;

    private static final double MODEL_SCALE = 1.0D;

    // ===== ALTITUDE-BASED FLYING SYSTEM (like Raevyx) =====
    private static final double RIDER_GLIDE_ALTITUDE_THRESHOLD = 40.0D;
    private static final double RIDER_GLIDE_ALTITUDE_EXIT = 30.0D; // Hysteresis: exit at lower altitude
    private boolean inHighAltitudeGlide = false; // Track glide state for smooth transitions

    // ===== RIDER LANDING BLEND SYSTEM =====
    private static final double RIDER_LANDING_BLEND_ALTITUDE = 8.0D; // Trigger landing animation at this altitude
    private static final int RIDER_LANDING_BLEND_DURATION = 3; // ticks to keep landing blend active
    private int riderLandingBlendTicks = 0;

    // ===== SIT TRANSITION SYSTEM =====
    private int sitTransitionTicks = 0; // Counts down during down/up animations
    private boolean isSittingDown = false; // True during "down" animation (45 ticks)
    private boolean isStandingUp = false;  // True during "up" animation (46 ticks)

    // ===== SLEEP SYSTEM =====
    // Sleep transition state
    private int sleepTransitionTicks = 0;
    private int sleepAmbientCooldownTicks = 0;
    // Re-entry suppression after aggression/damage to prevent instant resleep
    private int sleepReentryCooldownTicks = 0;
    private int sleepCancelTicks = 0;
    private boolean sleepLocked = false;
    private int sleepCommandSnapshot = -1;

    // ===== CLIENT LOCATOR CACHE (client-side only) =====
    private final Map<String, Vec3> clientLocatorCache = new java.util.concurrent.ConcurrentHashMap<>();

    // ===== Client animation overrides (for robust observer sync) =====

    public Cindervane(EntityType<? extends Cindervane> type, Level level) {
        super(type, level);
        this.m_274367_(1.1F);

        this.groundNav = new DragonPathNavigateGround(this, level);
        this.airNav = new FlyingPathNavigation(this, level) {
            @Override
            public boolean m_6342_(@Nonnull BlockPos pos) {
                BlockState below = this.f_26495_.m_8055_(pos.m_7495_());
                return !below.m_60795_();
            }
        };
        this.airNav.m_26440_(false);
        this.airNav.m_7008_(false);
        this.airNav.m_26443_(false);

        this.f_21344_ = groundNav;
        this.f_21342_ = new MoveControl(this);
        this.usingAirNav = false;
        this.riderController = new CindervaneRiderController(this);

        this.m_21441_(BlockPathTypes.LEAVES, -1.0F);
        this.m_21441_(BlockPathTypes.DANGER_FIRE, -1.0F);

        RandomSource rng = this.m_217043_();
        this.ambientSoundTimer = rng.m_188503_(80);
        this.nextAmbientSoundDelay = MIN_AMBIENT_DELAY + rng.m_188503_(Math.max(1, MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY + 1));
    }

    @Override
    public @NotNull SpawnGroupData m_6518_(@NotNull ServerLevelAccessor level, @NotNull DifficultyInstance difficulty, @NotNull MobSpawnType spawnType,
                                                 @Nullable SpawnGroupData spawnData, @Nullable CompoundTag dataTag) {
        SpawnGroupData data = super.m_6518_(level, difficulty, spawnType, spawnData, dataTag);

        if (!this.m_21824_()) {
            this.m_21816_(null);
            this.setCommand(2);
            this.m_21839_(false);
        }

        return data;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return TamableAnimal.m_21552_()
                .m_22268_(Attributes.f_22276_, 80.0D)
                .m_22268_(Attributes.f_22279_, 0.45D)
                .m_22268_(Attributes.f_22277_, 48.0D)
                .m_22268_(Attributes.f_22280_, 0.60D) // Slower for glider behavior
                .m_22268_(Attributes.f_22284_, 4.0D);
    }

    public static boolean canSpawnHere(EntityType<? extends Cindervane> type,
                                       LevelAccessor level,
                                       MobSpawnType spawnType,
                                       BlockPos pos,
                                       RandomSource random) {
        if (!Animal.m_218104_(type, level, spawnType, pos, random)) {
            return false;
        }

        // Reject waterlogged blocks or fluid directly around the spawn
        if (!level.m_6425_(pos).m_76178_()) {
            return false;
        }
        if (!level.m_6425_(pos.m_7495_()).m_76178_()) {
            return false;
        }

        // Optional: enforce a sturdy block underneath
        return level.m_8055_(pos.m_7495_()).m_60783_(level, pos.m_7495_(), Direction.UP);
    }

    // Amphithere-specific entity data accessors
    private static final EntityDataAccessor<Boolean> DATA_FIRE_BREATHING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    
    // Rideable dragon data accessors specific to Cindervane
    private static final EntityDataAccessor<Boolean> DATA_FLYING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_TAKEOFF =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_HOVERING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_LANDING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_RUNNING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Integer> DATA_GROUND_MOVE_STATE =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Integer> DATA_FLIGHT_MODE =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Float> DATA_RIDER_FORWARD =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Float> DATA_RIDER_STRAFE =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Boolean> DATA_GOING_UP =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_GOING_DOWN =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_ACCELERATING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Float> DATA_SCREEN_SHAKE_AMOUNT =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Boolean> DATA_RIDER_LANDING_BLEND =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);

    // Sleep system entity data accessors
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING_ENTERING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> DATA_SLEEPING_EXITING =
            SynchedEntityData.m_135353_(Cindervane.class, EntityDataSerializers.f_135035_);

    @Override
    protected void m_8097_() {
        super.m_8097_();
        // Define Amphithere-specific data
        this.f_19804_.m_135372_(DATA_FIRE_BREATHING, false);
        this.f_19804_.m_135372_(DATA_SCREEN_SHAKE_AMOUNT, 0f);
        this.f_19804_.m_135372_(DATA_RIDER_LANDING_BLEND, false);
        // Define sleep system data
        this.f_19804_.m_135372_(DATA_SLEEPING, false);
        this.f_19804_.m_135372_(DATA_SLEEPING_ENTERING, false);
        this.f_19804_.m_135372_(DATA_SLEEPING_EXITING, false);
    }

    @Override
    protected void defineRideableDragonData() {
        // Define all rideable dragon data keys for AmphithereEntity
        this.f_19804_.m_135372_(DATA_FLYING, false);
        this.f_19804_.m_135372_(DATA_TAKEOFF, false);
        this.f_19804_.m_135372_(DATA_HOVERING, false);
        this.f_19804_.m_135372_(DATA_LANDING, false);
        this.f_19804_.m_135372_(DATA_RUNNING, false);
        this.f_19804_.m_135372_(DATA_GROUND_MOVE_STATE, 0);
        this.f_19804_.m_135372_(DATA_FLIGHT_MODE, -1);
        this.f_19804_.m_135372_(DATA_RIDER_FORWARD, 0f);
        this.f_19804_.m_135372_(DATA_RIDER_STRAFE, 0f);
        this.f_19804_.m_135372_(DATA_GOING_UP, false);
        this.f_19804_.m_135372_(DATA_GOING_DOWN, false);
        this.f_19804_.m_135372_(DATA_ACCELERATING, false);
    }

    // Implementation of abstract accessor methods
    @Override
    protected EntityDataAccessor<Float> getRiderForwardAccessor() {
        return DATA_RIDER_FORWARD;
    }

    @Override
    protected EntityDataAccessor<Float> getRiderStrafeAccessor() {
        return DATA_RIDER_STRAFE;
    }

    @Override
    protected EntityDataAccessor<Integer> getGroundMoveStateAccessor() {
        return DATA_GROUND_MOVE_STATE;
    }

    @Override
    protected EntityDataAccessor<Integer> getFlightModeAccessor() {
        return DATA_FLIGHT_MODE;
    }

    @Override
    protected EntityDataAccessor<Boolean> getGoingUpAccessor() {
        return DATA_GOING_UP;
    }

    @Override
    protected EntityDataAccessor<Boolean> getGoingDownAccessor() {
        return DATA_GOING_DOWN;
    }

    @Override
    protected EntityDataAccessor<Boolean> getAcceleratingAccessor() {
        return DATA_ACCELERATING;
    }

    @Override
    protected void applyLoadedFlightState(boolean flying, boolean takeoff, boolean hovering, boolean landing) {
        setFlying(flying);
        setTakeoff(takeoff);
        setHovering(hovering);
        setLanding(landing);
    }

    @Override
    protected void m_8099_() {
        this.f_21345_.m_25352_(0, new FloatGoal(this));
        this.f_21345_.m_25352_(1, new CindervaneSleepGoal(this)); // Sleep goal - high priority (tamed dragons sleep with owner)
        this.f_21345_.m_25352_(2, new CindervaneRestGoal(this)); // Wild rest/sleep goal - night-time only (MUST be before FlightGoal!)
        this.f_21345_.m_25352_(3, new SitWhenOrderedToGoal(this));
        this.f_21345_.m_25352_(4, new CindervaneFlightGoal(this));
        this.f_21345_.m_25352_(5, new CindervaneCombatGoal(this));
        this.f_21345_.m_25352_(6, new CindervaneFollowOwnerGoal(this));
        this.f_21345_.m_25352_(7, new CindervaneGroundWanderGoal(this, 0.6D, 160));

        this.f_21346_.m_25352_(1, new com.leon.saintsdragons.server.ai.goals.base.DragonOwnerHurtByTargetGoal(this));
        this.f_21346_.m_25352_(2, new com.leon.saintsdragons.server.ai.goals.base.DragonOwnerHurtTargetGoal(this));
        this.f_21346_.m_25352_(3, new HurtByTargetGoal(this));
        // Look goals that skip when being ridden (so rider has full control)
        this.f_21345_.m_25352_(12, new RandomLookAroundGoal(this) {
            @Override
            public boolean m_8036_() {
                return !Cindervane.this.m_20160_() && super.m_8036_();
            }
        });
        this.f_21345_.m_25352_(12, new LookAtPlayerGoal(this, Player.class, 8.0F) {
            @Override
            public boolean m_8036_() {
                return !Cindervane.this.m_20160_() && super.m_8036_();
            }
        });
    }

    @Override
    public void m_8107_() {
        super.m_8107_();

        if (!this.m_9236_().f_46443_) {
            if (!this.m_21827_() && this.f_19804_.m_135370_(DATA_SIT_PROGRESS) != 0f) {
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
            }
            // Only consider SOLID ground, not water (water should not trigger landing)
            boolean onGroundNow = this.m_20096_() && !this.m_20069_();

            if (m_29443_()) {
                airTicks++;
                groundTicks = 0;
                this.f_19789_ = 0.0F;

                if (isTakeoff() && !onGroundNow && airTicks > 5) {
                    setTakeoff(false);
                }

                if (onGroundNow && !isTakeoff()) {
                    if (!isLanding()) {
                        setLanding(true);
                    }
                    setFlying(false);
                } else if (isLanding() && !onGroundNow) {
                    setLanding(false);
                }
            } else {
                groundTicks++;
                airTicks = 0;
            }

            if (isLanding()) {
                // Hold landing state briefly so the landing animation can finish before ground loops resume
                if (onGroundNow) {
                    landingTicks++;
                    if (landingTicks >= LANDING_SETTLE_TICKS) {
                        markLandedNow();
                    }
                } else {
                    landingTicks = 0;
                }
            } else {
                landingTicks = 0;
            }

            // Update animation states
            tickAnimationStates();
        }

        this.m_20242_(m_29443_() || isHovering());
        if (!m_29443_() && usingAirNav) {
            switchToGroundNavigation();
        }
    }

    public void m_8119_() {
        super.m_8119_();

        // Tick physics controller to update flight mode computation
        physicsController.tick();

        tickSittingState();
        tickBankingLogic();
        tickPitchingLogic();
        tickRiderTakeoff();
        tickMountedState();
        tickScreenShake();
        updateSittingProgress();
        tickSleepTransition();
        tickSleepCooldowns();
        tickWaterSlicing();

        if (!m_9236_().f_46443_) {
            // Ensure sit animation is cleared for riders even if packets arrive late
            if (m_20160_() && this.f_19804_.m_135370_(DATA_SIT_PROGRESS) != 0f) {
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
            }
            if (targetCooldown > 0) {
                targetCooldown--;
            }
            handleFireBodyCrash();
            // Update timeFlying counter
            if (m_29443_()) {
                timeFlying++;
            } else {
                timeFlying = 0;
            }
            handleAmbientSounds();

            // Wake up if sleeping and conditions changed
            if (m_5803_() || isSleepingEntering() || isSleepingExiting()) {
                if (this.m_5448_() != null || this.m_5912_()) {
                    wakeUpImmediately();
                    suppressSleep(200);
                } else if (this.m_20072_() || this.m_20077_()) {
                    wakeUpImmediately();
                    suppressSleep(200);
                }
            }
        }

        // Initialize animation state on first tick after loading to prevent thrashing
        if (!m_9236_().f_46443_ && this.f_19797_ == 1) {
            initializeAnimationState();
        }

        tickClientSideUpdates();
    }

    private void tickSittingState() {
        // Clear sitting state if the dragon is being ridden
        if (!this.m_9236_().f_46443_ && this.m_20160_() && this.m_21827_()) {
            this.m_21839_(false);
        }
    }

    private void tickMountedState() {
        boolean mounted = this.m_20160_();

        if (mounted && !wasVehicleLastTick) {
            this.sitProgress = 0f;
            this.prevSitProgress = 0f;
            this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
            clearStatesWhenMounted();

            if (this.m_21827_()) {
                this.m_21839_(false);
                if (this.getCommand() == 1) {
                    this.setCommand(0);
                }
            }

            // Clear sleep states when mounted
            if (m_5803_() || isSleepingEntering() || isSleepingExiting()) {
                wakeUpImmediately();
                suppressSleep(300); // ~15 seconds
            }
        }

        if (!mounted && wasVehicleLastTick) {
            this.setBreathingFire(false);
            combatManager.forceEndActiveAbility();
            this.sitProgress = 0f;
            this.prevSitProgress = 0f;
            this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
            this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, 0);
            this.f_19804_.m_135381_(DATA_FLIGHT_MODE, -1);
            this.f_19804_.m_135381_(DATA_RIDER_FORWARD, 0f);
            this.f_19804_.m_135381_(DATA_RIDER_STRAFE, 0f);
            this.syncAnimState(0, -1);
        }

        wasVehicleLastTick = mounted;
    }

    private void updateSittingProgress() {
        if (m_9236_().f_46443_) {
            return;
        }

        // Tick down sit transition animations
        if (sitTransitionTicks > 0) {
            sitTransitionTicks--;
            if (sitTransitionTicks == 0) {
                isSittingDown = false;
                isStandingUp = false;
            }
        }

        if (this.m_21827_()) {
            // Trigger sit down animation when:
            // 1. Starting from standing (sitProgress == 0), OR
            // 2. Interrupting a stand-up animation (isStandingUp = true)
            if ((sitProgress == 0f || isStandingUp) && !isSittingDown) {
                animationHandler.triggerSitDownAnimation();
                isSittingDown = true;
                isStandingUp = false; // Cancel the stand-up
                sitTransitionTicks = 45; // down animation is 2.25s = 45 ticks
            }

            if (sitProgress < maxSitTicks()) {
                sitProgress++;
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        } else {
            // NOT ordered to sit - standing up sequence
            if (m_20160_()) {
                if (sitProgress != 0f) {
                    sitProgress = 0f;
                    prevSitProgress = 0f;
                    this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
                }
            } else if (sitProgress > 0f) {
                // Trigger sit up animation when:
                // 1. At or near max sitting and ready to stand, OR
                // 2. Interrupting a sit-down animation (isSittingDown = true)
                if ((sitProgress >= maxSitTicks() - 1 || isSittingDown) && !isStandingUp) {
                    animationHandler.triggerSitUpAnimation();
                    isStandingUp = true;
                    isSittingDown = false; // Cancel the sit-down
                    sitTransitionTicks = 46; // up animation is 2.2917s = ~46 ticks
                }

                // Always decrement sitProgress when standing up (let the animation play as it decrements)
                sitProgress--;
                if (sitProgress < 0f) sitProgress = 0f;
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        }
    }

    private void tickClientSideUpdates() {
        // Update client-side sit progress from synchronized data
        if (m_9236_().f_46443_) {
            prevSitProgress = sitProgress;
            sitProgress = this.f_19804_.m_135370_(DATA_SIT_PROGRESS);
        }
    }

    private void handleAmbientSounds() {
        if (nextAmbientSoundDelay <= 0) {
            resetAmbientSoundTimer();
        }

        // Suppress ambient sounds during transitions to prevent animation snapping
        if (m_6162_() || isDying() || m_5803_() || isSleepTransitioning() || isInSitTransition() || sleepAmbientCooldownTicks > 0) {
            ambientSoundTimer = 0;
            return;
        }

        if (getActiveAbility() != null || isBreathingFire() || this.m_5448_() != null) {
            ambientSoundTimer = 0;
            return;
        }

        if (m_20160_() || isTakeoff() || isLanding() || isHovering()) {
            return;
        }

        ambientSoundTimer++;
        if (ambientSoundTimer < nextAmbientSoundDelay) {
            return;
        }

        String vocal = selectAmbientGrumble();
        if (vocal != null) {
            this.getSoundHandler().playVocal(vocal);
        }
        resetAmbientSoundTimer();
    }

    private String selectAmbientGrumble() {
        RandomSource random = m_217043_();
        float roll = random.m_188501_();

        if (roll < 0.45f) {
            return "grumble1";
        }
        if (roll < 0.8f) {
            return "grumble2";
        }
        return "grumble3";
    }

    private void resetAmbientSoundTimer() {
        ambientSoundTimer = 0;
        RandomSource random = m_217043_();
        int range = Math.max(1, MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY + 1);
        nextAmbientSoundDelay = MIN_AMBIENT_DELAY + random.m_188503_(range);
    }

    private void clearStatesWhenMounted() {
        if (m_9236_().f_46443_ || !this.m_20160_()) {
            return;
        }

        setRunning(false);
        setGoingUp(false);
        setGoingDown(false);
        setHovering(false);
        setLanding(false);
        setTakeoff(false);
        setAccelerating(false);
        this.riderTakeoffTicks = 0;

        if (!m_29443_()) {
            airTicks = 0;
        }

        if (this.m_21573_().m_26570_() != null) {
            this.m_21573_().m_26573_();
        }

        if (!m_29443_() && usingAirNav) {
            switchToGroundNavigation();
        }

        this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, 0);
        this.f_19804_.m_135381_(DATA_FLIGHT_MODE, -1);
        this.f_19804_.m_135381_(DATA_RIDER_FORWARD, 0f);
        this.f_19804_.m_135381_(DATA_RIDER_STRAFE, 0f);
        this.syncAnimState(0, -1);

        this.m_6710_(null);
        this.m_21839_(false);
        this.m_20242_(m_29443_() || isHovering());
    }
    private void tickRiderTakeoff() {
        if (!m_9236_().f_46443_ && riderTakeoffTicks > 0) {
            riderTakeoffTicks--;
            Vec3 velocity = this.m_20184_();
            double boost = this.m_29443_() ? 0.08D : 0.12D;
            if (velocity.f_82480_ < boost) {
                this.m_20334_(velocity.f_82479_, boost, velocity.f_82481_);
            }
            this.f_19812_ = true;
        }
    }

    private void tickBankingLogic() {
        prevBankAngle = bankAngle;

        // Apply banking to all flying Cindervanes (ridden and wild)
        boolean shouldBank = m_29443_() && !isLanding() && !isHovering() && !m_21827_();

        // Reset banking when not flying - instant snap back
        if (!shouldBank) {
            if (bankDir != 0 || bankAngle != 0f || bankSmoothedYaw != 0f) {
                bankDir = 0;
                bankSmoothedYaw = 0f;
                bankHoldTicks = 0;
                bankAngle = 0f;
                prevBankAngle = 0f;
            }
            return;
        }

        // Exponential smoothing on yaw delta to avoid jitter, wrap to account for crossing 360 -> 0
        float yawChange = Mth.m_14177_(m_146908_() - f_19859_);
        bankSmoothedYaw = bankSmoothedYaw * 0.75f + yawChange * 0.25f;

        // Convert smoothed yaw delta into a banking roll. Multiplying gives us headroom for aggressive turns.
        // More aggressive multiplier for glider-style banking (6.0f vs Raevyx's 5.0f)
        float targetAngle = Mth.m_14036_(bankSmoothedYaw * 6.0f, -90f, 90f);
        // Ease toward the new target so long sweeping turns feel weighty but responsive.
        bankAngle = Mth.m_14179_(0.30f, bankAngle, targetAngle);
        if (Math.abs(bankAngle) < 0.01f) {
            bankAngle = 0f;
        }

        // Update coarse direction for animation fallbacks
        float enter = 10.0f;
        float exit = 4.0f;

        int desiredDir = bankDir;
        if (bankAngle > enter) desiredDir = 1;
        else if (bankAngle < -enter) desiredDir = -1;
        else if (Math.abs(bankAngle) < exit) desiredDir = 0;  // banking_off when flying straight

        if (desiredDir != bankDir) {
            // If transitioning to "off" (0), use very short hold time for instant reset
            int holdTime = (desiredDir == 0) ? 1 : 2;
            if (bankHoldTicks >= holdTime) {
                bankDir = desiredDir;
                bankHoldTicks = 0;
            } else {
                bankHoldTicks++;
            }
        } else {
            bankHoldTicks = Math.min(bankHoldTicks + 1, 10);
        }
    }

    private void tickRiderLandingBlendTimer() {
        if (!m_20160_() || !m_29443_() || m_20096_()) {
            riderLandingBlendTicks = 0;
            if (!m_9236_().f_46443_) {
                this.f_19804_.m_135381_(DATA_RIDER_LANDING_BLEND, false);
            }
            return;
        }
        if (riderLandingBlendTicks > 0) {
            riderLandingBlendTicks--;
            if (riderLandingBlendTicks == 0 && !m_9236_().f_46443_) {
                this.f_19804_.m_135381_(DATA_RIDER_LANDING_BLEND, false);
            }
        }
    }

    private void triggerRiderLandingBlend() {
        riderLandingBlendTicks = RIDER_LANDING_BLEND_DURATION;
        if (!m_9236_().f_46443_) {
            this.f_19804_.m_135381_(DATA_RIDER_LANDING_BLEND, true);
        }
    }

    public boolean isRiderLandingBlendActive() {
        return this.f_19804_.m_135370_(DATA_RIDER_LANDING_BLEND);
    }

    private double getAltitudeAboveTerrain() {
        net.minecraft.core.BlockPos pos = this.m_20183_();
        if (!m_9236_().m_46805_(pos)) {
            return Double.POSITIVE_INFINITY;
        }

        // Use MOTION_BLOCKING_NO_LEAVES to find solid ground below water
        int groundY = this.m_9236_().m_6924_(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                pos.m_123341_(), pos.m_123343_());

        // Scan a column from slightly above dragon down to BELOW the heightmap (heightmap returns +1 above actual blocks)
        int dragonY = (int) Math.floor(this.m_20186_());
        int scanTopY = dragonY + 3; // Check a bit above dragon (in case partially submerged)
        int scanBottomY = Math.min(groundY - 1, dragonY - 15);  // Scan below heightmap to catch water

        // Scan downward from above dragon to ground, checking for water at any height
        for (int y = scanTopY; y >= scanBottomY; y--) {
            BlockPos checkPos = new BlockPos(pos.m_123341_(), y, pos.m_123343_());
            BlockState checkState = m_9236_().m_8055_(checkPos);

            if (!checkState.m_60819_().m_76178_()) {
                // Water/lava detected in column - don't trigger landing
                return Double.POSITIVE_INFINITY;
            }
        }

        return this.m_20186_() - groundY;
    }

    private void tickPitchingLogic() {
        tickRiderLandingBlendTimer();
        // Reset pitching when not flying or when controls are locked - INSTANT reset
        if (!m_29443_() || isLanding() || isHovering() || m_21827_()) {
            if (pitchDir != 0) {
                pitchDir = 0;
                pitchSmoothedPitch = 0f;
                pitchHoldTicks = 0;
            }
            return;
        }
        
        int desiredDir = pitchDir;

        if (this.m_20160_() && this.m_6688_() instanceof Player) {
            // Handle rider input for pitching
            if (isGoingUp()) {
                desiredDir = -1;  // Pitching up
            } else if (isGoingDown()) {
                desiredDir = 1;   // Pitching down
            } else {
                desiredDir = 0;   // No pitching
            }
            // Trigger landing blend when descending close to ground
            if (isGoingDown()) {
                double altitude = getAltitudeAboveTerrain();
                if (altitude != Double.POSITIVE_INFINITY && altitude >= -0.25D && altitude <= RIDER_LANDING_BLEND_ALTITUDE) {
                    desiredDir = 0; // Stop pitching down
                    triggerRiderLandingBlend();
                }
            }
        } else {
            // AI-controlled pitching based on movement - slower for glider
            float pitchChange = m_146909_() - f_19860_;
            pitchSmoothedPitch = pitchSmoothedPitch * 0.90f + pitchChange * 0.10f; // Slower smoothing

            // Hysteresis thresholds - less sensitive for smoother glider behavior
            float enter = 4.0f;  // Less sensitive for smoother pitching
            float exit = 6.0f;   // Larger exit threshold for stability

            if (pitchSmoothedPitch > enter) desiredDir = 1;
            else if (pitchSmoothedPitch < -enter) desiredDir = -1;
            else if (Math.abs(pitchSmoothedPitch) < exit) desiredDir = 0;  // pitching_off when flying straight
        }

        // Smoother transitions for glider behavior
        if (desiredDir != pitchDir) {
            // Longer hold times for smoother pitching transitions
            int holdTime = (desiredDir == 0) ? 4 : 6; // Longer hold for smoother pitching
            if (pitchHoldTicks >= holdTime) {
                pitchDir = desiredDir;
                pitchHoldTicks = 0;
            } else {
                pitchHoldTicks++;
            }
        } else {
            pitchHoldTicks = Math.min(pitchHoldTicks + 1, 15);  // Increased max for stability
        }
    }

    private void tickScreenShake() {
        prevScreenShakeAmount = screenShakeAmount;
        if (screenShakeAmount > 0f) {
            screenShakeAmount = Math.max(0f, screenShakeAmount - 0.12F);
            this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, screenShakeAmount);
        }
    }

    // ===== WATER DISTURBANCE EFFECT (wing downforce) =====

    // Tuneable constants
    private static final double WATER_EFFECT_MAX_HEIGHT = 10.0;  // Max height above water to trigger effect
    private static final double WATER_EFFECT_INTENSITY = 1.5;    // Multiplier for particle count (bigger = more splash)

    /**
     * Creates water disturbance effects when flying over water.
     * Uses vanilla-style splash logic based on bounding box size.
     * Bigger dragons automatically create bigger splashes!
     */
    private void tickWaterSlicing() {
        // Only run on server side
        if (m_9236_().f_46443_) return;

        // Only when flying
        if (!m_29443_()) return;

        // Get dragon position and bounding box
        Vec3 pos = m_20182_();
        AABB box = m_20191_();

        // Check for water below (scan down from dragon position)
        for (int checkDown = 0; checkDown < WATER_EFFECT_MAX_HEIGHT; checkDown++) {
            BlockPos checkPos = new BlockPos(
                (int) Math.floor(pos.f_82479_),
                (int) Math.floor(pos.f_82480_) - checkDown,
                (int) Math.floor(pos.f_82481_)
            );

            BlockState state = m_9236_().m_8055_(checkPos);

            // Found water surface?
            if (!state.m_60819_().m_76178_()) {
                double waterY = checkPos.m_123342_() + 1.0; // Top of water block

                // === VANILLA-STYLE SPLASH BASED ON BOUNDING BOX SIZE ===
                // Calculate bounding box dimensions
                double boxWidth = box.m_82362_();   // Width (X axis)
                double boxLength = box.m_82385_();  // Length (Z axis)

                // Calculate particle count based on entity size (vanilla formula)
                // Bigger bounding box = more particles
                int particleCount = (int) Math.ceil((boxWidth + boxLength) / 2.0 * WATER_EFFECT_INTENSITY * 8.0);
                particleCount = Math.min(particleCount, 50); // Cap to prevent lag

                // Spawn particles around the perimeter of the bounding box
                for (int i = 0; i < particleCount; i++) {
                    // Random position within bounding box horizontal area
                    double offsetX = (f_19796_.m_188500_() - 0.5) * boxWidth;
                    double offsetZ = (f_19796_.m_188500_() - 0.5) * boxLength;

                    double particleX = pos.f_82479_ + offsetX;
                    double particleZ = pos.f_82481_ + offsetZ;

                    // Spawn splash particles
                    ((ServerLevel) m_9236_()).m_8767_(
                        ParticleTypes.f_123769_,
                        particleX, waterY, particleZ,
                        1,
                        offsetX * 0.2, 0.1, offsetZ * 0.2,  // Velocity based on offset (spreads outward)
                        0.1
                    );

                    // Bubbles (fewer than splashes)
                    if (f_19796_.m_188501_() < 0.3f) {
                        ((ServerLevel) m_9236_()).m_8767_(
                            ParticleTypes.f_123772_,
                            particleX, waterY, particleZ,
                            1,
                            0.0, 0.0, 0.0,
                            0.0
                        );
                    }
                }

                break; // Found water, stop scanning down
            }
        }
    }

    /**
     * Gets the current bank direction for animation purposes
     * @return -1 for left, 0 for none, 1 for right
     */
    public int getBankDirection() {
        return bankDir;
    }

    /**
     * Gets the current bank angle in degrees. Positive values bank right, negative bank left.
     * This is based on mouse drag sensitivity - faster mouse movement = harder banking.
     */
    public float getBankAngleDegrees() {
        return bankAngle;
    }

    /**
     * Interpolated bank angle for smooth client-side rendering.
     */
    public float getBankAngleDegrees(float partialTick) {
        return Mth.m_14179_(partialTick, prevBankAngle, bankAngle);
    }

    /**
     * Legacy method - returns smooth bank direction for animation
     * Returns a smooth value based on actual bank angle
     */
    public float getSmoothBankDirection() {
        // Normalize bank angle to -1.0 to 1.0 range for animation
        return Mth.m_14036_(bankAngle / 45.0f, -1.0f, 1.0f);
    }

    public int getPitchDirection() {
        return pitchDir;
    }

    /**
     * Gets the number of ticks the dragon has been airborne.
     * Used for takeoff animation timing.
     */
    public int getAirTicks() {
        return airTicks;
    }
    public int getTimeFlying() {
        return timeFlying;
    }

    // ===== Rider Control Methods =====
    @Override
    public boolean isGoingUp() {
        return this.f_19804_.m_135370_(DATA_GOING_UP); 
    }

    // ===== Animation State Methods =====
    
    @Override
    public boolean isRunning() {
        return this.f_19804_.m_135370_(DATA_RUNNING);
    }

    @Override
    public void setRunning(boolean running) {
        this.f_19804_.m_135381_(DATA_RUNNING, running);
    }
    
    public boolean isWalking() {
        if (m_9236_().f_46443_) {
            int s = getEffectiveGroundState();
            return s == 1; // walking state
        }
        int s = this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);
        return s == 1; // walking state
    }
    

    public void setGroundMoveStateFromAI(int state) {
        if (!this.m_9236_().f_46443_) {
            int s = Mth.m_14045_(state, 0, 2);
            if (this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE) != s) {
                this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, s);
                this.syncAnimState(s, getSyncedFlightMode());
            }
        }
    }


    
    // Rider input snapshots for server-side animation sync
    
    /**
     * Initialize animation state after entity loading to prevent thrashing.
     */
    @Override
    public void initializeAnimationState() {
        super.initializeAnimationState();
        if (!m_9236_().f_46443_) {
            // Reset all tick counters to ensure clean state
            groundTicks = 0;
            airTicks = 0;
            landingTicks = 0;
        }
    }
    

    // ===== Client animation overrides (for robust observer sync) =====
    
    

    @Override
    public int getFlightMode() {
        // Delegate to physics controller for consistent flight mode computation
        return physicsController.computeFlightModeForSync();
    }

    @Override
    protected void applyRiderVerticalInput(Player player, boolean goingUp, boolean goingDown, boolean locked) {
        if (this.m_29443_()) {
            setGoingUp(goingUp);
            setGoingDown(goingDown);
        } else {
            setGoingUp(false);
            setGoingDown(false);
        }
    }

    @Override
    protected void applyRiderMovementInput(Player player, float forward, float strafe, float yaw, boolean locked) {
        float fwd = applyInputDeadzone(forward);
        float str = applyInputDeadzone(strafe);
        setLastRiderForward(fwd);
        setLastRiderStrafe(str);
        if (!m_29443_()) {
            int moveState = 0;
            float magnitude = Math.abs(fwd) + Math.abs(str);
            if (magnitude > 0.05f) {
                moveState = isAccelerating() ? 2 : 1;
            }
            setGroundMoveStateFromAI(moveState);
            setRunning(moveState == 2);
        }
    }

    @Override
    protected void handleRiderAction(ServerPlayer player, DragonRiderAction action, String abilityName, boolean locked) {
        if (action == null) {
            return;
        }
        switch (action) {
            case TAKEOFF_REQUEST -> requestRiderTakeoff();
            case ACCELERATE -> setAccelerating(true);
            case STOP_ACCELERATE -> setAccelerating(false);
            case ABILITY_USE -> {
                if (abilityName != null && !abilityName.isEmpty()) {
                    useRidingAbility(abilityName);
                }
            }
            case ABILITY_STOP -> {
                if (abilityName != null && !abilityName.isEmpty()) {
                    forceEndActiveAbility();
                }
            }
            default -> { }
        }
    }

    @Override
    public RiderAbilityBinding getTertiaryRiderAbility() {
        return new RiderAbilityBinding(CindervaneAbilities.FIRE_BODY_ID, RiderAbilityBinding.Activation.HOLD);
    }

    @Override
    public RiderAbilityBinding getPrimaryRiderAbility() {
        return new RiderAbilityBinding(CindervaneAbilities.ROAR_ID, RiderAbilityBinding.Activation.PRESS);
    }

    @Override
    public RiderAbilityBinding getSecondaryRiderAbility() {
        return new RiderAbilityBinding(CindervaneAbilities.FIRE_BREATH_VOLLEY_ID, RiderAbilityBinding.Activation.PRESS);
    }

    @Override
    public RiderAbilityBinding getAttackRiderAbility() {
        return new RiderAbilityBinding(CindervaneAbilities.BITE_ID, RiderAbilityBinding.Activation.PRESS);
    }


    // ===== Riding System Methods =====

    protected int getMaxPassengers() {
        // Two-seater: Seat 0 (driver/owner) + Seat 1 (passenger)
        return 2;
    }

    @Override
    protected boolean m_7310_(@NotNull Entity passenger) {
        // Allow up to 2 passengers
        return this.m_20197_().size() < getMaxPassengers();
    }

    public void requestRiderTakeoff() {
        riderController.requestRiderTakeoff();
    }

    public double m_6048_() {
        return riderController.getPassengersRidingOffset();
    }
    
    @Override
    protected void m_19956_(@Nonnull Entity passenger, @Nonnull Entity.MoveFunction moveFunction) {
        riderController.positionRider(passenger, moveFunction);
    }
    
    @Override
    public @NotNull Vec3 m_7688_(@Nonnull LivingEntity passenger) {
        return riderController.getDismountLocationForPassenger(passenger);
    }
    
    @Override
    public @Nullable LivingEntity m_6688_() {
        return riderController.getControllingPassenger();
    }
    
    @Override
    protected float m_245547_(@Nonnull Player rider) {
        return riderController.getRiddenSpeed(rider);
    }
    
    @Override
    protected void m_274498_(@Nonnull Player player, @Nonnull Vec3 travelVector) {
        super.m_274498_(player, travelVector);
        riderController.tickRidden(player, travelVector);
        // Only call copyRiderLook when not using any ability (active or overlay) to preserve pitch animation
        if (areRiderControlsLocked() && combatManager.getActiveAbility() == null && !combatManager.hasActiveOverlay()) {
            copyRiderLook(player);
        }
    }
    
    @Override
    public @NotNull Vec3 m_274312_(@Nonnull Player player, @Nonnull Vec3 deltaIn) {
        Vec3 input = riderController.getRiddenInput(player, deltaIn);
        
        // Capture rider inputs for animation state (like Lightning Dragon)
        if (!m_9236_().f_46443_ && !m_29443_()) {
            float fwd = (float) Mth.m_14008_(input.f_82481_, -1.0, 1.0);
            float str = (float) Mth.m_14008_(input.f_82479_, -1.0, 1.0);
            this.f_19804_.m_135381_(DATA_RIDER_FORWARD, RideableDragonData.applyInputThreshold(fwd));
            this.f_19804_.m_135381_(DATA_RIDER_STRAFE, RideableDragonData.applyInputThreshold(str));
        }
        
        return input;
    }

    @Override
    public void m_21839_(boolean sitting) {
        super.m_21839_(sitting);

        if (sitting) {
            if (m_29443_()) {
                this.setLanding(true);
            }
            this.setRunning(false);
            this.m_21573_().m_26573_();
            if (!m_9236_().f_46443_) {
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, this.sitProgress);
            }
        }
        // Don't clear sitProgress when standing - let updateSittingProgress() handle the "up" animation transition
    }
    
    @Override
    public void m_7023_(@NotNull Vec3 motion) {
        // Riding logic
        if (this.m_20160_() && this.m_6688_() instanceof Player player) {
            // Clear any AI navigation when being ridden
            if (this.m_21573_().m_26570_() != null) {
                this.m_21573_().m_26573_();
            }

            if (m_29443_()) {
                // Delegate flying movement to rider controller for consistency
                this.riderController.handleRiderMovement(player, motion);
            } else {
                // Ground movement - use vanilla system which calls getRiddenInput()
                super.m_7023_(motion);
            }
        } else {
            // Normal AI movement
            super.m_7023_(motion);
        }
    }

    public void switchToAirNavigation() {
        if (!usingAirNav) {
            this.f_21344_ = this.airNav;
            this.f_21342_ = new DragonFlightMoveHelper(this, getGliderFlightParameters());
            this.usingAirNav = true;
        }
    }

    // Amphithere-specific flight parameters for glider behavior
    private DragonFlightMoveHelper.FlightParameters getGliderFlightParameters() {
        return new DragonFlightMoveHelper.FlightParameters(
            3.0F,    // maxYawChange - smoother turns for gradual banking
            5.0F,    // maxPitchChange - slower pitching for glider
            0.3F,    // speedFactorMin - lower minimum speed
            2.0F,    // speedFactorMax - lower maximum speed for glider
            0.08F,   // speedTransitionRate - slower transitions for glider
            0.15D,   // accelerationCap - lower acceleration cap for glider
            0.10D    // velocityBlendRate - gentler blend for glider
        );
    }

    private void handleFireBodyCrash() {
        boolean fireActive = this.isBreathingFire();
        boolean airborne = !this.m_20096_();
        LivingEntity rider = this.m_6688_();
        if (fireActive && rider != null) {
            rider.m_7292_(new MobEffectInstance(MobEffects.f_19607_, 10, 0, true, false, false));
        }
        if (fireActive && airborne) {
            if (!fireBodyCrashArmed) {
                fireBodyCrashMaxHeight = this.m_20186_();
            } else if (this.m_20186_() > fireBodyCrashMaxHeight) {
                fireBodyCrashMaxHeight = this.m_20186_();
            }
            fireBodyCrashArmed = true;
        }
        if (fireBodyCrashArmed && !airborne && fireActive) {
            double dropDistance = fireBodyCrashMaxHeight - this.m_20186_();
            if (dropDistance >= FIRE_BODY_CRASH_MIN_DROP) {
                triggerFireBodyCrash();
            }
            fireBodyCrashArmed = false;
            fireBodyCrashMaxHeight = 0.0D;
        }
        if (!fireActive && !airborne) {
            fireBodyCrashArmed = false;
            fireBodyCrashMaxHeight = 0.0D;
        }
    }

    private void triggerFireBodyCrash() {
        if (!(m_9236_() instanceof ServerLevel server)) {
            return;
        }
        double x = this.m_20185_();
        double y = this.m_20186_();
        double z = this.m_20189_();
        List<Entity> immune = new ArrayList<>(this.m_20197_());
        
        // Give passengers explosion resistance before the explosion
        for (Entity passenger : immune) {
            if (passenger instanceof LivingEntity livingPassenger) {
                livingPassenger.m_7292_(new MobEffectInstance(MobEffects.f_19606_, 20, 4, true, false, false));
            }
        }
        
        ExplosionDamageCalculator calculator = new ExplosionDamageCalculator() {
            @Override
            public @NotNull Optional<Float> m_6617_(@NotNull Explosion explosion, @NotNull BlockGetter level, @NotNull BlockPos pos, @NotNull BlockState state, @NotNull FluidState fluid) {
                if (isFireBodyImmuneBlock(state)) {
                    return Optional.of(Float.MAX_VALUE);
                }
                return Optional.of(0.0F);
            }

            @Override
            public boolean m_6714_(@NotNull Explosion explosion, @NotNull BlockGetter level, @NotNull BlockPos pos, @NotNull BlockState state, float exposure) {
                return !isFireBodyImmuneBlock(state);
            }
        };

        Explosion explosion = new Explosion(server, this, server.m_269111_().m_269036_(this, this), calculator,
                x, y + 0.2D, z, FIRE_BODY_EXPLOSION_RADIUS, true, Explosion.BlockInteraction.DESTROY);

        List<LivingEntity> allies = grantAlliesExplosionImmunity(server, x, y, z);

        // Make allies temporarily invulnerable to prevent armor damage
        for (LivingEntity ally : allies) {
            ally.m_20331_(true);
        }

        explosion.m_46061_();
        explosion.m_46075_(true);

        // Restore vulnerability
        for (LivingEntity ally : allies) {
            ally.m_20331_(false);
        }

        applyFireBodyBlastDamage(server, x, y, z, immune);

        carveFireBodyImprint(server, BlockPos.m_274561_(x, y, z));

        server.m_8767_(ParticleTypes.f_123744_, x, y + 0.8D, z, 150, 2.0D, 1.0D, 2.0D, 0.2D);
        server.m_8767_(ParticleTypes.f_175834_, x, y + 0.5D, z, 120, 1.8D, 0.8D, 1.8D, 0.15D);
        server.m_8767_(ParticleTypes.f_123756_, x, y + 0.5D, z, 40, 1.3D, 0.6D, 1.3D, 0.12D);
        server.m_8767_(ParticleTypes.f_123755_, x, y + 0.5D, z, 80, 2.2D, 0.7D, 2.2D, 0.05D);

        BlockPos.MutableBlockPos flamePos = new BlockPos.MutableBlockPos();
        int baseY = this.m_146904_();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                if (this.m_217043_().m_188501_() > 0.45F) {
                    continue;
                }
                flamePos.m_122169_(x + dx, baseY, z + dz);
                if (!server.m_46749_(flamePos)) {
                    continue;
                }
                if (!server.m_8055_(flamePos).m_60795_()) {
                    continue;
                }
                BlockState belowState = server.m_8055_(flamePos.m_7495_());
                if (!belowState.m_60795_() && Blocks.f_50083_.m_49966_().m_60710_(server, flamePos)) {
                    server.m_7731_(flamePos, Blocks.f_50083_.m_49966_(), 11);
                }
            }
        }
        this.forceEndActiveAbility();
    }

    private boolean isFireBodyImmuneBlock(BlockState state) {
        return state.m_60713_(Blocks.f_50752_) || state.m_60713_(Blocks.f_50080_);
    }

    private List<LivingEntity> grantAlliesExplosionImmunity(ServerLevel server, double x, double y, double z) {
        double radius = FIRE_BODY_EXPLOSION_RADIUS + 4.0D;
        AABB area = new AABB(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius);
        List<LivingEntity> allies = server.m_6443_(LivingEntity.class, area,
                entity -> entity.m_6084_() && entity != this && this.isAlly(entity));

        if (allies.isEmpty()) {
            return allies;
        }

        for (LivingEntity ally : allies) {
            ally.m_7292_(new MobEffectInstance(MobEffects.f_19606_, 40, 4, true, false, false));
            ally.m_7292_(new MobEffectInstance(MobEffects.f_19607_, 200, 0, true, false, false));
            ally.m_7311_(0);
        }

        return allies;
    }

    private void applyFireBodyBlastDamage(ServerLevel server, double x, double y, double z, List<Entity> immune) {
        double radius = FIRE_BODY_EXPLOSION_RADIUS + 2.5D;
        AABB area = new AABB(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius);

        Set<Integer> immuneIds = new HashSet<>();
        for (Entity entity : immune) {
            immuneIds.add(entity.m_19879_());
        }
        immuneIds.add(this.m_19879_());

        List<LivingEntity> targets = server.m_6443_(LivingEntity.class, area,
                living -> living.m_6084_() && !immuneIds.contains(living.m_19879_()) && !this.isAlly(living));

        if (targets.isEmpty()) {
            return;
        }

        for (LivingEntity target : targets) {
            if (target.m_6469_(server.m_269111_().m_269036_(this, this), FIRE_BODY_EXPLOSION_DAMAGE)) {
                target.m_20254_(8);
            }
        }
    }

    private void carveFireBodyImprint(ServerLevel server, BlockPos center) {
        int radius = Mth.m_14165_(FIRE_BODY_IMPRINT_RADIUS);
        double radiusSq = FIRE_BODY_IMPRINT_RADIUS * FIRE_BODY_IMPRINT_RADIUS;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double horizontalSq = dx * dx + dz * dz;
                if (horizontalSq > radiusSq) {
                    continue;
                }

                double normalized = Math.sqrt(horizontalSq) / FIRE_BODY_IMPRINT_RADIUS;
                double depth = (1.0D - normalized * normalized) * (FIRE_BODY_IMPRINT_RADIUS * FIRE_BODY_IMPRINT_DEPTH_FACTOR);
                int maxDepth = Mth.m_14107_(depth);

                for (int dy = 0; dy <= maxDepth; dy++) {
                    cursor.m_122178_(center.m_123341_() + dx, center.m_123342_() - dy, center.m_123343_() + dz);
                    if (!server.m_46749_(cursor)) {
                        continue;
                    }

                    BlockState state = server.m_8055_(cursor);
                    if (state.m_60795_() || isFireBodyImmuneBlock(state)) {
                        continue;
                    }

                    server.m_46953_(cursor, true, this);
                }
            }
        }
    }
    public void switchToGroundNavigation() {
        if (usingAirNav) {
            this.f_21344_ = this.groundNav;
            this.f_21342_ = new MoveControl(this);
            this.usingAirNav = false;
        }
    }

    // Fire immunity is now handled by DragonEntity base class via DragonType.FIRE elemental profile

    public boolean isBreathingFire() {
        return this.f_19804_.m_135370_(DATA_FIRE_BREATHING);
    }

    public void setBreathingFire(boolean breathing) {
        this.f_19804_.m_135381_(DATA_FIRE_BREATHING, breathing);
    }

    @Override
    protected @NotNull PathNavigation m_6037_(@Nonnull Level level) {
        return new DragonPathNavigateGround(this, level);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        AnimationController<Cindervane> movement = new AnimationController<>(this, "movement", 5, animationHandler::handleMovementAnimation);
        movement.setSoundKeyframeHandler(this::onAnimationSound);
        controllers.add(movement);

        AnimationController<Cindervane> banking = new AnimationController<>(this, "banking", 10, animationHandler::bankingPredicate);
        controllers.add(banking);

        AnimationController<Cindervane> pitching = new AnimationController<>(this, "pitching", 10, animationHandler::pitchingPredicate);
        controllers.add(pitching);

        AnimationController<Cindervane> actions = new AnimationController<>(this, "actions", 5, animationHandler::actionPredicate);
        animationHandler.setupActionController(actions);
        actions.setSoundKeyframeHandler(this::onAnimationSound);
        controllers.add(actions);

        AnimationController<Cindervane> HurtController = new AnimationController<>(this, "hurt", 3,
                state -> software.bernie.geckolib.core.object.PlayState.STOP);
        HurtController.triggerableAnim("cindervane_hurt",
                RawAnimation.begin().thenPlay("animation.cindervane.hurt"));
        HurtController.setSoundKeyframeHandler(this::onAnimationSound);
        controllers.add(HurtController);
    }

    private void onAnimationSound(SoundKeyframeEvent<Cindervane> event) {
        soundHandler.handleAnimationSound(this, event.getKeyframeData(), event.getController());
    }

    public DragonSoundHandler getSoundHandler() {
        return soundHandler;
    }

    public com.leon.saintsdragons.server.entity.sleep.DragonRestManager getRestManager() {
        return restManager;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    public Map<String, VocalEntry> getVocalEntries() {
        return VOCAL_ENTRIES;
    }

    @Override
    public DragonSoundProfile getSoundProfile() {
        return CindervaneSoundProfile.INSTANCE;
    }

    @Override
    public DragonAbilityType<?, ?> getPrimaryAttackAbility() {
        return CindervaneAbilities.BITE;
    }

    @Override
    public boolean hasSecondaryMelee() {
        return false; // Cindervane only has bite, no secondary melee
    }

    @Override
    public DragonAbilityType<?, ?> getRoaringAbility() {
        return CindervaneAbilities.ROAR;
    }

    @Override
    protected DragonAbilityType<?, ?> getHurtAbilityType() {
        return CindervaneAbilities.HURT;
    }

    @Override
    public int getDeathAnimationDurationTicks() {
        return 95; // 4.75s - matches amphithere death animation length
    }

    // Death handling now uses base class helpers

    @Override
    public boolean m_6469_(@Nonnull DamageSource source, float amount) {
        // During dying sequence, ignore all damage except the final generic kill used by DieAbility
        if (isDying()) {
            if (source.m_276093_(DamageTypes.f_286979_)) {
                return super.m_6469_(source, amount);
            }
            return false;
        }

        // Wake if sleeping and suppress re-entry on damage
        if (m_5803_() || isSleepingEntering() || isSleepingExiting()) {
            wakeUpImmediately();
            suppressSleep(200);
        }

        // Intercept lethal damage to play custom death ability first
        if (handleLethalDamage(source, amount, CindervaneAbilities.DIE)) {
            return true;
        }
        return super.m_6469_(source, amount);
    }

    @Override
    protected void m_6153_() {
        // Override vanilla death animation to prevent rotation/flop
        // Just increment death time without the rotation animation
        ++this.f_20919_;
        if (this.f_20919_ >= 20) {
            this.m_142687_(RemovalReason.KILLED);
            this.m_21226_();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends DragonEntity> DragonAbility<T> getActiveAbility() {
        return (DragonAbility<T>) combatManager.getActiveAbility();
    }

    public boolean isAbilityActive(DragonAbilityType<?, ?> abilityType) {
        return combatManager.isAbilityActive(abilityType);
    }

    public void forceEndAbility(DragonAbilityType<?, ?> abilityType) {
        combatManager.forceEndAbility(abilityType);
    }

    public void useRidingAbility(String abilityName) {
        if (abilityName == null || abilityName.isEmpty()) {
            return;
        }
        Entity rider = this.m_6688_();
        if (!(rider instanceof LivingEntity)) {
            return;
        }
        if (this.m_21824_() && rider instanceof Player player && !this.m_21830_(player)) {
            return;
        }
        DragonAbilityType<?, ?> type = AbilityRegistry.get(abilityName);
        if (type == CindervaneAbilities.BITE || type == CindervaneAbilities.FIRE_BODY || type == CindervaneAbilities.ROAR || type == CindervaneAbilities.FIRE_BREATH_VOLLEY) {
            combatManager.tryUseAbility(type);
        }
    }

    public void forceEndActiveAbility() {
        combatManager.forceEndActiveAbility();
        fireBodyCrashArmed = false;
        this.setBreathingFire(false);
    }

    @Override
    public boolean m_7327_(net.minecraft.world.entity.@NotNull Entity target) {
        // Use bite ability for melee attacks
        if (!this.m_20160_() && !this.m_21827_()) {
            combatManager.tryUseAbility(CindervaneAbilities.BITE);
        }
        // Return true to indicate we handled the attack
        return true;
    }

    @Override
    public Vec3 getHeadPosition() {
        return this.m_146892_();
    }

    @Override
    public Vec3 getMouthPosition() {
        return computeMouthOrigin(1.0f);
    }

    public Vec3 computeMouthOrigin(float partialTicks) {
        double x = Mth.m_14139_(partialTicks, this.f_19854_, this.m_20185_());
        double y = Mth.m_14139_(partialTicks, this.f_19855_, this.m_20186_());
        double z = Mth.m_14139_(partialTicks, this.f_19856_, this.m_20189_());

        float yawDeg = Mth.m_14179_(partialTicks, this.f_20886_, this.f_20885_);
        float pitchDeg = Mth.m_14179_(partialTicks, this.f_19860_, this.m_146909_());

        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);

        double R = (-0.4 / 16.0) * MODEL_SCALE;
        double U = (5.2 / 16.0) * MODEL_SCALE;
        double F = (12.5 / 16.0) * MODEL_SCALE;

        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        double up = U * cp - F * sp;
        double fwd = U * sp + F * cp;

        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        double offX = R * cy - fwd * sy;
        double offZ = R * sy + fwd * cy;

        return new Vec3(x + offX, y + up, z + offZ);
    }

    @Override
    public boolean m_6898_(@Nonnull ItemStack stack) {
        return stack.m_150930_(Items.f_42526_) || stack.m_150930_(Items.f_42527_) || stack.m_150930_(Items.f_42528_) || stack.m_150930_(Items.f_42581_);
    }

    @Override
    public @NotNull InteractionResult m_6071_(@NotNull Player player, @NotNull InteractionHand hand) {
        // Use interaction handler for all interactions
        InteractionResult handlerResult = interactionHandler.handleInteraction(player, hand);
        if (handlerResult != InteractionResult.PASS) {
            return handlerResult;
        }

        // Fall back to base implementation for any unhandled interactions
        return super.m_6071_(player, hand);
    }


    @Nullable
    @Override
    public AgeableMob m_142606_(@Nonnull ServerLevel level, @Nonnull AgeableMob partner) {
        return ModEntities.CINDERVANE.get().m_20615_(level);
    }

    @Override
    public void m_7380_(@NotNull CompoundTag tag) {
        super.m_7380_(tag);
        tag.m_128405_("TimeFlying", timeFlying);
        saveRideableData(tag);
        restManager.save(tag);
    }

    @Override
    public void m_7378_(@NotNull CompoundTag tag) {
        super.m_7378_(tag);

        loadRideableData(tag);
        boolean savedFlying = tag.m_128471_("Flying");
        this.timeFlying = tag.m_128451_("TimeFlying");

        // Reset all tick counters to prevent state inconsistencies
        // Reset ground ticks when flying
        if (!savedFlying) {
            landingTicks = 0;
            airTicks = 0;
        } else {
            airTicks = Math.max(airTicks, 1);
        }
        groundTicks = 0; // Reset ground ticks on load

        this.m_20242_(m_29443_() || isHovering());

        // Restore rest state manager and re-trigger animations based on loaded state
        restManager.load(tag);
        com.leon.saintsdragons.server.entity.sleep.DragonRestState restState = restManager.getCurrentState();
        switch (restState) {
            case SLEEPING -> {
                m_21839_(true);
                animationHandler.triggerSleepAnimation();
            }
            case SITTING_DOWN, SITTING, SITTING_AFTER -> {
                m_21839_(true);
            }
            case FALLING_ASLEEP -> {
                m_21839_(true);
                startSleepEnter();
            }
            case WAKING_UP -> {
                m_21839_(true);
                startSleepExit();
            }
            case STANDING_UP -> {
                m_21839_(false);
            }
        }

        // Force animation state sync after loading to prevent thrashing
        if (!m_9236_().f_46443_) {
            // Delay the sync slightly to ensure all systems are initialized
            this.f_19797_ = 0; // Reset tick counter to ensure proper initialization
        }
    }

    public void prepareForMounting() {
        if (m_9236_().f_46443_) {
            return;
        }

        this.m_21839_(false);
        if (this.getCommand() == 1) {
            this.setCommand(0);
        }
        this.sitProgress = 0f;
        this.prevSitProgress = 0f;
        this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
        this.m_6710_(null);

        if (this.m_21573_().m_26570_() != null) {
            this.m_21573_().m_26573_();
        }

        clearStatesWhenMounted();
    }

    // ===== DragonFlightCapable =====

    @Override
    protected boolean isDragonFlying() {
        return this.f_19804_.m_135370_(DATA_FLYING);
    }

    @Override
    public void setFlying(boolean flying) {
        if (flying == m_29443_()) {
            return;
        }
        this.f_19804_.m_135381_(DATA_FLYING, flying);
        if (flying) {
            switchToAirNavigation();
            setLanding(false);
            setTakeoff(true);
            this.m_21573_().m_26573_();
        } else {
            switchToGroundNavigation();
            setHovering(false);
            setTakeoff(false);
        }
    }

    @Override
    public boolean isTakeoff() {
        return this.f_19804_.m_135370_(DATA_TAKEOFF);
    }

    @Override
    public void setTakeoff(boolean takeoff) {
        this.f_19804_.m_135381_(DATA_TAKEOFF, takeoff);
    }

    @Override
    public boolean isHovering() {
        return this.f_19804_.m_135370_(DATA_HOVERING);
    }

    @Override
    public void setHovering(boolean hovering) {
        this.f_19804_.m_135381_(DATA_HOVERING, hovering);
    }

    @Override
    public boolean isLanding() {
        return this.f_19804_.m_135370_(DATA_LANDING);
    }

    @Override
    public void setLanding(boolean landing) {
        this.f_19804_.m_135381_(DATA_LANDING, landing);
        landingTicks = 0;
        if (landing) {
            setHovering(false);
            setTakeoff(false);
        }
    }

    @Override
    public float getFlightSpeed() {
        return 0.5F;
    }

    @Override
    public double getPreferredFlightAltitude() {
        double base = 24.0D + this.m_217043_().m_188500_() * 10.0D;
        return Mth.m_14008_(base, 20.0D, 45.0D);
    }

    @Override
    public boolean canTakeoff() {
        return !this.m_6162_() && !this.m_21827_() && this.m_6084_() && (this.m_20096_() || this.m_20069_());
    }

    @Override
    public void markLandedNow() {
        setLanding(false);
        setTakeoff(false);
        this.riderTakeoffTicks = 0;
    }

    public void setRiderTakeoffTicks(int ticks) {
        this.riderTakeoffTicks = Math.max(0, ticks);
    }


    @Override
    public boolean m_142535_(float fallDistance, float fallMultiplier, @NotNull DamageSource source) {
        if (this.m_29443_() || this.isTakeoff() || this.isLanding()) {
            return false;
        }
        return super.m_142535_(fallDistance, fallMultiplier, source);
    }

    // ===== FlyingAnimal =====
    @Override
    public boolean m_142039_() {
        return m_29443_() && this.m_20184_().f_82480_ > -0.1D;
    }
    
    /**
     * Check if this amphithere can be bound (not flying, not dying, etc.)
     */
    public boolean canBeBound() {
        return !m_29443_() && !isDying() && !isAccelerating();
    }

    @Override
    public DragonAbilityType<?, ?> getChannelingAbility() {
        return CindervaneAbilities.FIRE_BREATH_VOLLEY;
    }

    @Override
    public void m_7822_(byte eventId) {
        if (eventId == 6) {
            // Failed taming - show smoke particles ONLY, no sitting behavior at all
            if (m_9236_().f_46443_) {
                // Show smoke particles for failed taming
                for (int i = 0; i < 7; ++i) {
                    double d0 = this.f_19796_.m_188583_() * 0.02D;
                    double d1 = this.f_19796_.m_188583_() * 0.02D;
                    double d2 = this.f_19796_.m_188583_() * 0.02D;
                    this.m_9236_().m_7106_(net.minecraft.core.particles.ParticleTypes.f_123762_,
                            this.m_20208_(1.0D), this.m_20187_() + 0.5D, this.m_20262_(1.0D), d0, d1, d2);
                }
            }
            // IMPORTANT: Don't call super for event 6 - it might trigger sitting behavior
        } else if (eventId == 7) {
            // Successful taming - show hearts only, sitting is handled separately
            if (m_9236_().f_46443_) {
                // Show heart particles for successful taming
                for (int i = 0; i < 7; ++i) {
                    double d0 = this.f_19796_.m_188583_() * 0.02D;
                    double d1 = this.f_19796_.m_188583_() * 0.02D;
                    double d2 = this.f_19796_.m_188583_() * 0.02D;
                    this.m_9236_().m_7106_(net.minecraft.core.particles.ParticleTypes.f_123750_,
                            this.m_20208_(1.0D), this.m_20187_() + 0.5D, this.m_20262_(1.0D), d0, d1, d2);
                }
            }
            // IMPORTANT: Don't call super for event 7 either - sitting is explicitly handled in mobInteract
        } else {
            // Call super for all other entity events (NOT 6 or 7)
            super.m_7822_(eventId);
        }
    }

    // ===== CLIENT LOCATOR CACHE METHODS =====

    /**
     * Store a client-side locator position (used by renderer to cache bone positions)
     */
    public void setClientLocatorPosition(String name, Vec3 pos) {
        if (name == null || pos == null) return;
        this.clientLocatorCache.put(name, pos);
    }

    /**
     * Get a client-side locator position (used by rider controller to position passengers)
     */
    @Override
    public Vec3 getClientLocatorPosition(String name) {
        if (name == null) return null;
        return this.clientLocatorCache.get(name);
    }

    @Override
    public float getScreenShakeAmount(float partialTicks) {
        float current = this.f_19804_.m_135370_(DATA_SCREEN_SHAKE_AMOUNT);
        return prevScreenShakeAmount + (current - prevScreenShakeAmount) * partialTicks;
    }

    @Override
    public double getShakeDistance() {
        return 18.0;
    }

    @Override
    public boolean canFeelShake(Entity player) {
        // Allow screen shake regardless of whether player is on ground
        // This is important for dragon riding scenarios
        return true;
    }

    public void triggerScreenShake(float intensity) {
        screenShakeAmount = Math.max(screenShakeAmount, intensity);
        this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, screenShakeAmount);
    }

    // ===== SIT TRANSITION HELPERS =====

    public boolean isInSitTransition() {
        return isSittingDown || isStandingUp;
    }

    public boolean isSittingDownAnimation() {
        return isSittingDown;
    }

    public boolean isStandingUpAnimation() {
        return isStandingUp;
    }

    // ===== SLEEP SYSTEM =====

    private void tickSleepTransition() {
        // Handle sleep enter transition: sit_down → fall_asleep → sleep loop
        if (isSleepingEntering() && !m_9236_().f_46443_) {
            // Check if sit_down is complete (using sit progress)
            if (getSitProgress() >= maxSitTicks()) {
                // Sit down complete, now trigger fall_asleep and start countdown
                if (sleepTransitionTicks > 60) {
                    // Just reached sitting position, trigger fall_asleep
                    animationHandler.triggerFallAsleepAnimation();
                    sleepTransitionTicks = 60; // Start countdown for fall_asleep duration
                }
            } else {
                // While sitting down, keep transition ticks above the threshold
                sleepTransitionTicks = 61;
                return; // Don't count down yet
            }
        }

        if (sleepTransitionTicks > 0) {
            sleepTransitionTicks--;
            if (sleepTransitionTicks == 0) {
                if (isSleepingEntering()) {
                    // fall_asleep finished: mark sleeping and trigger loop animation
                    setSleeping(true);
                    setSleepingEntering(false);
                    animationHandler.triggerSleepAnimation();
                } else if (isSleepingExiting()) {
                    // wake_up finished: clear exiting state
                    setSleepingExiting(false);
                    // Brief cooldown before ambient sounds resume
                    sleepAmbientCooldownTicks = 10;
                }
            }
        }
    }

    private void tickSleepCooldowns() {
        if (sleepAmbientCooldownTicks > 0) sleepAmbientCooldownTicks--;
        if (sleepReentryCooldownTicks > 0) sleepReentryCooldownTicks--;
        if (sleepCancelTicks > 0) sleepCancelTicks--;
    }

    // ===== SLEEP STATE ACCESSORS =====

    @Override
    public boolean m_5803_() {
        return this.f_19804_.m_135370_(DATA_SLEEPING);
    }

    public void setSleeping(boolean sleeping) {
        this.f_19804_.m_135381_(DATA_SLEEPING, sleeping);
    }

    @Override
    public boolean isSleepTransitioning() {
        return isSleepingEntering() || isSleepingExiting();
    }

    public boolean isSleepingEntering() {
        return this.f_19804_.m_135370_(DATA_SLEEPING_ENTERING);
    }

    public void setSleepingEntering(boolean entering) {
        this.f_19804_.m_135381_(DATA_SLEEPING_ENTERING, entering);
    }

    public boolean isSleepingExiting() {
        return this.f_19804_.m_135370_(DATA_SLEEPING_EXITING);
    }

    public void setSleepingExiting(boolean exiting) {
        this.f_19804_.m_135381_(DATA_SLEEPING_EXITING, exiting);
    }

    public boolean isSleepLocked() {
        return sleepLocked || m_5803_() || isSleepingEntering() || isSleepingExiting();
    }

    private void enterSleepLock() {
        int snapshot = getCommand();
        if (!sleepLocked) {
            sleepLocked = true;
            sleepCommandSnapshot = snapshot;
            // Force sit command during sleep
            if (getCommand() != 1) {
                setCommand(1);
                m_21839_(true);
            }
        }
    }

    private void releaseSleepLock() {
        if (sleepLocked) {
            int desired = sleepCommandSnapshot;
            sleepCommandSnapshot = -1;
            sleepLocked = false;

            // Restore command state
            if (desired >= 0 && desired != getCommand()) {
                setCommand(desired);
                m_21839_(desired == 1);
            }
        }
    }

    @Override
    public void startSleepEnter() {
        if (m_5803_() || isSleepingEntering() || isSleepingExiting()) return;
        setSleepingEntering(true);
        // New system: sit_down (uses sitProgress) → fall_asleep (3s = 60 ticks) → sleep loop
        sleepTransitionTicks = 61; // Use 61 as sentinel value - will be set to 60 when sit_down completes

        // enterSleepLock forces sit command, which triggers sit_down via updateSittingProgress
        if (!m_9236_().f_46443_) {
            enterSleepLock();
        }
    }

    @Override
    public void startSleepExit() {
        if ((!m_5803_() && !isSleepingEntering()) || isSleepingExiting()) return;
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        setSleepingEntering(false);
        setSleepingExiting(true);
        // New system: wake_up (2.0833s = ~42 ticks) → sit (brief) → sit_up
        sleepTransitionTicks = 42; // Duration of wake_up animation (2.0833 seconds)
        // Trigger wake_up animation
        animationHandler.triggerWakeUpAnimation();
        if (!m_9236_().f_46443_) {
            suppressSleep(20);
            releaseSleepLock();
        }
    }

    public void wakeUpImmediately() {
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        setSleepingEntering(false);
        setSleepingExiting(false);
        sleepTransitionTicks = 0;
        sleepCancelTicks = 2;
        if (!m_9236_().f_46443_) {
            suppressSleep(20);
            releaseSleepLock();
        }
    }

    public void suppressSleep(int ticks) {
        sleepReentryCooldownTicks = Math.max(sleepReentryCooldownTicks, ticks);
    }

    @Override
    public boolean isSleepSuppressed() {
        return sleepReentryCooldownTicks > 0;
    }

    @Override
    public DragonSleepCapable.SleepPreferences getSleepPreferences() {
        return new DragonSleepCapable.SleepPreferences(
            true,  // canSleepAtNight - Cindervanes sleep at night
            false, // canSleepDuringDay - Cindervanes are diurnal
            true,  // requiresShelter
            true,  // avoidsThunderstorms
            true   // sleepsNearOwner
        );
    }

    @Override
    public boolean canSleepNow() {
        return !isBreathingFire() && !m_20160_() && getActiveAbility() == null;
    }

}
