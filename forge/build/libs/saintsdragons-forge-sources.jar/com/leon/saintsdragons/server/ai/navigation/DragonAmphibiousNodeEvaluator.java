package com.leon.saintsdragons.server.ai.navigation;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.PathNavigationRegion;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.AmphibiousNodeEvaluator;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.pathfinder.Node;
import org.jetbrains.annotations.NotNull;

/**
 * Amphibious evaluator that keeps the generous water handling from {@link DragonSwimNodeEvaluator}
 * while still allowing surface/ground traversal via the vanilla amphibious logic.
 * Designed to be shared by all semiaquatic dragons that rely on {@link DragonAmphibiousNavigation}.
 */
public class DragonAmphibiousNodeEvaluator extends AmphibiousNodeEvaluator {

    public DragonAmphibiousNodeEvaluator() {
        super(true); // Allow breaching so mobs can leave the water column.
    }

    public void prepare(PathNavigationRegion region, PathfinderMob mob) {
        super.m_6028_(region, mob);
        mob.m_21441_(BlockPathTypes.WATER, 0.0F);
        mob.m_21441_(BlockPathTypes.WATER_BORDER, 0.0F);
        mob.m_21441_(BlockPathTypes.BREACH, 0.0F);
    }

    @Override
    public @NotNull Node m_7171_() {
        // Sample around mid-body height to reduce thrashing at the surface for tall mobs.
        int centerY = Mth.m_14107_(this.f_77313_.m_20191_().f_82289_ + (this.f_77313_.m_20206_() * 0.5D));
        BlockPos origin = BlockPos.m_274446_(this.f_77313_.m_20182_());

        if (!isWaterColumn(origin)) {
            BlockPos.MutableBlockPos cursor = origin.m_122032_();
            while (cursor.m_123342_() > this.f_77313_.m_9236_().m_141937_()) {
                cursor.m_122184_(0, -1, 0);
                if (isWaterColumn(cursor)) {
                    origin = cursor.m_7949_();
                    centerY = cursor.m_123342_();
                    break;
                }
            }
        }
        return super.m_5676_(origin.m_123341_(), centerY, origin.m_123343_());
    }

    public BlockPathTypes getBlockPathType(BlockGetter level, int x, int y, int z, PathfinderMob mob) {
        BlockPathTypes base = super.m_7209_(level, x, y, z, mob);
        if (base == BlockPathTypes.WATER_BORDER || base == BlockPathTypes.BREACH) {
            return BlockPathTypes.WATER;
        }

        if (base == BlockPathTypes.OPEN) {
            BlockState state = level.m_8055_(BlockPos.m_274561_(x, y, z));
            if (!state.m_60819_().m_76178_()) {
                return BlockPathTypes.WATER;
            }
        }
        return base;
    }

    private boolean isWaterColumn(BlockPos pos) {
        FluidState fluid = this.f_77313_.m_9236_().m_6425_(pos);
        return !fluid.m_76178_();
    }
}
