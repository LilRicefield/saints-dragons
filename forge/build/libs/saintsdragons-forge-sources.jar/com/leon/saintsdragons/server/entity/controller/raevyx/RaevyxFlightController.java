package com.leon.saintsdragons.server.entity.controller.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Handles all flight-related logic for Raevyx including:
 * - Takeoff and landing mechanics
 * - Flight physics and navigation switching
 * - Banking and pitch control
 * - Gliding and hovering behavior
 */
public class RaevyxFlightController {
    private final Raevyx wyvern;
    private net.minecraft.core.BlockPos plannedLandingPos = null;

    // Flight constants
    private static final double TAKEOFF_UPWARD_FORCE = 0.11D;
    private static final double LANDING_DOWNWARD_FORCE = 0.4D;
    private static final double FALLING_RESISTANCE = 0.6D;
    private static final int TAKEOFF_TIME_THRESHOLD = 30;
    private static final int LANDING_TIME_THRESHOLD = 40;

    public RaevyxFlightController(Raevyx wyvern) {
        this.wyvern = wyvern;
    }

    /**
     * Main flight logic handler called every tick
     */
    public void handleFlightLogic() {
        if (wyvern.m_29443_()) {
            handleFlyingTick();
        } else {
            handleGroundedTick();
        }

        if (wyvern.isLanding()) {
            handleSimpleLanding();
        }
    }

    /**
     * Switches wyvern to ground navigation mode
     */
    public void switchToGroundNavigation() {
        wyvern.switchToGroundNavigation();
    }

    /**
     * Plan and start a smart landing by selecting a safe nearby flat spot and
     * steering navigation toward it. Called when landing is initiated.
     */
    public void planSmartLanding() {
        if (wyvern.m_9236_().f_46443_) return;
        // Prefer owner's vicinity if reasonably close
        net.minecraft.world.entity.LivingEntity owner = wyvern.m_269323_();
        net.minecraft.core.BlockPos center;
        if (owner != null && owner.m_9236_() == wyvern.m_9236_() && wyvern.m_20270_(owner) < 40.0) {
            center = owner.m_20183_();
        } else {
            center = wyvern.m_20183_();
        }

        plannedLandingPos = findSafeLandingSpot(center);
        if (plannedLandingPos != null) {
            // Aim slightly above ground and move toward it
            wyvern.m_21573_().m_26519_(
                    plannedLandingPos.m_123341_() + 0.5,
                    plannedLandingPos.m_123342_() + 0.5,
                    plannedLandingPos.m_123343_() + 0.5,
                    1.2
            );
            wyvern.setHovering(true);
        }
    }

    private net.minecraft.core.BlockPos findSafeLandingSpot(BlockPos center) {
        var level = wyvern.m_9236_();
        // Spiral/ring search: radii 2..radius, angle steps ~16
        for (int r = 2; r <= 10; r += 2) {
            for (int step = 0; step < 16; step++) {
                double ang = (Math.PI * 2.0) * (step / 16.0);
                int x = center.m_123341_() + (int) Math.round(Math.cos(ang) * r);
                int z = center.m_123343_() + (int) Math.round(Math.sin(ang) * r);
                // Probe vertical: find first solid below with air headroom
                int startY = center.m_123342_() + 6; // allow slight uphill landing
                int minY = center.m_123342_() - 8;
                for (int y = startY; y >= minY; y--) {
                    var pos = new net.minecraft.core.BlockPos(x, y, z);
                    var below = pos.m_7495_();
                    var bsBelow = level.m_8055_(below);
                    var bsAt = level.m_8055_(pos);
                    // Solid ground must NOT be water/lava - only accept actual solid blocks
                    boolean solidBelow = !bsBelow.m_60795_()
                                      && !bsBelow.m_60812_(level, below).m_83281_()
                                      && bsBelow.m_60819_().m_76178_(); // Exclude water/lava!
                    boolean freeAt = bsAt.m_60812_(level, pos).m_83281_();
                    boolean fluidOk = bsAt.m_60819_().m_76178_();
                    if (solidBelow && freeAt && fluidOk && isFlatEnough(pos)) {
                        return pos;
                    }
                }
            }
        }
        return null;
    }

    private boolean isFlatEnough(net.minecraft.core.BlockPos pos) {
        // Check neighboring heights are within 1 block
        var level = wyvern.m_9236_();
        int y = pos.m_123342_();
        int[] dx = {1, -1, 0, 0};
        int[] dz = {0, 0, 1, -1};
        for (int i = 0; i < 4; i++) {
            var p = pos.m_7918_(dx[i], 0, dz[i]);
            int ny = surfaceYAt(p);
            if (Math.abs(ny - y) > 1) return false;
            // Avoid leaves/water/lava as landing base
            var below = new net.minecraft.core.BlockPos(p.m_123341_(), ny - 1, p.m_123343_());
            var st = level.m_8055_(below);
            if (!st.m_60819_().m_76178_()) return false;
        }
        return true;
    }

    private int surfaceYAt(net.minecraft.core.BlockPos pos) {
        var level = wyvern.m_9236_();
        int y = pos.m_123342_();
        for (int dy = 0; dy <= 6; dy++) {
            var p = new net.minecraft.core.BlockPos(pos.m_123341_(), y - dy, pos.m_123343_());
            var below = p.m_7495_();
            var bsBelow = level.m_8055_(below);
            var bsAt = level.m_8055_(p);
            if (!bsBelow.m_60795_() && !bsBelow.m_60812_(level, below).m_83281_() && bsAt.m_60812_(level, p).m_83281_()) {
                return p.m_123342_();
            }
        }
        return y;
    }
    /**
     * Forces aggressive landing for combat situations
     */
    public void initiateAggressiveLanding() {
        if (!wyvern.m_29443_()) return;

        wyvern.setLanding(true);
        wyvern.setFlying(false);
        wyvern.setTakeoff(false);
        wyvern.setHovering(false);
        wyvern.setRunning(true);
        wyvern.m_21573_().m_26573_();
        wyvern.setHovering(true);
        wyvern.landingTimer = 0;
    }

    /**
     * Handles flight travel behavior based on current flight state
     */
    public void handleFlightTravel(Vec3 motion) {
        if (wyvern.isTakeoff() || wyvern.isHovering()) {
            handleHoveringTravel(motion);
        } else {
            handleGlidingTravel(motion);
        }
    }

    private void handleFlyingTick() {
        wyvern.timeFlying++;

        // Reduce falling speed while flying
        if (wyvern.m_20184_().f_82480_ < 0 && wyvern.m_6084_()) {
            wyvern.m_20256_(wyvern.m_20184_().m_82542_(1, FALLING_RESISTANCE, 1));
        }

        // Auto-land when sitting or being a passenger
        if (wyvern.m_21827_() || wyvern.m_20159_()) {
            wyvern.setTakeoff(false);
            wyvern.setHovering(false);
            wyvern.setFlying(false);
            return;
        }

        // Server-side logic
        if (!wyvern.m_9236_().f_46443_) {
            handleServerFlightLogic();
            handleFlightPitchControl();
        }

        // Apply post-logic stabilizer on both sides to reduce visible jitter while hovering/aiming
        applyHoverStabilizer();
    }

    private void handleServerFlightLogic() {
        // Update takeoff state
        wyvern.setTakeoff(shouldTakeoff() && wyvern.m_29443_());

        // Handle takeoff physics
        if (wyvern.isTakeoff() && wyvern.m_29443_() && wyvern.m_6084_()) {
            // Apply upward force during initial takeoff window
            if (wyvern.timeFlying < TAKEOFF_TIME_THRESHOLD) {
                wyvern.m_20256_(wyvern.m_20184_().m_82520_(0, TAKEOFF_UPWARD_FORCE, 0));
            }
            if (wyvern.landingFlag) {
                wyvern.m_20256_(wyvern.m_20184_().m_82520_(0, -LANDING_DOWNWARD_FORCE, 0));
            }
        }

        // Landing logic when touching ground - fixed timing
        if (!wyvern.isTakeoff() && wyvern.m_29443_() && wyvern.timeFlying > LANDING_TIME_THRESHOLD && wyvern.m_20096_()) {
            LivingEntity target = wyvern.m_5448_();
            // Allow natural ground transition when no target, OR when being ridden (simple ground contact)
            if (target == null || !target.m_6084_() || wyvern.m_20160_()) {
                wyvern.setFlying(false);
            }
        }

        // Nudge toward planned landing if any - use desynced checks for navigation refresh
        if (wyvern.isLanding() && plannedLandingPos != null) {
            // Refresh target in case navigation has stopped (check periodically)
            if (wyvern.f_19797_ % 5 == 0 && wyvern.m_21573_().m_26571_()) {
                wyvern.m_21573_().m_26519_(plannedLandingPos.m_123341_() + 0.5, plannedLandingPos.m_123342_() + 0.5, plannedLandingPos.m_123343_() + 0.5, 1.1);
            }
            // Clear plan once grounded
            if (wyvern.m_20096_()) {
                plannedLandingPos = null;
            }
        }
    }

    /**
     * Reduce small oscillations while hovering or beaming by adding a velocity deadzone
     * and a small angular deadzone around the target lock.
     */
    private void applyHoverStabilizer() {
        if (!wyvern.m_29443_()) return;
        // Do not interfere with rider control
        if (wyvern.m_6688_() != null) return;

        boolean hoveringLike = wyvern.isHovering() || wyvern.isTakeoff() || wyvern.isBeaming();
        if (!hoveringLike) return;

        // Velocity deadzone for XY drift
        Vec3 v = wyvern.m_20184_();
        double h = Math.sqrt(v.f_82479_ * v.f_82479_ + v.f_82481_ * v.f_82481_);
        if (h < 0.03) {
            // Snap tiny drift to zero
            wyvern.m_20334_(0.0, v.f_82480_ * 0.98, 0.0);
        } else {
            // Heavier horizontal damping while hovering/beaming
            wyvern.m_20334_(v.f_82479_ * 0.85, v.f_82480_ * 0.98, v.f_82481_ * 0.85);
        }

        // Angular jitter is handled via deadzones in MoveHelper/beam logic; avoid forcibly snapping here
    }

    private void handleGroundedTick() {
        wyvern.timeFlying = 0;
    }

    public boolean shouldTakeoff() {
        // Do not auto-takeoff just because there is a target; prefer ground combat if viable
        if (wyvern.m_6688_() != null) {
            // When ridden, honor an explicit rider takeoff window
            return wyvern.getRiderTakeoffTicks() > 0;
        }

        final var target = wyvern.m_5448_();
        if (target != null && target.m_6084_()) {
            double d = wyvern.m_20270_(target);
            boolean targetFarAway = d > 20.0;
            boolean targetAbove = target.m_20186_() - wyvern.m_20186_() > 5.0;
            boolean cantReachOnGround = d > 10.0 && !wyvern.m_21574_().m_148306_(target);
            return wyvern.landingFlag || targetFarAway || targetAbove || cantReachOnGround;
        }

        // During initial takeoff sequence, allow upward force for a short period
        return wyvern.landingFlag || wyvern.timeFlying < TAKEOFF_TIME_THRESHOLD;
    }

    private void handleFlightPitchControl() {
        // Authority separation: when ridden, rider fully controls pitch. Avoid server auto-correct.
        if (wyvern.m_6688_() != null) return;
        if (!wyvern.m_29443_() || wyvern.isLanding() || wyvern.isHovering()) return;

        Vec3 velocity = wyvern.m_20184_();
        double horizontalSpeed = Math.sqrt(velocity.f_82479_ * velocity.f_82479_ + velocity.f_82481_ * velocity.f_82481_);

        if (horizontalSpeed > 0.05) {
            float desiredPitch = (float) (Math.atan2(-velocity.f_82480_, horizontalSpeed) * 57.295776F);
            desiredPitch = Mth.m_14036_(desiredPitch, -25.0F, 35.0F);
            wyvern.m_146926_(Mth.m_14148_(wyvern.m_146909_(), desiredPitch, 3.0F));
        }
    }

    private void handleSimpleLanding() {
        if (!wyvern.m_9236_().f_46443_) {
            wyvern.landingTimer++;

            // Complete landing after a fixed duration or on touching ground
            int landingTime = 60; // ticks
            if (wyvern.landingTimer > landingTime || wyvern.m_20096_()) {
                wyvern.setLanding(false);
                wyvern.setFlying(false);
                wyvern.setTakeoff(false);
                wyvern.setHovering(false);
                wyvern.markLandedNow();
                switchToGroundNavigation();
            }
        }
    }

    @SuppressWarnings("unused") // Motion parameter for method signature consistency
    private void handleGlidingTravel(Vec3 motion) {
        Vec3 vec3 = wyvern.m_20184_();

        if (vec3.f_82480_ > -0.5D) {
            wyvern.f_19789_ = 1.0F;
        }

        Vec3 moveDirection = wyvern.m_20154_().m_82541_();
        float pitchRad = wyvern.m_146909_() * ((float) Math.PI / 180F);

        // Enhanced gliding physics that responds to animation state
        vec3 = applyGlidingPhysics(vec3, moveDirection, pitchRad);

        // Dynamic friction based on flight state
        float horizontalFriction = 0.99F;
        float verticalFriction = 0.98F;
        wyvern.m_20256_(vec3.m_82542_(horizontalFriction, verticalFriction, horizontalFriction));
        wyvern.m_6478_(MoverType.SELF, wyvern.m_20184_());
    }

    private Vec3 applyGlidingPhysics(Vec3 currentVel, Vec3 moveDirection, float pitchRad) {
        double horizontalSpeed = Math.sqrt(moveDirection.f_82479_ * moveDirection.f_82479_ + moveDirection.f_82481_ * moveDirection.f_82481_);
        if (horizontalSpeed < 0.001) {
            return currentVel;
        }

        double currentHorizontalSpeed = Math.sqrt(currentVel.m_165925_());
        double lookDirectionLength = moveDirection.m_82553_();

        float pitchFactor = Mth.m_14089_(pitchRad);
        pitchFactor = (float) ((double) pitchFactor * (double) pitchFactor * Math.min(1.0D, lookDirectionLength / 0.4D));

        double gravity = getGravity();
        Vec3 result = currentVel.m_82520_(0.0D, gravity * (-1.0D + (double) pitchFactor * 0.75D), 0.0D);

        // Enhanced lift calculation with animation influence
        if (result.f_82480_ < 0.0D && horizontalSpeed > 0.0D) {
            double liftFactor = getLiftFactor(result, pitchFactor);
            result = result.m_82520_(
                    moveDirection.f_82479_ * liftFactor / horizontalSpeed,
                    liftFactor,
                    moveDirection.f_82481_ * liftFactor / horizontalSpeed
            );
        }

        // Dive calculation
        if (pitchRad < 0.0F && horizontalSpeed > 0.0D) {
            double diveFactor = currentHorizontalSpeed * (double) (-Mth.m_14031_(pitchRad)) * 0.04D;
            result = result.m_82520_(
                    -moveDirection.f_82479_ * diveFactor / horizontalSpeed,
                    diveFactor * 3.2D,
                    -moveDirection.f_82481_ * diveFactor / horizontalSpeed
            );
        }

        // Directional alignment
        if (horizontalSpeed > 0.0D) {
            double alignmentFactor = 0.1D;
            result = result.m_82520_(
                    (moveDirection.f_82479_ / horizontalSpeed * currentHorizontalSpeed - result.f_82479_) * alignmentFactor,
                    0.0D,
                    (moveDirection.f_82481_ / horizontalSpeed * currentHorizontalSpeed - result.f_82481_) * alignmentFactor
            );
        }

        return result;
    }

    private double getLiftFactor(Vec3 result, double pitchFactor) {
        double baseLiftFactor = result.f_82480_ * -0.1D * pitchFactor;

        double liftMultiplier = 1.0;
        if (wyvern.getFlappingFraction() > 0.3f) {
            liftMultiplier += wyvern.getFlappingFraction() * 0.6;
        }
        if (wyvern.getGlidingFraction() > 0.5f) {
            liftMultiplier += wyvern.getGlidingFraction() * 0.4;
        }

        return baseLiftFactor * liftMultiplier;
    }

    private double getGravity() {
        double gravity = 0.08D;

        if (wyvern.getFlappingFraction() > 0.2f) {
            gravity *= (1.0 - wyvern.getFlappingFraction() * 0.5);
        } else if (wyvern.getHoveringFraction() > 0.4f) {
            gravity *= (1.0 - wyvern.getHoveringFraction() * 0.3);
        }

        if (wyvern.getGlidingFraction() > 0.5f) {
            gravity *= (1.0 - wyvern.getGlidingFraction() * 0.2);
        }

        return gravity;
    }

    private void handleHoveringTravel(Vec3 motion) {
        BlockPos ground = new BlockPos((int) wyvern.m_20185_(), (int) (wyvern.m_20191_().f_82289_ - 1.0D), (int) wyvern.m_20189_());
        float friction = 0.91F;

        if (wyvern.m_20096_()) {
            friction = wyvern.m_9236_().m_8055_(ground).getFriction(wyvern.m_9236_(), ground, wyvern) * 0.91F;
        }

        float frictionFactor = 0.16277137F / (friction * friction * friction);
        friction = 0.91F;

        if (wyvern.m_20096_()) {
            friction = wyvern.m_9236_().m_8055_(ground).getFriction(wyvern.m_9236_(), ground, wyvern) * 0.91F;
        }

        wyvern.m_19920_(wyvern.m_20096_() ? 0.1F * frictionFactor : 0.02F, motion);
        wyvern.m_6478_(MoverType.SELF, wyvern.m_20184_());
        wyvern.m_20256_(wyvern.m_20184_().m_82490_(friction));

        BlockPos destination = wyvern.m_21573_().m_26567_();
        if (destination != null) {
            double dx = destination.m_123341_() - wyvern.m_20185_();
            double dy = destination.m_123342_() - wyvern.m_20186_();
            double dz = destination.m_123343_() - wyvern.m_20189_();
            double distanceToDest = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (distanceToDest < 0.1) {
                wyvern.m_20334_(0, 0, 0);
            }
        }
    }
}
