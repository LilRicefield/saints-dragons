package com.leon.saintsdragons.server.entity.effect.raevyx;

import com.leon.saintsdragons.common.particle.raevyx.RaevyxLightningArcData;
import com.leon.saintsdragons.common.particle.raevyx.RaevyxLightningStormData;
import com.leon.saintsdragons.common.particle.raevyx.RaevyxLightningChainData;
import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.UUID;

/**
 * Entity that manages chain lightning effects, spawning particles and dealing damage
 * over time rather than using individual particles for each segment.
 */
public class RaevyxLightningChainEntity extends Entity {
    private static final EntityDataAccessor<Float> DAMAGE = SynchedEntityData.m_135353_(RaevyxLightningChainEntity.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Float> SIZE = SynchedEntityData.m_135353_(RaevyxLightningChainEntity.class, EntityDataSerializers.f_135029_);
    private static final EntityDataAccessor<Integer> LIFESPAN = SynchedEntityData.m_135353_(RaevyxLightningChainEntity.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Integer> DELAY = SynchedEntityData.m_135353_(RaevyxLightningChainEntity.class, EntityDataSerializers.f_135028_);
    private static final EntityDataAccessor<Boolean> IS_CHAIN = SynchedEntityData.m_135353_(RaevyxLightningChainEntity.class, EntityDataSerializers.f_135035_);
    private static final EntityDataAccessor<Boolean> CASTER_FEMALE = SynchedEntityData.m_135353_(RaevyxLightningChainEntity.class, EntityDataSerializers.f_135035_);

    @Nullable
    private LivingEntity owner;
    @Nullable
    private UUID ownerUUID;

    // Chain lightning specific data
    private Vec3 startPos;
    private Vec3 endPos;
    private int chainCount = 0;
    private int maxChains = 3;

    public RaevyxLightningChainEntity(EntityType<? extends RaevyxLightningChainEntity> entityType, Level level) {
        super(entityType, level);
    }

    public RaevyxLightningChainEntity(Level level, double x, double y, double z, float damage, float size,
                                      LivingEntity caster, boolean isChain) {
        this(ModEntities.RAEVYX_LIGHTNING_CHAIN.get(), level);
        this.m_6034_(x, y, z);
        this.setDamage(damage);
        this.setSize(size);
        this.setCaster(caster);
        this.setIsChain(isChain);
        this.setDelay(0);
        this.setLifespan(0);
    }

    public RaevyxLightningChainEntity(Level level, Vec3 startPos, Vec3 endPos, float damage, float size,
                                      LivingEntity caster, boolean isChain) {
        this(level, startPos.f_82479_, startPos.f_82480_, startPos.f_82481_, damage, size, caster, isChain);
        this.startPos = startPos;
        this.endPos = endPos;
    }

    @Override
    public @NotNull Packet<ClientGamePacketListener> m_5654_() {
        return new ClientboundAddEntityPacket(this);
    }

    @Override
    protected void m_8097_() {
        this.f_19804_.m_135372_(DAMAGE, 0F);
        this.f_19804_.m_135372_(SIZE, 1.0F);
        this.f_19804_.m_135372_(LIFESPAN, 0);
        this.f_19804_.m_135372_(DELAY, 0);
        this.f_19804_.m_135372_(IS_CHAIN, false);
        this.f_19804_.m_135372_(CASTER_FEMALE, false);
    }

    public int getLifespan() {
        return this.f_19804_.m_135370_(LIFESPAN);
    }

    public void setLifespan(int lifespan) {
        this.f_19804_.m_135381_(LIFESPAN, lifespan);
    }

    public int getDelay() {
        return this.f_19804_.m_135370_(DELAY);
    }

    public void setDelay(int delay) {
        this.f_19804_.m_135381_(DELAY, delay);
    }

    public float getSize() {
        return this.f_19804_.m_135370_(SIZE);
    }

    public void setSize(float size) {
        if (!this.m_9236_().f_46443_) {
            this.f_19804_.m_135381_(SIZE, Mth.m_14036_(size, 0.5F, 3.0F));
        }
    }

    public float getDamage() {
        return f_19804_.m_135370_(DAMAGE);
    }

    public void setDamage(float damage) {
        f_19804_.m_135381_(DAMAGE, damage);
    }

    public boolean getIsChain() {
        return f_19804_.m_135370_(IS_CHAIN);
    }

    public void setIsChain(boolean isChain) {
        f_19804_.m_135381_(IS_CHAIN, isChain);
    }

    public void setCaster(@Nullable LivingEntity caster) {
        this.owner = caster;
        this.ownerUUID = caster == null ? null : caster.m_20148_();
        if (caster instanceof DragonEntity dragon) {
            this.f_19804_.m_135381_(CASTER_FEMALE, dragon.isFemale());
        }
    }

    @Nullable
    public LivingEntity getCaster() {
        if (this.owner == null && this.ownerUUID != null && this.m_9236_() instanceof ServerLevel) {
            Entity entity = ((ServerLevel)this.m_9236_()).m_8791_(this.ownerUUID);
            if (entity instanceof LivingEntity) {
                this.owner = (LivingEntity)entity;
            }
        }
        return this.owner;
    }

    private boolean isCasterFemale() {
        return this.f_19804_.m_135370_(CASTER_FEMALE);
    }

    @Override
    public boolean m_6783_(double distance) {
        double d0 = 64.0F * m_20150_();
        return distance < d0 * d0;
    }

    @Override
    public @NotNull PushReaction m_7752_() {
        return PushReaction.IGNORE;
    }

    @Override
    public @NotNull EntityDimensions m_6972_(@Nonnull Pose pose) {
        return EntityDimensions.m_20395_(this.getSize() * 0.5F, this.getSize());
    }

    @Override
    public void m_8119_() {
        super.m_8119_();
        
        setLifespan(this.getLifespan() + 1);
        int adjustedLifespan = this.getLifespan() - this.getDelay();

        if (this.m_9236_().f_46443_) {
            // Client-side particle effects
            if (adjustedLifespan == 1) {
                spawnLightningParticles();
            }
        } else {
            // Server-side damage and chain logic
            if (adjustedLifespan == 5) {
                dealDamage();
                if (getIsChain() && chainCount < maxChains) {
                    attemptChainLightning();
                }
            }
            
            if (adjustedLifespan > 20) {
                this.m_146870_();
            }
        }
    }

    private void spawnLightningParticles() {
        boolean female = isCasterFemale();
        if (startPos != null && endPos != null) {
            // Spawn animated lightning arc that traces the path
            if (getIsChain()) {
                // Animated chain lightning arc
                this.m_9236_().m_7107_(
                    new RaevyxLightningChainData(getSize(), startPos, endPos, female),
                    startPos.f_82479_, startPos.f_82480_, startPos.f_82481_,
                    0, 0, 0
                );
            } else {
                // Static lightning storm for single strikes
                Vec3 delta = endPos.m_82546_(startPos);
                int segments = Math.max(3, (int)(delta.m_82553_() * 4));
                Vec3 step = delta.m_82490_(1.0 / segments);
                
                for (int i = 0; i <= segments; i++) {
                    Vec3 pos = startPos.m_82549_(step.m_82490_(i));
                    Vec3 dir = step.m_82541_();
                    
                    this.m_9236_().m_7107_(
                        new RaevyxLightningStormData(getSize(), female),
                        pos.f_82479_, pos.f_82480_, pos.f_82481_,
                        dir.f_82479_, dir.f_82480_, dir.f_82481_
                    );
                }
            }
        } else {
            // Single point lightning
            if (getIsChain()) {
                this.m_9236_().m_7107_(
                    new RaevyxLightningArcData(getSize(), female),
                    this.m_20185_(), this.m_20186_(), this.m_20189_(),
                    0, 0, 0
                );
            } else {
                this.m_9236_().m_7107_(
                    new RaevyxLightningStormData(getSize(), female),
                    this.m_20185_(), this.m_20186_(), this.m_20189_(),
                    0, 0, 0
                );
            }
        }
    }

    private void dealDamage() {
        AABB damageBox = this.m_20191_().m_82400_(getSize() * 2.0);
        
        for (LivingEntity entity : this.m_9236_().m_45976_(LivingEntity.class, damageBox)) {
            if (entity.m_6084_() && !entity.m_20147_() && entity != getCaster()) {
                LivingEntity caster = getCaster();
                if (!isProtectedFromCaster(caster, entity)) {
                    DamageSource damageSource = caster != null ? 
                        this.m_269291_().m_269333_(caster) : 
                        this.m_269291_().m_269425_();
                    
                    entity.m_6469_(damageSource, getDamage());
                    
                    // Spawn impact effects at the target location
                    spawnImpactEffects(entity.m_20182_().m_82520_(0, entity.m_20206_() / 2, 0));
                }
            }
        }
    }

    private void spawnImpactEffects(Vec3 impactPos) {
        if (!(this.m_9236_() instanceof ServerLevel server)) return;
        boolean female = isCasterFemale();
        
        // Spawn layered lightning arc impact effects for dramatic visual
        float size = getSize() * 0.6f; // Reduced from 1.2f
        
        // Spawn multiple layered particles for impact effect
        for (int layer = 0; layer < 4; layer++) {
            float layerSize = size * (1.0f + layer * 0.25f);
            float layerOffset = layer * 0.1f; // Reduced from 0.15f
            
            // Spawn particles in a small radius around the impact point
            for (int i = 0; i < 6; i++) {
                double angle = (i * Math.PI * 2) / 6.0;
                double offsetX = Math.cos(angle) * layerOffset;
                double offsetZ = Math.sin(angle) * layerOffset;
                
                server.m_8767_(new RaevyxLightningArcData(layerSize, female),
                        impactPos.f_82479_ + offsetX, impactPos.f_82480_ + layerOffset, impactPos.f_82481_ + offsetZ,
                        1, 0, 0, 0, 0.0);
            }
        }
    }

    private void spawnChainImpactEffects(Vec3 chainPos) {
        if (!(this.m_9236_() instanceof ServerLevel server)) return;
        boolean female = isCasterFemale();
        
        // Spawn chain-specific impact effects (smaller, more focused)
        float size = getSize() * 0.4f; // Reduced from 0.8f
        
        // Spawn fewer layers for chain impacts (more focused effect)
        for (int layer = 0; layer < 3; layer++) {
            float layerSize = size * (1.0f + layer * 0.2f);
            float layerOffset = layer * 0.05f; // Reduced from 0.1f
            
            // Spawn particles in a tighter radius for chain effects
            for (int i = 0; i < 4; i++) {
                double angle = (i * Math.PI * 2) / 4.0;
                double offsetX = Math.cos(angle) * layerOffset;
                double offsetZ = Math.sin(angle) * layerOffset;
                
                server.m_8767_(new RaevyxLightningArcData(layerSize, female),
                        chainPos.f_82479_ + offsetX, chainPos.f_82480_ + layerOffset, chainPos.f_82481_ + offsetZ,
                        1, 0, 0, 0, 0.0);
            }
        }
    }

    private void attemptChainLightning() {
        if (!(this.m_9236_() instanceof ServerLevel serverLevel)) return;
        
        AABB searchBox = this.m_20191_().m_82400_(getSize() * 4.0);
        LivingEntity nearestTarget = null;
        double nearestDistance = Double.MAX_VALUE;
        
        for (LivingEntity entity : serverLevel.m_45976_(LivingEntity.class, searchBox)) {
            if (entity.m_6084_() && !entity.m_20147_() && entity != getCaster()) {
                LivingEntity caster = getCaster();
                if (!isProtectedFromCaster(caster, entity)) {
                    double distance = this.m_20270_(entity);
                    if (distance < nearestDistance) {
                        nearestTarget = entity;
                        nearestDistance = distance;
                    }
                }
            }
        }
        
        if (nearestTarget != null) {
            // Create chain lightning to the nearest target
            Vec3 chainStart = this.m_20182_();
            Vec3 chainEnd = nearestTarget.m_20182_().m_82520_(0, nearestTarget.m_20206_() / 2, 0);
            
            // Spawn impact effect at the current position (where chain originates)
            spawnChainImpactEffects(chainStart);
            
            RaevyxLightningChainEntity chainEntity = new RaevyxLightningChainEntity(
                serverLevel, chainStart, chainEnd, 
                getDamage() * 0.8f, getSize() * 0.9f, 
                getCaster(), true
            );
            chainEntity.chainCount = this.chainCount + 1;
            chainEntity.maxChains = this.maxChains;
            
            serverLevel.m_7967_(chainEntity);
        }
    }


    private boolean isProtectedFromCaster(@Nullable LivingEntity caster, LivingEntity target) {
        if (caster == null) {
            return false;
        }

        if (caster instanceof com.leon.saintsdragons.server.entity.base.DragonEntity dragon && dragon.isAlly(target)) {
            return true;
        }

        return caster.m_7307_(target);
    }

    @Override
    protected void m_7380_(@Nonnull CompoundTag compound) {
        compound.m_128405_("lifespan", this.getLifespan());
        compound.m_128405_("delay", this.getDelay());
        compound.m_128350_("damage", this.getDamage());
        compound.m_128350_("size", this.getSize());
        compound.m_128379_("isChain", this.getIsChain());
        compound.m_128379_("casterFemale", this.f_19804_.m_135370_(CASTER_FEMALE));
        compound.m_128405_("chainCount", this.chainCount);
        compound.m_128405_("maxChains", this.maxChains);
        
        if (this.ownerUUID != null) {
            compound.m_128362_("Owner", this.ownerUUID);
        }
        
        if (startPos != null) {
            compound.m_128347_("startX", startPos.f_82479_);
            compound.m_128347_("startY", startPos.f_82480_);
            compound.m_128347_("startZ", startPos.f_82481_);
        }
        
        if (endPos != null) {
            compound.m_128347_("endX", endPos.f_82479_);
            compound.m_128347_("endY", endPos.f_82480_);
            compound.m_128347_("endZ", endPos.f_82481_);
        }
    }

    @Override
    protected void m_7378_(@Nonnull CompoundTag compound) {
        this.setLifespan(compound.m_128451_("lifespan"));
        this.setDelay(compound.m_128451_("delay"));
        this.setDamage(compound.m_128457_("damage"));
        this.setSize(compound.m_128457_("size"));
        this.setIsChain(compound.m_128471_("isChain"));
        if (compound.m_128441_("casterFemale")) {
            this.f_19804_.m_135381_(CASTER_FEMALE, compound.m_128471_("casterFemale"));
        }
        this.chainCount = compound.m_128451_("chainCount");
        this.maxChains = compound.m_128451_("maxChains");
        
        if (compound.m_128403_("Owner")) {
            this.ownerUUID = compound.m_128342_("Owner");
        }
        
        if (compound.m_128441_("startX")) {
            this.startPos = new Vec3(
                compound.m_128459_("startX"),
                compound.m_128459_("startY"),
                compound.m_128459_("startZ")
            );
        }
        
        if (compound.m_128441_("endX")) {
            this.endPos = new Vec3(
                compound.m_128459_("endX"),
                compound.m_128459_("endY"),
                compound.m_128459_("endZ")
            );
        }
    }
}
