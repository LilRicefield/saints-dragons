package com.leon.saintsdragons.server.entity.ability.abilities.nulljaw;

import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType.ACTIVE;
import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType.RECOVERY;
import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType.STARTUP;

/**
 * Phase 2 rage mode bite - AOE bite shorter range than horn gore, more damage than phase 1.
 */
public class NulljawBite2Ability extends DragonAbility<Nulljaw> {
    private static final float BASE_DAMAGE = 50.0f;
    private static final double BASE_RANGE = 5.5;          // Shorter than horn gore (7.0)
    private static final double RIDDEN_RANGE_BONUS = 0.5;
    private static final double SWIM_RANGE_BONUS = 2.0;     // Reduced from 8.0
    private static final double BITE_ANGLE_DEG = 95.0;      // Slightly wider than phase 1
    private static final double BITE_SWIPE_HORIZONTAL = 4.5;
    private static final double BITE_SWIPE_HORIZONTAL_RIDDEN = 2.0;
    private static final double BITE_SWIPE_VERTICAL = 4.5;

    // Faster than phase 1 bite
    private static final DragonAbilitySection[] TRACK = new DragonAbilitySection[] {
            new AbilitySectionDuration(STARTUP, 5),
            new AbilitySectionDuration(ACTIVE, 6),
            new AbilitySectionDuration(RECOVERY, 6)
    };

    private boolean appliedHit;

    public NulljawBite2Ability(DragonAbilityType<Nulljaw, NulljawBite2Ability> type,
                               Nulljaw user) {
        super(type, user, TRACK, 15);
    }

    @Override
    public boolean tryAbility() {
        // Only allow in phase 2
        return getUser().isPhaseTwoActive();
    }

    @Override
    protected void beginSection(DragonAbilitySection section) {
        if (section == null) {
            return;
        }

        if (section.sectionType == STARTUP) {
            Nulljaw dragon = getUser();
            dragon.triggerAnim("action", "bite2");
            appliedHit = false;
        }
    }

    @Override
    public void tickUsing() {
        DragonAbilitySection section = getCurrentSection();
        if (section == null) {
            return;
        }

        if (section.sectionType == ACTIVE && !appliedHit) {
            Nulljaw dragon = getUser();

            // AOE bite - hit ALL valid targets in range
            java.util.List<LivingEntity> targets = findAllTargetsInCone();

            // Apply hit to all targets found
            for (LivingEntity target : targets) {
                applyHit(dragon, target);
            }

            appliedHit = true;
        }
    }

    private void applyHit(Nulljaw dragon, LivingEntity target) {
        float damage = BASE_DAMAGE;
        AttributeInstance attackAttr = dragon.m_21051_(Attributes.f_22281_);
        if (attackAttr != null) {
            double value = attackAttr.m_22135_();
            if (value > 0) {
                damage = (float) (value * 1.1); // 10% more than phase 1 bite
            }
        }

        DamageSource source = dragon.m_9236_().m_269111_().m_269333_(dragon);
        target.m_6469_(source, damage);

        Vec3 push = dragon.m_20154_().m_82490_(0.35);
        target.m_5997_(push.f_82479_, dragon.m_6069_() ? 0.2 : 0.08, push.f_82481_);
    }

    // ===== Range calculation =====

    private double getEffectiveRange() {
        Nulljaw dragon = getUser();
        double range = BASE_RANGE;

        if (dragon.m_6688_() != null) {
            range += RIDDEN_RANGE_BONUS;
        }
        if (dragon.m_6069_()) {
            range += SWIM_RANGE_BONUS;
        }

        return range;
    }

    // ===== AOE target finding - hits ALL valid targets in cone =====

    private java.util.List<LivingEntity> findAllTargetsInCone() {
        Nulljaw dragon = getUser();
        Vec3 mouth = dragon.getMouthPosition();
        Vec3 look = dragon.m_20154_().m_82541_();

        boolean ridden = dragon.m_6688_() != null;
        double effectiveRange = getEffectiveRange();

        // Forward sweep out from the mouth so hits originate ahead of the head
        double horizontalInflate = ridden ? BITE_SWIPE_HORIZONTAL_RIDDEN : BITE_SWIPE_HORIZONTAL;
        AABB forwardSweep = new AABB(mouth, mouth.m_82549_(look.m_82490_(effectiveRange)))
                .m_82377_(horizontalInflate, BITE_SWIPE_VERTICAL, horizontalInflate);

        java.util.List<LivingEntity> candidates = dragon.m_9236_().m_6443_(LivingEntity.class, forwardSweep,
                e -> e != dragon && e.m_6084_() && e.m_5789_() && !dragon.isAlly(e));

        double cosLimit = Math.cos(Math.toRadians(BITE_ANGLE_DEG));
        java.util.List<LivingEntity> validTargets = new java.util.ArrayList<>();

        for (LivingEntity e : candidates) {
            // Compute closest point on target's AABB to the mouth
            double distToAabb = distancePointToAABB(mouth, e.m_20191_());
            if (distToAabb > effectiveRange + 0.4) continue;

            // Direction toward the closest point for angle test
            Vec3 toward = closestPointOnAABB(mouth, e.m_20191_()).m_82546_(mouth);
            double len = toward.m_82553_();
            if (len <= 0.0001) continue;
            Vec3 dir = toward.m_82490_(1.0 / len);
            double dot = dir.m_82526_(look);

            // Require the bite to project forward from the head
            if (dot <= 0.0) continue;

            // Be forgiving with angle when very close; otherwise enforce cone
            boolean veryClose = distToAabb < (effectiveRange * 0.35);
            boolean goodAngle = dot >= cosLimit;
            if (ridden) {
                // Slightly relax the cone while ridden but keep hits forward
                goodAngle = goodAngle || dot >= (cosLimit * 0.75);
            }
            if (!(veryClose || goodAngle)) continue;

            // Add ALL valid targets instead of picking just the closest
            validTargets.add(e);
        }
        return validTargets;
    }

    // ===== Geometry helpers =====

    private static double distancePointToAABB(Vec3 p, AABB box) {
        double dx = Math.max(Math.max(box.f_82288_ - p.f_82479_, 0.0), p.f_82479_ - box.f_82291_);
        double dy = Math.max(Math.max(box.f_82289_ - p.f_82480_, 0.0), p.f_82480_ - box.f_82292_);
        double dz = Math.max(Math.max(box.f_82290_ - p.f_82481_, 0.0), p.f_82481_ - box.f_82293_);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static Vec3 closestPointOnAABB(Vec3 p, AABB box) {
        double cx = Mth.m_14008_(p.f_82479_, box.f_82288_, box.f_82291_);
        double cy = Mth.m_14008_(p.f_82480_, box.f_82289_, box.f_82292_);
        double cz = Mth.m_14008_(p.f_82481_, box.f_82290_, box.f_82293_);
        return new Vec3(cx, cy, cz);
    }
}
