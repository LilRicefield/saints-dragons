package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Features smart flight triggering, performance optimizations, and realistic distances... maybe, cuz if the player keeps walking away from Dink, he'd move incrementally, not walk to his owner in an instant.
 */

public class RaevyxFollowOwnerGoal extends Goal {
    private final Raevyx wyvern;

    // Distance constants - tuned for better behavior
    private static final double START_FOLLOW_DIST = 5.0;
    private static final double STOP_FOLLOW_DIST = 5.0; // Increased slightly to prevent constant state changes
    private static final double TELEPORT_DIST = 500.0;
    private static final double RUN_DIST = 15.0;
    private static final double FLIGHT_TRIGGER_DIST = 20.0;
    private static final double FLIGHT_HEIGHT_DIFF = 8.0;
    private static final double LANDING_DISTANCE = 12.0; // Distance at which to start landing sequence
    private static final double HOVER_HEIGHT = 3.0; // Height above owner when hovering

    // Performance optimization - don't re-path constantly
    private int pathRecalcCooldown = 0;
    private double lastOwnerX = Double.NaN;
    private double lastOwnerY = Double.NaN;
    private double lastOwnerZ = Double.NaN;

    public RaevyxFollowOwnerGoal(Raevyx wyvern) {
        this.wyvern = wyvern;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        // Basic requirements

        if (!wyvern.m_21824_() || wyvern.m_21827_() || wyvern.isSleepLocked()) {
            return false;
        }

        // Never follow while actively targeting an enemy
        if (wyvern.m_5448_() != null && wyvern.m_5448_().m_6084_()) {
            return false;
        }

        LivingEntity owner = wyvern.m_269323_();
        if (owner == null || !owner.m_6084_()) {
            return false;
        }

        // Must be in same dimension
        if (owner.m_9236_() != wyvern.m_9236_()) {
            return false;
        }

        // Only follow if owner is far enough away
        double ownerDist = wyvern.getCachedDistanceToOwner();
        return ownerDist > START_FOLLOW_DIST * START_FOLLOW_DIST;
    }

    @Override
    public boolean m_8045_() {
        LivingEntity owner = wyvern.m_269323_();
        if (owner == null || !owner.m_6084_() || wyvern.m_21827_() || wyvern.isSleepLocked()) {
            return false;
        }

        // Suspend following while fighting
        if (wyvern.m_5448_() != null && wyvern.m_5448_().m_6084_()) {
            return false;
        }

        if (owner.m_9236_() != wyvern.m_9236_()) {
            return false;
        }

        // Keep following until we're close enough
        double dist = wyvern.m_20280_(owner);
        return dist > STOP_FOLLOW_DIST * STOP_FOLLOW_DIST;
    }

    @Override
    public void m_8056_() {
        // Reset tracking
        resetPathTracking();

        // Don't immediately fly - let tick() decide based on conditions
        LivingEntity owner = wyvern.m_269323_();
        double dist = owner != null ? Math.sqrt(wyvern.m_20280_(owner)) : -1;
        
    }

    @Override
    public void m_8037_() {
        LivingEntity owner = wyvern.m_269323_();
        if (owner == null) return;

        double distance = wyvern.m_20270_(owner);

        // Emergency teleport if owner gets stupidly far away
        if (distance > TELEPORT_DIST) {
            wyvern.m_6021_(owner.m_20185_(), owner.m_20186_() + 3, owner.m_20189_());
            // transition to flying
            wyvern.setFlying(true);
            wyvern.setTakeoff(false);
            wyvern.setLanding(false);
            wyvern.setHovering(false);
            resetPathTracking();
            

            return;
        }

        // Always look at owner while following
        wyvern.m_21563_().m_24960_(owner, 10.0f, 10.0f);

        // Smart flight decision making
        boolean shouldFly = shouldTriggerFlight(owner, distance);

        // Handle flight state changes
        if (shouldFly && !wyvern.m_29443_()) {
            // Take off to follow owner
            wyvern.setFlying(true);
            wyvern.setTakeoff(true);
            wyvern.setLanding(false);
            wyvern.setHovering(false);
            resetPathTracking();
            
        } else if (wyvern.m_29443_() && distance < STOP_FOLLOW_DIST * 1.5) {
            // Start landing sequence when close enough to owner
            wyvern.setLanding(true);
            wyvern.setFlying(false);
            wyvern.setHovering(true);
            pathRecalcCooldown = 0;
            
        }

        // Movement logic
        if (wyvern.m_29443_()) {
            handleFlightFollowing(owner);
        } else {
            handleGroundFollowing(owner, distance);
        }
    }

    /**
     * Handle following while flying
     */
    private void handleFlightFollowing(LivingEntity owner) {
        // Calculate target position slightly above and behind owner
        double targetY = owner.m_20186_() + owner.m_20206_() + HOVER_HEIGHT;

        // Get owner's look vector for positioning behind them
        Vec3 ownerLook = owner.m_20154_();
        double offsetX = -ownerLook.f_82479_ * 3.0; // Reduced from 4.0 for closer following
        double offsetZ = -ownerLook.f_82481_ * 3.0;

        // Add slight vertical movement for more natural flight
        double verticalOffset = Math.sin(wyvern.f_19797_ * 0.2) * 0.3; // Subtle bobbing

        // Calculate target position with smoothing
        double targetX = owner.m_20185_() + offsetX;
        double targetZ = owner.m_20189_() + offsetZ;

        // Only update position if we're not too close to prevent jitter
        double distanceToTarget = Math.sqrt(wyvern.m_20275_(targetX, targetY, targetZ));
        if (distanceToTarget > 1.0) {
            wyvern.m_21566_().m_6849_(
                    targetX,
                    targetY + verticalOffset,
                    targetZ,
                    1.2 // Flight speed
            );
        } else {
            // Hover in place if we're close enough
            wyvern.m_21573_().m_26573_();
        }
    }

    /**
     * Handle following on ground
     */
    private void handleGroundFollowing(LivingEntity owner, double distance) {
        // Check if we should stop moving
        if (distance <= STOP_FOLLOW_DIST) {
            // Only update state if we were moving before
            if (wyvern.getGroundMoveState() > 0) {
                wyvern.m_21573_().m_26573_();
                wyvern.setRunning(false);
                wyvern.setGroundMoveStateFromAI(0);
                
            }
            pathRecalcCooldown = 0;
            return;
        }

        // Determine movement style based on distance
        boolean shouldRun = distance > RUN_DIST;
        wyvern.setRunning(shouldRun);

        // Set appropriate animation state (0=idle, 1=walking, 2=running)
        int moveState = shouldRun ? 2 : 1;
        wyvern.setGroundMoveStateFromAI(moveState);

        // Adjust speed based on movement style and distance
        double baseSpeed = shouldRun ? 1.5 : 0.8;
        double speed = baseSpeed * (1.0 + (distance / 50.0));
        speed = Math.min(speed, shouldRun ? 2.5 : 1.2); // Cap max speed

        updateGroundPath(owner, speed, distance, shouldRun);

        // If stuck, try to jump or find alternative path
        if (wyvern.m_21573_().m_26577_()) {
            wyvern.m_21569_().m_24901_();
            wyvern.m_21573_().m_26573_();
            pathRecalcCooldown = 0; // Force repath next tick
        }
    }

    /**
     * Determine if wyvern should take flight to follow owner
     * Uses Ice and Fire's logic for smarter flight decisions
     */
    private boolean shouldTriggerFlight(LivingEntity owner, double distance) {
        // If already flying, continue flying until we're close to landing
        if (wyvern.m_29443_()) {
            // Only stop flying if we're close to the owner and not too high up
            return !(distance < LANDING_DISTANCE && (owner.m_20186_() - wyvern.m_20186_()) < FLIGHT_HEIGHT_DIFF);
        }

        // Don't take off if we can't fly or are already hovering
        if (wyvern.isHovering() || !canTriggerFlight()) {
            return false;
        }

        // Don't take off if we're very close to the owner
        if (distance < STOP_FOLLOW_DIST * 1.5) {
            return false;
        }

        // Fly if owner is far away OR significantly higher up
        boolean farAway = distance > FLIGHT_TRIGGER_DIST;
        boolean ownerAbove = (owner.m_20186_() - wyvern.m_20186_()) > FLIGHT_HEIGHT_DIFF;

        // Check more frequently when we should be flying
        return farAway || ownerAbove;
    }

    /**
     * Check if wyvern is allowed to take flight
     * Uses existing wyvern flight requirements
     */
    private boolean canTriggerFlight() {
        return !wyvern.m_21827_() &&
                !wyvern.m_6162_() &&
                (wyvern.m_20096_() || wyvern.m_20069_()) &&
                wyvern.m_20197_().isEmpty() &&
                wyvern.m_6688_() == null &&
                !wyvern.m_20159_() &&
                wyvern.getActiveAbility() == null; // Don't interrupt abilities
    }

    @Override
    public void m_8041_() {
        wyvern.setRunning(false);
        wyvern.m_21573_().m_26573_();
        wyvern.setGroundMoveStateFromAI(0);
        resetPathTracking();
    }

    private void updateGroundPath(LivingEntity owner, double speed, double distance, boolean running) {
        if (pathRecalcCooldown > 0) {
            pathRecalcCooldown--;
        }

        boolean ownerMoved = ownerMovedSignificantly(owner);
        boolean navIdle = wyvern.m_21573_().m_26571_() || !wyvern.m_21573_().m_26572_();

        if (navIdle || ownerMoved || pathRecalcCooldown <= 0) {
            if (!wyvern.m_21573_().m_5624_(owner, speed)) {
                wyvern.m_21573_().m_26519_(owner.m_20185_(), owner.m_20186_(), owner.m_20189_(), speed);
            }
            rememberOwnerPosition(owner);
            pathRecalcCooldown = computeRepathCooldown(distance, running);
        }
    }

    private int computeRepathCooldown(double distance, boolean running) {
        int base = (int) Math.ceil(distance * (running ? 0.3 : 0.45));
        return Mth.m_14045_(base, running ? 4 : 6, running ? 18 : 24);
    }

    private boolean ownerMovedSignificantly(LivingEntity owner) {
        if (Double.isNaN(lastOwnerX)) {
            return true;
        }
        double dx = owner.m_20185_() - this.lastOwnerX;
        double dy = owner.m_20186_() - this.lastOwnerY;
        double dz = owner.m_20189_() - this.lastOwnerZ;
        return dx * dx + dy * dy + dz * dz > 1.2D;
    }

    private void rememberOwnerPosition(LivingEntity owner) {
        this.lastOwnerX = owner.m_20185_();
        this.lastOwnerY = owner.m_20186_();
        this.lastOwnerZ = owner.m_20189_();
    }

    private void resetPathTracking() {
        this.pathRecalcCooldown = 0;
        this.lastOwnerX = Double.NaN;
        this.lastOwnerY = Double.NaN;
        this.lastOwnerZ = Double.NaN;
    }
}
