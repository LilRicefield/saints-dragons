package com.leon.saintsdragons.server.ai.navigation;

import com.leon.saintsdragons.server.entity.interfaces.DragonFlightCapable;
import com.leon.saintsdragons.util.DragonMathUtil;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;

/**
 * Generic flight movement controller - handles AI flight pathfinding for any type
 * Banking is handled elsewhere; MoveHelper focuses on movement only
 * Works with any entity that implements DragonFlightCapable interface
 */
public class DragonFlightMoveHelper extends MoveControl {
    private final DragonFlightCapable dragon;
    private final net.minecraft.world.entity.Mob mob;
    private float speedFactor = 1.0F;

    // Dragon-specific flight parameters
    private final float maxYawChange;
    private final float maxPitchChange;
    private final float speedFactorMin;
    private final float speedFactorMax;
    private final float speedTransitionRate;
    private final double accelerationCap;
    private final double velocityBlendRate;

    public DragonFlightMoveHelper(DragonFlightCapable dragon) {
        this(dragon, getDefaultParameters());
    }

    public DragonFlightMoveHelper(DragonFlightCapable dragon, FlightParameters params) {
        super((net.minecraft.world.entity.Mob) dragon);
        this.dragon = dragon;
        this.f_24974_ = (net.minecraft.world.entity.Mob) dragon;
        
        this.maxYawChange = params.maxYawChange;
        this.maxPitchChange = params.maxPitchChange;
        this.speedFactorMin = params.speedFactorMin;
        this.speedFactorMax = params.speedFactorMax;
        this.speedTransitionRate = params.speedTransitionRate;
        this.accelerationCap = params.accelerationCap;
        this.velocityBlendRate = params.velocityBlendRate;
    }

    private static FlightParameters getDefaultParameters() {
        return new FlightParameters(
            4.0F,    // maxYawChange
            8.0F,    // maxPitchChange
            0.5F,    // speedFactorMin
            3.2F,    // speedFactorMax
            0.15F,   // speedTransitionRate
            0.22D,   // accelerationCap
            0.16D    // velocityBlendRate
        );
    }

    // Flight parameters for different types
    public static class FlightParameters {
        public final float maxYawChange;
        public final float maxPitchChange;
        public final float speedFactorMin;
        public final float speedFactorMax;
        public final float speedTransitionRate;
        public final double accelerationCap;
        public final double velocityBlendRate;

        public FlightParameters(float maxYawChange, float maxPitchChange, float speedFactorMin, 
                              float speedFactorMax, float speedTransitionRate, double accelerationCap, 
                              double velocityBlendRate) {
            this.maxYawChange = maxYawChange;
            this.maxPitchChange = maxPitchChange;
            this.speedFactorMin = speedFactorMin;
            this.speedFactorMax = speedFactorMax;
            this.speedTransitionRate = speedTransitionRate;
            this.accelerationCap = accelerationCap;
            this.velocityBlendRate = velocityBlendRate;
        }
    }

    @Override
    public void m_8126_() {
        if (this.f_24981_ != Operation.MOVE_TO) {
            return;
        }

        // Handle different flight modes
        if (dragon.isHovering() || dragon.isLanding()) {
            handleHoveringMovement();
        } else {
            handleGlidingMovement();
        }
    }

    /**
     * Gliding movement - this is where the magic happens
     */
    private void handleGlidingMovement() {
        // Collision handling - simple 180 turn
        if (f_24974_.f_19862_) {
            f_24974_.m_146922_(f_24974_.m_146908_() + 180.0F);
            this.speedFactor = speedFactorMin;
            f_24974_.m_21573_().m_26573_();
            return;
        }

        // Calculate movement vectors to target
        float distX = (float) (this.f_24975_ - f_24974_.m_20185_());
        float distY = (float) (this.f_24976_ - f_24974_.m_20186_());
        float distZ = (float) (this.f_24977_ - f_24974_.m_20189_());

        // Reduce Y influence on horizontal movement (guard against division by zero)
        double horizontalDist = Math.sqrt(distX * distX + distZ * distZ);
        if (horizontalDist > 1.0e-6) {
            double yFractionReduction = 1.0D - (double) Mth.m_14154_(distY * 0.7F) / horizontalDist;
            distX = (float) (distX * yFractionReduction);
            distZ = (float) (distZ * yFractionReduction);
            horizontalDist = Math.sqrt(distX * distX + distZ * distZ);
        }
        double totalDist = Math.sqrt(distX * distX + distZ * distZ + distY * distY);
        if (totalDist < 1.0e-6) {
            // We're essentially at the target; stop moving
            this.f_24981_ = Operation.WAIT;
            return;
        }

        // === YAW CALCULATION ===
        float currentYaw = f_24974_.m_146908_();
        float desiredYaw = (float) Mth.m_14136_(distZ, distX) * 57.295776F; // Convert to degrees

        // Smooth yaw approach
        float wrappedCurrentYaw = Mth.m_14177_(currentYaw + 90.0F);
        float wrappedDesiredYaw = Mth.m_14177_(desiredYaw);
        f_24974_.m_146922_(Mth.m_14148_(wrappedCurrentYaw, wrappedDesiredYaw, maxYawChange) - 90.0F);

        // Banking handled in animation/predicate; keep MoveHelper focused on movement
        // MoveHelper only handles movement - no banking calculation needed

        // Body rotation follows head
        f_24974_.f_20883_ = f_24974_.m_146908_();

        // === PITCH CALCULATION ===
        float desiredPitch = (float) (-(Mth.m_14136_(-distY, horizontalDist) * 57.295776F));
        f_24974_.m_146926_(Mth.m_14148_(f_24974_.m_146909_(), desiredPitch, maxPitchChange));

        // === ENHANCED SPEED MODULATION ===
        float yawDifference = Math.abs(Mth.m_14177_(f_24974_.m_146908_() - currentYaw));

        // Base speed factor adjustments
        float targetSpeedFactor;
        if (yawDifference < 3.0F) {
            // Facing right direction - speed up
            targetSpeedFactor = speedFactorMax;
        } else {
            // Turning - slow down based on turn severity using yaw difference
            float turnSeverity = Mth.m_14036_(yawDifference / 15.0f, 0.0f, 1.0f); // Normalize to 0-1
            targetSpeedFactor = DragonMathUtil.lerpSmooth(0.6f, speedFactorMax, 1.0f - turnSeverity,
                    DragonMathUtil.EasingFunction.EASE_OUT_SINE);
        }

        // Distance-based speed scaling (IaF-inspired): keep speed up at range, ease gently near goal
        float distScale = Mth.m_14036_((float) (totalDist / 45.0) + 0.35f, 0.35f, 1.0f);
        targetSpeedFactor *= distScale;

        // Combat bias: fly a bit faster when we have a live target and are airborne
        var target = f_24974_.m_5448_();
        if (dragon.isFlying() && target != null && target.m_6084_()) {
            targetSpeedFactor *= 1.12f; // modest global boost in combat
        }

        // If straight path to wanted position is obstructed by blocks, damp speed to avoid wall pushing
        if (isLineObstructed(f_24974_.m_20182_(), new Vec3(this.f_24975_, this.f_24976_, this.f_24977_))) {
            targetSpeedFactor *= 0.5f;
        }

        this.speedFactor = Mth.m_14036_(Mth.m_14121_(this.speedFactor, targetSpeedFactor, speedTransitionRate),
                speedFactorMin, speedFactorMax); // Dragon-specific speed transitions with clamping

        // === 3D MOVEMENT APPLICATION (robust, normalized toward target) ===
        Vec3 dir = new Vec3(distX, distY, distZ).m_82490_(1.0 / totalDist); // normalized
        Vec3 motion = f_24974_.m_20184_();
        Vec3 targetVel = dir.m_82490_(this.speedFactor);
        // Blend toward target velocity with per-axis acceleration cap to reduce twitch/overshoot
        Vec3 delta = targetVel.m_82546_(motion).m_82490_(velocityBlendRate); // wyvern-specific blend rate
        double accelCap = accelerationCap;
        // Additional dampening when obstructed
        if (isLineObstructed(f_24974_.m_20182_(), new Vec3(this.f_24975_, this.f_24976_, this.f_24977_))) {
            accelCap *= 0.6D;
            delta = delta.m_82490_(0.6D);
        }
        delta = clampPerAxis(delta, accelCap);
        Vec3 blended = motion.m_82549_(delta);
        f_24974_.m_20256_(blended);
    }

    /**
     * Hovering movement - simpler, more direct control
     */
    private void handleHoveringMovement() {
        // Look at target if we have one - use smooth looking with deadzone to avoid jitter
        var target = f_24974_.m_5448_();
        if (target != null && f_24974_.m_20280_(target) < 1600.0D) {
            float yawErr = DragonMathUtil.yawErrorToTarget(f_24974_, target);
            if (yawErr > 4.0f) {
                DragonMathUtil.smoothLookAt(f_24974_, target, 10.0f, 10.0f);
            } // else: within deadzone, do not adjust this tick
        }

        if (this.f_24981_ == Operation.MOVE_TO) {
            Vec3 targetVec = new Vec3(
                    this.f_24975_ - f_24974_.m_20185_(),
                    this.f_24976_ - f_24974_.m_20186_(),
                    this.f_24977_ - f_24974_.m_20189_()
            );
            double distance = targetVec.m_82553_();
            targetVec = targetVec.m_82541_();

            // Simple collision check for hovering
            if (checkCollisions(targetVec, Mth.m_14165_(distance))) {
                f_24974_.m_20256_(f_24974_.m_20184_().m_82549_(targetVec.m_82490_(0.1D)));
            } else {
                this.f_24981_ = Operation.WAIT;
            }
        }
    }

    /**
     * Collision checking for hovering mode
     */
    private boolean checkCollisions(Vec3 direction, int steps) {
        var boundingBox = f_24974_.m_20191_();
        for (int i = 1; i < steps; ++i) {
            boundingBox = boundingBox.m_82383_(direction);
            if (!f_24974_.m_9236_().m_45756_(f_24974_, boundingBox)) {
                return false;
            }
        }
        return true;
    }

    private static Vec3 clampPerAxis(Vec3 v, double cap) {
        double cx = Mth.m_14008_(v.f_82479_, -cap, cap);
        double cy = Mth.m_14008_(v.f_82480_, -cap, cap);
        double cz = Mth.m_14008_(v.f_82481_, -cap, cap);
        return new Vec3(cx, cy, cz);
    }

    private boolean isLineObstructed(Vec3 from, Vec3 to) {
        HitResult hit = f_24974_.m_9236_().m_45547_(new ClipContext(
                from, to,
                ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE,
                f_24974_
        ));
        return hit.m_6662_() != HitResult.Type.MISS;
    }

    public boolean hasGivenUp() {
        return this.f_24981_ == Operation.WAIT;
    }
}
