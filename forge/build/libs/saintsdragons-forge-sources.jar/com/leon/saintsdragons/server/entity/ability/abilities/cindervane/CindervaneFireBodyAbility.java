package com.leon.saintsdragons.server.entity.ability.abilities.cindervane;

import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection;
import com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionDuration;
import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType.ACTIVE;
import static com.leon.saintsdragons.server.entity.ability.DragonAbilitySection.AbilitySectionType.STARTUP;

/**
 * Sustained fire aura ability for the Amphithere.
 */
public class CindervaneFireBodyAbility extends DragonAbility<Cindervane> {
    private static final DragonAbilitySection[] TRACK = new DragonAbilitySection[] {
            new AbilitySectionDuration(STARTUP, 1),
            new AbilitySectionDuration(ACTIVE, 1000)
    };

    private static final double AURA_RADIUS = 3.5D;
    private static final double AURA_VERTICAL = 2.5D;
    private static final float BASE_DAMAGE = 3.0F;
    private static final int FIRE_SECONDS = 4;
    private static final int ALLY_FIRE_RESIST_TICKS = 60;
    private static final int ALLY_DAMAGE_RESIST_TICKS = 40;

    private int activeTicks;

    public CindervaneFireBodyAbility(DragonAbilityType<Cindervane, CindervaneFireBodyAbility> type,
                                     Cindervane user) {
        super(type, user, TRACK, 40);
    }

    @Override
    public boolean isOverlayAbility() {
        return true;
    }

    @Override
    protected void beginSection(DragonAbilitySection section) {
        if (section == null) {
            return;
        }
        if (section.sectionType == STARTUP) {
            activeTicks = 0;
            getUser().setBreathingFire(true);
            Level level = getLevel();
            level.m_5594_(null, getUser().m_20183_(), SoundEvents.f_11874_, getUser().m_5720_(), 1.2F, 1.0F + getUser().m_217043_().m_188501_() * 0.2F);
        } else if (section.sectionType == ACTIVE) {
            getUser().setBreathingFire(true);
        }
    }

    @Override
    protected void endSection(DragonAbilitySection section) {
        if (section != null && section.sectionType == ACTIVE) {
            getUser().setBreathingFire(false);
        }
    }

    @Override
    public void interrupt() {
        getUser().setBreathingFire(false);
        super.interrupt();
    }

    @Override
    protected boolean canContinueUsing() {
        Cindervane dragon = getUser();
        if (!dragon.m_6084_() || dragon.m_213877_()) {
            return false;
        }
        if (dragon.m_20072_()) {
            return false;
        }
        return true;
    }

    @Override
    public void tickUsing() {
        Cindervane dragon = getUser();
        Level level = dragon.m_9236_();
        if (!level.f_46443_) {
            activeTicks++;
            applyFireAura((ServerLevel) level, dragon);
            if (activeTicks % 20 == 0) {
                level.m_5594_(null, dragon.m_20183_(), SoundEvents.f_11705_, dragon.m_5720_(), 0.6F, 0.9F + dragon.m_217043_().m_188501_() * 0.2F);
            }
        }

    }

    private void applyFireAura(ServerLevel level, Cindervane dragon) {
        Vec3 center = dragon.m_20182_().m_82520_(0.0D, dragon.m_20206_() * 0.5D, 0.0D);
        AABB area = dragon.m_20191_().m_82377_(AURA_RADIUS, AURA_VERTICAL, AURA_RADIUS);

        protectAllies(level, dragon, area);

        Set<LivingEntity> hitThisTick = new HashSet<>();
        for (LivingEntity target : level.m_6443_(LivingEntity.class, area,
                e -> e != dragon && e.m_6084_() && e.m_5789_() && !dragon.isAlly(e))) {
            if (!hitThisTick.add(target)) {
                continue;
            }
            float damage = BASE_DAMAGE;
            target.m_6469_(level.m_269111_().m_269254_(), damage);
            target.m_20254_(FIRE_SECONDS);

            Vec3 pushDir = target.m_20182_().m_82546_(center);
            if (pushDir.m_82556_() > 1.0E-4) {
                pushDir = pushDir.m_82541_().m_82490_(0.15D);
                target.m_5997_(pushDir.f_82479_, 0.05D, pushDir.f_82481_);
            }
        }

        var rng = dragon.m_217043_();
        for (int i = 0; i < 12; i++) {
            double angle = rng.m_188500_() * (Math.PI * 2.0);
            double radius = 0.5D + rng.m_188500_() * (AURA_RADIUS - 0.5D);
            double height = rng.m_188500_() * AURA_VERTICAL;
            Vec3 sample = center.m_82520_(Math.cos(angle) * radius, -AURA_VERTICAL * 0.5D + height, Math.sin(angle) * radius);
            spawnParticles(level, sample);
            maybeIgnite(level, sample, dragon);
        }
    }

    private void spawnParticles(ServerLevel level, Vec3 sample) {
        double spread = 0.6D;
        int flameCount = 12;
        int emberCount = 9;
        int smokeCount = 6;

        level.m_8767_(ParticleTypes.f_123744_, sample.f_82479_, sample.f_82480_, sample.f_82481_, flameCount,
                spread, spread * 0.6D, spread, 0.05D);
        level.m_8767_(ParticleTypes.f_175834_, sample.f_82479_, sample.f_82480_, sample.f_82481_, emberCount,
                spread * 0.4D, spread * 0.25D, spread * 0.4D, 0.02D);
        level.m_8767_(ParticleTypes.f_123756_, sample.f_82479_, sample.f_82480_, sample.f_82481_, 3,
                spread * 0.2D, spread * 0.2D, spread * 0.2D, 0.07D);
        level.m_8767_(ParticleTypes.f_123755_, sample.f_82479_, sample.f_82480_, sample.f_82481_, smokeCount,
                spread * 0.8D, spread * 0.4D, spread * 0.8D, 0.0D);
    }

    private void maybeIgnite(ServerLevel level, Vec3 sample, Cindervane dragon) {
        if (dragon.m_217043_().m_188501_() > 0.12F) {
            return;
        }
        BlockPos pos = BlockPos.m_274561_(sample.f_82479_, sample.f_82480_ - 0.5D, sample.f_82481_);
        if (!level.m_46749_(pos) || !level.m_46859_(pos)) {
            return;
        }
        BlockPos below = pos.m_7495_();
        BlockState belowState = level.m_8055_(below);
        if (belowState.m_60795_()) {
            return;
        }
        if (Blocks.f_50083_.m_49966_().m_60710_(level, pos) && belowState.m_60783_(level, below, Direction.UP)) {
            level.m_7731_(pos, Blocks.f_50083_.m_49966_(), 11);
        }
    }

    private void protectAllies(ServerLevel level, Cindervane dragon, AABB area) {
        AABB expanded = area.m_82377_(1.5D, 0.75D, 1.5D);
        for (LivingEntity ally : level.m_6443_(LivingEntity.class, expanded,
                entity -> entity != dragon && entity.m_6084_() && dragon.isAlly(entity))) {
            ally.m_7292_(new MobEffectInstance(MobEffects.f_19607_, ALLY_FIRE_RESIST_TICKS, 0, true, false, false));
            ally.m_7292_(new MobEffectInstance(MobEffects.f_19606_, ALLY_DAMAGE_RESIST_TICKS, 4, true, false, false));
            ally.m_7311_(0);
        }
    }
}
