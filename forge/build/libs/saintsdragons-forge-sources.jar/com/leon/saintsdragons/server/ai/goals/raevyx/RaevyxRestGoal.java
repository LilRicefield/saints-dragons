package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.server.entity.sleep.DragonRestManager;
import com.leon.saintsdragons.server.entity.sleep.DragonRestState;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Casual rest goal for Raevyx - makes wild dragons sleep with full animation cycle.
 * Animation sequence: down → sit → fall_asleep → sleep → wake_up → sit → up → idle
 * Now uses persistent DragonRestManager so state survives save/load.
 */
public class RaevyxRestGoal extends Goal {

    private final Raevyx wyvern;
    private int retryCooldown;

    public RaevyxRestGoal(Raevyx wyvern) {
        this.wyvern = wyvern;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (retryCooldown > 0) {
            retryCooldown--;
            return false;
        }

        // If already in a rest cycle (e.g., loaded from save), continue it
        if (wyvern.getRestManager().isResting()) {
            return true;
        }

        if (wyvern.m_21824_()) return false;
        if (wyvern.m_21827_()) return false;
        if (wyvern.isSleepLocked()) return false;
        if (wyvern.m_20072_() || wyvern.m_20077_()) return false;
        if (wyvern.isDying() || wyvern.m_20160_()) return false;
        if (wyvern.m_5448_() != null || wyvern.m_5912_()) return false;
        if (wyvern.m_29443_()) return false;

        // Random chance to rest (about 1% chance per second when idle)
        return wyvern.m_217043_().m_188501_() < 0.0005f;
    }

    @Override
    public boolean m_8045_() {
        // Continue until rest manager completes the cycle
        boolean safeToRest = !wyvern.m_20072_() && wyvern.m_5448_() == null && !wyvern.m_5912_();
        return wyvern.getRestManager().isResting() && safeToRest;
    }

    @Override
    public void m_8056_() {
        var restManager = wyvern.getRestManager();

        // If already resting (loaded from save), don't restart
        if (restManager.isResting()) {
            // Resume from saved state
            return;
        }

        // Start new rest cycle with random sleep duration (5-10 seconds)
        int sleepDuration = 100 + wyvern.m_217043_().m_188503_(101);
        restManager.startRest(sleepDuration);

        wyvern.m_21839_(true); // Triggers down animation
        wyvern.m_21573_().m_26573_();
    }

    @Override
    public void m_8037_() {
        if (wyvern.m_9236_().f_46443_) return;

        var restManager = wyvern.getRestManager();
        DragonRestState state = restManager.getCurrentState();

        // Stop navigation and stay still
        wyvern.m_21573_().m_26573_();
        wyvern.m_20334_(0, wyvern.m_20184_().f_82480_, 0);

        // Ensure dragon stays sitting ONLY during initial sit-down and sitting states
        if (state == DragonRestState.SITTING_DOWN || state == DragonRestState.SITTING) {
            if (!wyvern.m_21827_()) {
                wyvern.m_21839_(true);
            }
        }

        // State machine for animation sequence
        switch (state) {
            case SITTING_DOWN:
                // Wait for down → sit animation (1.5s = 30 ticks, +5 buffer)
                if (restManager.getStateTimer() > 35 && !wyvern.isInSitTransition()) {
                    restManager.advanceState();
                }
                break;

            case SITTING:
                // Pause in sit idle before falling asleep (1 second)
                if (restManager.getStateTimer() > 20) {
                    restManager.advanceState();
                    wyvern.startSleepEnter(); // Triggers fall_asleep animation
                }
                break;

            case FALLING_ASLEEP:
                // Wait for fall_asleep animation (2.5s = 50 ticks, +5 buffer)
                if ((wyvern.m_5803_() && !wyvern.isSleepTransitioning()) || restManager.getStateTimer() > 55) {
                    restManager.advanceState();
                }
                break;

            case SLEEPING:
                // Sleep for the duration, then wake up
                restManager.incrementRestingTicks();
                if (restManager.getRestingTicks() >= restManager.getRestDuration()) {
                    restManager.advanceState();
                    wyvern.startSleepExit(); // Triggers wake_up animation
                    wyvern.m_21839_(true);
                }
                break;

            case WAKING_UP:
                // Wait for wake_up animation (2.625s = 53 ticks, +5 buffer)
                if (restManager.getStateTimer() > 58) {
                    restManager.advanceState();
                    wyvern.m_21839_(true);
                }
                break;

            case SITTING_AFTER:
                // Pause in sit after waking (stretching moment, 1 second)
                if (restManager.getStateTimer() > 20) {
                    restManager.advanceState();
                    wyvern.m_21839_(false); // Trigger stand up animation
                }
                break;

            case STANDING_UP:
                // Wait for up animation (1.0s = 20 ticks)
                if (restManager.getStateTimer() > 20) {
                    restManager.advanceState(); // Returns to IDLE
                }
                break;

            default:
                break;
        }

        // Tick the rest manager timer
        restManager.tick();
    }

    @Override
    public void m_8041_() {
        var restManager = wyvern.getRestManager();

        // Emergency cleanup - force stand up if interrupted mid-cycle
        if (restManager.isResting() && restManager.getCurrentState() != DragonRestState.STANDING_UP) {
            if (wyvern.m_5803_() || wyvern.isSleepTransitioning()) {
                wyvern.startSleepExit();
            }
            wyvern.m_21839_(false);
            restManager.stopRest(); // Clear rest state
        }

        // Set cooldown before next rest (200-400 ticks = 10-20 seconds)
        retryCooldown = 200 + wyvern.m_217043_().m_188503_(201);
    }

    @Override
    public boolean m_6767_() {
        return true; // Can be interrupted by threats
    }
}
