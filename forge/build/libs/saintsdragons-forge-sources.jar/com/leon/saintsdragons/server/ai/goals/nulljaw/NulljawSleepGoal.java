package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

/**
 * Sleep goal for Nulljaw. Tamed dragons curl up when their owner sleeps.
 * Wild dragons use {@link NulljawRestGoal} instead.
 */
public class NulljawSleepGoal extends Goal {

    private final Nulljaw drake;
    private int retryCooldown;

    public NulljawSleepGoal(Nulljaw drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (retryCooldown > 0) retryCooldown--;
        if (retryCooldown > 0) return false;
        if (drake.isSleepLocked()) return false;
        if (!drake.canSleepNow() || drake.isSleepSuppressed()) return false;
        if (drake.m_20072_() || drake.m_20077_()) return false;
        if (drake.isDying() || drake.m_20160_()) return false;
        if (drake.m_5448_() != null || drake.m_5912_()) return false;
        if (drake.m_9236_().m_46470_()) return false;

        return drake.m_21824_() && ownerAsleep();
    }

    @Override
    public boolean m_8045_() {
        return drake.isSleepLocked();
    }

    @Override
    public void m_8056_() {
        drake.startSleepEnter();
    }

    @Override
    public void m_8037_() {
        if (drake.m_9236_().f_46443_) return;
        if (drake.isSleepLocked() && !shouldRemainAsleep()) {
            if (!drake.isSleepTransitioning()) {
                drake.startSleepExit();
            }
        }
    }

    @Override
    public void m_8041_() {
        if (!drake.isSleepLocked()) {
            retryCooldown = 100;
        }
    }

    @Override
    public boolean m_6767_() {
        return false;
    }

    private boolean ownerAsleep() {
        LivingEntity owner = drake.m_269323_();
        if (!(owner instanceof Player player)) {
            return false;
        }
        if (!player.m_5803_() || !player.m_6084_()) {
            return false;
        }
        return player.m_9236_() == drake.m_9236_();
    }

    private boolean shouldRemainAsleep() {
        return ownerAsleep();
    }
}
