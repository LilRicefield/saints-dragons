package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import java.util.List;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.phys.AABB;
import net.minecraft.advancements.Advancement;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;

/**
 * Custom goal for Lightning Dragons that handles both eating fish AND taming.
 * When an untamed wyvern eats fish from the ground, it has a chance to become tamed.
 */
public class RaevyxTemptGoal extends Goal {
    private final Raevyx dragon;
    private final double speedModifier;
    private final Ingredient items;
    private final boolean canScare;
    private int consumptionCooldown = 0;
    private ItemEntity targetFish = null;

    public RaevyxTemptGoal(Raevyx dragon, double speedModifier, Ingredient items, boolean canScare) {
        this.dragon = dragon;
        this.speedModifier = speedModifier;
        this.items = items;
        this.canScare = canScare;
    }

    @Override
    public boolean m_8036_() {
        // Don't use this goal if wyvern is sleeping, dying, or being ridden
        if (dragon.m_5803_() || dragon.isDying() || dragon.m_20160_()) {
            return false;
        }
        
        // Check for nearby fish items on the ground
        return findNearestFish() != null;
    }
    
    /**
     * Find the nearest fish item that the wyvern can eat
     */
    private ItemEntity findNearestFish() {
        var broadphase = dragon.m_20191_().m_82377_(12.0, 12.0, 12.0); // 12 block radius
        var nearbyItems = dragon.m_9236_().m_6443_(
            ItemEntity.class,
            broadphase,
            item -> dragon.m_6898_(item.m_32055_())
        );
        
        if (nearbyItems.isEmpty()) {
            return null;
        }
        
        return nearbyItems.stream()
            .min((i1, i2) -> Double.compare(
                dragon.m_20280_(i1),
                dragon.m_20280_(i2)
            ))
            .orElse(null);
    }

    @Override
    public void m_8056_() {
        targetFish = findNearestFish();
        if (targetFish != null) {
            dragon.m_21573_().m_5624_(targetFish, speedModifier);
        }
    }
    
    @Override
    public void m_8041_() {
        targetFish = null;
        dragon.m_21573_().m_26573_();
    }
    
    @Override
    public boolean m_8045_() {
        // Continue if target fish still exists and wyvern hasn't reached it
        if (targetFish == null || !targetFish.m_6084_()) {
            return false;
        }
        
        // Stop if wyvern is too far from target
        if (dragon.m_20280_(targetFish) > 144.0) { // 12 blocks squared
            return false;
        }
        
        return true;
    }

    @Override
    public void m_8037_() {
        // Decrement cooldown
        if (consumptionCooldown > 0) {
            consumptionCooldown--;
        }
        
        // Check if wyvern is close enough to consume the target fish
        if (!dragon.m_9236_().f_46443_ && consumptionCooldown <= 0 && targetFish != null) {
            double distance = dragon.m_20280_(targetFish);
            
            // If wyvern is very close to target fish, consume it
            if (distance <= 2.25) { // 1.5 blocks squared
                handleFishConsumption(targetFish);
                consumptionCooldown = 20; // 1 second cooldown
                targetFish = null; // Clear target after consumption
            }
        }
    }

    /**
     * Handle fish consumption and potential taming when wyvern reaches fish items
     */
    private void handleFishConsumption(ItemEntity fishItem) {
        if (fishItem == null || !fishItem.m_6084_()) {
            return;
        }
        
        // Find the nearest player who might be "feeding" the wyvern
        Player feedingPlayer = findNearestPlayer();
        
        // Consume the fish item
        fishItem.m_146870_();
            
            // Trigger eat animation
            dragon.triggerAnim("action", "eat");
            
            // Play eating sound
            dragon.m_5496_(
                com.leon.saintsdragons.common.registry.ModSounds.RAEVYX_CHUFF.get(),
                1.0f,
                1.0f + dragon.m_217043_().m_188501_() * 0.3f
            );
            
            // Handle different behavior for tamed vs untamed dragons
            if (dragon.m_21824_()) {
                // Tamed wyvern: heal when eating fish
                float healAmount = 10.0f; // Heal 5 hearts per fish
                float oldHealth = dragon.m_21223_();
                float newHealth = Math.min(oldHealth + healAmount, dragon.m_21233_());
                dragon.m_21153_(newHealth);
                
                // Show healing particles (green hearts)
                dragon.m_9236_().m_7605_(dragon, (byte) 7);
                
                // Send appropriate feeding message to nearest player
                sendFeedingMessage(feedingPlayer, newHealth);
            } else {
                // Untamed wyvern: taming chance (same 1 in 10 chance as right-click taming)
                if (feedingPlayer != null && dragon.m_217043_().m_188503_(10) == 0) {
                    // Successful taming!
                    dragon.m_21828_(feedingPlayer);
                    dragon.m_21839_(true);
                    dragon.setCommandManual(1); // Set command to Sit (1)
                    dragon.m_9236_().m_7605_(dragon, (byte) 7); // Success particles
                    
                    // Trigger taming advancement
                    if (feedingPlayer instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
                        var advancement = serverPlayer.f_8924_.m_129889_()
                            .m_136041_(com.leon.saintsdragons.SaintsDragons.rl("tame_lightning_dragon"));
                        if (advancement != null) {
                            serverPlayer.m_8960_().m_135988_(advancement, "tame_lightning_dragon");
                        }
                    }
                } else {
                    // Failed taming - show smoke particles
                    dragon.m_9236_().m_7605_(dragon, (byte) 6);
                }
            }
        }

    /**
     * Find the nearest player who might be "feeding" the wyvern by dropping fish
     */
    private Player findNearestPlayer() {
        var nearbyPlayers = dragon.m_9236_().m_6443_(
            Player.class,
            dragon.m_20191_().m_82400_(10.0),
            player -> player.m_6084_() && !player.m_5833_()
        );

        if (nearbyPlayers.isEmpty()) {
            return null;
        }

        // Return the closest player
        return nearbyPlayers.stream()
            .min((p1, p2) -> Double.compare(
                dragon.m_20280_(p1),
                dragon.m_20280_(p2)
            ))
            .orElse(null);
    }
    
    /**
     * Send appropriate feeding message based on healing result.
     * Same logic as LightningDragonInteractionHandler.sendFeedingMessage()
     */
    private void sendFeedingMessage(Player player, float newHealth) {
        if (player instanceof ServerPlayer serverPlayer) {
            String messageKey = (newHealth >= dragon.m_21233_()) 
                ? "entity.saintsdragons.raevyx.fed"
                : "entity.saintsdragons.raevyx.fed_partial";
                
            serverPlayer.m_5661_(
                Component.m_237110_(messageKey, dragon.m_7755_()),
                true
            );
        }
    }
}
