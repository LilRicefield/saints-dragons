package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

public class NulljawFindWaterGoal extends Goal {

    private final Nulljaw drake;
    private BlockPos targetPos;
    private final int executionChance = 30;

    public NulljawFindWaterGoal(Nulljaw drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        // Only seek water when on ground and not already in water
        if (this.drake.m_20096_() && !this.drake.m_9236_().m_6425_(this.drake.m_20183_()).m_205070_(FluidTags.f_13131_)) {
            // Use the AquaticDragon interface method to determine if we should enter water
            if (this.drake.shouldEnterWater() && (this.drake.m_5448_() != null || this.drake.m_217043_().m_188503_(executionChance) == 0)) {
                targetPos = generateTarget();
                return targetPos != null;
            }
        }
        return false;
    }

    @Override
    public void m_8056_() {
        if (targetPos != null) {
            drake.m_21573_().m_26519_(targetPos.m_123341_(), targetPos.m_123342_(), targetPos.m_123343_(), 1.0D);
        }
    }

    @Override
    public void m_8037_() {
        if (targetPos != null) {
            drake.m_21573_().m_26519_(targetPos.m_123341_(), targetPos.m_123342_(), targetPos.m_123343_(), 1.0D);
        }
    }

    @Override
    public boolean m_8045_() {
        // Stop if we no longer should enter water
        if (!this.drake.shouldEnterWater()) {
            this.drake.m_21573_().m_26573_();
            return false;
        }
        return !this.drake.m_21573_().m_26571_() && targetPos != null && !this.drake.m_9236_().m_6425_(this.drake.m_20183_()).m_205070_(FluidTags.f_13131_);
    }

    public BlockPos generateTarget() {
        BlockPos blockpos = null;
        final RandomSource random = this.drake.m_217043_();
        final int range = this.drake.getWaterSearchRange();
        for(int i = 0; i < 15; i++) {
            BlockPos blockPos = this.drake.m_20183_().m_7918_(random.m_188503_(range) - range/2, 3, random.m_188503_(range) - range/2);
            while (this.drake.m_9236_().m_46859_(blockPos) && blockPos.m_123342_() > 1) {
                blockPos = blockPos.m_7495_();
            }

            if (this.drake.m_9236_().m_6425_(blockPos).m_205070_(FluidTags.f_13131_)) {
                blockpos = blockPos;
            }
        }
        return blockpos;
    }
}

