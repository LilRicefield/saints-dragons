package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.common.registry.raevyx.RaevyxAbilities;
import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.EnumSet;

/**
 * All-in-one combat goal for Raevyx - handles movement, attack selection, and execution.
 * No state machine, no windup phases - just instant attacks when in range.
 */
public class RaevyxCombatGoal extends Goal {
    private final Raevyx wyvern;
    private final double biteRange = 3.0;
    private final double goreRange = 4.5;
    private final double chaseSpeed = 1.40D;
    private int attackCooldown = 0;
    private int pathRecalcCooldown = 0;
    private double lastTargetX;
    private double lastTargetY;
    private double lastTargetZ;

    public RaevyxCombatGoal(Raevyx wyvern) {
        this.wyvern = wyvern;
        this.m_7021_(EnumSet.of(Flag.LOOK, Flag.MOVE));
    }

    @Override
    public boolean m_8036_() {
        LivingEntity target = wyvern.m_5448_();

        if (target == null || !target.m_6084_()) {
            return false;
        }

        if (wyvern.m_20160_() || wyvern.m_21827_()) {
            return false;
        }

        if (wyvern.m_20280_(target) > getMaxAggroDistanceSqr()) {
            return false;
        }

        return true;
    }

    @Override
    public boolean m_8045_() {
        LivingEntity target = wyvern.m_5448_();

        if (target == null || !target.m_6084_()) {
            return false;
        }

        if (wyvern.m_20160_() || wyvern.m_21827_()) {
            return false;
        }

        if (wyvern.m_20280_(target) > getMaxAggroDistanceSqr()) {
            return false;
        }

        return true;
    }

    @Override
    public boolean m_183429_() {
        return true;
    }

    @Override
    public void m_8041_() {
        wyvern.m_21573_().m_26573_();
        wyvern.setRunning(false);
        wyvern.m_21561_(false);
        pathRecalcCooldown = 0;
    }

    @Override
    public void m_8056_() {
        wyvern.setRunning(true);
        wyvern.m_21561_(true);

        LivingEntity target = wyvern.m_5448_();
        if (target != null) {
            wyvern.m_21563_().m_24960_(target, 30.0F, 30.0F);
            wyvern.m_21573_().m_5624_(target, chaseSpeed);
            rememberTargetPosition(target);

            // Try attacking immediately if in range
            tryAttack(target);
        }
    }

    @Override
    public void m_8037_() {
        if (attackCooldown > 0) {
            attackCooldown--;
        }

        LivingEntity target = wyvern.m_5448_();
        if (target != null) {
            wyvern.m_21563_().m_24960_(target, 30.0F, 30.0F);

            double gap = getGapToTarget(target);
            boolean hasLineOfSight = wyvern.m_21574_().m_148306_(target);

            // If not in attack range or no LOS, chase
            if (gap > goreRange || !hasLineOfSight) {
                if (!isCurrentlyAttacking()) {
                    updateChasePath(target);
                }
            } else {
                // In range - stop moving and attack
                wyvern.m_21573_().m_26573_();
                pathRecalcCooldown = 0;
                tryAttack(target);
            }
        }
    }

    /**
     * Check if wyvern is currently executing an attack ability
     */
    private boolean isCurrentlyAttacking() {
        return wyvern.isAbilityActive(RaevyxAbilities.RAEVYX_BITE)
            || wyvern.isAbilityActive(RaevyxAbilities.RAEVYX_HORN_GORE);
    }

    /**
     * Try to attack target based on distance. Instant execution, no windup.
     */
    private void tryAttack(LivingEntity target) {
        if (attackCooldown > 0 || isCurrentlyAttacking()) {
            return;
        }

        if (!wyvern.m_21574_().m_148306_(target)) {
            return;
        }

        double gap = getGapToTarget(target);

        // Choose attack based on distance - fire immediately
        if (gap <= biteRange) {
            // Close range - bite attack
            wyvern.combatManager.tryUseAbility(RaevyxAbilities.RAEVYX_BITE);
            attackCooldown = 20;
        } else if (gap <= goreRange) {
            // Medium range - horn gore
            wyvern.combatManager.tryUseAbility(RaevyxAbilities.RAEVYX_HORN_GORE);
            attackCooldown = 20;
        }
    }

    /**
     * Get the gap between entity edges (not centers)
     */
    private double getGapToTarget(LivingEntity target) {
        double centerDistance = this.wyvern.m_20270_(target);
        double combinedRadii = (this.wyvern.m_20205_() + target.m_20205_()) * 0.5;
        return Math.max(0.0, centerDistance - combinedRadii);
    }

    private double getMaxAggroDistanceSqr() {
        double followRange = this.wyvern.m_21133_(Attributes.f_22277_);
        if (followRange <= 0.0D) {
            followRange = 32.0D;
        }
        return followRange * followRange;
    }

    private void updateChasePath(LivingEntity target) {
        if (--pathRecalcCooldown <= 0 || targetMovedSignificantly(target)) {
            rememberTargetPosition(target);
            double distance = wyvern.m_20270_(target);
            pathRecalcCooldown = Mth.m_14045_((int) (distance * 0.6D), 5, 20);
            wyvern.m_21573_().m_5624_(target, chaseSpeed);
        }
    }

    private void rememberTargetPosition(LivingEntity target) {
        this.lastTargetX = target.m_20185_();
        this.lastTargetY = target.m_20186_();
        this.lastTargetZ = target.m_20189_();
    }

    private boolean targetMovedSignificantly(LivingEntity target) {
        double dx = target.m_20185_() - this.lastTargetX;
        double dy = target.m_20186_() - this.lastTargetY;
        double dz = target.m_20189_() - this.lastTargetZ;
        return dx * dx + dy * dy + dz * dz > 4.0D;
    }
}
