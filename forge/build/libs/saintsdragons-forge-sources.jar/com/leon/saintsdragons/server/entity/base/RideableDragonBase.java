package com.leon.saintsdragons.server.entity.base;

import com.leon.saintsdragons.server.entity.interfaces.RideableDragon;
import com.leon.saintsdragons.common.network.DragonRiderAction;
import com.leon.saintsdragons.common.network.MessageDragonRideInput;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Base implementation for rideable dragons.
 * Provides common functionality for animation state management and rider input handling.
 * Usage: Extend this class in your dragon entity to get the standard rideable dragon behavior.
 */
public abstract class RideableDragonBase extends DragonEntity implements RideableDragon, FlyingAnimal {

    /** Entity data accessor for melee mode (0=primary melee, 1=secondary melee) */
    private static final EntityDataAccessor<Integer> DATA_MELEE_MODE =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(RideableDragonBase.class, net.minecraft.network.syncher.EntityDataSerializers.f_135028_);

    protected RideableDragonBase(EntityType<? extends TamableAnimal> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    protected void m_8097_() {
        super.m_8097_();
        this.f_19804_.m_135372_(DATA_MELEE_MODE, 0); // Default to primary melee (mode 0)
        defineRideableDragonData();
    }

    // This method should be overridden by subclasses to define their own entity data keys
    protected abstract void defineRideableDragonData();


    public boolean canBeControlledBy(Player player) {
        if (player == null) {
            return false;
        }
        if (this.m_21824_()) {
            return this.m_21830_(player);
        }
        return player.m_7500_() || player.m_5833_();
    }

    public void handleRiderNetworkInput(ServerPlayer player, MessageDragonRideInput msg) {
        boolean locked = isRiderInputLocked(player);
        applyRiderVerticalInput(player, msg.goingUp(), msg.goingDown(), locked);
        applyRiderMovementInput(player, msg.forward(), msg.strafe(), msg.yaw(), locked);
        handleRiderAction(player, msg.action(), msg.abilityName(), locked);
    }

    protected boolean isRiderInputLocked(Player player) {
        return false;
    }

    protected void applyRiderVerticalInput(Player player, boolean goingUp, boolean goingDown, boolean locked) {
        if (locked) {
            setGoingUp(false);
            setGoingDown(false);
            return;
        }
        setGoingUp(goingUp);
        setGoingDown(goingDown);
    }

    protected float applyInputDeadzone(float value) {
        return Math.abs(value) > 0.02f ? value : 0f;
    }

    protected void applyRiderMovementInput(Player player, float forward, float strafe, float yaw, boolean locked) {
        float clampedForward = locked ? 0f : applyInputDeadzone(forward);
        float clampedStrafe = locked ? 0f : applyInputDeadzone(strafe);
        setLastRiderForward(clampedForward);
        setLastRiderStrafe(clampedStrafe);
    }

    protected void handleRiderAction(ServerPlayer player, DragonRiderAction action, String abilityName, boolean locked) {
        if (action == null) {
            return;
        }
        switch (action) {
            case TAKEOFF_REQUEST -> { if (!locked) onRiderTakeoffRequest(player); }
            case ACCELERATE -> { if (!locked) onRiderAccelerationStart(player); }
            case STOP_ACCELERATE -> onRiderAccelerationStop(player);
            case ABILITY_USE -> { if (!locked) onRiderAbilityUse(player, abilityName); }
            case ABILITY_STOP -> { if (!locked) onRiderAbilityStop(player, abilityName); }
            case TOGGLE_MELEE -> { if (!locked) onRiderToggleMelee(player); }
            default -> { }
        }
    }

    protected void onRiderToggleMelee(Player player) {
        // Check if this dragon has a secondary melee attack
        if (!hasSecondaryMelee()) {
            if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
                serverPlayer.m_5661_(
                    net.minecraft.network.chat.Component.m_237115_("saintsdragons.message.no_secondary_melee"),
                    true // Action bar
                );
            }
            return;
        }

        toggleMeleeMode();
    }

    /**
     * Override this to specify if the dragon has a secondary melee attack.
     * Defaults to true - dragons without secondary melee should override and return false.
     */
    public boolean hasSecondaryMelee() {
        return true;
    }

    protected void onRiderTakeoffRequest(Player player) {
    }

    protected void onRiderAccelerationStart(Player player) {
        setAccelerating(true);
    }

    protected void onRiderAccelerationStop(Player player) {
        setAccelerating(false);
    }

    protected void onRiderAbilityUse(Player player, String abilityName) {
    }

    protected void onRiderAbilityStop(Player player, String abilityName) {
    }

    protected float getRiderLockYawBlend() {
        return 0.18F;
    }

    protected float getRiderLockPitchBlend() {
        return 0.18F;
    }

    protected float getRiderLockPitchMin() {
        return -45.0F;
    }

    protected float getRiderLockPitchMax() {
        return 45.0F;
    }


    @Nullable
    public RiderAbilityBinding getPrimaryRiderAbility() {
        return null;
    }

    @Nullable
    public RiderAbilityBinding getSecondaryRiderAbility() {
        return null;
    }

    @Nullable
    public RiderAbilityBinding getTertiaryRiderAbility() {
        return null;
    }

    @Nullable
    public RiderAbilityBinding getAttackRiderAbility() {
        return null;
    }

    /**
     * Get the current melee mode (0=primary, 1=secondary)
     */
    public int getMeleeMode() {
        return this.f_19804_.m_135370_(DATA_MELEE_MODE);
    }

    /**
     * Set the melee mode (0=primary, 1=secondary)
     */
    public void setMeleeMode(int mode) {
        this.f_19804_.m_135381_(DATA_MELEE_MODE, Mth.m_14045_(mode, 0, 1));
    }

    /**
     * Toggle between primary and secondary melee mode
     */
    public void toggleMeleeMode() {
        setMeleeMode(getMeleeMode() == 0 ? 1 : 0);
    }

    @Override
    public void m_7380_(CompoundTag tag) {
        super.m_7380_(tag);
        tag.m_128405_("MeleeMode", getMeleeMode());
    }

    @Override
    public void m_7378_(CompoundTag tag) {
        super.m_7378_(tag);
        if (tag.m_128441_("MeleeMode")) {
            setMeleeMode(tag.m_128451_("MeleeMode"));
        }
    }

    public byte buildClientControlState(boolean ascendDown, boolean descendDown, boolean attackDown, boolean primaryDown, boolean secondaryDown, boolean sneakDown) {
        return (byte) -1;
    }

    public record RiderAbilityBinding(String abilityId, Activation activation) {
        public enum Activation {
            PRESS,
            HOLD
        }
    }

    // ===== RIDER INPUT IMPLEMENTATION =====

    // Abstract methods for entity-specific data accessors
    protected abstract EntityDataAccessor<Float> getRiderForwardAccessor();
    protected abstract EntityDataAccessor<Float> getRiderStrafeAccessor();
    protected abstract EntityDataAccessor<Integer> getGroundMoveStateAccessor();
    protected abstract EntityDataAccessor<Integer> getFlightModeAccessor();
    protected abstract EntityDataAccessor<Boolean> getGoingUpAccessor();
    protected abstract EntityDataAccessor<Boolean> getGoingDownAccessor();
    protected abstract EntityDataAccessor<Boolean> getAcceleratingAccessor();

    @Override
    public void setLastRiderForward(float forward) {
        this.f_19804_.m_135381_(getRiderForwardAccessor(), forward);
    }

    @Override
    public void setLastRiderStrafe(float strafe) {
        this.f_19804_.m_135381_(getRiderStrafeAccessor(), strafe);
    }

    // ===== MOVEMENT STATE IMPLEMENTATION =====

    @Override
    public int getGroundMoveState() {
        return this.f_19804_.m_135370_(getGroundMoveStateAccessor());
    }

    @Override
    public int getSyncedFlightMode() {
        return this.f_19804_.m_135370_(getFlightModeAccessor());
    }

    @Override
    public int getEffectiveGroundState() {
        Integer state = this.getAnimData(com.leon.saintsdragons.common.network.DragonAnimTickets.GROUND_STATE);
        if (state != null) {
            return state;
        }
        return this.f_19804_.m_135370_(getGroundMoveStateAccessor());
    }

    // ===== RIDER CONTROL IMPLEMENTATION =====

    @Override
    public boolean isGoingUp() {
        return this.f_19804_.m_135370_(getGoingUpAccessor());
    }

    @Override
    public void setGoingUp(boolean goingUp) {
        this.f_19804_.m_135381_(getGoingUpAccessor(), goingUp);
    }

    @Override
    public boolean isGoingDown() {
        return this.f_19804_.m_135370_(getGoingDownAccessor());
    }

    @Override
    public void setGoingDown(boolean goingDown) {
        this.f_19804_.m_135381_(getGoingDownAccessor(), goingDown);
    }

    @Override
    public boolean isAccelerating() {
        return this.f_19804_.m_135370_(getAcceleratingAccessor());
    }

    @Override
    public void setAccelerating(boolean accelerating) {
        this.f_19804_.m_135381_(getAcceleratingAccessor(), accelerating);
    }

    protected void copyRiderLook(Player player) {
        if (player == null) {
            return;
        }

        float currentYaw = this.m_146908_();
        float targetYaw = player.m_146908_();
        float yawDelta = Mth.m_14177_(targetYaw - currentYaw);
        float yawBlend = getRiderLockYawBlend();
        float blendedYaw = currentYaw + yawDelta * yawBlend;

        this.m_146922_(blendedYaw);
        this.f_20884_ = this.f_20883_;
        this.f_20883_ = blendedYaw;
        this.f_20886_ = this.f_20885_;
        this.m_5616_(blendedYaw);

        float targetPitch = Mth.m_14036_(player.m_146909_(), getRiderLockPitchMin(), getRiderLockPitchMax());
        float blendedPitch = Mth.m_14179_(getRiderLockPitchBlend(), this.m_146909_(), targetPitch);
        this.f_19860_ = this.m_146909_();
        this.m_146926_(blendedPitch);
    }

    // ===== ANIMATION SYNC IMPLEMENTATION =====

    @Override
    public void syncAnimState(int groundState, int flightMode) {
        if (m_9236_().f_46443_) {
            return;
        }
        this.setAnimData(com.leon.saintsdragons.common.network.DragonAnimTickets.GROUND_STATE, groundState);
        this.setAnimData(com.leon.saintsdragons.common.network.DragonAnimTickets.FLIGHT_MODE, flightMode);
    }

    @Override
    public void initializeAnimationState() {
        if (!m_9236_().f_46443_) {
            // Set initial state based on current entity state
            int initialGroundState = 0; // Default to idle
            int initialFlightMode = -1; // Default to ground state

            if (!m_29443_() && !isTakeoff() && !isLanding() && !isHovering()) {
                // Check if entity is actually moving
                double velSqr = this.m_20184_().m_165925_();
                initialGroundState = RideableDragonData.getGroundStateFromVelocity(velSqr);
            } else if (m_29443_()) {
                initialFlightMode = getFlightMode();
            }

            // Set the initial state without triggering sync (to avoid thrashing)
            this.f_19804_.m_135381_(getGroundMoveStateAccessor(), initialGroundState);
            this.f_19804_.m_135381_(getFlightModeAccessor(), initialFlightMode);
        }
    }

    @Override
    public void resetAnimationState() {
        if (!m_9236_().f_46443_) {
            // Recalculate current state based on actual entity state
            int currentGroundState = 0; // Default to idle

            if (!m_29443_() && !isTakeoff() && !isLanding() && !isHovering()) {
                // Recalculate ground movement state based on current velocity
                double velSqr = this.m_20184_().m_165925_();
                currentGroundState = RideableDragonData.getGroundStateFromVelocity(velSqr);
            }

            int currentFlightMode = getFlightMode();

            // Update entity data to match calculated state
            this.f_19804_.m_135381_(getGroundMoveStateAccessor(), currentGroundState);
            this.f_19804_.m_135381_(getFlightModeAccessor(), currentFlightMode);

            // Force sync current state
            this.syncAnimState(currentGroundState, currentFlightMode);
        }
    }

    // ===== REQUIRED OVERRIDES IMPLEMENTATION =====

    @Override
    public @NotNull Vec3 m_274312_(@NotNull Player player, @NotNull Vec3 deltaIn) {
        Vec3 input = super.m_274312_(player, deltaIn);

        // Capture rider inputs for animation state (like Lightning Dragon)
        if (!m_9236_().f_46443_ && !m_29443_()) {
            float fwd = (float) Mth.m_14008_(input.f_82481_, -1.0, 1.0);
            float str = (float) Mth.m_14008_(input.f_82479_, -1.0, 1.0);
            this.setLastRiderForward(RideableDragonData.applyInputThreshold(fwd));
            this.setLastRiderStrafe(RideableDragonData.applyInputThreshold(str));
        }

        return input;
    }

    @Override
    public void m_20351_(@NotNull Entity passenger) {
        super.m_20351_(passenger);
        // Reset rider-driven movement states immediately on dismount
        if (!this.m_9236_().f_46443_) {
            this.setAccelerating(false);
            this.setRunning(false);
            this.setLastRiderForward(0f);
            this.setLastRiderStrafe(0f);
            this.f_19804_.m_135381_(getGroundMoveStateAccessor(), 0);
            // Nudge observers so animation stops if we dismounted mid-run/walk
            this.syncAnimState(0, getSyncedFlightMode());
        }
    }

    // ===== ANIMATION STATE TICKING IMPLEMENTATION =====

    @Override
    public void tickAnimationStates() {
        // Update ground movement state with more sophisticated detection
        int moveState = 0; // idle

        if (!m_29443_() && !isTakeoff() && !isLanding() && !isHovering()) {
            // If being ridden, prefer rider inputs for robust state selection
            if (m_6688_() != null) {
                float fwd = this.f_19804_.m_135370_(getRiderForwardAccessor());
                float str = this.f_19804_.m_135370_(getRiderStrafeAccessor());

                if (RideableDragonData.isSignificantRiderInput(fwd, str)) {
                    moveState = this.isAccelerating() ? 2 : 1;
                } else {
                    // Fallback while ridden: use actual velocity so observers still see walk/run
                    double speedSqr = m_20184_().m_165925_();
                    moveState = RideableDragonData.getRiddenGroundStateFromVelocity(speedSqr);
                }
            } else {
                // Use horizontal velocity for AI classification
                double velSqr = this.m_20184_().m_165925_();
                moveState = RideableDragonData.getGroundStateFromVelocity(velSqr);
            }
        }

        // Update flight mode
        int flightMode = getFlightMode();

        // Update entity data and sync to clients
        boolean groundStateChanged = this.f_19804_.m_135370_(getGroundMoveStateAccessor()) != moveState;
        boolean flightModeChanged = this.f_19804_.m_135370_(getFlightModeAccessor()) != flightMode;

        if (groundStateChanged) {
            this.f_19804_.m_135381_(getGroundMoveStateAccessor(), moveState);
        }

        if (flightModeChanged) {
            this.f_19804_.m_135381_(getFlightModeAccessor(), flightMode);
        }

        // Send animation state sync to clients when states change
        if (groundStateChanged || flightModeChanged) {
            this.syncAnimState(moveState, flightMode);
        }

        // Decay rider inputs slightly each tick to avoid sticking when packets drop
        if (this.f_19804_.m_135370_(getRiderForwardAccessor()) != 0f ||
                this.f_19804_.m_135370_(getRiderStrafeAccessor()) != 0f) {

            float nf = RideableDragonData.decayRiderInput(this.f_19804_.m_135370_(getRiderForwardAccessor()));
            float ns = RideableDragonData.decayRiderInput(this.f_19804_.m_135370_(getRiderStrafeAccessor()));

            this.f_19804_.m_135381_(getRiderForwardAccessor(), nf);
            this.f_19804_.m_135381_(getRiderStrafeAccessor(), ns);
        }

        // Stop running if not moving
        if (this.isRunning() && this.m_20184_().m_165925_() < 0.01) {
            this.setRunning(false);
        }
    }

    // ===== ABSTRACT METHODS TO IMPLEMENT =====

    /**
     * Get the current flight mode. Must be implemented by subclasses.
     *
     * @return flight mode (-1=ground, 0=glide, 1=forward, 2=hover, 3=takeoff)
     */
    protected abstract int getFlightMode();

    /**
     * Check if the dragon is flying. Final bridge delegates to subclass hook to avoid obfuscation mismatches.
     */
    @Override
    public final boolean m_29443_() {
        return isDragonFlying();
    }

    /**
     * Subclass hook to report actual flying state.
     */
    protected abstract boolean isDragonFlying();

    /**
     * Check if the dragon is taking off. Must be implemented by subclasses.
     */
    public abstract boolean isTakeoff();

    /**
     * Check if the dragon is landing. Must be implemented by subclasses.
     */
    public abstract boolean isLanding();

    /**
     * Check if the dragon is hovering. Must be implemented by subclasses.
     */
    public abstract boolean isHovering();

    /**
     * Check if the dragon is running. Must be implemented by subclasses.
     */
    public abstract boolean isRunning();

    /**
     * Set if the dragon is running. Must be implemented by subclasses.
     */
    public abstract void setRunning(boolean running);

    /**
     * Persist the common rideable dragon state to NBT so every dragon saves the same baseline data.
     */
    protected void saveRideableData(CompoundTag tag) {
        tag.m_128379_("Flying", m_29443_());
        tag.m_128379_("Takeoff", isTakeoff());
        tag.m_128379_("Hovering", isHovering());
        tag.m_128379_("Landing", isLanding());
        tag.m_128379_("Running", isRunning());
        tag.m_128379_("Accelerating", this.f_19804_.m_135370_(getAcceleratingAccessor()));
        tag.m_128379_("GoingUp", isGoingUp());
        tag.m_128379_("GoingDown", isGoingDown());
        tag.m_128405_("GroundMoveState", this.f_19804_.m_135370_(getGroundMoveStateAccessor()));
        tag.m_128405_("FlightMode", this.f_19804_.m_135370_(getFlightModeAccessor()));
        tag.m_128350_("RiderForward", this.f_19804_.m_135370_(getRiderForwardAccessor()));
        tag.m_128350_("RiderStrafe", this.f_19804_.m_135370_(getRiderStrafeAccessor()));
        tag.m_128379_("IsSitting", this.m_21827_());
        tag.m_128350_("SitProgress", this.sitProgress);
    }

    /**
     * Load the common rideable state from NBT. Subclasses can override {@link #applyLoadedFlightState}
     * if they need to push the booleans into custom accessors.
     */
    protected void loadRideableData(CompoundTag tag) {
        boolean savedFlying = tag.m_128471_("Flying");
        boolean savedTakeoff = tag.m_128471_("Takeoff");
        boolean savedHovering = tag.m_128471_("Hovering");
        boolean savedLanding = tag.m_128471_("Landing");
        applyLoadedFlightState(savedFlying, savedTakeoff, savedHovering, savedLanding);

        this.setRunning(tag.m_128471_("Running"));
        this.setAccelerating(tag.m_128471_("Accelerating"));
        this.setGoingUp(savedFlying && tag.m_128471_("GoingUp"));
        this.setGoingDown(savedFlying && tag.m_128471_("GoingDown"));

        int groundState = tag.m_128441_("GroundMoveState") ? tag.m_128451_("GroundMoveState") : 0;
        this.f_19804_.m_135381_(getGroundMoveStateAccessor(), Mth.m_14045_(groundState, 0, 2));

        int flightMode = tag.m_128441_("FlightMode") ? tag.m_128451_("FlightMode") : -1;
        this.f_19804_.m_135381_(getFlightModeAccessor(), savedFlying ? Mth.m_14045_(flightMode, -1, 3) : -1);

        float riderForward = tag.m_128441_("RiderForward") ? tag.m_128457_("RiderForward") : 0f;
        float riderStrafe = tag.m_128441_("RiderStrafe") ? tag.m_128457_("RiderStrafe") : 0f;
        this.f_19804_.m_135381_(getRiderForwardAccessor(), riderForward);
        this.f_19804_.m_135381_(getRiderStrafeAccessor(), riderStrafe);

        boolean savedSitting = tag.m_128471_("IsSitting");
        this.m_21839_(savedSitting);
        float savedSitProgress = tag.m_128441_("SitProgress")
                ? tag.m_128457_("SitProgress")
                : (savedSitting ? this.maxSitTicks() : 0f);
        this.sitProgress = Mth.m_14036_(savedSitProgress, 0f, this.maxSitTicks());
        this.prevSitProgress = this.sitProgress;
        this.f_19804_.m_135381_(DATA_SIT_PROGRESS, this.sitProgress);

        if (!m_9236_().f_46443_) {
            this.syncAnimState(this.f_19804_.m_135370_(getGroundMoveStateAccessor()),
                    this.f_19804_.m_135370_(getFlightModeAccessor()));
        }
    }

    /**
     * Hook for subclasses to push saved flight booleans into their own accessors.
     * Ground-only dragons can ignore it.
     */
    protected void applyLoadedFlightState(boolean flying, boolean takeoff, boolean hovering, boolean landing) {
        // Default no-op; dragons with dedicated flight data should override.
    }
}
