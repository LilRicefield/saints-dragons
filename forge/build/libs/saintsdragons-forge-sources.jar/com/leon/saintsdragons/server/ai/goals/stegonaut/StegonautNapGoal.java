package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Handles daytime napping for Stegonauts.
 * Separate from the main sleep goal to avoid conflicts.
 * Wild drakes occasionally take short naps during the day.
 */
public class StegonautNapGoal extends Goal {
    private final Stegonaut drake;
    private int napDuration;
    private int napTicks;

    private static final int MIN_NAP_DURATION = 60;  // 3 seconds
    private static final int MAX_NAP_DURATION = 120; // 6 seconds
    private static final int NAP_COOLDOWN = 600;     // 30 seconds between naps
    private int napCooldown = 0;

    public StegonautNapGoal(Stegonaut drake) {
        this.drake = drake;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean m_8036_() {
        // Only during daytime
        if (!drake.m_9236_().m_46461_()) {
            return false;
        }

        // Don't nap if already sleeping via main sleep goal
        if (drake.m_5803_()) {
            return false;
        }

        // Don't nap if sitting, playing dead, or being ridden
        if (drake.m_21827_() || false || drake.m_20160_()) {
            return false;
        }

        // Cooldown between naps
        if (napCooldown > 0) {
            napCooldown--;
            return false;
        }

        // Random chance to nap (~0.5% per tick when conditions are met)
        return drake.m_217043_().m_188501_() < 0.005f;
    }

    @Override
    public boolean m_8045_() {
        // Stop if disturbed
        if (drake.m_5448_() != null || drake.m_20160_()) {
            return false;
        }

        // Stop if owner commands to stand
        if (drake.m_21824_() && !drake.m_21827_()) {
            return false;
        }

        // Stop if nap duration is over
        return napTicks < napDuration;
    }

    @Override
    public void m_8056_() {
        // Set nap duration
        napDuration = MIN_NAP_DURATION + drake.m_217043_().m_188503_(MAX_NAP_DURATION - MIN_NAP_DURATION);
        napTicks = 0;

        // Sit down
        drake.m_21839_(true);
        drake.m_21573_().m_26573_();
    }

    @Override
    public void m_8037_() {
        napTicks++;
    }

    @Override
    public void m_8041_() {
        // Stand back up
        drake.m_21839_(false);

        // Set cooldown before next nap
        napCooldown = NAP_COOLDOWN + drake.m_217043_().m_188503_(NAP_COOLDOWN);
        napTicks = 0;
    }
}
