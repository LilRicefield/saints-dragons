package com.leon.saintsdragons.server.ai.goals.cindervane;

import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

/**
 * Sleep goal for Cindervanes.
 * Tamed Cindervanes sleep at night when their owner sleeps nearby.
 * Wild behavior will be implemented later.
 */
public class CindervaneSleepGoal extends Goal {

    private final Cindervane amphithere;
    private int retryCooldown;

    public CindervaneSleepGoal(Cindervane amphithere) {
        this.amphithere = amphithere;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (retryCooldown > 0) {
            retryCooldown--;
            return false;
        }

        if (amphithere.isSleepLocked()) return false;
        if (!amphithere.canSleepNow() || amphithere.isSleepSuppressed()) return false;
        if (amphithere.m_20072_() || amphithere.m_20077_()) return false;
        if (amphithere.isDying() || amphithere.m_20160_() || amphithere.m_5448_() != null || amphithere.m_5912_()) return false;
        if (amphithere.m_9236_().m_46470_()) return false;

        // Only tamed behavior for now - wild behavior will be added later
        return amphithere.m_21824_() && ownerAsleep();
    }

    @Override
    public boolean m_8045_() {
        return amphithere.isSleepLocked();
    }

    @Override
    public void m_8056_() {
        amphithere.startSleepEnter();
    }

    @Override
    public void m_8037_() {
        if (amphithere.m_9236_().f_46443_) return;
        if (amphithere.isSleepLocked() && !shouldRemainAsleep()) {
            if (!amphithere.isSleepTransitioning()) {
                amphithere.startSleepExit();
            }
        }
    }

    @Override
    public void m_8041_() {
        if (!amphithere.isSleepLocked()) {
            retryCooldown = 100;
        }
    }

    @Override
    public boolean m_6767_() {
        return false;
    }

    /**
     * Check if owner is sleeping.
     * Cindervanes sleep whenever their owner sleeps, regardless of distance.
     */
    private boolean ownerAsleep() {
        LivingEntity owner = amphithere.m_269323_();
        if (!(owner instanceof Player player)) {
            return false;
        }
        if (!player.m_5803_() || !player.m_6084_()) {
            return false;
        }
        if (player.m_9236_() != amphithere.m_9236_()) {
            return false;
        }
        return true;
    }

    /**
     * Check if dragon should remain asleep.
     * For now, only tamed behavior is implemented.
     */
    private boolean shouldRemainAsleep() {
        if (amphithere.m_21824_()) {
            return ownerAsleep();
        }
        // Wild behavior will be added later
        return false;
    }
}
