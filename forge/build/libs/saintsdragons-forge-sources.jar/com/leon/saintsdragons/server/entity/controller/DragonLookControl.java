package com.leon.saintsdragons.server.entity.controller;

import com.leon.saintsdragons.server.entity.base.DragonEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.control.LookControl;

/**
 * Custom LookControl for dragons that limits rotation speed for smoother head movement.
 * Vanilla LookControl can rotate very fast - we slow it down for natural behavior.
 */
public class DragonLookControl<T extends DragonEntity> extends LookControl {

    protected final T dragon;
    protected float maxYRotSpeed = 10.0f;  // Max degrees per tick for yaw (default: ~40)
    protected float maxXRotSpeed = 10.0f;  // Max degrees per tick for pitch (default: ~40)

    public DragonLookControl(T dragon) {
        super(dragon);
        this.dragon = dragon;
    }

    public DragonLookControl(T dragon, float maxYRotSpeed, float maxXRotSpeed) {
        super(dragon);
        this.dragon = dragon;
        this.maxYRotSpeed = maxYRotSpeed;
        this.maxXRotSpeed = maxXRotSpeed;
    }

    @Override
    public void m_8128_() {
        // When being ridden, skip custom clamping but still call vanilla logic
        // (vanilla tick() might update internal state needed for camera smoothness)
        if (dragon.m_20160_()) {
            super.m_8128_();
            return;
        }

        // Vanilla LookControl can rotate at ~40 deg/tick which looks snappy
        // We clamp rotation speed for smoother, more natural head movement
        float oldYaw = dragon.f_20885_;
        float oldPitch = dragon.m_146909_();

        super.m_8128_(); // Let vanilla calculate target rotations

        float newYaw = dragon.f_20885_;
        float newPitch = dragon.m_146909_();

        // Calculate how much vanilla rotated
        float yawChange = Mth.m_14177_(newYaw - oldYaw);
        float pitchChange = newPitch - oldPitch;

        // Clamp to our speed limits
        yawChange = Mth.m_14036_(yawChange, -maxYRotSpeed, maxYRotSpeed);
        pitchChange = Mth.m_14036_(pitchChange, -maxXRotSpeed, maxXRotSpeed);

        // Apply clamped rotation
        dragon.m_5616_(oldYaw + yawChange);
        dragon.m_146926_(oldPitch + pitchChange);
    }
}
