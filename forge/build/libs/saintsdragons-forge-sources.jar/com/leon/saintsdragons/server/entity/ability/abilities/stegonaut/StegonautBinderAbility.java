package com.leon.saintsdragons.server.entity.ability.abilities.stegonaut;

import com.leon.saintsdragons.common.item.StegonautBinderItem;
import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Handles portable resistance buffs from bound Drake Binders.
 * When a player carries a bound Drake Binder anywhere in their inventory,
 * they and nearby allies get resistance buffs.
 */
public final class StegonautBinderAbility {

    // Buff parameters
    private static final double BUFF_RANGE = 8.0; // Same range as the drake's original ability
    private static final int BUFF_DURATION_TICKS = 40; // Short duration so we can expire it when binder removed
    private static final int BUFF_AMPLIFIER = 2; // Resistance
    private static final int ABSORPTION_AMPLIFIER = 1; // Absorption

    // Track which entities are currently buffed per dimension so effects can be cleaned up
    private static final Map<ResourceKey<Level>, Set<UUID>> ACTIVE_BUFF_TARGETS = new HashMap<>();

    private StegonautBinderAbility() {
        // Utility class
    }

    /**
     * Update the portable resistance buffs for all players carrying bound Drake Binders
     */
    public static void updateAllPortableBuffs(ServerLevel level) {
        Set<UUID> currentTargets = new HashSet<>();

        for (Player player : level.m_6907_()) {
            if (!player.m_6084_()) {
                continue;
            }

            if (!hasBoundDrakeBinder(player)) {
                continue;
            }

            applyPortableResistanceBuffs(level, player, currentTargets);
        }

        Set<UUID> previousTargets = ACTIVE_BUFF_TARGETS.getOrDefault(level.m_46472_(), Collections.emptySet());
        if (!previousTargets.isEmpty()) {
            for (UUID uuid : previousTargets) {
                if (currentTargets.contains(uuid)) {
                    continue;
                }
                Entity entity = level.m_8791_(uuid);
                if (entity instanceof LivingEntity livingEntity) {
                    livingEntity.m_21195_(MobEffects.f_19606_);
                    livingEntity.m_21195_(MobEffects.f_19617_);
                }
            }
        }

        ACTIVE_BUFF_TARGETS.put(level.m_46472_(), currentTargets);
    }

    /**
     * Apply portable resistance buffs to the player and nearby allies
     */
    private static void applyPortableResistanceBuffs(ServerLevel level, Player player, Set<UUID> currentTargets) {
        applyBuffsToEntity(player, currentTargets);

        var nearbyEntities = level.m_6443_(
            LivingEntity.class,
            player.m_20191_().m_82400_(BUFF_RANGE),
            entity -> entity != player && isEligibleForPortableBuff(entity, player)
        );

        for (LivingEntity entity : nearbyEntities) {
            applyBuffsToEntity(entity, currentTargets);
        }
    }

    /**
     * Check if the player has a bound Drake Binder anywhere in their inventory
     */
    private static boolean hasBoundDrakeBinder(Player player) {
        if (findBoundDrakeBinderInList(player.m_150109_().f_35974_)) {
            return true;
        }
        if (findBoundDrakeBinderInList(player.m_150109_().f_35976_)) {
            return true;
        }
        return findBoundDrakeBinderInList(player.m_150109_().f_35975_);
    }

    private static boolean findBoundDrakeBinderInList(net.minecraft.core.NonNullList<ItemStack> stacks) {
        for (ItemStack item : stacks) {
            if (item.m_41619_()) {
                continue;
            }
            if (item.m_41720_() instanceof StegonautBinderItem && StegonautBinderItem.isBound(item)) {
                return StegonautBinderItem.getBoundDrakeUUID(item) != null;
            }
        }
        return false;
    }

    /**
     * Check if an entity is eligible for portable resistance buff
     */
    private static boolean isEligibleForPortableBuff(LivingEntity entity, Player player) {
        if (!entity.m_6084_()) {
            return false;
        }

        if (entity instanceof Player) {
            return true;
        }

        if (entity instanceof com.leon.saintsdragons.server.entity.base.DragonEntity dragon) {
            return dragon.m_21824_() && dragon.m_21830_(player);
        }

        if (entity instanceof Stegonaut drake) {
            return drake.m_21824_() && drake.allyManager.isAlly(player);
        }

        if (entity instanceof OwnableEntity ownable) {
            LivingEntity owner = ownable.m_269323_();
            if (owner instanceof Player ownerPlayer) {
                return ownerPlayer.m_20148_().equals(player.m_20148_());
            }
        }

        return false;
    }

    /**
     * Apply resistance effect to an entity and record it for cleanup tracking
     */
    private static void applyBuffsToEntity(LivingEntity entity, Set<UUID> currentTargets) {
        MobEffectInstance resistanceEffect = new MobEffectInstance(
            MobEffects.f_19606_,
            BUFF_DURATION_TICKS,
            BUFF_AMPLIFIER,
            false,
            false,
            false
        );
        MobEffectInstance absorptionEffect = new MobEffectInstance(
            MobEffects.f_19617_,
            BUFF_DURATION_TICKS,
            ABSORPTION_AMPLIFIER,
            false,
            false,
            false
        );
        entity.m_7292_(resistanceEffect);
        entity.m_7292_(absorptionEffect);
        currentTargets.add(entity.m_20148_());
    }
}
