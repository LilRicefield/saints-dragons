package com.leon.saintsdragons.server.entity.controller.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Handles all riding mechanics for the Lightning Dragon
 */
public record RaevyxRiderController(Raevyx wyvern) {
    // ===== SEAT TUNING CONSTANTS =====
    // Baseline vertical offset relative to wyvern height
    private static final double SEAT_BASE_FACTOR = 0.50D; // 0.0..1.0 of bbHeight

    // No head-follow offsets; keep static body seat

    // ===== SIMPLIFIED FLIGHT PHYSICS =====
    // Clean, responsive arcade-style flight controls
    private static final double CRUISE_SPEED_MULT = 3.75;     // Normal flight speed multiplier
    private static final double SPRINT_SPEED_MULT = 7.85;     // Sprint speed multiplier (80% faster)
    private static final double ACCELERATION = 0.15;         // How quickly dragon reaches target speed
    private static final double DRAG_WITH_INPUT = 0.08;      // Gentle drag when player is actively flying
    private static final double DRAG_NO_INPUT = 0.5;         // Strong braking when player releases controls
    private static final double STRAFE_POWER = 0.5;          // Strafe input strength (constant)

    // ===== VERTICAL PHYSICS (dive acceleration only) =====
    private static final double ASCEND_THRUST = 0.08D;       // Upward thrust when climbing
    private static final double DESCEND_THRUST = 1.0D;       // Downward thrust when diving (accelerates)
    private static final double TERMINAL_VELOCITY = 1.5D;    // Max falling speed
    private static final double VERTICAL_DRAG = 0.92D;       // Damping when no vertical input (air resistance)

    // ===== RIDING UTILITIES =====

    @Nullable
    public Player getRidingPlayer() {
        if (wyvern.m_6688_() instanceof Player player) {
            return player;
        }
        return null;
    }
    // ===== RIDER INPUT PROCESSING =====

    /**
     * Processes rider input and converts to movement vector
     */
    public Vec3 getRiddenInput(Player player, @SuppressWarnings("unused") Vec3 deltaIn) {
        float f = player.f_20902_ < 0.0F ? 0.5F : 1.0F;

        if (wyvern.m_29443_()) {
            // Flying movement – NO pitch-based vertical movement.
            // Vertical is controlled exclusively by ascend/descend keybinds.
            return new Vec3(player.f_20900_ * 0.4F, 0.0F, player.f_20902_ * 1.0F * f);
        } else {
            // Ground movement - no vertical component, responsive controls
            return new Vec3(player.f_20900_ * 0.5F, 0.0D, player.f_20902_ * 0.9F * f);
        }
    }

    /**
     * Main rider tick method - handles rotation
     * Smooth turning handled by DragonBodyControl + bodyRotDeviation system
     */
    public void tickRidden(Player player, @SuppressWarnings("unused") Vec3 travelVector) {
        // Prevent accidental rider fall damage while mounted
        player.f_19789_ = 0.0F;
        wyvern.f_19789_ = 0.0F;
        // Clear target when being ridden to prevent AI interference
        wyvern.m_6710_(null);

        boolean flying = wyvern.m_29443_();

        // Simple yaw alignment - DragonBodyControl + bodyRotDeviation handle smoothing
        float yawDiff = Math.abs(player.m_146908_() - wyvern.m_146908_());
        if (player.f_20902_ != 0 || player.f_20900_ != 0 || yawDiff > 5.0f) {
            float currentYaw = wyvern.m_146908_();
            float targetYaw = player.m_146908_();
            float rawDiff = Mth.m_14177_(targetYaw - currentYaw);
            float blend = flying ? 0.35f : 0.28f; // Slightly more responsive when flying
            float newYaw = currentYaw + (rawDiff * blend);

            // Set rotation - don't manually set old values, let vanilla interpolate
            wyvern.m_146922_(newYaw);
            wyvern.f_20883_ = newYaw;
            wyvern.f_20885_ = newYaw;

            // Simple pitch for flight
            if (flying) {
                float targetPitch = Mth.m_14036_(player.m_146909_() * 0.55f, -35.0f, 30.0f);
                wyvern.m_146926_(targetPitch);
            } else {
                wyvern.m_146926_(0.0F);
            }

            // Force entity to be dirty for network sync
            wyvern.m_20256_(wyvern.m_20184_());
        }

        // Extra safety: if we just touched ground, ensure rider has no fall damage
        if (wyvern.m_20096_()) {
            player.f_19789_ = 0.0F;
            wyvern.f_19789_ = 0.0F;
        }
    }

    /**
     * Calculate riding speed based on current state
     */
    public float getRiddenSpeed(@SuppressWarnings("unused") Player rider) {
        if (wyvern.m_29443_()) {
            // Flying speed - use ONLY the attributed flying speed, no modifiers
            return (float) wyvern.m_21133_(Attributes.f_22280_);
        } else {
            // Ground speed - use movement speed attribute with acceleration multipliers
            float baseSpeed = (float) wyvern.m_21133_(Attributes.f_22279_);

            // Check if actually moving to prevent sprint animation when standing still
            boolean isMoving = wyvern.m_20184_().m_165925_() > 0.0001;

            if (wyvern.isAccelerating() && isMoving) {
                // L-Ctrl pressed AND moving - trigger run animation and boost speed
                wyvern.setRunning(true);
                return baseSpeed * 0.7F;
            } else {
                // Normal ground speed - use walk animation, stop running
                wyvern.setRunning(false);
                return baseSpeed * 0.5F;
            }
        }
    }

    // ===== RIDING MOVEMENT =====

    /**
     * Handle rider movement - called from travel() method
     * CLEAN SIMPLIFIED PHYSICS - responsive arcade-style flight
     */
    public void handleRiderMovement(Player player, Vec3 motion) {
        // Clear any AI navigation when being ridden
        if (wyvern.m_21573_().m_26570_() != null) {
            wyvern.m_21573_().m_26573_();
        }

        if (wyvern.m_29443_()) {
            // === SETUP ===
            final double baseSpeed = wyvern.m_21133_(Attributes.f_22280_);
            final boolean sprinting = wyvern.isAccelerating();
            final double targetSpeed = (sprinting ? SPRINT_SPEED_MULT : CRUISE_SPEED_MULT) * baseSpeed;

            // Get current velocity (split horizontal and vertical for independent control)
            Vec3 currentVelocity = wyvern.m_20184_();
            Vec3 horizontalVel = new Vec3(currentVelocity.f_82479_, 0.0, currentVelocity.f_82481_);
            double currentSpeed = horizontalVel.m_82553_();

            // === INPUT PROCESSING ===
            double forwardInput = motion.f_82481_;   // W/S keys (-1 to 1)
            double strafeInput = motion.f_82479_;    // A/D keys (-1 to 1)
            boolean hasInput = Math.abs(forwardInput) > 0.01 || Math.abs(strafeInput) > 0.01;

            // Calculate world-space direction from player input
            float yawRad = (float) Math.toRadians(wyvern.m_146908_());
            double forwardX = -Math.sin(yawRad);
            double forwardZ = Math.cos(yawRad);
            double rightX = Math.cos(yawRad);
            double rightZ = Math.sin(yawRad);

            // Combine forward and strafe (strafe is constant power now)
            double targetDirX = forwardX * forwardInput + rightX * (strafeInput * STRAFE_POWER);
            double targetDirZ = forwardZ * forwardInput + rightZ * (strafeInput * STRAFE_POWER);
            double dirLength = Math.hypot(targetDirX, targetDirZ);

            Vec3 newHorizontalVel;

            if (hasInput && dirLength > 0.01) {
                // === ACTIVE FLYING (player is pressing keys) ===
                // Normalize direction
                targetDirX /= dirLength;
                targetDirZ /= dirLength;

                // Calculate target velocity vector
                Vec3 targetVelocity = new Vec3(targetDirX * targetSpeed, 0, targetDirZ * targetSpeed);

                // Smoothly accelerate toward target velocity
                newHorizontalVel = new Vec3(
                    Mth.m_14139_(ACCELERATION, horizontalVel.f_82479_, targetVelocity.f_82479_),
                    0,
                    Mth.m_14139_(ACCELERATION, horizontalVel.f_82481_, targetVelocity.f_82481_)
                );

                // Apply gentle drag for smooth cruising
                newHorizontalVel = newHorizontalVel.m_82490_(1.0 - DRAG_WITH_INPUT);

            } else {
                // === COASTING (player released keys) ===
                // Apply strong braking for immediate stop feel
                newHorizontalVel = horizontalVel.m_82490_(1.0 - DRAG_NO_INPUT);

                // Stop completely if speed is very low (prevents endless drift)
                if (newHorizontalVel.m_82553_() < 0.01) {
                    newHorizontalVel = Vec3.f_82478_;
                }
            }

            // === VERTICAL MOVEMENT (dive acceleration, no gravity) ===
            double verticalVel = currentVelocity.f_82480_;

            if (wyvern.isGoingUp()) {
                // Apply upward thrust
                verticalVel += ASCEND_THRUST;
            } else if (wyvern.isGoingDown()) {
                // Apply downward thrust - DIVES ACCELERATE!
                verticalVel -= DESCEND_THRUST;
            } else {
                // Coasting - apply air resistance to slow vertical movement
                verticalVel *= VERTICAL_DRAG;
            }

            // Clamp to terminal velocity during dives
            verticalVel = Mth.m_14008_(verticalVel, -TERMINAL_VELOCITY, TERMINAL_VELOCITY);

            // === APPLY MOVEMENT ===
            Vec3 finalVelocity = new Vec3(newHorizontalVel.f_82479_, verticalVel, newHorizontalVel.f_82481_);
            wyvern.m_6478_(MoverType.SELF, finalVelocity);
            wyvern.m_20256_(finalVelocity);
            wyvern.m_267651_(true);

            // Clear fall damage while flying
            player.f_19789_ = 0.0F;
            wyvern.f_19789_ = 0.0F;
        }
    }

    // ===== RIDING SUPPORT =====
    
    public double getPassengersRidingOffset() {
        return (double) wyvern.m_20206_() * SEAT_BASE_FACTOR;
    }
    
    public void positionRider(@NotNull Entity passenger, Entity.@NotNull MoveFunction moveFunction) {
        if (!wyvern.m_20363_(passenger)) return;

        // Get the bone position from the renderer's cache (updated each render frame)
        Vec3 passengerLoc = wyvern.getClientLocatorPosition("passengerLocator");

        if (passengerLoc != null) {
            // The cached position is in world-space but may be from the previous frame
            // We need to convert to dragon-local space to handle both movement AND rotation

            // Get dragon's old position and rotation (from when bone was sampled)
            Vec3 dragonOldPos = new Vec3(wyvern.f_19854_, wyvern.f_19855_, wyvern.f_19856_);
            float oldYaw = wyvern.f_19859_;

            // Calculate offset in world space
            Vec3 worldOffset = passengerLoc.m_82546_(dragonOldPos);

            // Convert world offset to dragon-local space (relative to old rotation)
            double oldYawRad = Math.toRadians(-oldYaw); // Negative because Minecraft yaw is inverted
            double cosOld = Math.cos(oldYawRad);
            double sinOld = Math.sin(oldYawRad);

            // Rotate world offset back to local space
            double localX = worldOffset.f_82479_ * cosOld - worldOffset.f_82481_ * sinOld;
            double localY = worldOffset.f_82480_;
            double localZ = worldOffset.f_82479_ * sinOld + worldOffset.f_82481_ * cosOld;

            // Now rotate local offset to current rotation
            float currentYaw = wyvern.m_146908_();
            double currentYawRad = Math.toRadians(-currentYaw);
            double cosCurrent = Math.cos(currentYawRad);
            double sinCurrent = Math.sin(currentYawRad);

            double currentWorldX = localX * cosCurrent + localZ * sinCurrent;
            double currentWorldZ = -localX * sinCurrent + localZ * cosCurrent;

            // Apply to current dragon position
            Vec3 dragonCurrentPos = wyvern.m_20182_();
            Vec3 passengerCurrentPos = dragonCurrentPos.m_82520_(currentWorldX, localY, currentWorldZ);

            moveFunction.m_20372_(passenger, passengerCurrentPos.f_82479_, passengerCurrentPos.f_82480_, passengerCurrentPos.f_82481_);
        } else {
            // Fallback to vanilla positioning if bone position not available yet
            double x = wyvern.m_20185_();
            double y = wyvern.m_20186_() + getPassengersRidingOffset() + passenger.m_6049_();
            double z = wyvern.m_20189_();
            moveFunction.m_20372_(passenger, x, y, z);
        }
    }
    
    public @NotNull Vec3 getDismountLocationForPassenger(@NotNull LivingEntity passenger) {
        passenger.f_19789_ = 0.0F;
        var level = wyvern.m_9236_();
        Vec3 base = wyvern.m_20182_();

        // Sample radial candidates around the wyvern for a safe dismount
        double[] radii = new double[] { 2.5, 3.5, 1.8 };
        int[] angles = new int[] { 0, 30, -30, 60, -60, 90, -90, 150, -150, 180 };

        for (double r : radii) {
            for (int a : angles) {
                double rad = Math.toRadians(wyvern.m_146908_() + a);
                double cx = base.f_82479_ + Math.cos(rad) * r;
                double cz = base.f_82481_ + Math.sin(rad) * r;

                // Project down to find ground up to 6 blocks below current Y
                int startY = (int) Math.floor(base.f_82480_ + 1.0);
                for (int dy = 0; dy <= 6; dy++) {
                    int y = startY - dy;
                    var pos = new net.minecraft.core.BlockPos((int) Math.floor(cx), y, (int) Math.floor(cz));
                    var below = pos.m_7495_();
                    var bsBelow = level.m_8055_(below);
                    var bsAt = level.m_8055_(pos);
                    boolean solidBelow = !bsBelow.m_60795_() && !bsBelow.m_60812_(level, below).m_83281_();
                    boolean spaceFree = bsAt.m_60812_(level, pos).m_83281_();
                    boolean fluidOk = bsAt.m_60819_().m_76178_();
                    if (solidBelow && spaceFree && fluidOk) {
                        // Found a safe spot; return precise center with a slight lift
                        return new Vec3(pos.m_123341_() + 0.5, pos.m_123342_() + 0.05, pos.m_123343_() + 0.5);
                    }
                }
            }
        }

        // Fallback: ahead of wyvern
        Vec3 direction = wyvern.m_20252_(1.0F);
        return base.m_82549_(direction.m_82490_(2.0));
    }
    
    @Nullable 
    public LivingEntity getControllingPassenger() {
        Entity entity = wyvern.m_146895_();
        if (entity instanceof Player player && wyvern.m_21824_() && wyvern.m_21830_(player)) {
            return player;
        }
        return null;
    }
    
    /**
     * Forces the wyvern to take off when being ridden. Called when player presses Space while on ground.
     */
    public void requestRiderTakeoff() {
        if (!wyvern.m_21824_() || getRidingPlayer() == null || wyvern.m_29443_()) return;
        // Block takeoff if locked (e.g., during roar)
        if (wyvern.isTakeoffLocked()) return;
        // Gentle cooldown after landing to prevent spam takeoff/land jitter
        long now = wyvern.m_9236_().m_46467_();
        long lastLand = wyvern.getLastLandingGameTime();
        if (lastLand != Long.MIN_VALUE && (now - lastLand) < 20L) { // ~1s cooldown
            return;
        }
        
        // Reset all flight states for a fresh takeoff
        wyvern.timeFlying = 0;
        wyvern.landingFlag = false;
        wyvern.landingTimer = 0;
        
        // Initiate takeoff sequence
        wyvern.setFlying(true);
        wyvern.setTakeoff(true);
        wyvern.setHovering(false);
        wyvern.setLanding(false);
        // Keep takeoff active for a brief window so server flight logic applies upward force
        wyvern.setRiderTakeoffTicks(30);

        // Play takeoff sound (Ender Dragon flap)
        if (wyvern.m_9236_().f_46443_) {
            float urgency = wyvern.m_5448_() != null ? 1.3f : 1.0f;
            wyvern.m_9236_().m_7785_(wyvern.m_20185_(), wyvern.m_20186_(), wyvern.m_20189_(),
                    net.minecraft.sounds.SoundEvents.f_11893_,
                    net.minecraft.sounds.SoundSource.NEUTRAL, urgency * 1.2f, 0.85f, false);
        }
    }
}
