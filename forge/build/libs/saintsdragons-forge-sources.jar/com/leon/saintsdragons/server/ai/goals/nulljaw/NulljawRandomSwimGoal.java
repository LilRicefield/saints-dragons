package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class NulljawRandomSwimGoal extends RandomStrollGoal {

    private final Nulljaw drake;

    public NulljawRandomSwimGoal(Nulljaw drake, double speed, int chance) {
        super(drake, speed, chance, false);
        this.drake = drake;
    }

    public void forceTrigger() {
        this.f_25731_ = true;
    }

    @Override
    public boolean m_8036_() {
        // Don't use if being ridden, is a passenger, has a target, or is sitting
        if (this.drake.m_20160_() || this.drake.m_20159_() ||
            this.drake.m_5448_() != null || this.drake.m_21827_()) {
            return false;
        }

        // Only use when actually in water and swimming
        if (!this.drake.m_20069_() || !this.drake.m_6069_()) {
            return false;
        }

        // Random chance check (unless force triggered)
        if (!this.f_25731_) {
            if (this.drake.m_217043_().m_188503_(this.f_25730_) != 0) {
                return false;
            }
        }

        // Try to find a valid position to swim to
        Vec3 vector3d = this.m_7037_();
        if (vector3d == null) {
            return false;
        }

        this.f_25726_ = vector3d.f_82479_;
        this.f_25727_ = vector3d.f_82480_;
        this.f_25728_ = vector3d.f_82481_;
        this.f_25731_ = false;
        return true;
    }

    @Override
    public boolean m_8045_() {
        // Stop if no longer in water or being controlled
        if (!this.drake.m_20069_() || this.drake.m_20160_() ||
            this.drake.m_5448_() != null || this.drake.m_21827_()) {
            return false;
        }

        // Continue if navigation is still in progress
        return !this.drake.m_21573_().m_26571_();
    }

    @Nullable
    @Override
    protected Vec3 m_7037_() {
        if (drake.m_217043_().m_188501_() < 0.25F) {
            Vec3 surface = findSurfaceTarget();
            if (surface != null) {
                return surface;
            }
        }
        Vec3 pos = DefaultRandomPos.m_148403_(drake, 10, 4);
        int attempts = 0;
        while (pos != null && !drake.m_9236_().m_8055_(net.minecraft.core.BlockPos.m_274446_(pos)).m_60647_(drake.m_9236_(), net.minecraft.core.BlockPos.m_274446_(pos), PathComputationType.WATER) && attempts++ < 12) {
            pos = DefaultRandomPos.m_148403_(drake, 10, 4);
        }
        return pos;
    }

    @Nullable
    private Vec3 findSurfaceTarget() {
        net.minecraft.core.BlockPos.MutableBlockPos cursor = drake.m_20183_().m_122032_();
        while (drake.m_9236_().m_6425_(cursor).m_205070_(FluidTags.f_13131_) && cursor.m_123342_() < drake.m_9236_().m_151558_()) {
            cursor.m_122184_(0, 1, 0);
        }
        cursor.m_122184_(0, -1, 0);
        if (!drake.m_9236_().m_6425_(cursor).m_205070_(FluidTags.f_13131_)) {
            return null;
        }
        if (drake.m_9236_().m_8055_(cursor.m_7494_()).m_60795_()) {
            return new Vec3(cursor.m_123341_() + 0.5D, cursor.m_123342_() + 0.2D, cursor.m_123343_() + 0.5D);
        }
        return null;
    }
}

