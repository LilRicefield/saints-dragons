package com.leon.saintsdragons.server.ai.goals.nulljaw;

import com.leon.saintsdragons.server.entity.dragons.nulljaw.Nulljaw;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Simple ground wandering for Lightning Dragon when not flying
 */
public class NulljawGroundWanderGoal extends RandomStrollGoal {

    private final Nulljaw dragon;

    public NulljawGroundWanderGoal(Nulljaw dragon, double speed, int interval) {
        // Fixed interval wandering
        super(dragon, speed, interval);
        this.dragon = dragon;
    }

    @Override
    public boolean m_8036_() {
        // Only wander on ground when not flying
        if (dragon.m_29443_()) {
            return false;
        }
        if (dragon.m_6069_() || dragon.m_20072_()) {
            return false;
        }

        // Don't interfere with important behaviors
        if (dragon.m_21827_() || dragon.m_20160_() || dragon.m_20159_()) {
            return false;
        }

        // Don't wander during combat
        if (dragon.m_5448_() != null && dragon.m_5448_().m_6084_()) {
            return false;
        }

        // Hook up to command system - only wander when command is 2 (Wander) or when untamed
        if (dragon.m_21824_()) {
            int command = dragon.getCommand();
            if (command != 2) { // 0=Follow, 1=Sit, 2=Wander
                return false;
            }
        }

        return super.m_8036_();
    }

    @Override
    public boolean m_8045_() {
        // Stop if we start flying
        if (dragon.m_29443_()) {
            return false;
        }
        if (dragon.m_6069_() || dragon.m_20072_()) {
            return false;
        }

        // Stop if combat starts
        if (dragon.m_5448_() != null && dragon.m_5448_().m_6084_()) {
            return false;
        }

        // Stop if ordered to sit
        if (dragon.m_21827_()) {
            return false;
        }

        return super.m_8045_();
    }

    @Nullable
    @Override
    protected Vec3 m_7037_() {
        // If tamed and owner is far, bias movement towards owner
        if (dragon.m_21824_()) {
            var owner = dragon.m_269323_();
            if (owner != null && dragon.m_20280_(owner) > 20.0 * 20.0) {
                // Move generally towards owner but not directly (maintain some independence)
                return DefaultRandomPos.m_148412_(
                        this.f_25725_,
                        16, // range
                        7,  // vertical range
                        owner.m_20182_(),
                        (float) Math.PI / 3F // 60-degree cone towards owner
                );
            }
        }

        // Default random wandering
        return DefaultRandomPos.m_148403_(this.f_25725_, 20, 8); // Slightly larger range for a wyvern
    }

    public void forceTrigger() {
        this.f_25731_ = true;
    }
}
