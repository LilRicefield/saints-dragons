package com.leon.saintsdragons.server.ai.goals.cindervane;

import com.leon.saintsdragons.common.registry.cindervane.CindervaneAbilities;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.EnumSet;

/**
 * Combat goal for Amphithere - uses bite attack and FireBody ability when in combat
 */
public class CindervaneCombatGoal extends Goal {
    private final Cindervane amphithere;
    private final double attackRange = 4.5; // Amphithere has longer neck, slightly more range
    private final double fireBodyActivationRange = 8.0; // Activate FireBody when enemy is within this range
    private final double chaseSpeed = 1.2D;
    private int attackCooldown = 0;
    private int fireBodyCheckCooldown = 0;
    private int pathRecalcCooldown = 0;
    private double lastTargetX;
    private double lastTargetY;
    private double lastTargetZ;

    public CindervaneCombatGoal(Cindervane amphithere) {
        this.amphithere = amphithere;
        this.m_7021_(EnumSet.of(Flag.LOOK, Flag.MOVE));
    }

    @Override
    public boolean m_8036_() {
        LivingEntity target = amphithere.m_5448_();

        if (target == null || !target.m_6084_()) {
            return false;
        }

        if (amphithere.m_20160_() || amphithere.m_21827_()) {
            return false;
        }

        if (amphithere.m_20280_(target) > getMaxAggroDistanceSqr()) {
            return false;
        }

        return true;
    }

    @Override
    public boolean m_8045_() {
        LivingEntity target = amphithere.m_5448_();

        if (target == null || !target.m_6084_()) {
            return false;
        }

        if (amphithere.m_20160_() || amphithere.m_21827_()) {
            return false;
        }

        if (amphithere.m_20280_(target) > getMaxAggroDistanceSqr()) {
            return false;
        }

        return true;
    }

    @Override
    public boolean m_183429_() {
        return true;
    }

    @Override
    public void m_8041_() {
        amphithere.m_21573_().m_26573_();
        deactivateFireBodyIfActive();
        pathRecalcCooldown = 0;
    }

    @Override
    public void m_8056_() {
        LivingEntity target = amphithere.m_5448_();
        if (target != null) {
            amphithere.m_21563_().m_24960_(target, 30.0F, 30.0F);
            amphithere.m_21573_().m_5624_(target, chaseSpeed);
            rememberTargetPosition(target);

            double distanceSq = amphithere.m_20280_(target);
            if (distanceSq <= getAttackReachSqr(target)) {
                tryPerformBite(target);
            }
        }
    }

    @Override
    public void m_8037_() {
        if (attackCooldown > 0) {
            attackCooldown--;
        }
        if (fireBodyCheckCooldown > 0) {
            fireBodyCheckCooldown--;
        }

        LivingEntity target = amphithere.m_5448_();
        if (target != null) {
            amphithere.m_21563_().m_24960_(target, 30.0F, 30.0F);

            double distanceSq = amphithere.m_20280_(target);
            double attackReachSq = getAttackReachSqr(target);
            boolean inAttackRange = distanceSq <= attackReachSq;
            boolean hasLineOfSight = amphithere.m_21574_().m_148306_(target);

            if (!inAttackRange || !hasLineOfSight) {
                if (!isCurrentlyBiting()) {
                    updateChasePath(target);
                }
            } else {
                amphithere.m_21573_().m_26573_();
                pathRecalcCooldown = 0;
                tryPerformBite(target);
            }

            handleFireBodyActivation(target);
        } else {
            deactivateFireBodyIfActive();
        }
    }

    private boolean isCurrentlyBiting() {
        return amphithere.isAbilityActive(CindervaneAbilities.BITE);
    }

    private void tryPerformBite(LivingEntity target) {
        if (attackCooldown > 0 || isCurrentlyBiting()) {
            return;
        }

        if (!amphithere.m_21574_().m_148306_(target)) {
            return;
        }

        amphithere.combatManager.tryUseAbility(CindervaneAbilities.BITE);
        attackCooldown = 40; // 2 second cooldown
    }

    /**
     * Activates FireBody when enemies are nearby to create a defensive/offensive aura
     */
    private void handleFireBodyActivation(LivingEntity target) {
        // Only check every 2 seconds to avoid spam
        if (fireBodyCheckCooldown > 0) {
            return;
        }

        // Don't activate if being ridden (let rider control it)
        if (amphithere.m_20160_()) {
            return;
        }

        // Don't activate if in water (FireBody doesn't work in water)
        if (amphithere.m_20072_()) {
            return;
        }

        boolean fireBodyActive = amphithere.isAbilityActive(CindervaneAbilities.FIRE_BODY);
        double distanceToTarget = amphithere.m_20270_(target);

        if (!fireBodyActive && distanceToTarget < fireBodyActivationRange) {
            amphithere.combatManager.tryUseAbility(CindervaneAbilities.FIRE_BODY);
            fireBodyCheckCooldown = 40; // 2 second cooldown before checking again
        } else if (fireBodyActive && distanceToTarget > fireBodyActivationRange * 1.5) {
            amphithere.forceEndAbility(CindervaneAbilities.FIRE_BODY);
            fireBodyCheckCooldown = 40;
        }
    }


    /**
     * Deactivates FireBody when there's no target (enemy killed or lost)
     */
    private void deactivateFireBodyIfActive() {
        // Don't interfere if being ridden
        if (amphithere.m_20160_()) {
            return;
        }

        if (amphithere.isAbilityActive(CindervaneAbilities.FIRE_BODY)) {
            amphithere.forceEndAbility(CindervaneAbilities.FIRE_BODY);
        }
    }


    private double getAttackReachSqr(LivingEntity target) {
        double combinedRadii = (this.amphithere.m_20205_() + target.m_20205_()) * 0.5;
        double reach = this.attackRange + combinedRadii;
        return reach * reach;
    }

    private double getMaxAggroDistanceSqr() {
        double followRange = this.amphithere.m_21133_(Attributes.f_22277_);
        if (followRange <= 0.0D) {
            followRange = 16.0D;
        }
        return followRange * followRange;
    }

    private void updateChasePath(LivingEntity target) {
        if (--pathRecalcCooldown <= 0 || targetMovedSignificantly(target)) {
            rememberTargetPosition(target);
            double distance = amphithere.m_20270_(target);
            pathRecalcCooldown = Mth.m_14045_((int) (distance * 0.6D), 5, 20);
            amphithere.m_21573_().m_5624_(target, chaseSpeed);
        }
    }

    private void rememberTargetPosition(LivingEntity target) {
        this.lastTargetX = target.m_20185_();
        this.lastTargetY = target.m_20186_();
        this.lastTargetZ = target.m_20189_();
    }

    private boolean targetMovedSignificantly(LivingEntity target) {
        double dx = target.m_20185_() - this.lastTargetX;
        double dy = target.m_20186_() - this.lastTargetY;
        double dz = target.m_20189_() - this.lastTargetZ;
        return dx * dx + dy * dy + dz * dz > 4.0D;
    }
}
