package com.leon.saintsdragons.server.ai.goals.cindervane;

import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Custom ground wandering for Amphithere when not flying
 * Provides better control over movement behavior and animation triggers
 */
public class CindervaneGroundWanderGoal extends RandomStrollGoal {

    private final Cindervane amphithere;

    public CindervaneGroundWanderGoal(Cindervane amphithere, double speed, int interval) {
        // Fixed interval wandering
        super(amphithere, speed, interval);
        this.amphithere = amphithere;
    }

    @Override
    public boolean m_8036_() {
        // Only wander on ground when not flying
        if (amphithere.m_29443_()) {
            return false;
        }

        // Don't interfere with important behaviors
        if (amphithere.m_21827_() || amphithere.m_20160_() || amphithere.m_20159_()) {
            return false;
        }

        // Don't wander while sitting down (but standing up is OK)
        if (amphithere.isSittingDownAnimation()) {
            return false;
        }

        // Don't wander during transitional states
        if (amphithere.isTakeoff() || amphithere.isLanding() || amphithere.isHovering()) {
            return false;
        }

        // Don't wander during combat
        var target = amphithere.m_5448_();
        if (target != null && target.m_6084_()) {
            return false;
        }

        // Hook up to command system - only wander when command is 2 (Wander) or when untamed
        if (amphithere.m_21824_()) {
            int command = amphithere.getCommand();
            if (command != 2) { // 0=Follow, 1=Sit, 2=Wander
                return false;
            }
        }

        return super.m_8036_();
    }

    @Override
    public boolean m_8045_() {
        // Stop if we start flying
        if (amphithere.m_29443_()) {
            return false;
        }

        // Stop if we enter transitional states
        if (amphithere.isTakeoff() || amphithere.isLanding() || amphithere.isHovering()) {
            return false;
        }

        // Stop if combat starts
        var target = amphithere.m_5448_();
        if (target != null && target.m_6084_()) {
            return false;
        }

        // Stop if ordered to sit
        if (amphithere.m_21827_()) {
            return false;
        }

        return super.m_8045_();
    }


    @Nullable
    @Override
    protected Vec3 m_7037_() {
        // If tamed and owner is far, bias movement towards owner
        if (amphithere.m_21824_()) {
            var owner = amphithere.m_269323_();
            if (owner != null && amphithere.m_20280_(owner) > 20.0 * 20.0) {
                // Move generally towards owner but not directly (maintain some independence)
                return DefaultRandomPos.m_148412_(
                        this.f_25725_,
                        16, // range
                        7,  // vertical range
                        owner.m_20182_(),
                        (float) Math.PI / 3F // 60-degree cone towards owner
                );
            } else if (owner != null) {
                Vec3 aroundOwner = DefaultRandomPos.m_148412_(
                        this.f_25725_,
                        12,
                        6,
                        owner.m_20182_(),
                        (float) Math.PI
                );
                if (aroundOwner != null) {
                    return aroundOwner;
                }
            }
        }

        // Default random wandering
        return DefaultRandomPos.m_148403_(this.f_25725_, 20, 8); // Slightly larger range for a dragon
    }
}
