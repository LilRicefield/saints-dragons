package com.leon.saintsdragons.server.ai.navigation;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.PathNavigationRegion;
import net.minecraft.world.level.pathfinder.Node;
import net.minecraft.world.level.pathfinder.NodeEvaluator;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.level.pathfinder.PathFinder;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Fixes vanilla Minecraft pathfinding issues and provides smoother movement.
 */
public class DragonPathFinder extends PathFinder {
    public DragonPathFinder(NodeEvaluator processor, int maxVisitedNodes) {
        super(processor, maxVisitedNodes);
    }

    @Nullable
    @Override
    public Path m_77427_(@Nonnull PathNavigationRegion regionIn, @Nonnull Mob mob, @Nonnull Set<BlockPos> targetPositions, float maxRange, int accuracy, float searchDepthMultiplier) {
        Path path = super.m_77427_(regionIn, mob, targetPositions, maxRange, accuracy, searchDepthMultiplier);
        return path == null ? null : new DragonPatchedPath(path);
    }

    /**
     * Custom path implementation that fixes vanilla entity positioning issues.
     * Properly accounts for entity bounding box width when calculating path positions.
     */
    static class DragonPatchedPath extends Path {
        public DragonPatchedPath(Path original) {
            super(copyPathPoints(original), original.m_77406_(), original.m_77403_());
        }

        @Override
        public @NotNull Vec3 m_77382_(@Nonnull Entity entity, int index) {
            Node point = this.m_77375_(index);
            // Properly center the entity based on its actual bounding box width
            double d0 = point.f_77271_ + Mth.m_14143_(entity.m_20205_() + 1.0F) * 0.5D;
            double d1 = point.f_77272_;
            double d2 = point.f_77273_ + Mth.m_14143_(entity.m_20205_() + 1.0F) * 0.5D;
            return new Vec3(d0, d1, d2);
        }

        private static List<Node> copyPathPoints(Path original) {
            List<Node> points = new ArrayList<>();
            for (int i = 0; i < original.m_77398_(); i++) {
                points.add(original.m_77375_(i));
            }
            return points;
        }
    }
}
