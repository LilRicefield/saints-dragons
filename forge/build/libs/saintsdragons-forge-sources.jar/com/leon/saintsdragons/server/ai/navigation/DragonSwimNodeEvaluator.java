package com.leon.saintsdragons.server.ai.navigation;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.PathNavigationRegion;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.pathfinder.Node;
import net.minecraft.world.level.pathfinder.SwimNodeEvaluator;
import org.jetbrains.annotations.NotNull;

/**
 * Swim node evaluator that is a little more permissive for large semi-aquatic dragons.
 * Keeps water traversal enabled while smoothing transitions when the mob breaches or
 * moves near the water surface.
 */
public class DragonSwimNodeEvaluator extends SwimNodeEvaluator {

    public DragonSwimNodeEvaluator() {
        super(true);
    }

    public void prepare(PathNavigationRegion region, PathfinderMob mob) {
        super.m_6028_(region, mob);
        mob.m_21441_(BlockPathTypes.WATER, 0.0F);
        mob.m_21441_(BlockPathTypes.WATER_BORDER, 0.0F);
    }

    @Override
    public @NotNull Node m_7171_() {
        // Bias start position toward the entity's mid-body rather than feet to reduce
        // thrashing when entering deep water.
        int y = Mth.m_14107_(this.f_77313_.m_20191_().f_82289_ + (this.f_77313_.m_20206_() * 0.5D));
        BlockPos pos = BlockPos.m_274446_(this.f_77313_.m_20182_());
        FluidState fluid = this.f_77313_.m_9236_().m_6425_(pos);
        if (fluid.m_76178_()) {
            // Slide downward until we find the first fluid column so the path starts underwater
            BlockPos down = pos.m_122032_();
            while (down.m_123342_() > this.f_77313_.m_9236_().m_141937_()) {
                down = down.m_7495_();
                if (!this.f_77313_.m_9236_().m_6425_(down).m_76178_()) {
                    pos = down;
                    y = down.m_123342_();
                    break;
                }
            }
        }
        return super.m_5676_(pos.m_123341_(), y, pos.m_123343_());
    }

    public BlockPathTypes getBlockPathType(BlockGetter level, int x, int y, int z, PathfinderMob mob) {
        BlockPathTypes type = super.m_7209_(level, x, y, z, mob);
        if (type == BlockPathTypes.WATER || type == BlockPathTypes.WATER_BORDER) {
            return BlockPathTypes.WATER;
        }
        if (type == BlockPathTypes.BREACH) {
            return BlockPathTypes.WATER;
        }
        if (type == BlockPathTypes.OPEN) {
            BlockState state = level.m_8055_(BlockPos.m_274561_(x, y, z));
            if (!state.m_60819_().m_76178_()) {
                return BlockPathTypes.WATER;
            }
        }
        return type;
    }
}

