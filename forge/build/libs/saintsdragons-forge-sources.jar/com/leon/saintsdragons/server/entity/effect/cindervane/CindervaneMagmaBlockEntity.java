package com.leon.saintsdragons.server.entity.effect.cindervane;

import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.server.entity.dragons.cindervane.Cindervane;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.List;

public class CindervaneMagmaBlockEntity extends Entity {
    private static final EntityDataAccessor<BlockState> DATA_BLOCK_STATE =
            SynchedEntityData.m_135353_(CindervaneMagmaBlockEntity.class, EntityDataSerializers.f_135034_);

    private Cindervane owner;
    private double impactRadius;
    private float impactDamage;
    private int lifetimeTicks;
    private int livedTicks;

    public CindervaneMagmaBlockEntity(EntityType<? extends CindervaneMagmaBlockEntity> type, Level level) {
        super(type, level);
        this.f_19850_ = true;
        this.m_6210_();
    }

    public CindervaneMagmaBlockEntity(Level level, Vec3 pos, Cindervane owner,
                                      double impactRadius, float impactDamage, int lifetimeTicks) {
        this(ModEntities.CINDERVANE_MAGMA_BLOCK.get(), level);
        this.m_146884_(pos);
        this.owner = owner;
        this.impactRadius = impactRadius;
        this.impactDamage = impactDamage;
        this.lifetimeTicks = lifetimeTicks;
        this.m_20256_(Vec3.f_82478_);
        this.setBlockState(Blocks.f_50450_.m_49966_());
        this.m_6210_();
    }

    @Override
    protected void m_8097_() {
        this.f_19804_.m_135372_(DATA_BLOCK_STATE, Blocks.f_50450_.m_49966_());
    }

    public void setFiringProperties(Cindervane owner, double impactRadius, float impactDamage, int lifetimeTicks) {
        this.owner = owner;
        this.impactRadius = impactRadius;
        this.impactDamage = impactDamage;
        this.lifetimeTicks = lifetimeTicks;
    }

    public void setBlockState(BlockState state) {
        this.f_19804_.m_135381_(DATA_BLOCK_STATE, state);
    }

    public BlockState getBlockState() {
        return this.f_19804_.m_135370_(DATA_BLOCK_STATE);
    }

    @Override
    public void m_8119_() {
        // Don't call super.tick() - handle movement manually like FallingBlockEntity does

        if (this.getBlockState().m_60795_()) {
            m_146870_();
            return;
        }

        livedTicks++;

        // Apply gravity (on both sides for smooth client prediction)
        if (!this.m_20068_()) {
            this.m_20256_(this.m_20184_().m_82520_(0.0D, -0.04D, 0.0D));
        }

        // Move (on both sides)
        this.m_6478_(MoverType.SELF, this.m_20184_());

        // Server-side logic only
        if (!m_9236_().f_46443_) {
            // Apply air resistance
            this.m_20256_(this.m_20184_().m_82490_(0.98D));

            // Check lifetime
            if (livedTicks > lifetimeTicks) {
                explode();
                return;
            }

            // Check for ground impact
            if (this.m_20096_()) {
                Vec3 motion = this.m_20184_();
                this.m_20334_(motion.f_82479_ * 0.7D, -motion.f_82480_ * 0.5D, motion.f_82481_ * 0.7D);
                explode();
                return;
            }
        } else {
            // Client-side: apply same air resistance for prediction
            this.m_20256_(this.m_20184_().m_82490_(0.98D));

            // Spawn trail particles
            spawnTrailParticles();
        }
    }

    private void spawnTrailParticles() {
        m_9236_().m_7106_(ParticleTypes.f_123744_, m_20185_(), m_20186_() + 0.2D, m_20189_(), 0.0D, 0.011D, 0.0D);
        m_9236_().m_7106_(ParticleTypes.f_175834_, m_20185_(), m_20186_() + 0.2D, m_20189_(), 0.0D, 0.003D, 0.0D);
        m_9236_().m_7106_(ParticleTypes.f_123801_, m_20185_(), m_20186_(), m_20189_(), 0.0D, -0.035D, 0.0D);
    }

    private void explode() {
        if (!(m_9236_() instanceof ServerLevel server)) {
            m_146870_();
            return;
        }

        Vec3 impact = m_20182_();
        server.m_8767_(ParticleTypes.f_123756_, impact.f_82479_, impact.f_82480_ + 0.5D, impact.f_82481_, 18,
                0.5D, 0.3D, 0.5D, 0.04D);
        server.m_8767_(ParticleTypes.f_123744_, impact.f_82479_, impact.f_82480_ + 0.5D, impact.f_82481_, 30,
                0.6D, 0.4D, 0.6D, 0.08D);
        server.m_5594_(null, m_20183_(), SoundEvents.f_11913_, m_5720_(), 0.7F, 1.1F);

        AABB area = new AABB(impact.f_82479_ - impactRadius, impact.f_82480_ - impactRadius, impact.f_82481_ - impactRadius,
                impact.f_82479_ + impactRadius, impact.f_82480_ + impactRadius, impact.f_82481_ + impactRadius);
        List<net.minecraft.world.entity.LivingEntity> hits = server.m_6443_(net.minecraft.world.entity.LivingEntity.class, area,
                target -> target.m_6084_() && target != owner && (owner == null || !owner.isAlly(target)));

        for (net.minecraft.world.entity.LivingEntity target : hits) {
            target.m_6469_(server.m_269111_().m_269036_(this, owner != null ? owner : this), impactDamage);
            target.m_20254_(4);
        }

        igniteArea(server, BlockPos.m_274446_(impact));
        m_146870_();
    }

    private void igniteArea(ServerLevel server, BlockPos base) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos pos = base.m_7918_(dx, 0, dz);
                BlockState state = server.m_8055_(pos);
                if (!state.m_60795_()) continue;

                BlockPos below = pos.m_7495_();
                BlockState belowState = server.m_8055_(below);
                if (!belowState.m_60795_() && Blocks.f_50083_.m_49966_().m_60710_(server, pos)) {
                    server.m_7731_(pos, Blocks.f_50083_.m_49966_(), 11);
                }
            }
        }
    }

    @Override
    protected void m_7378_(@NotNull CompoundTag tag) {
        this.livedTicks = tag.m_128451_("Lived");
        this.lifetimeTicks = tag.m_128451_("Lifetime");
        this.impactRadius = tag.m_128459_("ImpactRadius");
        this.impactDamage = tag.m_128457_("ImpactDamage");
        if (tag.m_128425_("BlockState", CompoundTag.f_178203_) && m_9236_() instanceof ServerLevel server) {
            BlockState state = NbtUtils.m_247651_(server.m_246945_(net.minecraft.core.registries.Registries.f_256747_), tag.m_128469_("BlockState"));
            setBlockState(state.m_60795_() ? Blocks.f_50450_.m_49966_() : state);
        }
    }

    @Override
    protected void m_7380_(@NotNull CompoundTag tag) {
        tag.m_128405_("Lived", livedTicks);
        tag.m_128405_("Lifetime", lifetimeTicks);
        tag.m_128347_("ImpactRadius", impactRadius);
        tag.m_128350_("ImpactDamage", impactDamage);
        tag.m_128365_("BlockState", NbtUtils.m_129202_(getBlockState()));
    }

    @Override
    public Packet<ClientGamePacketListener> m_5654_() {
        return new ClientboundAddEntityPacket(this);
    }

    @Override
    public void m_141965_(ClientboundAddEntityPacket packet) {
        super.m_141965_(packet);
        // Restore velocity from packet
        this.m_20334_(packet.m_131503_(), packet.m_131504_(), packet.m_131505_());
    }

    @Override
    public boolean m_6087_() {
        return true;
    }

    @Override
    public boolean m_6783_(double distance) {
        // Render up to 64 blocks away
        return distance < 4096.0D;
    }

    @Override
    protected boolean m_7310_(Entity passenger) {
        return false;
    }

    @Override
    public boolean m_6051_() {
        return false;
    }

    @Override
    public boolean m_6469_(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (source.m_269533_(net.minecraft.tags.DamageTypeTags.f_268738_)) {
            return super.m_6469_(source, amount);
        }
        return false;
    }

    @Override
    public double m_6048_() {
        return -0.2D;
    }

    @Override
    public boolean m_6673_(net.minecraft.world.damagesource.DamageSource source) {
        return !source.m_269533_(net.minecraft.tags.DamageTypeTags.f_268738_);
    }

    @Override
    public float m_20236_(@NotNull Pose pose) {
        return 0.5F;
    }

    @Override
    public EntityDimensions m_6972_(@NotNull Pose pose) {
        return EntityDimensions.m_20398_(0.98F, 0.98F);
    }

    @Nullable
    public Cindervane getOwner() {
        return owner;
    }
}
