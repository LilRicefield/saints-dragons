package com.leon.saintsdragons.server.entity.controller.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import static com.leon.saintsdragons.server.entity.dragons.raevyx.handlers.RaevyxConstantsHandler.*;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;

/**
 * Clean physics controller for Raevyx - simple and maintainable
 */
public class RaevyxPhysicsController {
    private final Raevyx wyvern;
    // Takeoff animation timing tuning
    private static final int TAKEOFF_ANIM_MAX_TICKS = 24;   // previously 30
    private static final int TAKEOFF_ANIM_EARLY_TICKS = 16; // start even sooner once airborne

    // Physics envelopes for renderer effects
    private final Envelope01 glideEnv = new Envelope01(0.25f, 0.25f);
    private final Envelope01 flapEnv  = new Envelope01(0.25f, 0.18f);
    private final Envelope01 hoverEnv = new Envelope01(0.40f, 0.15f);

    // Animation fraction values for smooth blending
    public float glidingFraction = 0f;
    public float prevGlidingFraction = 0f;
    public float flappingFraction = 0f;
    public float prevFlappingFraction = 0f;
    public float hoveringFraction = 0f;
    public float prevHoveringFraction = 0f;

    // Flight animation state tracking
    private RawAnimation currentFlightAnimation = FLY_GLIDE;

    // ===== Envelopes and lift model =====
    public static class Envelope01 {
        private float val = 0f;
        private float prev = 0f;
        private final float upRate;
        private final float downRate;
        public Envelope01(float upRate, float downRate) { this.upRate = upRate; this.downRate = downRate; }
        public void tickToward(float target) {
            prev = val;
            float rate = target > val ? upRate : downRate;
            val += (target - val) * rate;
            if (val < 0f) val = 0f; else if (val > 1f) val = 1f;
        }
        public float raw() { return val; }
        public float get(float pt) { return Mth.m_14179_(pt, prev, val); }
        public void setRaw(float v) { prev = val = Mth.m_14036_(v, 0f, 1f); }
    }

    // Physics envelopes enabled by default
    private static final float MASS = 1.3f;
    private static final float LIFT_K = 11.0f;
    private static final float CLIMB_COST = 6.0f;
    private static final float RESPONSE = 1.5f;
    public RaevyxPhysicsController(Raevyx wyvern) {
        this.wyvern = wyvern;
    }

    /**
     * Main tick method - call this from your entity's tick()
     */
    public void tick() {
        // Store previous values for interpolation
        prevGlidingFraction = glidingFraction;
        prevFlappingFraction = flappingFraction;
        prevHoveringFraction = hoveringFraction;

        updatePhysicsEnvelopes();
    }

    public PlayState handleMovementAnimation(AnimationState<Raevyx> state) {
        // Default transition length (safe baseline); override per-branch below
        state.getController().transitionLength(6);

        // PRIORITY: Handle dying and sleeping FIRST (applies to both baby and adult)
        if (wyvern.isDying() || wyvern.m_5803_() || wyvern.isSleepingEntering() || wyvern.isSleepingExiting()) {
            return PlayState.STOP;
        }

        // PRIORITY: Handle sitting BEFORE baby check (applies to both baby and adult)
        // Drive SIT from our custom progress system only to avoid desync
        float maxSit = wyvern.maxSitTicks();
        float sitProgress = wyvern.getSitProgress();

        if (sitProgress >= maxSit) {
            // Fully sitting - play SIT loop
            state.setAndContinue(SIT);
            return PlayState.CONTINUE;
        } else if (sitProgress > 0f) {
            // In transition (either sitting down or standing up) - let action controller handle it
            return PlayState.STOP;
        }

        // BABY dragons use simple idle/walk/run only (no flying, no complex behaviors)
        // NOTE: Uses same animation names as adult - renderer switches JSON file based on isBaby()
        if (wyvern.m_6162_()) {
            if (wyvern.isActuallyRunning()) {
                state.getController().transitionLength(3);
                state.setAndContinue(GROUND_RUN);
            } else if (wyvern.isWalking()) {
                state.getController().transitionLength(3);
                state.setAndContinue(GROUND_WALK);
            } else {
                state.getController().transitionLength(4);
                state.setAndContinue(GROUND_IDLE);
            }
            return PlayState.CONTINUE;
        }

        // ADULT-ONLY animations below (babies returned above)
        if (wyvern.isDodging()) {
            state.setAndContinue(DODGE);
        } else if (wyvern.isLanding()) {
            state.setAndContinue(LANDING);
        } else if (wyvern.m_29443_()) {
            // Prefer server-synced flight mode when available for observer consistency
            int syncedMode = wyvern.getSyncedFlightMode();
            Vec3 vNow = wyvern.m_20184_();
            if (syncedMode == 3) {
                state.getController().transitionLength(4);
                state.setAndContinue(TAKEOFF);
                return PlayState.CONTINUE;
            }
            if (wyvern.isRiderLandingBlendActive()) {
                state.getController().transitionLength(4);
                currentFlightAnimation = LANDING;
                state.setAndContinue(LANDING);
                return PlayState.CONTINUE;
            }

            boolean manualRiderControl = wyvern.m_21824_() && wyvern.m_20160_();
            if (manualRiderControl) {
                // Check if actually moving to determine hover vs active flight
                Vec3 vel = wyvern.m_20184_();
                boolean isMovingHorizontally = vel.m_165925_() > 0.01;
                boolean isMovingVertically = Math.abs(vel.f_82480_) > 0.02;
                boolean isStationary = !isMovingHorizontally && !isMovingVertically;

                // GLIDE_DOWN - absolute priority, nothing overrides diving
                if (wyvern.isGoingDown() && !wyvern.isRiderLandingBlendActive()) {
                    RawAnimation descend = GLIDE_DOWN;
                    if (currentFlightAnimation != descend) {
                        state.getController().transitionLength(6);
                        currentFlightAnimation = descend;
                    }
                    state.setAndContinue(descend);
                    return PlayState.CONTINUE;
                }

                // HOVER - second priority: truly stationary in air (no input or holding position)
                if (isStationary) {
                    RawAnimation hover = FLAP;
                    if (currentFlightAnimation != hover) {
                        state.getController().transitionLength(6);
                        currentFlightAnimation = hover;
                    }
                    state.setAndContinue(hover);
                    return PlayState.CONTINUE;
                }

                // SPRINT FLYING - third priority (after dive and hover)
                // Only play sprint animation if actually moving
                if (wyvern.isAccelerating() && isMovingHorizontally) {
                    RawAnimation sprint = SPRINT_FLAP;
                    if (currentFlightAnimation != sprint) {
                        state.getController().transitionLength(3);
                        currentFlightAnimation = sprint;
                    }
                    state.setAndContinue(sprint);
                    return PlayState.CONTINUE;
                }

                // ASCENDING - fourth priority
                if (wyvern.isGoingUp()) {
                    RawAnimation upward = FLAP;
                    if (currentFlightAnimation != upward) {
                        state.getController().transitionLength(4);
                        currentFlightAnimation = upward;
                    }
                    state.setAndContinue(upward);
                    return PlayState.CONTINUE;
                }
            }
            if (syncedMode == 2) {
                // Stationary/hover: play dedicated air hover clip
                state.getController().transitionLength(6);
                state.setAndContinue(FLAP);
                return PlayState.CONTINUE;
            }
            if (syncedMode == 1) {
                // Mode 1 = FLAP (low altitude or physics demands flapping)
                state.getController().transitionLength(4);
                state.setAndContinue(FLAP);
                return PlayState.CONTINUE;
            }
            if (syncedMode == 0) {
                // Server says GLIDE: evaluate descend heuristics for tamed dragons
                // Longer transition for smoother high-altitude gliding feel
                state.getController().transitionLength(12);
                state.setAndContinue(resolveGlideAnimation(vNow));
                return PlayState.CONTINUE;
            }

            if (shouldPlayTakeoff()) {
                // Snappier blend into takeoff when leaving ground
                state.getController().transitionLength(4);
                state.setAndContinue(TAKEOFF);
            } else {
                // HYSTERESIS - prevent rapid switching between animations
                float hoverWeight = hoveringFraction;
                float flapWeight = flappingFraction;

                boolean descendingNow = vNow.f_82480_ < -0.03;
                if (wyvern.m_20160_()) {
                    descendingNow |= wyvern.isGoingDown();
                } else {
                    descendingNow |= wyvern.getPitchDirection() > 0;
                }

                // Base thresholds for entering/exiting flap (without locks)
                boolean shouldFlapBase = (currentFlightAnimation == FLAP)
                        ? (flapWeight > 0.55f || hoverWeight > 0.65f) // Higher threshold to stay flapping
                        : (flapWeight > 0.22f || hoverWeight > 0.28f); // Lower threshold to enter flapping

                // If we are clearly in hover without a synced mode (fallback), play air hover
                if (hoverWeight > 0.45f) {
                    state.getController().transitionLength(6);
                    currentFlightAnimation = FLAP;
                    state.setAndContinue(FLAP);
                    return PlayState.CONTINUE;
                }

                // PHYSICS-BASED: Use flap/glide envelope weights
                boolean ascendingNow = wyvern.isGoingUp() || vNow.f_82480_ > 0.02;

                // Always flap when ascending
                if (ascendingNow) {
                    if (currentFlightAnimation != FLAP) {
                        state.getController().transitionLength(4);
                        currentFlightAnimation = FLAP;
                    }
                    state.setAndContinue(FLAP);
                }
                // Use physics envelope to decide
                else if (shouldFlapBase) {
                    if (currentFlightAnimation != FLAP) {
                        state.getController().transitionLength(4);
                        currentFlightAnimation = FLAP;
                    }
                    state.setAndContinue(FLAP);
                } else {
                    // Default to gliding when not ascending and physics doesn't demand flapping
                    RawAnimation glideAnimation = resolveGlideAnimation(vNow);
                    if (currentFlightAnimation != glideAnimation) {
                        state.getController().transitionLength(8);
                        currentFlightAnimation = glideAnimation;
                    }
                    state.setAndContinue(glideAnimation);
                }
            }
        } else {
            // Ground movement transitions tuned to be snappier
            if (wyvern.isActuallyRunning()) {
                state.getController().transitionLength(3); // even faster into run
                state.setAndContinue(GROUND_RUN);
            } else if (wyvern.isWalking()) {
                state.getController().transitionLength(3); // quicker walk engage/disengage
                state.setAndContinue(GROUND_WALK);
            } else {
                state.getController().transitionLength(4); // slightly softer into idle
                state.setAndContinue(GROUND_IDLE);
            }
        }
        return PlayState.CONTINUE;
    }

    private boolean shouldPlayTakeoff() {
        // Play takeoff at the very start of flight, and also as soon as we clear the ground or start ascending
        if (wyvern.timeFlying < TAKEOFF_ANIM_EARLY_TICKS) return true;

        boolean airborne = !wyvern.m_20096_();
        boolean ascending = wyvern.m_20184_().f_82480_ > 0.08;

        return (wyvern.timeFlying < TAKEOFF_ANIM_MAX_TICKS) && (airborne || ascending);
    }

    private void updatePhysicsEnvelopes() {
        Vec3 v = wyvern.m_20184_();
        float vH = (float)Math.hypot(v.f_82479_, v.f_82481_);
        float vY = (float)v.f_82480_;

        float glideLift = LIFT_K * vH * vH;
        float climbNeed = vY > 0 ? (vY * CLIMB_COST) : 0f;
        float need = MASS + climbNeed - glideLift;

        float flapTarget = need <= 0 ? 0f : (need / (need + RESPONSE));
        flapTarget = Mth.m_14036_(flapTarget, 0f, 1f);

        // Treat hover as a near-stationary state: only when horizontal speed is tiny AND vertical nearly zero,
        // or when explicitly flagged (hovering/landing/beaming)
        float hoverTarget = (
                wyvern.isHovering() || wyvern.isLanding() || wyvern.isBeaming() ||
                (vH < 0.02f && Math.abs(vY) < 0.02f)
        ) ? 1f : 0f;
        float glideTarget = Mth.m_14036_(1f - flapTarget, 0.15f, 1f);

        // Explicit ascent bias so climbing always triggers visible flaps
        // Rider-controlled ascent
        if (wyvern.m_29443_()) {
            if (wyvern.m_6688_() != null && wyvern.isGoingUp()) {
                flapTarget = Math.max(flapTarget, 0.6f);
            } else if (vY > 0.06f) {
                // AI/physics ascent: scale bias by vertical speed
                float ascentBias = Mth.m_14036_((vY - 0.02f) * 3.0f, 0.2f, 0.8f);
                flapTarget = Math.max(flapTarget, ascentBias);
            }
            // Recompute glide target after bias
            glideTarget = Mth.m_14036_(1f - flapTarget, 0.15f, 1f);
        }

        flapEnv.tickToward(flapTarget);
        hoverEnv.tickToward(hoverTarget);
        glideEnv.tickToward(glideTarget);

        // Update animation fractions for renderer from envelopes
        glidingFraction = glideEnv.raw();
        flappingFraction = flapEnv.raw();
        hoveringFraction = hoverEnv.raw();
    }

    private RawAnimation resolveGlideAnimation(Vec3 velocity) {
        if (!wyvern.m_21824_()) {
            return FLY_GLIDE;
        }

        Vec3 motion = velocity == null ? Vec3.f_82478_ : velocity;
        double verticalSpeed = motion.f_82480_;
        double horizontalSpeedSqr = motion.m_165925_();

        boolean riderDescending = wyvern.m_20160_() && wyvern.isGoingDown();
        boolean pitchingDown = !wyvern.m_20160_() && wyvern.getPitchDirection() > 0;
        boolean fallingFast = verticalSpeed < -0.06;
        boolean moderateDescent = verticalSpeed < -0.025;
        boolean sustainedGlide = glidingFraction > 0.18f || flapEnv.raw() < 0.35f;
        boolean hasForwardSpeed = horizontalSpeedSqr > 0.0009;

        if ((pitchingDown || riderDescending || fallingFast || moderateDescent) && sustainedGlide && hasForwardSpeed) {
            return GLIDE_DOWN;
        }

        return FLY_GLIDE;
    }

    // ===== SAVE/LOAD SUPPORT =====
    public void writeToNBT(net.minecraft.nbt.CompoundTag tag) {
        // Store envelope values (authoritative for physics system)
        tag.m_128350_("GlideVal", glideEnv.raw());
        tag.m_128350_("FlapVal", flapEnv.raw());
        tag.m_128350_("HoverVal", hoverEnv.raw());
    }

    public void readFromNBT(net.minecraft.nbt.CompoundTag tag) {
        // Restore all animation state after load
        if (tag.m_128441_("GlideVal")) {
            glideEnv.setRaw(tag.m_128457_("GlideVal"));
            flapEnv.setRaw(tag.m_128457_("FlapVal"));
            hoverEnv.setRaw(tag.m_128457_("HoverVal"));
        }

        glidingFraction = glideEnv.raw();
        flappingFraction = flapEnv.raw();
        hoveringFraction = hoverEnv.raw();

        prevGlidingFraction = glidingFraction;
        prevFlappingFraction = flappingFraction;
        prevHoveringFraction = hoveringFraction;
    }
}
