package com.leon.saintsdragons.server.ai.goals.raevyx;

import com.leon.saintsdragons.server.entity.dragons.raevyx.Raevyx;
import com.leon.saintsdragons.util.DragonMathUtil;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * - picks the projectile MOST moving toward us (dot product)
 * - chooses the better lateral side (left/right)
 * - predicts impact line and initiates a multi-tick dodge burst via entity.beginDodge(...)
 */
public class RaevyxDodgeGoal extends Goal {
    private final Raevyx wyvern;

    // tuning
    private static final double SCAN_RADIUS_H = 32.0;
    private static final double SCAN_RADIUS_V = 22.0;
    private static final int    SCAN_INTERVAL = 2;     // faster scans
    private static final int    DODGE_TICKS   = 9;     // slightly longer dodge burst
    private static final int    COOLDOWN      = 8;     // reduced cooldown between dodges

    private static final double DOT_THREAT    = 0.65;  // more permissive threat angle
    private static final double MIN_SPEED2    = 0.0015; // accept slightly slower projectiles

    // Dodge impulse constants - flight only
    private static final double DODGE_LAT_IMPULSE = 0.80;
    private static final double DODGE_UP_IMPULSE  = 0.40;

    private long nextScanTime = 0L;
    private long nextAllowedDodgeTime = 0L; // <-- time-based cooldown

    private List<Projectile> getCachedThreats() {
        return wyvern.getCachedNearbyProjectiles().stream()
                .filter(p -> p.m_6084_() &&
                        p.m_19749_() != wyvern &&
                        p.m_19749_() != wyvern.m_269323_() &&
                        p.m_20184_().m_82556_() > MIN_SPEED2)
                .collect(Collectors.toList());
    }

    public RaevyxDodgeGoal(Raevyx wyvern) {
        this.wyvern = wyvern;
        this.m_7021_(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean m_8036_() {
        if (!wyvern.m_6084_()) return false;
        if (wyvern.m_21824_() && wyvern.m_20160_()) return false;
        if (wyvern.isDodging()) return false;
        if (!wyvern.m_29443_()) return false;

        long now = wyvern.m_9236_().m_46467_();
        if (now < nextScanTime) return false;
        nextScanTime = now + SCAN_INTERVAL;

        if (now < nextAllowedDodgeTime) return false;

        // Use cached nearby projectiles for better performance
        List<Projectile> threats = getCachedThreats().stream()
                .filter(p -> DragonMathUtil.hasLineOfSight(wyvern, p)) // prefer LOS
                .collect(Collectors.toList());

        // If none pass LOS (e.g., player between us and projectile), fall back to no-LOS set
        if (threats.isEmpty()) {
            threats = getCachedThreats();
        }

        Projectile mostThreatening = mostMovingTowardMeFromList(threats, wyvern);
        if (mostThreatening == null) return false;

        Vec3 dv = new Vec3(
                mostThreatening.m_20185_() - mostThreatening.f_19854_,
                mostThreatening.m_20186_() - mostThreatening.f_19855_,
                mostThreatening.m_20189_() - mostThreatening.f_19856_
        );

        if (dv.m_82556_() < MIN_SPEED2) return false;

        // Use dodge calculation function instead of manually doing it
        Vec3 dodgeDirection = DragonMathUtil.calculateDodgeDirection(wyvern, mostThreatening);

        if (dodgeDirection.equals(Vec3.f_82478_)) return false;

        // Since we only dodge when flying, use flight constants directly
        Vec3 dodgeVec = new Vec3(
                dodgeDirection.f_82479_ * DODGE_LAT_IMPULSE,
                DODGE_UP_IMPULSE,
                dodgeDirection.f_82481_ * DODGE_LAT_IMPULSE
        );

        dodgeVec = DragonMathUtil.clampVectorLength(dodgeVec, 1.5); // Max dodge strength

        wyvern.beginDodge(dodgeVec, DODGE_TICKS);
        nextAllowedDodgeTime = now + COOLDOWN;
        return true;
    }

    @Override
    public void m_8056_() {
        wyvern.m_21573_().m_26573_();
        // Trigger dodge animation every time
        wyvern.triggerDodgeAnimation();
        // Play annoyed sound when dodging attacks
        wyvern.playAnnoyedSound();
    }

    @Override public boolean m_8045_() { return false; }
    @Override public void m_8041_() { /* nothing; cooldown is time-based */ }

    // ========== HELPERS ==========

    private Vec3 guessProjectileDestination(Projectile projectile) {
        Vec3 from = projectile.m_20182_();
        Vec3 vel  = projectile.m_20184_();
        if (vel.m_82556_() < 1.0e-6) return from;
        Vec3 to   = from.m_82549_(vel.m_82490_(50)); // long ray
        return projectile.m_9236_().m_45547_(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, projectile)).m_82450_();
    }

    @Nullable
    private <T extends Projectile> T mostMovingTowardMe(Class<? extends T> cls,
                                                        Predicate<? super T> pred,
                                                        LivingEntity me,
                                                        AABB box) {
        return mostMovingTowardMeFromList(me.m_9236_().m_6443_(cls, box, pred), me);
    }

    private <T extends Projectile> T mostMovingTowardMeFromList(List<? extends T> entities, LivingEntity me) {
        double best = DOT_THREAT;
        T bestEnt = null;
        for (T p : entities) {
            Vec3 dv = new Vec3(p.m_20185_() - p.f_19854_, p.m_20186_() - p.f_19855_, p.m_20189_() - p.f_19856_);
            double ls = dv.m_82556_();
            if (ls < MIN_SPEED2) continue;
            double dot = dv.m_82541_().m_82526_(me.m_20182_().m_82546_(p.m_20182_()).m_82541_());
            if (dot > best) { best = dot; bestEnt = p; }
        }
        return bestEnt;
    }
}
