package com.leon.saintsdragons.server.ai.navigation;

import com.leon.saintsdragons.server.entity.interfaces.AquaticDragon;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.phys.Vec3;

/**
 * Smooth aquatic movement controller used while a wyvern relies on {@link DragonAmphibiousNavigation}.
 * Based on Critters & Companions' Otter movement system - uses movement intention values (zza/yya)
 * instead of direct velocity manipulation to prevent jittering.
 */
public class DragonSwimMoveControl extends MoveControl {

    private final Mob mob;
    private final float yawLimit;
    private final double accelerationScale;
    private final double speedBoost;

    public DragonSwimMoveControl(Mob mob, float yawLimitDegrees, double accelerationScale, double speedBoost) {
        super(mob);
        this.f_24974_ = mob;
        this.yawLimit = yawLimitDegrees;
        this.accelerationScale = accelerationScale;
        this.speedBoost = speedBoost;
    }

    @Override
    public void m_8126_() {
        // Only control movement when in water and not being ridden
        if (this.f_24981_ != Operation.MOVE_TO || this.f_24974_.m_20159_() || !this.f_24974_.m_20069_()) {
            this.f_24981_ = Operation.WAIT;
            this.f_24974_.m_21564_(0.0F);
            this.f_24974_.m_21567_(0.0F);
            this.f_24974_.m_21570_(0.0F);
            return;
        }

        // Calculate direction to target
        double dx = this.f_24975_ - this.f_24974_.m_20185_();
        double dy = this.f_24976_ - this.f_24974_.m_20186_();
        double dz = this.f_24977_ - this.f_24974_.m_20189_();
        double distanceSqr = dx * dx + dy * dy + dz * dz;

        // If very close to target, stop moving
        if (distanceSqr < 2.5000003E-7F) {
            this.f_24974_.m_21564_(0.0F);
            this.f_24974_.m_21567_(0.0F);
            this.f_24981_ = Operation.WAIT;
            return;
        }

        // Calculate target yaw (horizontal rotation)
        float targetYaw = (float) (Mth.m_14136_(dz, dx) * Mth.f_144834_) - 90.0F;
        this.f_24974_.m_146922_(m_24991_(this.f_24974_.m_146908_(), targetYaw, yawLimit));
        this.f_24974_.f_20883_ = this.f_24974_.m_146908_();
        this.f_24974_.f_20885_ = this.f_24974_.m_146908_();

        // Calculate speed - amplify for swimming (dragons are large and need more power)
        float baseSpeed = (float) (this.f_24978_ * this.f_24974_.m_21133_(Attributes.f_22279_));
        this.f_24974_.m_7910_(baseSpeed * 0.2F);  // Entity speed (for physics)

        // Calculate pitch (vertical rotation) - angle from horizontal to target
        double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
        if (Math.abs(dy) > 1.0E-5F || Math.abs(horizontalDistance) > 1.0E-5F) {
            float targetPitch = -((float) (Mth.m_14136_(dy, horizontalDistance) * Mth.f_144834_));
            targetPitch = Mth.m_14036_(Mth.m_14177_(targetPitch), -85.0F, 85.0F);
            this.f_24974_.m_146926_(m_24991_(this.f_24974_.m_146909_(), targetPitch, yawLimit * 0.5F));
        }

        // Set movement intention values using pitch
        // BOOST the intention values significantly for large aquatic creatures
        // Otters are small, dragons are MASSIVE and need more power to move through water
        float pitchRad = this.f_24974_.m_146909_() * Mth.f_144833_;
        float cosXRot = Mth.m_14089_(pitchRad);
        float sinXRot = Mth.m_14031_(pitchRad);

        // Apply significant boost to movement intention (5x multiplier for large creature)
        float amplifiedSpeed = baseSpeed * 5.0F;
        this.f_24974_.f_20902_ = cosXRot * amplifiedSpeed;      // Horizontal forward component
        this.f_24974_.f_20901_ = -sinXRot * amplifiedSpeed;     // Vertical component

        // Add small upward push when target is above to help fight gravity
        if (dy > 0.5D && horizontalDistance < 2.0D) {
            this.f_24974_.m_20256_(this.f_24974_.m_20184_().m_82520_(0.0D, 0.015D, 0.0D));
        }
    }

    private double getNaturalSwimSpeed(Mob mob) {
        if (mob instanceof AquaticDragon dragon) {
            return dragon.getSwimSpeed() + speedBoost;
        }
        return 0.6D + speedBoost;
    }

    @Override
    protected float m_24991_(float current, float target, float maxDelta) {
        float delta = Mth.m_14177_(target - current);
        delta = Mth.m_14036_(delta, -maxDelta, maxDelta);
        return current + delta;
    }
}

