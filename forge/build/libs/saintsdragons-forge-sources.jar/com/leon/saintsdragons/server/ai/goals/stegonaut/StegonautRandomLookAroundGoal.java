package com.leon.saintsdragons.server.ai.goals.stegonaut;

import com.leon.saintsdragons.server.entity.dragons.stegonaut.Stegonaut;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;

/**
 * Custom RandomLookAroundGoal for Primitive Drake that respects play dead state
 */
public class StegonautRandomLookAroundGoal extends RandomLookAroundGoal {
    private final Stegonaut drake;

    public StegonautRandomLookAroundGoal(Stegonaut drake) {
        super(drake);
        this.drake = drake;
    }

    @Override
    public boolean m_8036_() {
        // Don't look around while playing dead
        if (false) {
            return false;
        }
        return super.m_8036_();
    }

    @Override
    public boolean m_8045_() {
        // Stop looking around if start playing dead
        if (false) {
            return false;
        }
        return super.m_8045_();
    }
}
