/**
 * My name's Zap Van Dink. I'm a lightning wyvern.
 */
package com.leon.saintsdragons.server.entity.dragons.raevyx;

//Custom stuff
import com.leon.saintsdragons.common.particle.raevyx.*;
import com.leon.saintsdragons.common.registry.raevyx.RaevyxAbilities;
import com.leon.saintsdragons.server.ai.goals.raevyx.*;
import com.leon.saintsdragons.server.ai.goals.raevyx.baby.RaevyxFollowParentGoal;
import com.leon.saintsdragons.server.ai.navigation.DragonFlightMoveHelper;
import com.leon.saintsdragons.server.entity.controller.raevyx.RaevyxPhysicsController;
import com.leon.saintsdragons.server.entity.base.DragonEntity;
import com.leon.saintsdragons.server.entity.base.DragonGender;
import com.leon.saintsdragons.server.entity.base.RideableDragonBase;
import com.leon.saintsdragons.server.entity.interfaces.*;
import com.leon.saintsdragons.server.entity.controller.raevyx.RaevyxFlightController;
import com.leon.saintsdragons.server.entity.dragons.raevyx.handlers.RaevyxInteractionHandler;
import com.leon.saintsdragons.server.entity.dragons.raevyx.handlers.RaevyxAnimationHandler;
import com.leon.saintsdragons.server.entity.dragons.raevyx.handlers.RaevyxSoundProfile;
import static com.leon.saintsdragons.server.entity.dragons.raevyx.handlers.RaevyxConstantsHandler.*;

import com.leon.saintsdragons.server.entity.conductivity.ElectricalConductivityProfile;
import com.leon.saintsdragons.server.entity.conductivity.ElectricalConductivityState;
import com.leon.saintsdragons.server.entity.controller.raevyx.RaevyxRiderController;
import com.leon.saintsdragons.server.entity.handler.DragonSoundHandler;
import com.leon.saintsdragons.util.DragonMathUtil;
import com.leon.saintsdragons.server.entity.ability.DragonAbility;
import com.leon.saintsdragons.server.entity.ability.DragonAbilityType;
import com.leon.saintsdragons.common.registry.ModEntities;
import com.leon.saintsdragons.common.registry.ModSounds;
import com.leon.saintsdragons.common.registry.AbilityRegistry;
import com.leon.saintsdragons.common.network.DragonRiderAction;
//Minecraft
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.particles.ParticleTypes;


//GeckoLib
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.keyframe.event.SoundKeyframeEvent;

//WHO ARE THESE SUCKAS
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import javax.annotation.Nonnull;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

//Just everything
public class Raevyx extends RideableDragonBase implements FlyingAnimal, RangedAttackMob,
        DragonFlightCapable, DragonSleepCapable, ShakesScreen, SoundHandledDragon, ElectricalConductivityCapable {
    // ===== ENTITY DATA ACCESSORS =====

    /** Entity data accessor for flying state */
    public static final EntityDataAccessor<Boolean> DATA_FLYING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for takeoff state */
    public static final EntityDataAccessor<Boolean> DATA_TAKEOFF =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for hovering state */
    public static final EntityDataAccessor<Boolean> DATA_HOVERING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for landing state */
    public static final EntityDataAccessor<Boolean> DATA_LANDING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for running state */
    public static final EntityDataAccessor<Boolean> DATA_RUNNING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for ground move state (0=idle, 1=walk, 2=run) */
    public static final EntityDataAccessor<Integer> DATA_GROUND_MOVE_STATE =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135028_);

    /** Entity data accessor for flight mode (0=glide,1=forward,2=hover,3=takeoff,-1=ground) */
    public static final EntityDataAccessor<Integer> DATA_FLIGHT_MODE =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135028_);

    /** Entity data accessor for rider forward input */
    public static final EntityDataAccessor<Float> DATA_RIDER_FORWARD =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for rider strafe input */
    public static final EntityDataAccessor<Float> DATA_RIDER_STRAFE =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for screen shake amount */
    public static final EntityDataAccessor<Float> DATA_SCREEN_SHAKE_AMOUNT =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for beaming state */
    public static final EntityDataAccessor<Boolean> DATA_BEAMING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for rider landing blend active state */
    public static final EntityDataAccessor<Boolean> DATA_RIDER_LANDING_BLEND =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for rider controls locked state */
    public static final EntityDataAccessor<Boolean> DATA_RIDER_LOCKED =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for beam end position set flag */
    public static final EntityDataAccessor<Boolean> DATA_BEAM_END_SET =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for beam end X coordinate */
    public static final EntityDataAccessor<Float> DATA_BEAM_END_X =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for beam end Y coordinate */
    public static final EntityDataAccessor<Float> DATA_BEAM_END_Y =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for beam end Z coordinate */
    public static final EntityDataAccessor<Float> DATA_BEAM_END_Z =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for beam start position set flag */
    public static final EntityDataAccessor<Boolean> DATA_BEAM_START_SET =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for beam start X coordinate */
    public static final EntityDataAccessor<Float> DATA_BEAM_START_X =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for beam start Y coordinate */
    public static final EntityDataAccessor<Float> DATA_BEAM_START_Y =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for beam start Z coordinate */
    public static final EntityDataAccessor<Float> DATA_BEAM_START_Z =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135029_);

    /** Entity data accessor for going up state */
    public static final EntityDataAccessor<Boolean> DATA_GOING_UP =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for going down state */
    public static final EntityDataAccessor<Boolean> DATA_GOING_DOWN =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for accelerating state */
    public static final EntityDataAccessor<Boolean> DATA_ACCELERATING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for sleeping state */
    public static final EntityDataAccessor<Boolean> DATA_SLEEPING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for sleep enter transition state */
    public static final EntityDataAccessor<Boolean> DATA_SLEEPING_ENTERING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    /** Entity data accessor for sleep exit transition state */
    public static final EntityDataAccessor<Boolean> DATA_SLEEPING_EXITING =
            net.minecraft.network.syncher.SynchedEntityData.m_135353_(Raevyx.class, net.minecraft.network.syncher.EntityDataSerializers.f_135035_);

    // ===== OTHER CONSTANTS =====

    public static final float MAX_BEAM_YAW_DEG = 40.0f;
    public static final float MAX_BEAM_PITCH_DEG = 50.0f;


    // Simple per-field caches - more maintainable than generic system
    private double cachedOwnerDistance = Double.MAX_VALUE;
    private int ownerDistanceCacheTime = -1;
    private List<Projectile> cachedNearbyProjectiles = new java.util.concurrent.CopyOnWriteArrayList<>();
    private int nearbyProjectilesCacheTime = -1;
    private int projectileCacheIntervalTicks = 3; // dynamic backoff (min 3)
    private int emptyProjectileScans = 0;
    private double cachedHorizontalSpeed = 0.0;
    private int horizontalSpeedCacheTime = -1;
    private static final double RIDER_GLIDE_ALTITUDE_THRESHOLD = 40.0D;
    private static final double RIDER_GLIDE_ALTITUDE_EXIT = 30.0D; // Hysteresis: exit at lower altitude
    private static final double RIDER_LANDING_BLEND_ALTITUDE = 8.5D;
    private static final int RIDER_LANDING_BLEND_DURATION = 5; // ticks to keep landing blend active after triggering
    private boolean inHighAltitudeGlide = false; // Track glide state for smooth transitions
    private static final Map<String, VocalEntry> VOCAL_ENTRIES = new VocalEntryBuilder()
            .add("grumble1", "action", "animation.raevyx.grumble1", ModSounds.RAEVYX_GRUMBLE_1, 0.8f, 0.95f, 0.1f, false, false, false)
            .add("grumble2", "action", "animation.raevyx.grumble2", ModSounds.RAEVYX_GRUMBLE_2, 0.8f, 0.95f, 0.1f, false, false, false)
            .add("grumble3", "action", "animation.raevyx.grumble3", ModSounds.RAEVYX_GRUMBLE_3, 0.8f, 0.95f, 0.1f, false, false, false)
            .add("purr", "action", "animation.raevyx.purr", ModSounds.RAEVYX_PURR, 0.8f, 1.05f, 0.05f, true, false, true)
            .add("snort", "action", "animation.raevyx.snort", ModSounds.RAEVYX_SNORT, 0.9f, 0.9f, 0.2f, false, false, false)
            .add("chuff", "action", "animation.raevyx.chuff", ModSounds.RAEVYX_CHUFF, 0.9f, 0.9f, 0.2f, false, false, false)
            .add("content", "action", "animation.raevyx.content", ModSounds.RAEVYX_CONTENT, 0.8f, 1.0f, 0.1f, true, false, true)
            .add("excited", "action", "", ModSounds.RAEVYX_EXCITED, 1.0f, 1.0f, 0.3f, false, false, false)  // Sound-only, no animation
            .add("growl_warning", "action", "", ModSounds.RAEVYX_GROWL_WARNING, 1.2f, 0.8f, 0.4f, false, false, false)  // Sound-only, no animation
            .add("roar", "action", "animation.raevyx.roar", ModSounds.RAEVYX_ROAR, 1.4f, 0.9f, 0.15f, false, false, false)
            .add("roar_ground", "action", "animation.raevyx.roar_ground", ModSounds.RAEVYX_ROAR, 1.4f, 0.9f, 0.15f, false, false, false)
            .add("roar_air", "action", "animation.raevyx.roar_air", ModSounds.RAEVYX_ROAR, 1.4f, 0.9f, 0.15f, false, false, false)
            .add("raevyx_hurt", "hurt", "animation.raevyx.hurt", ModSounds.RAEVYX_HURT, 1.2f, 0.95f, 0.1f, true, true, true)
            .add("raevyx_die", "action", "animation.raevyx.die", ModSounds.RAEVYX_DIE, 1.5f, 0.95f, 0.1f, false, true, true)
            .add("baby_raevyx_hurt", "hurt", "animation.raevyx.hurt", ModSounds.BABY_RAEVYX_HURT, 1.4f, 1.05f, 0.15f, true, true, true)
            .add("baby_raevyx_die", "action", "animation.raevyx.die", ModSounds.BABY_RAEVYX_DIE, 1.3f, 1.0f, 0.1f, false, true, true)
            .build();

    private boolean manualSitCommand = false;
    private boolean commandChangeManual = false;
    private int riderLandingBlendTicks = 0;

    @Override
    public void setCommand(int command) {
        int previous = super.getCommand();
        super.setCommand(command);
        if (command == 1) {
            this.manualSitCommand = this.commandChangeManual || this.manualSitCommand;
        } else {
            this.manualSitCommand = false;
        }
        this.commandChangeManual = false;
    }

    public void setCommandManual(int command) {
        this.commandChangeManual = true;
        this.setCommand(command);
    }

    public void setCommandAuto(int command) {
        this.commandChangeManual = false;
        this.setCommand(command);
    }

    // ===== AMBIENT SOUND SYSTEM =====
    private int ambientSoundTimer;
    private int nextAmbientSoundDelay;
    // ===== SCREEN SHAKE SYSTEM =====
    private float prevScreenShakeAmount = 0.0F;
    private float screenShakeAmount = 0.0F;
    // ===== ENTITY DATA HELPER METHODS =====
    /**
     * Helper method for boolean entity data access
     */
    private boolean getBooleanData(EntityDataAccessor<Boolean> accessor) {
        return this.f_19804_.m_135370_(accessor);
    }

    /**
     * Helper method for boolean entity data setting
     */
    private void setBooleanData(EntityDataAccessor<Boolean> accessor, boolean value) {
        this.f_19804_.m_135381_(accessor, value);
    }
    
    /**
     * Helper method for integer entity data access
     */
    private int getIntegerData(EntityDataAccessor<Integer> accessor) {
        return this.f_19804_.m_135370_(accessor);
    }
    
    /**
     * Helper method for integer entity data setting
     */
    private void setIntegerData(EntityDataAccessor<Integer> accessor, int value) {
        this.f_19804_.m_135381_(accessor, value);
    }
    
    /**
     * Helper method for float entity data access
     */
    private float getFloatData(EntityDataAccessor<Float> accessor) {
        return this.f_19804_.m_135370_(accessor);
    }

    /**
     * Helper method for float entity data setting
     */
    private void setFloatData(EntityDataAccessor<Float> accessor, float value) {
        this.f_19804_.m_135381_(accessor, value);
    }

    // ===== STATE VARIABLES (Package-private for controller access) =====
    public int timeFlying = 0;
    public boolean landingFlag = false;

    public int landingTimer = 0;
    int runningTicks = 0;
    // Banking smoothing state
    private float bankSmoothedYaw = 0f;
    private int bankHoldTicks = 0;
    private int bankDir = 0; // -1 left, 0 none, 1 right
    private float bankAngle = 0f;
    private float prevBankAngle = 0f;

    // Pitching smoothing state
    private float pitchSmoothedPitch = 0f;
    private int pitchHoldTicks = 0;
    private int pitchDir = 0; // -1 down, 0 none, 1 up

    // Dodge system
    boolean dodging = false;
    int dodgeTicksLeft = 0;
    Vec3 dodgeVec = Vec3.f_82478_;

    private boolean allowGroundBeamDuringStorm = false;
    // Sit transition state
    // Track sit down/up animations separately from sitProgress (which is for sit pose interpolation)
    private int sitTransitionTicks = 0; // Counts down during down/up animations
    private boolean isSittingDown = false; // True during "down" animation (93 ticks)
    private boolean isStandingUp = false;  // True during "up" animation (23 ticks)

    // Sleep transition state
    // Sleep transition states now synced via entity data (DATA_SLEEPING_ENTERING, DATA_SLEEPING_EXITING)
    // Removed public boolean fields in favor of synced entity data
    private int sleepTransitionTicks = 0;
    // Tiny ambient resume buffer after exit completes
    private int sleepAmbientCooldownTicks = 0;
    // Re-entry suppression after aggression/damage to prevent instant resleep
    private int sleepReentryCooldownTicks = 0;
    // Hard-stop flag to kill sleep clips immediately across ticks
    private int sleepCancelTicks = 0;
    private boolean sleepLocked = false;
    private int sleepCommandSnapshot = -1;

    // Post-load stabilization to preserve midair riding state across save/load
    private int postLoadAirStabilizeTicks = 0; // counts down after world load if we saved while flying
    private int followFailsafeCooldown = 0;
    private int postStandUnlockTicks = 0;

    // Rider takeoff request timer: while > 0, flight controller treats state as takeoff
    private int riderTakeoffTicks = 0;


    // Last landing completion time (server game time). Used for takeoff cooldowns.
    private long lastLandingGameTime = Long.MIN_VALUE;

    public long getLastLandingGameTime() {
        return lastLandingGameTime;
    }


    public void markLandedNow() {
        if (!m_9236_().f_46443_) {
            this.lastLandingGameTime = m_9236_().m_46467_();
        }
    }


    // Navigation (Package-private for controller access)
    public final GroundPathNavigation groundNav;
    public final FlyingPathNavigation airNav;
    public boolean usingAirNav = false;

    // ===== CONTROLLER INSTANCES =====
    public final RaevyxFlightController flightController;
    private final RaevyxInteractionHandler lightningInteractionHandler;
    private final RaevyxAnimationHandler animationHandler;

    // ===== SPECIALIZED HANDLER SYSTEMS =====
    private final RaevyxRiderController riderController;
    private final DragonSoundHandler soundHandler;
    private final com.leon.saintsdragons.server.entity.sleep.DragonRestManager restManager;

    // ===== CLIENT LOCATOR CACHE (client-side only) =====
    private final Map<String, Vec3> clientLocatorCache = new ConcurrentHashMap<>();

    // ===== CUSTOM SITTING SYSTEM =====
    // Completely replace TamableAnimal's broken sitting behavior


    @Override
    public boolean m_21825_() {
        return super.m_21825_() && !(this.m_20160_() || this.m_20159_() || this.m_29443_());
    }
    // GeckoLib cache is now handled by base DragonEntity class

    //FLIGHT
    public float getGlidingFraction() {
        return animationController.glidingFraction;
    }
    public float getFlappingFraction() {
        return animationController.flappingFraction;
    }
    public float getHoveringFraction() {
        return animationController.hoveringFraction;
    }
    private final RaevyxPhysicsController animationController = new RaevyxPhysicsController(this);

    // Animation controller is internal-only; external integration goes via GeckoLib controllers.


    public Raevyx(EntityType<? extends TamableAnimal> type, Level level) {
        super(type, level);
        this.m_274367_(1.25F);

        // Initialize both navigators with custom pathfinding
        this.groundNav = new com.leon.saintsdragons.server.ai.navigation.DragonPathNavigateGround(this, level);
        this.airNav = new FlyingPathNavigation(this, level) {
            @Override
            public boolean m_6342_(@Nonnull BlockPos pos) {
                return !this.f_26495_.m_8055_(pos.m_7495_()).m_60795_();
            }
        };
        this.airNav.m_26440_(false);
        this.airNav.m_7008_(false);
        this.airNav.m_26443_(false);

        // Start with ground navigation
        this.f_21344_ = this.groundNav;
        this.f_21342_ = new MoveControl(this);
        // lookControl inherited from DragonEntity (uses DragonLookControl)

        // Pathfinding setup
        this.m_21441_(BlockPathTypes.DANGER_FIRE, -1.0F);
        this.m_21441_(BlockPathTypes.WATER, -1.0F);
        this.m_21441_(BlockPathTypes.WATER_BORDER, -1.0F);
        this.m_21441_(BlockPathTypes.FENCE, -1.0F);

        // Initialize controllers
        this.flightController = new RaevyxFlightController(this);
        this.lightningInteractionHandler = new RaevyxInteractionHandler(this);
        this.animationHandler = new RaevyxAnimationHandler(this);

        // Initialize specialized handler systems
        this.riderController = new RaevyxRiderController(this);
        this.soundHandler = new DragonSoundHandler(this);
        this.restManager = new com.leon.saintsdragons.server.entity.sleep.DragonRestManager(this);

        // Desynchronize ambient system across instances to avoid synchronized vocals/animations
        RandomSource rng = this.m_217043_();
        this.ambientSoundTimer = rng.m_188503_(80); // small random offset
        this.nextAmbientSoundDelay = MIN_AMBIENT_DELAY + rng.m_188503_(MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY);

    }

    @Override
    protected float getBodyTurnSpeed() {
        return 0.6f; // Match default turn speed like other dragons
    }

    // ===== HANDLER ACCESS METHODS (expose only what is used externally) =====

    public DragonSoundHandler getSoundHandler() {
        return soundHandler;
    }

    public com.leon.saintsdragons.server.entity.sleep.DragonRestManager getRestManager() {
        return restManager;
    }

    // Client-only: stash per-frame sampled locator world positions
    public void setClientLocatorPosition(String name, Vec3 pos) {
        if (name == null || pos == null) return;
        this.clientLocatorCache.put(name, pos);
    }

    public Vec3 getClientLocatorPosition(String name) {
        if (name == null) return null;
        return this.clientLocatorCache.get(name);
    }

    public boolean isStayOrSitMuted() {
        return this.m_21827_() || this.m_21825_();
    }

    @Override
    protected void m_7355_(@Nonnull BlockPos pos, @Nonnull BlockState state) {
        // Intentionally empty — step sounds are driven by GeckoLib keyframes (step1/step2)
    }

    public static AttributeSupplier.Builder createAttributes() {
        return TamableAnimal.m_21552_()
                .m_22268_(Attributes.f_22276_, 180.0D)
                .m_22268_(Attributes.f_22279_, WALK_SPEED)
                .m_22268_(Attributes.f_22277_, 80.0D)
                .m_22268_(Attributes.f_22280_, 1.0D)
                .m_22268_(Attributes.f_22278_, 1.0D)
                .m_22268_(Attributes.f_22284_, 8.0D);
    }

    // Cooldown to prevent hurt sound spam when ridden or under rapid hits
    private int hurtSoundCooldown = 0;
    @Override
    protected void m_8097_() {
        super.m_8097_();
        // Define Lightning Dragon specific data
        this.f_19804_.m_135372_(DATA_SCREEN_SHAKE_AMOUNT, 0.0F);
        this.f_19804_.m_135372_(DATA_BEAMING, false);
        this.f_19804_.m_135372_(DATA_RIDER_LANDING_BLEND, false);
        this.f_19804_.m_135372_(DATA_RIDER_LOCKED, false);
        this.f_19804_.m_135372_(DATA_SLEEPING_ENTERING, false);
        this.f_19804_.m_135372_(DATA_SLEEPING_EXITING, false);
        this.f_19804_.m_135372_(DATA_BEAM_END_SET, false);
        this.f_19804_.m_135372_(DATA_BEAM_END_X, 0f);
        this.f_19804_.m_135372_(DATA_BEAM_END_Y, 0f);
        this.f_19804_.m_135372_(DATA_BEAM_END_Z, 0f);
        this.f_19804_.m_135372_(DATA_BEAM_START_SET, false);
        this.f_19804_.m_135372_(DATA_BEAM_START_X, 0f);
        this.f_19804_.m_135372_(DATA_BEAM_START_Y, 0f);
        this.f_19804_.m_135372_(DATA_BEAM_START_Z, 0f);
        this.f_19804_.m_135372_(DATA_SLEEPING, false);
    }

    @Override
    protected void defineRideableDragonData() {
        // Define all rideable wyvern data keys for LightningDragonEntity
        this.f_19804_.m_135372_(DATA_FLYING, false);
        this.f_19804_.m_135372_(DATA_TAKEOFF, false);
        this.f_19804_.m_135372_(DATA_HOVERING, false);
        this.f_19804_.m_135372_(DATA_LANDING, false);
        this.f_19804_.m_135372_(DATA_RUNNING, false);
        this.f_19804_.m_135372_(DATA_GROUND_MOVE_STATE, 0);
        this.f_19804_.m_135372_(DATA_FLIGHT_MODE, -1);
        this.f_19804_.m_135372_(DATA_RIDER_FORWARD, 0f);
        this.f_19804_.m_135372_(DATA_RIDER_STRAFE, 0f);
        this.f_19804_.m_135372_(DATA_GOING_UP, false);
        this.f_19804_.m_135372_(DATA_GOING_DOWN, false);
        this.f_19804_.m_135372_(DATA_ACCELERATING, false);
    }

    // Implementation of abstract accessor methods
    @Override
    protected EntityDataAccessor<Float> getRiderForwardAccessor() {
        return DATA_RIDER_FORWARD;
    }

    @Override
    protected EntityDataAccessor<Float> getRiderStrafeAccessor() {
        return DATA_RIDER_STRAFE;
    }

    @Override
    protected EntityDataAccessor<Integer> getGroundMoveStateAccessor() {
        return DATA_GROUND_MOVE_STATE;
    }

    @Override
    protected EntityDataAccessor<Integer> getFlightModeAccessor() {
        return DATA_FLIGHT_MODE;
    }

    @Override
    protected EntityDataAccessor<Boolean> getGoingUpAccessor() {
        return DATA_GOING_UP;
    }

    @Override
    protected EntityDataAccessor<Boolean> getGoingDownAccessor() {
        return DATA_GOING_DOWN;
    }

    @Override
    protected EntityDataAccessor<Boolean> getAcceleratingAccessor() {
        return DATA_ACCELERATING;
    }

    @Override
    protected void applyLoadedFlightState(boolean flying, boolean takeoff, boolean hovering, boolean landing) {
        setFlying(flying);
        setTakeoff(takeoff);
        setHovering(hovering);
        setLanding(landing);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends DragonEntity> DragonAbility<T> getActiveAbility() {
        return (DragonAbility<T>) combatManager.getActiveAbility();
    }

    public boolean isAbilityActive(DragonAbilityType<?, ?> abilityType) {
        return combatManager.isAbilityActive(abilityType);
    }

    public boolean canUseAbility() {
        return !m_6162_() && combatManager.canUseAbility();
    }
    public void useRidingAbility(String abilityName) {
        if (m_6162_()) {
            return;
        }
        if (abilityName == null || abilityName.isEmpty()) return;
        // Only allow when actually being ridden by a living controller (owner ideally)
        var cp = m_6688_();
        if (!(cp instanceof net.minecraft.world.entity.LivingEntity)) {
            return;
        }
        // Block during rider control lock (e.g., Summon Storm windup)
        if (areRiderControlsLocked()) {
            return;
        }
        if (this.m_21824_() && cp instanceof net.minecraft.world.entity.player.Player p && !this.m_21830_(p)) {
            return; // owner-gate abilities on tamed dragons
        }
        var type = AbilityRegistry.get(abilityName);
        if (type != null) {
            // Delegate to combat manager which handles proper generic casting
            combatManager.tryUseAbility(type);
        }
    }

    @Override
    public <T extends DragonEntity> void tryActivateAbility(DragonAbilityType<T, ?> abilityType) {
        if (m_6162_()) {
            return;
        }
        super.tryActivateAbility(abilityType);
    }


    @Override
    protected boolean isRiderInputLocked(Player player) {
        return areRiderControlsLocked();
    }

    @Override
    protected void applyRiderVerticalInput(Player player, boolean goingUp, boolean goingDown, boolean locked) {
        if (this.m_29443_()) {
            setGoingUp(goingUp);
            setGoingDown(goingDown);
        } else {
            setGoingUp(false);
            setGoingDown(false);
        }
    }

    @Override
    protected void applyRiderMovementInput(Player player, float forward, float strafe, float yaw, boolean locked) {
        float fwd = applyInputDeadzone(forward);
        float str = applyInputDeadzone(strafe);
        setLastRiderForward(fwd);
        setLastRiderStrafe(str);
        if (!m_29443_()) {
            int moveState = 0;
            float magnitude = Math.abs(fwd) + Math.abs(str);
            if (magnitude > 0.05f) {
                moveState = this.isAccelerating() ? 2 : 1;
            }
            if (this.m_20088_().m_135370_(DATA_GROUND_MOVE_STATE) != moveState) {
                this.m_20088_().m_135381_(DATA_GROUND_MOVE_STATE, moveState);
                this.syncAnimState(moveState, this.getSyncedFlightMode());
            }
        }
    }

    @Override
    protected void handleRiderAction(ServerPlayer player, DragonRiderAction action, String abilityName, boolean locked) {
        if (action == null) {
            return;
        }
        switch (action) {
            case TAKEOFF_REQUEST -> {
                if (!locked) {
                    requestRiderTakeoff();
                }
            }
            case ACCELERATE -> {
                if (!locked) {
                    setAccelerating(true);
                }
            }
            case STOP_ACCELERATE -> setAccelerating(false);
            case ABILITY_USE -> {
                if (abilityName != null && !abilityName.isEmpty()) {
                    useRidingAbility(abilityName);
                }
            }
            case ABILITY_STOP -> {
                if (abilityName != null && !abilityName.isEmpty()) {
                    var active = getActiveAbility();
                    if (active != null) {
                        forceEndActiveAbility();
                    }
                }
            }
            case TOGGLE_MELEE -> {
                if (!locked) {
                    toggleMeleeMode();
                }
            }
            default -> { }
        }
    }


    /**
     * Forces the wyvern to take off when being ridden. Called when player presses Space while on ground.
     */
    public void requestRiderTakeoff() {
        riderController.requestRiderTakeoff();
    }

    // (External callers should use triggerable action keys on the GeckoLib controller.)

    @Override
    public Vec3 getHeadPosition() {
        return m_146892_();
    }
    @Override
    public Vec3 getMouthPosition() {
        // Try to use bone-based mouth position from renderer cache (most accurate!)
        Vec3 mouthLoc = getClientLocatorPosition("mouth_origin");
        if (mouthLoc != null) {
            return mouthLoc;
        }
        // Fallback to computed position if bone data not available (server-side, etc.)
        return computeHeadMouthOrigin(1.0f);
    }

    /**
     * Compute a mouth origin in world space from head yaw/pitch and a fixed local offset.
     * FALLBACK ONLY - bone-based positioning is preferred and more accurate!
     */
    public Vec3 computeHeadMouthOrigin(float partialTicks) {
        double x = Mth.m_14139_(partialTicks, this.f_19854_, this.m_20185_());
        double y = Mth.m_14139_(partialTicks, this.f_19855_, this.m_20186_());
        double z = Mth.m_14139_(partialTicks, this.f_19856_, this.m_20189_());

        float yawDeg = Mth.m_14179_(partialTicks, this.f_20886_, this.f_20885_);
        float pitchDeg = Mth.m_14179_(partialTicks, this.f_19860_, this.m_146909_());

        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);

        // Local offsets (Right=X, Up=Y, Forward=Z)
        // Small rightward nudge (negative flips to the other side in world yaw math)
        double R = (-0.5 / 16.0) * MODEL_SCALE;
        double U = (6.6 / 16.0) * MODEL_SCALE;
        double F = (14.65 / 16.0) * MODEL_SCALE;

        // Pitch around X axis - transform Up and Forward components
        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        // Local offsets after applying pitch (around X axis)
        double up = U * cp - F * sp;       // Y component after pitch
        double fwd = U * sp + F * cp;      // Z component after pitch

        // Yaw around Y axis - transform all components into world space
        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        double offX = R * cy - fwd * sy; // World X after yaw
        double offZ = R * sy + fwd * cy; // World Z after yaw

        return new Vec3(x + offX, y + up, z + offZ);
    }

    public void forceEndActiveAbility() {
        combatManager.forceEndActiveAbility();
    }

    public boolean isBeaming() { return getBooleanData(DATA_BEAMING); }
    public void setBeaming(boolean beaming) {
        boolean wasBeaming = getBooleanData(DATA_BEAMING);
        setBooleanData(DATA_BEAMING, beaming);
        if (!beaming || !wasBeaming) {
            resetBeamAim();
        }
    }

    // (No client/server rider anchor fields; seat uses math-based head-space anchor)

    // ===== BEAM END SYNC + CLIENT LERP =====
    private Vec3 prevClientBeamEnd = null;
    private Vec3 clientBeamEnd = null;
    private Vec3 beamLookLerp = null;
    private Vec3 beamAimDir = null;
    private float beamYawOffsetRad = 0.0f;
    private float beamPitchOffsetRad = 0.0f;

    public void setBeamEndPosition(@org.jetbrains.annotations.Nullable Vec3 pos) {
        if (pos == null) {
            this.f_19804_.m_135381_(DATA_BEAM_END_SET, false);
        } else {
            this.f_19804_.m_135381_(DATA_BEAM_END_SET, true);
            this.f_19804_.m_135381_(DATA_BEAM_END_X, (float) pos.f_82479_);
            this.f_19804_.m_135381_(DATA_BEAM_END_Y, (float) pos.f_82480_);
            this.f_19804_.m_135381_(DATA_BEAM_END_Z, (float) pos.f_82481_);
        }
    }

    public Vec3 getBeamEndPosition() {
        if (!getBooleanData(DATA_BEAM_END_SET)) return null;
        return new Vec3(
                getFloatData(DATA_BEAM_END_X),
                getFloatData(DATA_BEAM_END_Y),
                getFloatData(DATA_BEAM_END_Z)
        );
    }

    public Vec3 getClientBeamEndPosition(float partialTicks) {
        if (clientBeamEnd != null && prevClientBeamEnd != null) {
            Vec3 d = clientBeamEnd.m_82546_(prevClientBeamEnd);
            return prevClientBeamEnd.m_82549_(d.m_82490_(partialTicks));
        }
        Vec3 serverPos = getBeamEndPosition();
        return clientBeamEnd != null ? clientBeamEnd : (serverPos != null ? serverPos : Vec3.f_82478_);
    }

    public void setBeamStartPosition(@org.jetbrains.annotations.Nullable Vec3 pos) {
        if (pos == null) {
            this.f_19804_.m_135381_(DATA_BEAM_START_SET, false);
        } else {
            this.f_19804_.m_135381_(DATA_BEAM_START_SET, true);
            this.f_19804_.m_135381_(DATA_BEAM_START_X, (float) pos.f_82479_);
            this.f_19804_.m_135381_(DATA_BEAM_START_Y, (float) pos.f_82480_);
            this.f_19804_.m_135381_(DATA_BEAM_START_Z, (float) pos.f_82481_);
        }
    }

    public Vec3 getBeamStartPosition() {
        if (!getBooleanData(DATA_BEAM_START_SET)) return null;
        return new Vec3(
                getFloatData(DATA_BEAM_START_X),
                getFloatData(DATA_BEAM_START_Y),
                getFloatData(DATA_BEAM_START_Z)
        );
    }

    // ===== NAVIGATION SWITCHING =====
    public void switchToAirNavigation() {
        if (!this.usingAirNav) {
            this.f_21344_ = this.airNav;
            this.f_21342_ = new DragonFlightMoveHelper(this);
            this.usingAirNav = true;
        }
    }

    public void switchToGroundNavigation() {
        if (this.usingAirNav) {
            this.f_21344_ = this.groundNav;
            this.f_21342_ = new MoveControl(this);
            this.usingAirNav = false;
        }
    }

    @Override
    protected @NotNull PathNavigation m_6037_(@Nonnull Level level) {
        return new com.leon.saintsdragons.server.ai.navigation.DragonPathNavigateGround(this, level);
    }

    // ===== STATE MANAGEMENT =====

    public void setFlying(boolean flying) {
        if (flying && this.m_6162_()) flying = false;

        // Prevent forced grounding when being ridden by a player (unless explicitly ordered to sit or actually on ground)
        if (!flying && m_20160_() && !m_21827_() && !m_20096_()) {
            // Dragon is being ridden, not ordered to sit, and not actually touching ground - ignore forced grounding
            return;
        }

        boolean wasFlying = m_29443_();
        this.f_19804_.m_135381_(DATA_FLYING, flying);

        // Reset acceleration state when transitioning between ground and flight modes
        // This prevents ground sprinting from affecting flight speed and vice versa
        if (wasFlying != flying) {
            this.setAccelerating(false);
        }

        if (wasFlying != flying) {
            if (flying) {
                switchToAirNavigation();
                setRunning(false);
            } else {
                switchToGroundNavigation();
            }
        }
    }

    public void setTakeoff(boolean takeoff) {
        if (takeoff && this.m_6162_()) takeoff = false;
        this.f_19804_.m_135381_(DATA_TAKEOFF, takeoff);
    }

    public void setHovering(boolean hovering) {
        if (hovering && this.m_6162_()) hovering = false;
        this.f_19804_.m_135381_(DATA_HOVERING, hovering);
    }




    public boolean isWalking() {
        if (m_29443_()) return false;
        int s = m_9236_().f_46443_ ? getEffectiveGroundState() : this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);
        if (s == 1) return true;
        if (s == 2) return false;
        if (m_9236_().f_46443_ && super.getEffectiveGroundState() < 0) {
            double speed = m_20184_().m_165925_();
            return speed > 0.004 && speed <= 0.10;
        }
        return false;
    }

    public boolean isActuallyRunning() {
        if (m_29443_()) return false;
        int s = m_9236_().f_46443_ ? getEffectiveGroundState() : this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE);
        if (s == 2) return true;
        if (s == 1) return false;
        // Fallback: rely on synced running flag if state not yet set
        return getBooleanData(DATA_RUNNING);
    }


    public void setLanding(boolean landing) {
        // Prevent forced landing when being ridden by a player
        if (landing && m_20160_()) {
            // Dragon is being ridden, ignore landing requests to maintain player control
            return;
        }

        this.f_19804_.m_135381_(DATA_LANDING, landing);
        if (landing) {
            landingTimer = 0;
            this.m_21573_().m_26573_();
            this.setTakeoff(true);
            this.landingFlag = true;
            if (!m_9236_().f_46443_) {
                this.flightController.planSmartLanding();
            }
        } else {
            this.landingFlag = false;
        }
    }

    // DATA STUFF

    // Old attack system methods removed - using new state system instead
    
    // ===== NEW ATTACK STATE SYSTEM METHODS =====
    
    // ===== Lightning Dragon Specific Methods =====
    
    // Flight mode accessor for controllers (avoids accessing protected entityData outside entity)
    public int getSyncedFlightMode() { return getIntegerData(DATA_FLIGHT_MODE); }

    // Debug/inspection helper: expose raw ground move state
    public int getGroundMoveState() { return getIntegerData(DATA_GROUND_MOVE_STATE); }
    
    // ===== RideableDragonBase Abstract Method Implementations =====
    
    @Override
    protected int getFlightMode() {
        if (!m_29443_()) {
            inHighAltitudeGlide = false; // Reset when not flying
            return -1; // Ground state
        }
        if (isTakeoff()) return 3;  // Takeoff
        if (isHovering()) return 2; // Hover
        if (isLanding()) return 2;  // Landing (treat as hover)

        // Altitude-based animation for ridden dragons
        if (this.m_21824_() && this.m_20160_()) {
            Entity rider = this.m_6688_();
            if (rider instanceof Player player && this.m_21830_(player)) {
                int groundY = this.m_9236_().m_6924_(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        Mth.m_14107_(this.m_20185_()), Mth.m_14107_(this.m_20189_()));
                double altitudeAboveTerrain = this.m_20186_() - groundY;

                // Hysteresis: Enter glide at 40 blocks, exit at 30 blocks
                if (inHighAltitudeGlide) {
                    // Already gliding - stay in glide until we drop below exit threshold
                    if (altitudeAboveTerrain > RIDER_GLIDE_ALTITUDE_EXIT) {
                        return 0; // High-altitude glide
                    } else {
                        inHighAltitudeGlide = false;
                        return 1; // Low altitude - flap
                    }
                } else {
                    // Not gliding yet - enter glide if above entry threshold
                    if (altitudeAboveTerrain > RIDER_GLIDE_ALTITUDE_THRESHOLD) {
                        inHighAltitudeGlide = true;
                        return 0; // High-altitude glide
                    } else {
                        return 1; // Low altitude - flap
                    }
                }
            }
        } else {
            // Not being ridden by owner - reset flag
            inHighAltitudeGlide = false;
        }

        // Fallback for wild/untamed dragons: Check if gliding (moving horizontally without significant vertical movement)
        double horizontalSpeedSqr = m_20184_().m_165925_();
        double yDelta = this.m_20186_() - this.f_19855_;
        if (Math.abs(yDelta) < 0.06 && horizontalSpeedSqr > 0.01) {
            return 0; // Glide
        }

        return 1; // Forward flight
    }
    
    @Override
    protected boolean isDragonFlying() {
        return getBooleanData(DATA_FLYING);
    }
    
    @Override
    public boolean isTakeoff() {
        return getBooleanData(DATA_TAKEOFF);
    }
    
    @Override
    public boolean isLanding() {
        return getBooleanData(DATA_LANDING);
    }
    
    @Override
    public boolean isHovering() {
        return getBooleanData(DATA_HOVERING);
    }
    
    @Override
    public boolean isRunning() {
        return getBooleanData(DATA_RUNNING);
    }
    
    @Override
    public void setRunning(boolean running) {
        setBooleanData(DATA_RUNNING, running);
        if (running) {
            runningTicks = 0;
            Objects.requireNonNull(this.m_21051_(Attributes.f_22279_)).m_22100_(RUN_SPEED);
        } else {
            Objects.requireNonNull(this.m_21051_(Attributes.f_22279_)).m_22100_(WALK_SPEED);
        }
    }
    
    // ===== RideableDragonBase Override for Custom Logic =====
    
    @Override
    public void tickAnimationStates() {
        // Lightning Dragon already has this logic implemented in aiStep()
        // This method is here to satisfy the interface contract
        // The actual implementation is in the aiStep() method above
    }

    // ===== Client animation overrides (for robust observer sync) =====
    @Override
    public int getEffectiveGroundState() {
        return super.getEffectiveGroundState();
    }

    // Expose last-tick vertical delta for robust flight-mode decisions
    public double getYDelta() { return this.m_20186_() - this.f_19855_; }

    // Allow AI goals to set ground move state explicitly
    public void setGroundMoveStateFromAI(int state) {
        if (!this.m_9236_().f_46443_) {
            int s = Math.max(0, Math.min(2, state));
            if (this.f_19804_.m_135370_(DATA_GROUND_MOVE_STATE) != s) {
                this.f_19804_.m_135381_(DATA_GROUND_MOVE_STATE, s);
                this.syncAnimState(s, getSyncedFlightMode());
            }
        }
    }


    // Riding utilities
    @Nullable
    public Player getRidingPlayer() {
        if (this.m_6688_() instanceof Player player) {
            return player;
        }
        return null;
    }

    // Command get/set now inherited from base DragonEntity

    public boolean canOwnerCommand(Player ownerPlayer) {
        return ownerPlayer.m_6047_(); // Shift key pressed
    }

    @Override
    public RiderAbilityBinding getTertiaryRiderAbility() {
        return new RiderAbilityBinding(RaevyxAbilities.RAEVYX_LIGHTNING_BEAM.getName(), RiderAbilityBinding.Activation.HOLD);
    }

    @Override
    public RiderAbilityBinding getPrimaryRiderAbility() {
        return new RiderAbilityBinding(RaevyxAbilities.RAEVYX_ROAR.getName(), RiderAbilityBinding.Activation.PRESS);
    }

    @Override
    public RiderAbilityBinding getSecondaryRiderAbility() {
        return new RiderAbilityBinding(RaevyxAbilities.RAEVYX_SUMMON_STORM.getName(), RiderAbilityBinding.Activation.PRESS);
    }

    @Override
    public RiderAbilityBinding getAttackRiderAbility() {
        // Use melee mode to switch between bite and horn gore
        // Mode 0 = bite (primary), Mode 1 = horn gore (secondary)
        if (getMeleeMode() == 0) {
            return new RiderAbilityBinding(RaevyxAbilities.RAEVYX_BITE.getName(), RiderAbilityBinding.Activation.PRESS);
        } else {
            return new RiderAbilityBinding(RaevyxAbilities.RAEVYX_HORN_GORE.getName(), RiderAbilityBinding.Activation.PRESS);
        }
    }


    // ===== RIDING SUPPORT =====
    @Override
    public double m_6048_() {
        return riderController.getPassengersRidingOffset();
    }

    @Override
    protected void m_19956_(@Nonnull Entity passenger, @Nonnull Entity.MoveFunction moveFunction) {
        riderController.positionRider(passenger, moveFunction);
    }

    @Override
    public @NotNull Vec3 m_7688_(@Nonnull LivingEntity passenger) {
        return riderController.getDismountLocationForPassenger(passenger);
    }

    // Dodge system
    public boolean isDodging() { return dodging; }

    public void beginDodge(Vec3 vec, int ticks) {
        this.dodging = true;
        this.dodgeVec = vec;
        this.dodgeTicksLeft = Math.max(1, ticks);
        this.m_21573_().m_26573_();
        this.f_19812_ = true;
    }

    // ===== MAIN TICK METHOD =====
    @Override
    public void m_8119_() {
        animationController.tick();
        super.m_8119_();
        tickScreenShake();
        tickSittingState();
        tickSound();
        tickPostLoadStabilization();
        tickRiderTakeoff();
        tickControllers();
        tickHurtSoundCooldown();
        tickWaterDisturbance();
        if (!m_9236_().f_46443_) {
            // When ridden and flying, never stay in 'hovering' unless explicitly landing or beaming or taking off
            if (m_29443_() && m_6688_() != null) {
                if (!isLanding() && !isBeaming() && !isTakeoff() && isHovering()) {
                    setHovering(false);
                }
            }
            tickRiderControlLock();
            tickRiderControlLockMovement();
            handleAmbientSounds();
            // no-op
        }
        if (!m_9236_().f_46443_) {
            tickSuperchargeTimer();
            tickTempInvulnTimer();
            tickSuperchargeVfx();
            tickSleepTransition();
            tickSleepCooldowns();
            tickMountingState();
            tickFollowFailsafe();
            if (postStandUnlockTicks > 0) {
                postStandUnlockTicks--;
            }
        }
        
        // Update banking and pitching logic every tick
        tickBankingLogic();
        tickPitchingLogic();

        // Wake up if mounted or target appears/aggression
        if (!m_9236_().f_46443_ && (m_5803_() || isSleepingEntering() || isSleepingExiting())) {
            if (this.m_20160_()) {
                wakeUpImmediately();
                // Clear all states when mounted to ensure full control
                clearAllStatesWhenMounted();
            } else if (this.m_5448_() != null || this.m_5912_()) {
                // On aggression/target, clear immediately and suppress re-entry for a short window
                wakeUpImmediately();
                suppressSleep(200); // ~10s; adjust as desired
            } else if (this.m_20072_() || this.m_20077_()) {
                // Never sleep in fluids; wake and suppress to avoid drowning
                wakeUpImmediately();
                suppressSleep(200);
            }

            // Use RideableDragonBase animation state management
            super.tickAnimationStates();
        }

        // Use RideableDragonBase animation state management for normal ticks
        if (!m_9236_().f_46443_ && !(m_5803_() || isSleepingEntering() || isSleepingExiting())) {
            super.tickAnimationStates();
        }

        // Handle dodge movement first
        if (!m_9236_().f_46443_ && this.isDodging()) {
            handleDodgeMovement();
            return;
        }

        tickRunningTime();
        tickBeamLook();

        if (!m_9236_().f_46443_ && m_6162_()) {
            if (m_5448_() != null) {
                super.m_6710_(null);
            }
            if (getActiveAbility() != null) {
                combatManager.forceEndActiveAbility();
            }
            m_21561_(false);
        }

        tickClientSideUpdates();
    }


    // ===== TICK SUBMETHODS =====
    
    private void tickScreenShake() {
        // Update screen shake interpolation
        prevScreenShakeAmount = screenShakeAmount;
        if (screenShakeAmount > 0) {
            screenShakeAmount = Math.max(0, screenShakeAmount - 0.34F);
            this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, this.screenShakeAmount);
        }
    }

    // ===== WATER DISTURBANCE EFFECT (wing downforce) =====

    // Tuneable constants
    private static final double WATER_EFFECT_MAX_HEIGHT = 8.0;   // Max height above water to trigger effect
    private static final double WATER_EFFECT_INTENSITY = 1.2;    // Multiplier for particle count (smaller than Cindervane)

    /**
     * Creates water disturbance effects when flying over water.
     * Uses vanilla-style splash logic based on bounding box size.
     * Bigger dragons automatically create bigger splashes!
     */
    private void tickWaterDisturbance() {
        // Only run on server side
        if (m_9236_().f_46443_) return;

        // Only when flying
        if (!m_29443_()) return;

        // Get dragon position and bounding box
        Vec3 pos = m_20182_();
        AABB box = m_20191_();

        // Check for water below (scan down from dragon position)
        for (int checkDown = 0; checkDown < WATER_EFFECT_MAX_HEIGHT; checkDown++) {
            BlockPos checkPos = new BlockPos(
                (int) Math.floor(pos.f_82479_),
                (int) Math.floor(pos.f_82480_) - checkDown,
                (int) Math.floor(pos.f_82481_)
            );

            BlockState state = m_9236_().m_8055_(checkPos);

            // Found water surface?
            if (!state.m_60819_().m_76178_()) {
                double waterY = checkPos.m_123342_() + 1.0; // Top of water block

                // === VANILLA-STYLE SPLASH BASED ON BOUNDING BOX SIZE ===
                // Calculate bounding box dimensions
                double boxWidth = box.m_82362_();   // Width (X axis)
                double boxLength = box.m_82385_();  // Length (Z axis)

                // Calculate particle count based on entity size (vanilla formula)
                // Bigger bounding box = more particles
                int particleCount = (int) Math.ceil((boxWidth + boxLength) / 2.0 * WATER_EFFECT_INTENSITY * 8.0);
                particleCount = Math.min(particleCount, 50); // Cap to prevent lag

                // Spawn particles around the perimeter of the bounding box
                for (int i = 0; i < particleCount; i++) {
                    // Random position within bounding box horizontal area
                    double offsetX = (f_19796_.m_188500_() - 0.5) * boxWidth;
                    double offsetZ = (f_19796_.m_188500_() - 0.5) * boxLength;

                    double particleX = pos.f_82479_ + offsetX;
                    double particleZ = pos.f_82481_ + offsetZ;

                    // Spawn splash particles
                    ((ServerLevel) m_9236_()).m_8767_(
                        ParticleTypes.f_123769_,
                        particleX, waterY, particleZ,
                        1,
                        offsetX * 0.2, 0.1, offsetZ * 0.2,  // Velocity based on offset (spreads outward)
                        0.1
                    );

                    // Bubbles (fewer than splashes)
                    if (f_19796_.m_188501_() < 0.25f) {
                        ((ServerLevel) m_9236_()).m_8767_(
                            ParticleTypes.f_123772_,
                            particleX, waterY, particleZ,
                            1,
                            0.0, 0.0, 0.0,
                            0.0
                        );
                    }
                }

                break; // Found water, stop scanning down
            }
        }
    }

    private void tickHurtSoundCooldown() {
        // Cool down hurt sound throttle
        if (hurtSoundCooldown > 0) hurtSoundCooldown--;
    }

    private void tickSound() {
        // Drive pending sound scheduling (both sides)
        this.getSoundHandler().tick();
    }
    
    private void tickSittingState() {
        // Clear sitting state if the wyvern is being ridden
        if (!this.m_9236_().f_46443_ && this.m_20160_() && this.m_21827_()) {
            this.m_21839_(false);
        }
    }
    
    private boolean wasVehicleLastTick = false;
    
    private void tickMountingState() {
        // Check if wyvern just became a vehicle and clear all states
        if (!this.m_9236_().f_46443_ && this.m_20160_() && !wasVehicleLastTick) {
            clearAllStatesWhenMounted();
        }
        wasVehicleLastTick = this.m_20160_();
    }
    
    /**
     * Clears all wyvern states (sleep, sit) when mounted to ensure full player control
     */
    private void clearAllStatesWhenMounted() {
        if (!this.m_9236_().f_46443_ && this.m_20160_()) {
            // Clear sleep states aggressively - including any ongoing transitions
            wakeUpImmediately();
            
            // Clear sitting state and sync command value
            if (this.m_21827_()) {
                this.m_21839_(false);
                // If wyvern was sitting, set command to Follow (0) when mounted
                if (this.getCommand() == 1) {
                    this.setCommandAuto(0);
                }
            }
            
            // Stop any AI navigation
            if (this.m_21573_().m_26570_() != null) {
                this.m_21573_().m_26573_();
            }
            
            // Suppress sleep for a longer period to prevent immediate re-entry
            suppressSleep(300); // ~15 seconds
        }
    }
    
    private void tickRunningTime() {
        // Track running time for animations
        if (this.isRunning()) {
            runningTicks++;
        } else {
            runningTicks = Math.max(0, runningTicks - 2);
        }
    }
    
    // Steer the head/neck chain toward the active beam so VFX and rig stay aligned.
    private void tickBeamLook() {
        if (!isBeaming()) {
            resetBeamAim();
            return;
        }

        Vec3 start = getBeamStartPosition();
        if (start == null) {
            start = computeHeadMouthOrigin(1.0f);
        }
        if (start == null) {
            resetBeamAim();
            return;
        }

        Vec3 aimDir = refreshBeamAimDirection(start, true);
        if (aimDir == null) {
            beamAimDir = Vec3.m_82498_(this.m_146909_(), this.f_20885_).m_82541_();
            aimDir = beamAimDir;
            updateBeamOffsets(aimDir);
        }

        Vec3 desiredLook = start.m_82549_(aimDir.m_82490_(6.0));
        // Unified smoothing for both client and server to prevent jitter
        double alpha = 0.35D;
        beamLookLerp = beamLookLerp == null
                ? desiredLook
                : beamLookLerp.m_82549_(desiredLook.m_82546_(beamLookLerp).m_82490_(alpha));

        float yawSpeed = Math.max(90.0F, (float)this.m_21529_());
        float pitchRange = (float)this.m_8132_();
        this.m_21563_().m_24950_(beamLookLerp.f_82479_, beamLookLerp.f_82480_, beamLookLerp.f_82481_, yawSpeed, pitchRange);
    }

    public Vec3 getBeamAimDirection() {
        return beamAimDir;
    }

    public float getBeamYawOffsetRad() {
        return beamYawOffsetRad;
    }

    public float getBeamPitchOffsetRad() {
        return beamPitchOffsetRad;
    }

    public Vec3 refreshBeamAimDirection(Vec3 start, boolean smooth) {
        Vec3 desiredDir = computeRawBeamAimDirection(start);
        if (desiredDir == null) {
            updateBeamOffsets(null);
            return null;
        }
        Vec3 clamped = clampBeamDirection(desiredDir);
        if (clamped == null) {
            updateBeamOffsets(null);
            return null;
        }

        if (beamAimDir == null) {
            beamAimDir = clamped;
        } else if (smooth) {
            // Unified smoothing for both client and server to prevent jitter
            double blend = 0.35D;
            beamAimDir = beamAimDir.m_82549_(clamped.m_82546_(beamAimDir).m_82490_(blend));
            double len = beamAimDir.m_82553_();
            if (len > 1.0E-6) {
                beamAimDir = beamAimDir.m_82490_(1.0 / len);
            } else {
                beamAimDir = clamped;
            }
        } else {
            beamAimDir = clamped;
        }

        updateBeamOffsets(beamAimDir);
        return beamAimDir;
    }

    private Vec3 computeRawBeamAimDirection(Vec3 start) {
        Entity cp = m_6688_();
        if (cp instanceof LivingEntity rider) {
            Vec3 riderLook = rider.m_20154_();
            if (riderLook.m_82556_() > 1.0E-6) {
                return riderLook.m_82541_();
            }
        }

        LivingEntity target = m_5448_();
        if (target != null && target.m_6084_()) {
            Vec3 aimPoint = target.m_146892_().m_82520_(0.0, -0.25, 0.0);
            Vec3 towardTarget = aimPoint.m_82546_(start);
            if (towardTarget.m_82556_() > 1.0E-6) {
                return towardTarget.m_82541_();
            }
        }

        Vec3 fallbackDir = Vec3.m_82498_(this.m_146909_(), this.f_20885_);
        return fallbackDir.m_82556_() > 1.0E-6 ? fallbackDir.m_82541_() : Vec3.f_82478_;
    }

    private Vec3 clampBeamDirection(Vec3 desiredDir) {
        if (desiredDir == null || desiredDir.m_82556_() < 1.0E-6) {
            updateBeamOffsets(null);
            return null;
        }

        Vec3 dir = desiredDir.m_82541_();

        float desiredYawDeg = (float)(Math.atan2(-dir.f_82479_, dir.f_82481_) * (180.0 / Math.PI));
        float desiredPitchDeg = (float)(-Math.atan2(dir.f_82480_, Math.sqrt(dir.f_82479_ * dir.f_82479_ + dir.f_82481_ * dir.f_82481_)) * (180.0 / Math.PI));

        float headYaw = this.f_20885_;
        float headPitch = this.m_146909_();

        float yawErrDeg = net.minecraft.util.Mth.m_14118_(headYaw, desiredYawDeg);
        float pitchErrDeg = desiredPitchDeg - headPitch;

        float clampedYawErr = net.minecraft.util.Mth.m_14036_(yawErrDeg, -MAX_BEAM_YAW_DEG, MAX_BEAM_YAW_DEG);
        float clampedPitchErr = net.minecraft.util.Mth.m_14036_(pitchErrDeg, -MAX_BEAM_PITCH_DEG, MAX_BEAM_PITCH_DEG);

        float finalYaw = headYaw + clampedYawErr;
        float finalPitch = headPitch + clampedPitchErr;

        Vec3 finalDir = Vec3.m_82498_(finalPitch, finalYaw);
        return finalDir.m_82556_() > 1.0E-6 ? finalDir.m_82541_() : null;
    }

    private void resetBeamAim() {
        beamLookLerp = null;
        beamAimDir = null;
        beamYawOffsetRad = 0.0f;
        beamPitchOffsetRad = 0.0f;
    }

    private void updateBeamOffsets(@org.jetbrains.annotations.Nullable Vec3 direction) {
        if (direction == null || direction.m_82556_() < 1.0E-6) {
            beamYawOffsetRad = 0.0f;
            beamPitchOffsetRad = 0.0f;
            return;
        }

        Vec3 dir = direction.m_82541_();
        float finalYawDeg = (float)(Math.atan2(-dir.f_82479_, dir.f_82481_) * (180.0 / Math.PI));
        float finalPitchDeg = (float)(-Math.atan2(dir.f_82480_, Math.sqrt(dir.f_82479_ * dir.f_82479_ + dir.f_82481_ * dir.f_82481_)) * (180.0 / Math.PI));

        float headYaw = this.f_20885_;
        float headPitch = this.m_146909_();

        float yawOffsetDeg = net.minecraft.util.Mth.m_14118_(headYaw, finalYawDeg);
        float pitchOffsetDeg = finalPitchDeg - headPitch;

        beamYawOffsetRad = yawOffsetDeg * net.minecraft.util.Mth.f_144833_;
        beamPitchOffsetRad = pitchOffsetDeg * net.minecraft.util.Mth.f_144833_;
    }

    private void tickClientSideUpdates() {
        // Update client-side sit progress and lerp beam end from synchronized data
        if (m_9236_().f_46443_) {
            prevSitProgress = sitProgress;
            sitProgress = this.f_19804_.m_135370_(DATA_SIT_PROGRESS);

            // Beam end/start lerp
            this.prevClientBeamEnd = this.clientBeamEnd;
            this.clientBeamEnd = getBeamEndPosition();
        }
    }
    
    private void tickRiderTakeoff() {
        // Decrement rider takeoff window (no-op while dying)
        if (!m_9236_().f_46443_ && riderTakeoffTicks > 0 && !isDying()) {
            riderTakeoffTicks--;
        }
    }
    
    private void tickPostLoadStabilization() {
        // If we loaded while flying (e.g., player saved while riding in air), hold flight for a short grace period
        if (!m_9236_().f_46443_ && postLoadAirStabilizeTicks > 0) {
            // Ensure air nav + flight flags are consistent
            if (!m_29443_()) setFlying(true);
            if (!isTakeoff()) setTakeoff(true);
            setLanding(false);
            setHovering(true);
            switchToAirNavigation();

            // Reset flight timer so auto-landing logic doesn't immediately cancel flight
            timeFlying = Math.min(timeFlying, 5);
            landingFlag = false;
            landingTimer = 0;

            // Give stronger buoyancy to counter immediate drop before rider inputs arrive
            var v = m_20184_();
            if (v.f_82480_ < 0.05) {
                // Apply upward force to prevent drifting down
                m_20334_(v.f_82479_ * 0.95, Math.max(0.05, v.f_82480_ + 0.02), v.f_82481_ * 0.95);
            }

            postLoadAirStabilizeTicks--;
            
            // When stabilization expires, force wild/untamed dragons to land
            if (postLoadAirStabilizeTicks == 0 && !m_21824_() && !m_20160_()) {
                // Wild dragon reloaded mid-flight - force landing to prevent floating
                setFlying(false);
                setTakeoff(false);
                setHovering(false);
                setLanding(true);
                switchToGroundNavigation();
                // Apply downward force to start descent
                m_20256_(m_20184_().m_82542_(0.5, -0.3, 0.5));
            }
        }
    }
    
    private void tickControllers() {
        // Delegate to controllers (disabled while dying)
        if (!isDying()) {
            flightController.handleFlightLogic();
        }
        updateSittingProgress();
    }

    private void updateSittingProgress() {
        if (m_9236_().f_46443_) {
            return;
        }

        // Tick down sit transition animations
        if (sitTransitionTicks > 0) {
            sitTransitionTicks--;
            if (sitTransitionTicks == 0) {
                // Transition animation finished
                isSittingDown = false;
                isStandingUp = false;
            }
        }

        if (this.m_21827_()) {
            // Trigger sit down animation when:
            // 1. Starting from standing (sitProgress == 0), OR
            // 2. Interrupting a stand-up animation (isStandingUp = true)
            if ((sitProgress == 0f || isStandingUp) && !isSittingDown) {
                animationHandler.triggerSitDownAnimation();
                isSittingDown = true;
                isStandingUp = false; // Cancel the stand-up
                sitTransitionTicks = getSitDownAnimationTicks();
            }

            if (sitProgress < maxSitTicks()) {
                sitProgress++;
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        } else {
            if (!this.m_9236_().f_46443_ && super.m_21825_()) {
                this.m_21837_(false);
            }

            if (this.m_20160_()) {
                if (sitProgress != 0f) {
                    sitProgress = 0f;
                    prevSitProgress = 0f;
                    this.f_19804_.m_135381_(DATA_SIT_PROGRESS, 0f);
                    // Cancel any ongoing transitions
                    isSittingDown = false;
                    isStandingUp = false;
                    sitTransitionTicks = 0;
                }
            } else if (sitProgress > 0f) {
                // Trigger sit up animation when:
                // 1. At max sitting and ready to stand, OR
                // 2. Interrupting a sit-down animation (isSittingDown = true)
                if ((sitProgress == maxSitTicks() || isSittingDown) && !isStandingUp) {
                    animationHandler.triggerSitUpAnimation();
                    isStandingUp = true;
                    isSittingDown = false; // Cancel the sit-down
                    sitTransitionTicks = getSitUpAnimationTicks();
                }

                // Decrement sitProgress when standing up
                // Speed matches stand-up animation duration (20 ticks) not sit-down (30 ticks)
                float decrementRate = maxSitTicks() / (float) getSitUpAnimationTicks(); // 30/20 = 1.5
                sitProgress -= decrementRate;
                if (sitProgress < 0f) {
                    sitProgress = 0f;
                }
                this.f_19804_.m_135381_(DATA_SIT_PROGRESS, sitProgress);
            }
        }
    }
    
    private void tickRiderControlLockMovement() {
        // While rider controls are locked (e.g., Summon Storm windup), freeze movement and AI
        if (!areRiderControlsLocked()) {
            return;
        }

        // If there's no rider anymore, release the lock so AI can resume
        if (m_6688_() == null) {
            riderControlLockTicks = 0;
            return;
        }

        this.m_21573_().m_26573_();
        this.m_6710_(null);
        this.m_20334_(0, 0, 0);
    }
    
    private void tickFollowFailsafe() {
        if (followFailsafeCooldown > 0) {
            followFailsafeCooldown--;
            return;
        }
        followFailsafeCooldown = 20; // roughly once per second

        if (isSleepLocked() || m_21827_() || m_20159_() || m_20160_() || isDying()) {
            return;
        }

        if (getCommand() == 1 && !m_21827_()) {
            setCommandAuto(0);
        }

        LivingEntity owner = m_269323_();
        if (owner == null || !owner.m_6084_()) {
            return;
        }
        if (owner.m_9236_() != m_9236_()) {
            return;
        }

        if (m_5448_() != null && m_5448_().m_6084_()) {
            return; // combat movement handles this case
        }

        if (m_29443_()) {
            return; // airborne logic handled elsewhere
        }

        double distSq = this.m_20280_(owner);
        if (distSq < (18.0 * 18.0)) {
            /*
             * If we're in follow mode but not actively pathing, we'll keep nudging the navigation
             * so standing dragons don't sit idly in wander command after reloads.
             */
            if (!this.m_21573_().m_26572_() && this.getCommand() == 0 && !this.m_21827_()) {
                this.m_21573_().m_5624_(owner, 0.8);
            }
            return;
        }

        boolean moveGoalActive = this.f_21345_.m_25386_().anyMatch(wrapped -> {
            Goal goal = wrapped.m_26015_();
            return goal instanceof RaevyxFollowOwnerGoal || goal instanceof RaevyxCombatGoal;
        });
        if (moveGoalActive) {
            return;
        }

        switchToGroundNavigation();
        boolean shouldRun = distSq > (25.0 * 25.0);
        setRunning(shouldRun);
        setGroundMoveStateFromAI(shouldRun ? 2 : 1);
        double speed = shouldRun ? 1.35 : 0.9;
        if (!this.m_21573_().m_5624_(owner, speed)) {
            this.m_21573_().m_26573_();
            attemptOwnerTeleport(owner);
        }
    }

    private void attemptOwnerTeleport(LivingEntity owner) {
        BlockPos ownerPos = owner.m_20183_();
        for (int i = 0; i < 8; i++) {
            int dx = this.f_19796_.m_188503_(7) - 3;
            int dz = this.f_19796_.m_188503_(7) - 3;
            BlockPos candidate = ownerPos.m_7918_(dx, 0, dz);
            if (isTeleportFriendlyBlock(candidate)) {
                this.m_6021_(candidate.m_123341_() + 0.5, candidate.m_123342_(), candidate.m_123343_() + 0.5);
                this.m_21573_().m_26573_();
                return;
            }
        }
    }

    private boolean isTeleportFriendlyBlock(BlockPos pos) {
        BlockPos below = pos.m_7495_();
        BlockState floor = m_9236_().m_8055_(below);
        BlockState body = m_9236_().m_8055_(pos);
        BlockState above = m_9236_().m_8055_(pos.m_7494_());
        return floor.m_60804_(m_9236_(), below) && body.m_60795_() && above.m_60795_();
    }
    
    private void tickSuperchargeTimer() {
        // Supercharge timer (summon storm)
        if (superchargeTicks > 0) {
            superchargeTicks--;
            // When supercharge ends, restore normal max health
            if (superchargeTicks == 0) {
                Objects.requireNonNull(this.m_21051_(Attributes.f_22276_)).m_22100_(180.0D);
                // Don't let health go above the new max
                if (this.m_21223_() > this.m_21233_()) {
                    this.m_21153_(this.m_21233_());
                }
                allowGroundBeamDuringStorm = false;
            }
        }
    }

    private void tickTempInvulnTimer() {
        // Temporary invulnerability timer
        if (tempInvulnTicks > 0) {
            tempInvulnTicks--;
            if (tempInvulnTicks == 0 && !isDying()) this.m_20331_(false);
        }
    }
    
    private void tickSuperchargeVfx() {
        // Supercharge VFX: periodic arcs/sparks around the body
        if ((isSupercharged() || this.m_9236_().m_46470_()) && superchargeVfxCooldown-- <= 0) {
            spawnSuperchargeVfx();
            superchargeVfxCooldown = 6 + this.f_19796_.m_188503_(6); // pulse every ~0.3-0.6s
        }
    }
    
    private void tickSleepTransition() {
        // Handle sleep enter transition: sit_down → fall_asleep → sleep loop
        if (isSleepingEntering() && !m_9236_().f_46443_) {
            // Check if sit_down animation is complete (sitProgress reached max)
            if (getSitProgress() >= maxSitTicks()) {
                // Sit down complete, now trigger fall_asleep if we haven't started the transition timer yet
                if (sleepTransitionTicks == getFallAsleepAnimationTicks()) {
                    // Just reached sitting position, trigger fall_asleep
                    animationHandler.triggerFallAsleepAnimation();
                }
            }
        }

        if (sleepTransitionTicks > 0) {
            sleepTransitionTicks--;
            if (sleepTransitionTicks == 0) {
                if (isSleepingEntering()) {
                    // fall_asleep finished: mark sleeping and trigger loop animation
                    setSleeping(true);
                    setSleepingEntering(false);
                    animationHandler.triggerSleepAnimation();
                } else if (isSleepingExiting()) {
                    // wake_up finished: dragon is now sitting, will stand up via normal sit system
                    setSleepingExiting(false);
                    // Start small ambient cooldown buffer (~0.5s)
                    sleepAmbientCooldownTicks = 10;
                }
            }
        }
    }
    
    private void tickSleepCooldowns() {
        if (sleepAmbientCooldownTicks > 0) sleepAmbientCooldownTicks--;
        if (sleepReentryCooldownTicks > 0) sleepReentryCooldownTicks--;
        if (sleepCancelTicks > 0) sleepCancelTicks--;
    }
    
    private void tickBankingLogic() {
        prevBankAngle = bankAngle;

        // Reset banking when not flying or when controls are locked - instant snap back
        if (areRiderControlsLocked() || !m_29443_() || m_21827_()) {
            if (bankDir != 0 || bankAngle != 0f || bankSmoothedYaw != 0f) {
                bankDir = 0;
                bankSmoothedYaw = 0f;
                bankHoldTicks = 0;
                bankAngle = 0f;
                prevBankAngle = 0f;
            }
            return;
        }

        // Exponential smoothing on yaw delta to avoid jitter, wrap to account for crossing 360 -> 0
        float yawChange = Mth.m_14177_(m_146908_() - f_19859_);
        bankSmoothedYaw = bankSmoothedYaw * 0.65f + yawChange * 0.35f; // More reactive (was 0.75/0.25)

        // Convert smoothed yaw delta into a banking roll. Multiplying gives us headroom for aggressive turns.
        float targetAngle = Mth.m_14036_(bankSmoothedYaw * 6.5f, -90f, 90f); // More dramatic (was 5.0)
        // Ease toward the new target so long sweeping turns feel weighty but responsive.
        bankAngle = Mth.m_14179_(0.40f, bankAngle, targetAngle); // Snappier (was 0.28)
        if (Math.abs(bankAngle) < 0.01f) {
            bankAngle = 0f;
        }

        // Update coarse direction for animation fallbacks / sound hooks
        float enter = 10.0f;
        float exit = 4.0f;

        int desiredDir = bankDir;
        if (bankAngle > enter) desiredDir = 1;
        else if (bankAngle < -enter) desiredDir = -1;
        else if (Math.abs(bankAngle) < exit) desiredDir = 0;  // banking_off when flying straight

        if (desiredDir != bankDir) {
            // If transitioning to "off" (0), use very short hold time for instant reset
            int holdTime = (desiredDir == 0) ? 1 : 2;
            if (bankHoldTicks >= holdTime) {
                bankDir = desiredDir;
                bankHoldTicks = 0;
            } else {
                bankHoldTicks++;
            }
        } else {
            bankHoldTicks = Math.min(bankHoldTicks + 1, 10);  // Reduced max from 20 to 10
        }
    }
    
    private void tickRiderLandingBlendTimer() {
        if (!m_20160_() || !m_29443_() || m_20096_()) {
            riderLandingBlendTicks = 0;
            if (!m_9236_().f_46443_) {
                this.f_19804_.m_135381_(DATA_RIDER_LANDING_BLEND, false);
            }
            return;
        }
        if (riderLandingBlendTicks > 0) {
            riderLandingBlendTicks--;
            if (riderLandingBlendTicks == 0 && !m_9236_().f_46443_) {
                this.f_19804_.m_135381_(DATA_RIDER_LANDING_BLEND, false);
            }
        }
    }

    private void triggerRiderLandingBlend() {
        riderLandingBlendTicks = RIDER_LANDING_BLEND_DURATION;
        if (!m_9236_().f_46443_) {
            this.f_19804_.m_135381_(DATA_RIDER_LANDING_BLEND, true);
        }
    }

    public boolean isRiderLandingBlendActive() {
        // Use synced entity data so client can see it
        return this.f_19804_.m_135370_(DATA_RIDER_LANDING_BLEND);
    }

    private double getAltitudeAboveTerrain() {
        net.minecraft.core.BlockPos pos = this.m_20183_();
        if (!m_9236_().m_46805_(pos)) {
            return Double.POSITIVE_INFINITY;
        }

        // Use MOTION_BLOCKING (includes water surface) to find the actual surface
        int surfaceY = this.m_9236_().m_6924_(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                pos.m_123341_(), pos.m_123343_());

        // Use MOTION_BLOCKING_NO_LEAVES to find solid ground below water
        int groundY = this.m_9236_().m_6924_(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                pos.m_123341_(), pos.m_123343_());

        // Scan a column from slightly above dragon down to BELOW the heightmap (heightmap returns +1 above actual blocks)
        int dragonY = (int) Math.floor(this.m_20186_());
        int scanTopY = dragonY + 3; // Check a bit above dragon (in case partially submerged)
        int scanBottomY = Math.min(groundY - 1, dragonY - 15);  // Scan below heightmap to catch water

        // Scan downward from above dragon to ground, checking for water at any height
        for (int y = scanTopY; y >= scanBottomY; y--) {
            net.minecraft.core.BlockPos checkPos = new net.minecraft.core.BlockPos(pos.m_123341_(), y, pos.m_123343_());
            net.minecraft.world.level.block.state.BlockState checkState = m_9236_().m_8055_(checkPos);

            if (!checkState.m_60819_().m_76178_()) {
                // Water/lava detected in column - don't trigger landing
                return Double.POSITIVE_INFINITY;
            }
        }

        return this.m_20186_() - groundY;
    }
    
    private void tickPitchingLogic() {
        tickRiderLandingBlendTimer();
        // Reset pitching when not flying or when controls are locked - INSTANT reset
        if (areRiderControlsLocked() || !m_29443_() || m_21827_()) {
            if (pitchDir != 0) {
                pitchDir = 0;
                pitchSmoothedPitch = 0f;
                pitchHoldTicks = 0;
            }
            return;
        }
        
        int desiredDir = pitchDir;

        if (this.m_20160_() && this.m_6688_() instanceof Player) {
            if (isGoingUp()) {
                desiredDir = -1;  // Pitching up
            } else if (isGoingDown()) {
                desiredDir = 1;   // Pitching down
            } else {
                desiredDir = 0;   // No pitching
            }
            if (isGoingDown()) {
                double altitude = getAltitudeAboveTerrain();
                // Trigger landing blend when descending below threshold altitude
                if (altitude != Double.POSITIVE_INFINITY && altitude >= -0.25D && altitude <= RIDER_LANDING_BLEND_ALTITUDE) {
                    // Trigger landing blend immediately when below altitude threshold
                    desiredDir = 0; // Stop pitching down
                    triggerRiderLandingBlend();
                }
            }
        } else {
            float pitchChange = m_146909_() - f_19860_;
            pitchSmoothedPitch = pitchSmoothedPitch * 0.85f + pitchChange * 0.15f;

            // Hysteresis thresholds - tighter for more responsive straight flight
            float enter = 3.0f;
            float exit = 3.0f;

            if (pitchSmoothedPitch > enter) desiredDir = 1;
            else if (pitchSmoothedPitch < -enter) desiredDir = -1;
            else if (Math.abs(pitchSmoothedPitch) < exit) desiredDir = 0;  // pitching_off when flying straight
        }

        // Faster reset to off state (reduced hold time)
        if (desiredDir != pitchDir) {
            // If transitioning to "off" (0), use shorter hold time for faster reset
            int holdTime = (desiredDir == 0) ? 1 : 2;
            if (pitchHoldTicks >= holdTime) {
                pitchDir = desiredDir;
                pitchHoldTicks = 0;
            } else {
                pitchHoldTicks++;
            }
        } else {
            pitchHoldTicks = Math.min(pitchHoldTicks + 1, 20);
        }
    }

    @Override
    protected void m_6677_(@Nonnull DamageSource source) {
        // Hurt ability pipeline plays custom audio.
    }

    @Override
    protected DragonAbilityType<?, ?> getHurtAbilityType() {
        return m_6162_() ? RaevyxAbilities.BABY_HURT : RaevyxAbilities.HURT;
    }

    @Override
    protected void onSuccessfulDamage(DamageSource source, float amount) {
        if (isDying()) {
            return;
        }
        if (hurtSoundCooldown > 0) {
            return;
        }
        super.onSuccessfulDamage(source, amount);
        this.hurtSoundCooldown = this.m_20160_() ? 15 : 8;
    }
    /**
     * Plays appropriate ambient sound based on wyvern's current mood and state
     */
    private void playCustomAmbientSound() {
        if (m_6162_()) {
            return;
        }
        RandomSource random = m_217043_();

        // Don't make ambient sounds if we're in combat or using abilities
        if (isDying() || m_5912_() || isBeaming() || getActiveAbility() != null) {
            return;
        }
        String vocalKey = null;

        // Choose sound based on current state and mood
        if (m_21827_()) {
            // Content sitting sounds
            vocalKey = (random.m_188501_() < 0.6f) ? "content" : "purr";
        } else if (m_29443_()) {
            // Occasional aerial sounds
            if (random.m_188501_() < 0.3f) vocalKey = "chuff";
        } else if (!m_29443_() && !isTakeoff() && !isLanding() && !isHovering() && (isWalking() || isRunning())) {
            // Ground movement sounds - different based on speed
            if (isRunning()) {
                vocalKey = "snort"; // Heavy breathing when running
            } else {
                vocalKey = "chuff"; // Gentle snorts when walking
            }
        } else {
            // Regular idle grumbling
            float grumbleChance = random.m_188501_();
            if (grumbleChance < 0.4f) {
                vocalKey = "grumble1";
            } else if (grumbleChance < 0.7f) {
                vocalKey = "grumble2";
            } else if (grumbleChance < 0.9f) {
                vocalKey = "grumble3";
            } else {
                vocalKey = "purr";
            }
        }
        // Play/animate if we chose one
        if (vocalKey != null) this.getSoundHandler().playVocal(vocalKey);
    }
    /**
     * Handles all the ambient grumbling and personality sounds
     * Because a silent wyvern is a boring wyvern
     */
    private void handleAmbientSounds() {
        // Suppress ambient sounds during transitions to prevent animation snapping
        if (m_6162_() || isDying() || m_5803_() || isSleepTransitioning() || isInSitTransition() || sleepAmbientCooldownTicks > 0) return;
        ambientSoundTimer++;

        // Time to make some noise?
        if (ambientSoundTimer >= nextAmbientSoundDelay) {
            playCustomAmbientSound(); // Renamed to avoid conflict with Mob.playAmbientSound()
            resetAmbientSoundTimer();
        }
    }

    private void suppressAmbientSounds(int ticks) {
        this.sleepAmbientCooldownTicks = Math.max(this.sleepAmbientCooldownTicks, ticks);
        this.ambientSoundTimer = 0;
        this.nextAmbientSoundDelay = Math.max(this.nextAmbientSoundDelay, ticks);
    }
    /**
     * Resets the ambient sound timer with some randomness
     */
    private void resetAmbientSoundTimer() {
        RandomSource random = m_217043_();
        ambientSoundTimer = 0;
        nextAmbientSoundDelay = MIN_AMBIENT_DELAY + random.m_188503_(MAX_AMBIENT_DELAY - MIN_AMBIENT_DELAY);
    }
    /**
     * Call this method when wyvern gets excited/happy (like when player approaches)
     * Uses GeckoLib animation keyframe system - sound is handled by animation
     */
    public void playExcitedSound() {
        getSoundHandler().playVocal("excited");
    }

    /**
     * Call this when wyvern gets annoyed (like when attacked by something weak)
     * Uses GeckoLib animation keyframe system - sound is handled by animation
     */
    public void playAnnoyedSound() {
        getSoundHandler().playVocal("annoyed");
    }

    private void handleDodgeMovement() {
        Vec3 current = this.m_20184_();
        Vec3 boosted = current.m_82549_(dodgeVec.m_82490_(0.25));
        this.m_20256_(boosted.m_82542_(0.92, 0.95, 0.92));
        this.f_19812_ = true;

        if (--dodgeTicksLeft <= 0) {
            dodging = false;
            dodgeVec = Vec3.f_82478_;
        }
    }

    // ===== TRAVEL METHOD =====
    @Override
    public void m_7023_(@NotNull Vec3 motion) {
        // Handle sitting/dodging/dying states first
        boolean sittingLocked = (this.m_21827_() || this.m_21825_()) && postStandUnlockTicks <= 0;
        if (sittingLocked || this.isDodging() || this.isDying() || this.m_5803_() || this.isSleepTransitioning()) {
            if (this.m_21573_().m_26570_() != null) {
                this.m_21573_().m_26573_();
            }
            motion = Vec3.f_82478_;
            super.m_7023_(motion);
            return;
        }

        if (dodging) {
            super.m_7023_(motion);
            return;
        }

        // Riding logic
        if (this.m_20160_() && this.m_6688_() instanceof Player player) {
            // Clear any AI navigation when being ridden
            if (this.m_21573_().m_26570_() != null) {
                this.m_21573_().m_26573_();
            }

            // Let tickRidden handle rotation smoothly
            // No instant rotation here - all handled in tickRidden for responsiveness

            if (m_29443_()) {
                // Delegate flying movement to rider controller for consistency
                this.riderController.handleRiderMovement(player, motion);
            } else {
                // Ground movement - use vanilla system which calls getRiddenInput()
                super.m_7023_(motion);
            }
        } else {
            // Normal AI movement
            if (m_29443_()) {
                // AI flight movement
                flightController.handleFlightTravel(motion);
            } else {
                // AI ground movement
                super.m_7023_(motion);
            }
        }

    }

    // ===== RANGED ATTACK IMPLEMENTATION =====
    @Override
    public void m_6504_(@Nonnull LivingEntity target, float distanceFactor) {
        // No ranged logic for now; ground melee goal handles combat
        // Intentionally left blank to avoid unintended ranged behavior
    }

    // Attack resolution is handled by DragonMeleeAttackGoal via abilities


    // ===== UTILITY METHODS =====

    public boolean isFlightControllerStuck() {
        if (this.f_21342_ instanceof com.leon.saintsdragons.server.ai.navigation.DragonFlightMoveHelper flightHelper) {
            return flightHelper.hasGivenUp();
        }
        return false;
    }


    @SuppressWarnings("unused") // Forge interface requires these parameters
    public static boolean canSpawnHere(EntityType<Raevyx> type,
                                       net.minecraft.world.level.LevelAccessor level,
                                       MobSpawnType reason,
                                       BlockPos pos,
                                       net.minecraft.util.RandomSource random) {
        BlockPos below = pos.m_7495_();
        if (!level.m_6425_(pos).m_76178_()) {
            return false;
        }
        if (!level.m_6425_(below).m_76178_()) {
            return false;
        }
        boolean solidGround = level.m_8055_(below).m_60783_(level, below, net.minecraft.core.Direction.UP);
        boolean feetFree = level.m_8055_(pos).m_60812_(level, pos).m_83281_();
        boolean headFree = level.m_8055_(pos.m_7494_()).m_60812_(level, pos.m_7494_()).m_83281_();
        return solidGround && feetFree && headFree;
    }

    /**
     * Family group spawning: When a wild Raevyx spawns naturally, it has a 60% chance
     * to spawn with 2-3 baby hatchlings, creating a family group.
     */
    @Override
    @Nullable
    public SpawnGroupData m_6518_(
            @Nonnull net.minecraft.world.level.ServerLevelAccessor level,
            @Nonnull net.minecraft.world.DifficultyInstance difficulty,
            @Nonnull MobSpawnType spawnReason,
            @Nullable SpawnGroupData spawnData,
            @Nullable CompoundTag dataTag
    ) {
        spawnData = super.m_6518_(level, difficulty, spawnReason, spawnData, dataTag);

        // Only spawn families during chunk generation
        // Use a custom SpawnGroupData to track if we've already spawned babies
        if (spawnReason == MobSpawnType.CHUNK_GENERATION) {
            // Check if this is the parent (not a baby we're spawning)
            if (spawnData == null || !(spawnData instanceof RaevyxFamilyData)) {
                // 60% chance to spawn with babies
                if (this.f_19796_.m_188501_() < 0.6F) {
                    int babyCount = 2 + this.f_19796_.m_188503_(2); // 2 or 3 babies

                    // Mark this as a family spawn (false = don't spawn baby via vanilla logic)
                    spawnData = new RaevyxFamilyData(false);

                    for (int i = 0; i < babyCount; i++) {
                        Raevyx baby = ModEntities.RAEVYX.get().m_20615_(level.m_6018_());
                        if (baby != null) {
                            // Set baby properties
                            baby.m_6863_(true);
                            baby.m_146762_(-24000); // Standard baby age
                            baby.setGender(this.f_19796_.m_188499_() ? DragonGender.FEMALE : DragonGender.MALE);

                            // Position baby VERY close to parent to avoid chunk boundary issues
                            double angle = (Math.PI * 2.0 * i) / babyCount;
                            double distance = 1.0 + this.f_19796_.m_188500_() * 0.5; // 1-1.5 blocks away (very close)
                            double offsetX = Math.cos(angle) * distance;
                            double offsetZ = Math.sin(angle) * distance;

                            baby.m_7678_(
                                    this.m_20185_() + offsetX,
                                    this.m_20186_(),
                                    this.m_20189_() + offsetZ,
                                    this.f_19796_.m_188501_() * 360.0F,
                                    0.0F
                            );

                            // Finalize and add to world
                            // Pass the family data to prevent recursive baby spawning
                            baby.m_6518_(level, difficulty, MobSpawnType.CHUNK_GENERATION, spawnData, null);
                            level.m_7967_(baby);
                        }
                    }
                }
            }
        }

        return spawnData;
    }

    /**
     * Custom SpawnGroupData to track family spawning and prevent recursive baby spawning.
     * Extends AgeableMobGroupData to satisfy parent class requirements.
     */
    private static class RaevyxFamilyData extends AgeableMob.AgeableMobGroupData {
        public RaevyxFamilyData(boolean shouldSpawnBaby) {
            super(shouldSpawnBaby);
        }
    }

    @Override
    public int m_8132_() {
        return isBeaming() ? (int)MAX_BEAM_PITCH_DEG : 180;
    }

    // Help the wyvern keep its gaze while running: allow wide, fast head turns
    @Override
    public int m_8085_() {
        return isBeaming() ? (int)MAX_BEAM_YAW_DEG : 180;
    }

    @Override
    public int m_21529_() {
        // Slightly slower head-only snapping while beaming to avoid neck doing all the work
        return isBeaming() ? 90 : 180;
    }

    // ===== AI GOALS =====
    @Override
    protected void m_8099_() {
        this.f_21345_.m_25352_(1, new RaevyxDodgeGoal(this));
        this.f_21345_.m_25352_(5, new SitWhenOrderedToGoal(this));
        this.f_21345_.m_25352_(6, new FloatGoal(this));
        this.f_21345_.m_25352_(7, new RaevyxFollowParentGoal(this, 1.15D));
        this.f_21345_.m_25352_(7, new RaevyxBreedGoal(this, 1.0D));

        // Combat goal - all-in-one system (movement + attack selection)
        this.f_21345_.m_25352_(3, new RaevyxCombatGoal(this));

        // Movement/idle
        // Unified sleep goal: high priority to preempt follow/wander, but calm() prevents overriding combat/aggro
        this.f_21345_.m_25352_(0, new RaevyxSleepGoal(this));         // Higher priority than follow
        this.f_21345_.m_25352_(1, new RaevyxRestGoal(this));          // Casual sitting for wild dragons
        this.f_21345_.m_25352_(8, new RaevyxFollowOwnerGoal(this));   // Lower priority than combat
        this.f_21345_.m_25352_(9, new RaevyxGroundWanderGoal(this, 1.0, 60)); // Lower priority than combat
        
        // Item pickup behavior (like foxes eating berries) + ground fish taming
        this.f_21345_.m_25352_(10, new RaevyxTemptGoal(this, 1.2,
                net.minecraft.world.item.crafting.Ingredient.m_43929_(net.minecraft.world.item.Items.f_42527_, 
                                                               net.minecraft.world.item.Items.f_42526_,
                                                               net.minecraft.world.item.Items.f_42529_), false));
        
        this.f_21345_.m_25352_(11, new RaevyxFlightGoal(this));
        // Look goals that skip when being ridden (so rider has full control)
        this.f_21345_.m_25352_(12, new RandomLookAroundGoal(this) {
            @Override
            public boolean m_8036_() {
                return !Raevyx.this.m_20160_() && super.m_8036_();
            }
        });
        this.f_21345_.m_25352_(12, new LookAtPlayerGoal(this, Player.class, 8.0F) {
            @Override
            public boolean m_8036_() {
                return !Raevyx.this.m_20160_() && super.m_8036_();
            }
        });

        // Target selection - use custom goals that respect ally system
        this.f_21346_.m_25352_(1, new com.leon.saintsdragons.server.ai.goals.base.DragonOwnerHurtByTargetGoal(this));
        this.f_21346_.m_25352_(2, new com.leon.saintsdragons.server.ai.goals.base.DragonOwnerHurtTargetGoal(this));
        this.f_21346_.m_25352_(3, new RaevyxProtectBabiesGoal(this));  // Protect nearby babies
        this.f_21346_.m_25352_(4, new HurtByTargetGoal(this));
        // Neutral behavior: do not proactively target players. Only retaliate when hurt or defend owner.
    }

    @Override
    public boolean m_6469_(@Nonnull DamageSource damageSource, float amount) {
        // During dying sequence, ignore all damage except the final generic kill used by DieAbility
        if (isDying()) {
            if (damageSource.m_276093_(DamageTypes.f_286979_)) {
                return super.m_6469_(damageSource, amount);
            }
            return false;
        }
        // Immune to lightning damage
        if (damageSource.m_276093_(DamageTypes.f_268450_)) {
            return false;
        }
        // Wake if sleeping and suppress re-entry on damage
        if (m_5803_() || isSleepingEntering() || isSleepingExiting()) {
            wakeUpImmediately();
            suppressSleep(200);
        }
        if (damageSource.m_276093_(DamageTypes.f_268671_)) {
            return false;
        }

        // Intercept lethal damage to play custom death ability first
        DragonAbilityType<?, ?> dieAbility = m_6162_() ? RaevyxAbilities.BABY_DIE : RaevyxAbilities.DIE;
        if (handleLethalDamage(damageSource, amount, dieAbility)) {
            return true;
        }

        // Store previous flying state to restore if being ridden
        boolean wasFlying = m_29443_();
        boolean wasRidden = m_20160_();

        boolean result = super.m_6469_(damageSource, amount);

        // If the wyvern was being ridden and flying before taking damage,
        // ensure it stays flying regardless of any AI goals triggered by damage
        if (result && wasRidden && wasFlying && m_20160_()) {
            // Restore flying state to prevent forced landing when ridden
            setFlying(true);
            // Cancel any landing sequence that might have been triggered
            setLanding(false);
            // Ensure we're in air navigation mode
            switchToAirNavigation();
        }

        return result;
    }

    // Lightning immunity is now handled by DragonEntity base class via DragonType.LIGHTNING elemental profile

    // ===== BREATHING / AIR SUPPLY =====
    // Allow the wyvern to hold its breath underwater for ~3 minutes (3600 ticks)
    @Override
    public int m_6062_() {
        return 20 * 60 * 3; // 3600 ticks ~= 180s
    }

    // Speed up air refill when out of water so it doesn't take excessively long
    @Override
    public int m_7305_(int currentAir) {
        int refillPerTick = 50; // ~3600/72 ticks ≈ 3.6s to refill from 0
        return Math.min(m_6062_(), currentAir + refillPerTick);
    }

    // Prevent lightning strikes from igniting or applying any side effects
    @Override
    public void m_8038_(@Nonnull ServerLevel level, @Nonnull LightningBolt lightning) {
        // Do not call super; ignore ignition and effects
        if (this.m_6060_()) this.m_20095_();
    }
    // ===== ANIMATION HELPER METHODS =====
    
    /**
     * Gets the current bank direction for animation purposes
     * @return -1 for left, 0 for none, 1 for right
     */
    public int getBankDirection() {
        return bankDir;
    }

    /**
     * Gets the current bank angle in degrees. Positive values bank right, negative bank left.
     */
    public float getBankAngleDegrees() {
        return bankAngle;
    }

    /**
     * Interpolated bank angle for smooth client-side rendering.
     */
    public float getBankAngleDegrees(float partialTick) {
        return Mth.m_14179_(partialTick, prevBankAngle, bankAngle);
    }
    
    /**
     * Gets the current pitch direction for animation purposes
     * @return -1 for up, 0 for none, 1 for down
     */
    public int getPitchDirection() {
        return pitchDir;
    }

    /**
     * Checks if the wyvern is currently summoning (controls locked for ability)
     * @return true if summoning
     */
    public boolean isSummoning() {
        return false;
    }

    // ===== SUPERCHARGE (Summon Storm) =====
    private int superchargeTicks = 0;
    public void startSupercharge(int ticks) {
        boolean wasNotSupercharged = !isSupercharged();
        this.superchargeTicks = Math.max(this.superchargeTicks, Math.max(0, ticks));
        
        // When becoming supercharged, double the max health attribute and heal to full
        if (wasNotSupercharged && isSupercharged()) {
            // Double the max health attribute
            Objects.requireNonNull(this.m_21051_(Attributes.f_22276_)).m_22100_(360.0D);
            // Heal to full health
            this.m_21153_(this.m_21233_());
            this.allowGroundBeamDuringStorm = true;
        }
    }
    
    
    public boolean isSupercharged() { return superchargeTicks > 0; }
    public float getDamageMultiplier() { return isSupercharged() ? 2.0f : 1.0f; }
    // Temporary invulnerability timer (e.g., during Summon Storm windup)
    private int tempInvulnTicks = 0;
    public void startTemporaryInvuln(int ticks) {
        this.tempInvulnTicks = Math.max(this.tempInvulnTicks, Math.max(0, ticks));
        this.m_20331_(true);
    }

    // VFX pulse throttle
    private int superchargeVfxCooldown = 0;
    private void spawnSuperchargeVfx() {
        if (!(this.m_9236_() instanceof net.minecraft.server.level.ServerLevel server)) return;
        // Center around chest
        net.minecraft.world.phys.Vec3 center = this.m_20182_().m_82520_(0, this.m_20206_() * 0.6, 0);
        double radius = Math.max(this.m_20191_().m_82362_(), this.m_20191_().m_82385_()) * 0.55;
        // 2-4 micro-bursts per pulse, each very short and randomized
        int bursts = 2 + this.f_19796_.m_188503_(3);
        for (int i = 0; i < bursts; i++) {
            // Short local segment
            net.minecraft.world.phys.Vec3 dir = randomUnit(this.f_19796_);
            double length = 0.4 + this.f_19796_.m_188500_() * 0.7; // ~0.4-1.1 blocks
            net.minecraft.world.phys.Vec3 offset = randomUnit(this.f_19796_).m_82490_(radius * 0.35);
            net.minecraft.world.phys.Vec3 from = center.m_82549_(offset);
            net.minecraft.world.phys.Vec3 to = from.m_82549_(dir.m_82490_(length));
            float size = 0.5f + this.f_19796_.m_188501_() * 0.25f; // smaller sprites
            emitMicroArc(server, from, to, size);
        }
        // A couple of sparks near center (smaller spread)
        server.m_8767_(net.minecraft.core.particles.ParticleTypes.f_175830_,
                center.f_82479_, center.f_82480_, center.f_82481_,
                3, radius * 0.15, radius * 0.15, radius * 0.15, 0.0);
    }
    private void emitMicroArc(net.minecraft.server.level.ServerLevel server, net.minecraft.world.phys.Vec3 from, net.minecraft.world.phys.Vec3 to, float size) {
        net.minecraft.world.phys.Vec3 delta = to.m_82546_(from);
        int steps = 2 + this.f_19796_.m_188503_(3); // 2-4 points only
        net.minecraft.world.phys.Vec3 step = delta.m_82490_(1.0 / steps);
        net.minecraft.world.phys.Vec3 pos = from;
        net.minecraft.world.phys.Vec3 dir = step.m_82556_() > 1.0e-6 ? step.m_82541_() : randomUnit(this.f_19796_);
        boolean female = this.isFemale();
        for (int i = 0; i <= steps; i++) {
            // Randomly pick arc type per point and randomly drop some points for a crackly feel
            if (this.f_19796_.m_188501_() < 0.7f) {
                if (this.f_19796_.m_188499_()) {
                    server.m_8767_(new RaevyxLightningArcData(size, female),
                            pos.f_82479_, pos.f_82480_, pos.f_82481_, 1, dir.f_82479_, dir.f_82480_, dir.f_82481_, 0.0);
                } else {
                    server.m_8767_(new RaevyxLightningStormData(size, female),
                            pos.f_82479_, pos.f_82480_, pos.f_82481_, 1, dir.f_82479_, dir.f_82480_, dir.f_82481_, 0.0);
                }
            }
            pos = pos.m_82549_(step);
        }
    }
    private static net.minecraft.world.phys.Vec3 randomUnit(net.minecraft.util.RandomSource rnd) {
        double u = rnd.m_188500_();
        double v = rnd.m_188500_();
        double theta = 2 * Math.PI * u;
        double z = 2 * v - 1;
        double r = Math.sqrt(1 - z * z);
        return new net.minecraft.world.phys.Vec3(r * Math.cos(theta), z, r * Math.sin(theta));
    }

    // ===== SIT TRANSITIONS =====
    public boolean isInSitTransition() {
        return isSittingDown || isStandingUp;
    }

    public boolean isSittingDownAnimation() {
        return isSittingDown;
    }

    public boolean isStandingUpAnimation() {
        return isStandingUp;
    }

    // ===== ANIMATION TIMING HELPERS =====
    /**
     * Returns the duration in ticks for the sit down animation.
     * Uses shared animation name - both baby and adult use 1.5s animation.
     */
    private int getSitDownAnimationTicks() {
        return 30; // 1.5s for both baby and adult (unified)
    }

    /**
     * Returns the duration in ticks for the sit up animation.
     * Uses shared animation name - both baby and adult use 1.0s animation.
     */
    private int getSitUpAnimationTicks() {
        return 20; // 1.0s - matches actual animation length
    }

    /**
     * Returns the duration in ticks for the fall asleep animation.
     * Uses shared animation name - both baby and adult use 2.5s animation.
     */
    private int getFallAsleepAnimationTicks() {
        return 50; // 2.5s for both baby and adult (unified)
    }

    /**
     * Returns the duration in ticks for the wake up animation.
     * Uses shared animation name - both baby and adult use 2.625s animation.
     */
    private int getWakeUpAnimationTicks() {
        return 53; // 2.625s for both baby and adult (unified, ~2.65s)
    }

    /**
     * Override max sit ticks to match the actual sit_down animation length.
     * This prevents visual desync where the SIT loop starts before sit_down finishes.
     */
    @Override
    public float maxSitTicks() {
        return 30.0F; // Matches sit_down animation (1.5s = 30 ticks)
    }

    // ===== SLEEPING =====
    public boolean m_5803_() {
        return getBooleanData(DATA_SLEEPING);
    }
    public void setSleeping(boolean sleeping) {
        setBooleanData(DATA_SLEEPING, sleeping);
    }
    public boolean isSleepTransitioning() {
        return isSleepingEntering() || isSleepingExiting();
    }

    public boolean isSleepingEntering() {
        return getBooleanData(DATA_SLEEPING_ENTERING);
    }

    public void setSleepingEntering(boolean entering) {
        setBooleanData(DATA_SLEEPING_ENTERING, entering);
    }

    public boolean isSleepingExiting() {
        return getBooleanData(DATA_SLEEPING_EXITING);
    }

    public void setSleepingExiting(boolean exiting) {
        setBooleanData(DATA_SLEEPING_EXITING, exiting);
    }
    public boolean isSleepLocked() {
        return sleepLocked || m_5803_() || isSleepingEntering() || isSleepingExiting();
    }

    private void enterSleepLock() {
        int snapshot = this.getCommand();
        if (!sleepLocked) {
            sleepLocked = true;
            sleepCommandSnapshot = snapshot;
        }
        if (snapshot == 1) {
            this.setCommandManual(1);
        } else {
            this.setCommandAuto(1);
        }
        this.m_21839_(true);
        this.m_21573_().m_26573_();
        this.m_6710_(null);
        this.setRunning(false);
        this.setGroundMoveStateFromAI(0);
        this.m_20256_(Vec3.f_82478_);
        this.setFlying(false);
        this.setLanding(false);
        this.setTakeoff(false);
        this.setHovering(false);
    }

    private void releaseSleepLock() {
        if (sleepLocked) {
            int desired = sleepCommandSnapshot;
            sleepCommandSnapshot = -1;
            sleepLocked = false;
            if (desired == 1) {
                this.setCommandManual(1);
                this.m_21839_(true);
            } else {
                this.setCommandAuto(desired);
                this.m_21839_(false);
            }
        }
        this.m_21573_().m_26573_();
        this.setRunning(false);
        this.setGroundMoveStateFromAI(0);
    }

    public void startSleepEnter() {
        if (m_5803_() || isSleepingEntering() || isSleepingExiting()) return;
        setSleepingEntering(true);
        // New system: sit_down (uses sitProgress) → fall_asleep → sleep loop
        sleepTransitionTicks = getFallAsleepAnimationTicks();
        // Trigger sit_down animation first (handled by sit progress system)
        animationHandler.triggerSitDownAnimation();
        if (!m_9236_().f_46443_) {
            enterSleepLock();
        }
    }

    public void startSleepExit() {
        if ((!m_5803_() && !isSleepingEntering()) || isSleepingExiting()) return;
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        setSleepingEntering(false);
        setSleepingExiting(true);
        // New system: wake_up → sit (brief) → sit_up
        sleepTransitionTicks = getWakeUpAnimationTicks();
        // Trigger wake_up animation
        animationHandler.triggerWakeUpAnimation();
        if (!m_9236_().f_46443_) {
            suppressSleep(20);
            releaseSleepLock();
        }
    }

    public void wakeUpImmediately() {
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        setSleepingEntering(false);
        setSleepingExiting(false);
        sleepTransitionTicks = 0;
        sleepCancelTicks = 2;
        if (!m_9236_().f_46443_) {
            suppressSleep(20);
            releaseSleepLock();
        }
    }

    public void suppressSleep(int ticks) {
        sleepReentryCooldownTicks = Math.max(sleepReentryCooldownTicks, ticks);
    }
    public boolean isSleepSuppressed() {
        return sleepReentryCooldownTicks > 0;
    }

    // ===== INTERACTION =====
    @Override
    public @NotNull InteractionResult m_6071_(@NotNull Player player, @NotNull InteractionHand hand) {
        // Delegate to the specialized interaction handler
        InteractionResult result = lightningInteractionHandler.handleInteraction(player, hand);
        
        // If the handler didn't handle it, fall back to super implementation
        if (result == InteractionResult.PASS) {
            return super.m_6071_(player, hand);
        }
        
        return result;
    }

    @Override
    public void m_21839_(boolean sitting) {
        super.m_21839_(sitting);

        if (sitting) {
            // Force landing if flying when ordered to sit
            if (m_29443_()) {
                this.setLanding(true);
            }
            this.setRunning(false);
            this.m_21573_().m_26573_();
        } else {
            // Don't clear sitProgress here; let updateSittingProgress() play the stand-up animation first.
            if (!m_9236_().f_46443_) {
                // Ensure we are in ground navigation mode and not stuck in legacy flight flags
                switchToGroundNavigation();
                if (m_29443_()) {
                    setFlying(false);
                }
                setTakeoff(false);
                setLanding(false);
                setHovering(false);
                this.usingAirNav = false;
                postStandUnlockTicks = Math.max(postStandUnlockTicks, 20);
            }
            if (this.getCommand() == 1) {
                this.setCommandAuto(0);
            }
            if (!m_9236_().f_46443_) {
                this.followFailsafeCooldown = 0;
                this.m_21573_().m_26573_();
                this.tickFollowFailsafe();
            }
        }
    }

    @Override
    public void m_7822_(byte eventId) {
        if (eventId == 6) {
            // Failed taming - show smoke particles ONLY, no sitting behavior at all
            if (m_9236_().f_46443_) {
                // Show smoke particles for failed taming
                for (int i = 0; i < 7; ++i) {
                    double d0 = this.f_19796_.m_188583_() * 0.02D;
                    double d1 = this.f_19796_.m_188583_() * 0.02D;
                    double d2 = this.f_19796_.m_188583_() * 0.02D;
                    this.m_9236_().m_7106_(net.minecraft.core.particles.ParticleTypes.f_123762_,
                            this.m_20208_(1.0D), this.m_20187_() + 0.5D, this.m_20262_(1.0D), d0, d1, d2);
                }
            }
            // IMPORTANT: Don't call super for event 6 - it might trigger sitting behavior
        } else if (eventId == 7) {
            // Successful taming - show hearts only, sitting is handled separately
            if (m_9236_().f_46443_) {
                // Show heart particles for successful taming
                for (int i = 0; i < 7; ++i) {
                    double d0 = this.f_19796_.m_188583_() * 0.02D;
                    double d1 = this.f_19796_.m_188583_() * 0.02D;
                    double d2 = this.f_19796_.m_188583_() * 0.02D;
                    this.m_9236_().m_7106_(net.minecraft.core.particles.ParticleTypes.f_123750_,
                            this.m_20208_(1.0D), this.m_20187_() + 0.5D, this.m_20262_(1.0D), d0, d1, d2);
                }
            }
            // IMPORTANT: Don't call super for event 7 either - sitting is explicitly handled in mobInteract
        } else {
            // Call super for all other entity events (NOT 6 or 7)
            super.m_7822_(eventId);
        }
    }

    @Override
    public boolean m_6898_(@Nonnull ItemStack stack) {
        return stack.m_150930_(Items.f_42527_) || stack.m_150930_(Items.f_42526_);
    }


    // ===== SAVE/LOAD =====
    @Override
    public void m_7380_(@NotNull CompoundTag tag) {
        super.m_7380_(tag);
        saveRideableData(tag);
        tag.m_128405_("TimeFlying", timeFlying);
        tag.m_128379_("UsingAirNav", usingAirNav);
        tag.m_128405_("RiderTakeoffTicks", riderTakeoffTicks);

        // Save critical flight state variables that were missing
        tag.m_128356_("LastLandingGameTime", lastLandingGameTime);
        tag.m_128379_("LandingFlag", landingFlag);
        tag.m_128405_("LandingTimer", landingTimer);

        // Save lock states (transient rider/takeoff locks intentionally omitted)

        // Persist combat cooldowns
        this.combatManager.saveToNBT(tag);

        // Persist supercharge timer so logout/login doesn't clear buff early
        tag.m_128405_("SuperchargeTicks", Math.max(0, this.superchargeTicks));

        // Persist temporary invulnerability timer (e.g., during Summon Storm windup)
        tag.m_128405_("TempInvulnTicks", Math.max(0, this.tempInvulnTicks));
        tag.m_128379_("AllowGroundBeamStorm", this.allowGroundBeamDuringStorm);

        // Persist sleep state and transition timers
        tag.m_128379_("Sleeping", this.m_5803_());
        // Sleep transition states now synced via entity data, no need to save separately
        tag.m_128405_("SleepTransitionTicks", Math.max(0, this.sleepTransitionTicks));
        tag.m_128405_("SleepAmbientCooldownTicks", Math.max(0, this.sleepAmbientCooldownTicks));
        tag.m_128405_("SleepReentryCooldownTicks", Math.max(0, this.sleepReentryCooldownTicks));
        tag.m_128405_("SleepCancelTicks", Math.max(0, this.sleepCancelTicks));
        tag.m_128379_("SleepLock", this.sleepLocked);
        tag.m_128405_("SleepCommandSnapshot", this.sleepCommandSnapshot);
        tag.m_128379_("ManualSitCommand", this.manualSitCommand);

        // Persist rest state manager
        restManager.save(tag);

        animationController.writeToNBT(tag);
    }

    @Override
    public void m_7378_(@NotNull CompoundTag tag) {
        super.m_7378_(tag);
        loadRideableData(tag);
        this.timeFlying = tag.m_128451_("TimeFlying");
        this.usingAirNav = tag.m_128471_("UsingAirNav");
        this.riderTakeoffTicks = tag.m_128441_("RiderTakeoffTicks") ? tag.m_128451_("RiderTakeoffTicks") : 0;

        // Restore critical flight state variables that were missing
        this.lastLandingGameTime = tag.m_128441_("LastLandingGameTime") ? tag.m_128454_("LastLandingGameTime") : Long.MIN_VALUE;
        this.landingFlag = tag.m_128441_("LandingFlag") && tag.m_128471_("LandingFlag");
        this.landingTimer = tag.m_128441_("LandingTimer") ? tag.m_128451_("LandingTimer") : 0;

        // Restore lock states (transient rider/takeoff locks reset on load)
        this.riderControlLockTicks = 0;
        this.takeoffLockTicks = 0;

        // Restore combat cooldowns
        this.combatManager.loadFromNBT(tag);

        // Restore supercharge timer if present
        if (tag.m_128441_("SuperchargeTicks")) {
            this.superchargeTicks = Math.max(0, tag.m_128451_("SuperchargeTicks"));
        }
        // Restore temporary invulnerability
        if (tag.m_128441_("TempInvulnTicks")) {
            this.tempInvulnTicks = Math.max(0, tag.m_128451_("TempInvulnTicks"));
            if (this.tempInvulnTicks > 0) {
                this.m_20331_(true);
            }
        }

        if (tag.m_128441_("AllowGroundBeamStorm")) {
            this.allowGroundBeamDuringStorm = tag.m_128471_("AllowGroundBeamStorm");
        }

        // Restore sleep state and transition timers
        if (tag.m_128441_("Sleeping")) this.setSleeping(tag.m_128471_("Sleeping"));
        // Sleep transition states now synced via entity data, loaded automatically
        this.sleepTransitionTicks = Math.max(0, tag.m_128451_("SleepTransitionTicks"));
        this.sleepAmbientCooldownTicks = Math.max(0, tag.m_128451_("SleepAmbientCooldownTicks"));
        this.sleepReentryCooldownTicks = Math.max(0, tag.m_128451_("SleepReentryCooldownTicks"));
        this.sleepCancelTicks = Math.max(0, tag.m_128451_("SleepCancelTicks"));
        this.sleepLocked = tag.m_128471_("SleepLock");
        this.sleepCommandSnapshot = tag.m_128451_("SleepCommandSnapshot");

        // Restore rest state manager and re-trigger animations based on loaded state
        restManager.load(tag);
        com.leon.saintsdragons.server.entity.sleep.DragonRestState restState = restManager.getCurrentState();
        switch (restState) {
            case SLEEPING -> {
                m_21839_(true);
                animationHandler.triggerSleepAnimation();
            }
            case SITTING_DOWN, SITTING, SITTING_AFTER -> {
                m_21839_(true);
            }
            case FALLING_ASLEEP -> {
                m_21839_(true);
                startSleepEnter();
            }
            case WAKING_UP -> {
                m_21839_(true);
                startSleepExit();
            }
            case STANDING_UP -> {
                m_21839_(false);
            }
        }

        animationController.readFromNBT(tag);

        this.manualSitCommand = tag.m_128441_("ManualSitCommand") && tag.m_128471_("ManualSitCommand");

        if (this.usingAirNav) {
            switchToAirNavigation();
        } else {
            switchToGroundNavigation();
        }

        // Safety: if we reloaded while flagged as sitting but owner command isn't "sit",
        // clear the stuck sitting state so pathfinding goals can resume.
        if (this.getCommand() != 1 && this.m_21827_()) {
            this.m_21839_(false);
        }

        // If we reload while sleep-locked (or mid-transition), immediately wake and clear the lock so AI goals resume.
        if (this.sleepLocked || this.isSleepingEntering() || this.isSleepingExiting() || this.f_19804_.m_135370_(DATA_SLEEPING)) {
            this.releaseSleepLock();
            this.wakeUpImmediately();
            this.suppressSleep(200);
        }
        this.setSleepingEntering(false);
        this.setSleepingExiting(false);
        this.sleepTransitionTicks = 0;
        this.f_19804_.m_135381_(DATA_SLEEPING, false);
        this.sleepCommandSnapshot = -1;
        this.followFailsafeCooldown = 0;

        // If we saved while flying, keep the wyvern in the air briefly after load
        if (tag.m_128471_("Flying")) {
            this.postLoadAirStabilizeTicks = 60; // ~3 seconds of grace to receive rider inputs
            // Also treat as takeoff for a short while to apply upward force
            this.riderTakeoffTicks = Math.max(this.riderTakeoffTicks, 40);

            // Ensure flight controller is properly reactivated for ALL dragons
            if (!m_9236_().f_46443_) {
                // For all dragons, restart flight controller to prevent drifting
                this.flightController.shouldTakeoff();

                // Force proper flight state restoration
                this.setFlying(true);
                this.setTakeoff(true);
                this.setHovering(true);
                this.setLanding(false);
                this.switchToAirNavigation();
            }
        }

        // Clear navigation and target if wyvern is sitting to prevent AI goal issues on world reload
        if (this.m_21827_()) {
            this.m_21573_().m_26573_();
            this.m_6710_(null);
            this.m_21561_(false);
        }

        if (this.getCommand() == 1 && !this.manualSitCommand) {
            this.setCommandAuto(0);
            this.m_21839_(false);
        }
    }

    // Rider takeoff window accessors for controllers
    public int getRiderTakeoffTicks() { return riderTakeoffTicks; }
    public void setRiderTakeoffTicks(int ticks) { this.riderTakeoffTicks = Math.max(0, ticks); }
    
    /**
     * Clears all states when mounting to ensure clean transition to rider control
     */
    public void clearAllStatesForMounting() {
        // Clear combat states
        this.m_6710_(null);
        this.setBeaming(false);
        
        // Clear movement states
        this.setRunning(false);
        this.m_21573_().m_26573_();
        
        // Clear flight states (will be controlled by rider)
        this.setTakeoff(false);
        this.setLanding(false);
        this.setHovering(false);
        
        // Clear sitting state and sync command value
        if (this.m_21827_()) {
            this.m_21839_(false);
            // If wyvern was sitting, set command to Follow (0) when mounted
            if (this.getCommand() == 1) {
                this.setCommandAuto(0);
            }
        }
        
        // Clear any pending timers
        this.riderTakeoffTicks = 0;
        this.postLoadAirStabilizeTicks = 0;
        
        // Reset combat manager
        this.combatManager.clearAllStates();
        
        // Clear any sleep suppression (fresh start)
        this.sleepReentryCooldownTicks = 0;
        this.sleepAmbientCooldownTicks = 0;
    }



    // ===== ANIMATION TRIGGERS =====
    /**
     * Triggers the dodge animation - called when wyvern dodges projectiles
     */
    public void triggerDodgeAnimation() {
        // Trigger native GeckoLib action key
        animationHandler.triggerDodgeAnimation();
    }

    // Note: We rely on GeckoLib triggerAnim(...) to play action clips.

    // ===== GECKOLIB =====
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Use entity-specific controller names to prevent animation bleeding between dragons
        // Update frequency: run every tick to maintain accurate keyframe timing
        AnimationController<Raevyx> movementController =
                new AnimationController<>(this, "movement", 5, animationController::handleMovementAnimation);

        // Action controller uses ONLY triggers (no predicate logic)
        // All animations (combat, abilities, sleep, death) are triggered via triggerAnim()
        // Lightning wyvern = fast, aggressive combat - instant transitions
        AnimationController<Raevyx> actionController =
                new AnimationController<>(this, "action", 2, state -> PlayState.STOP);

        // Sound keyframes - only register on relevant controllers to prevent duplication
        // Movement controller: handles footsteps, wing flaps during locomotion
        movementController.setSoundKeyframeHandler(this::onAnimationSound);
        // Action controller: handles combat sounds, ability sounds, vocalizations
        actionController.setSoundKeyframeHandler(this::onAnimationSound);

        // Setup animation triggers via animation handler
        animationHandler.setupActionController(actionController);

        // Dedicated controller for instant hurt/die reactions (no transition easing)
        AnimationController<Raevyx> HurtController =
                new AnimationController<>(this, "hurt", 3, state -> PlayState.STOP);
        HurtController.triggerableAnim("raevyx_hurt",
                RawAnimation.begin().thenPlay("animation.raevyx.hurt"));
        HurtController.triggerableAnim("baby_raevyx_hurt",
                RawAnimation.begin().thenPlay("animation.raevyx.hurt"));

        HurtController.setSoundKeyframeHandler(this::onAnimationSound);
        controllers.add(HurtController);

        // Babies don't fly, so skip banking/pitching controllers
        if (!this.m_6162_()) {
            AnimationController<Raevyx> bankingController =
                    new AnimationController<>(this, "banking", 8, animationHandler::bankingPredicate);
            AnimationController<Raevyx> pitchingController =
                    new AnimationController<>(this, "pitching", 6, animationHandler::pitchingPredicate);
            // Banking/Pitching controllers: NO sound keyframes (purely visual animations)

            // Add controllers in order
            controllers.add(bankingController);
            controllers.add(pitchingController);
        }

        controllers.add(movementController);
        controllers.add(actionController);
    }

    @Override
    public Map<String, VocalEntry> getVocalEntries() {
        return VOCAL_ENTRIES;
    }

    @Override
    public DragonSoundProfile getSoundProfile() {
        return RaevyxSoundProfile.INSTANCE;
    }

    @Override
    public com.leon.saintsdragons.server.entity.ability.DragonAbilityType<?, ?> getPrimaryAttackAbility() {
        // Use melee mode to switch between bite and horn gore
        // Mode 0 = bite (primary), Mode 1 = horn gore (secondary)
        return getMeleeMode() == 0 ?
            RaevyxAbilities.RAEVYX_BITE :
            RaevyxAbilities.RAEVYX_HORN_GORE;
    }

    @Override
    public com.leon.saintsdragons.server.entity.ability.DragonAbilityType<?, ?> getRoaringAbility() {
        return RaevyxAbilities.RAEVYX_ROAR;
    }

    @Override
    public com.leon.saintsdragons.server.entity.ability.DragonAbilityType<?, ?> getChannelingAbility() {
        return RaevyxAbilities.RAEVYX_SUMMON_STORM;
    }

    public void onAnimationSound(SoundKeyframeEvent<Raevyx> event) {
        // Delegate all keyframed sounds to the sound handler
        // Pass the raw event data to the sound handler
        this.getSoundHandler().handleAnimationSound(this, event.getKeyframeData(), event.getController());
    }
    // Cache frequently used calculations
    public double getCachedDistanceToOwner() {
        // Lower cache window for snappier follow responsiveness
        int currentTick = f_19797_;
        if (currentTick - ownerDistanceCacheTime >= 3) {
            LivingEntity owner = m_269323_();
            cachedOwnerDistance = owner != null ? m_20280_(owner) : Double.MAX_VALUE;
            ownerDistanceCacheTime = currentTick;
        }
        return cachedOwnerDistance;
    }
    public List<Projectile> getCachedNearbyProjectiles() {
        // Server-side only; clients don't need this heavy scan
        if (!(this.m_9236_() instanceof net.minecraft.server.level.ServerLevel)) {
            return java.util.Collections.emptyList();
        }
        if (f_19797_ - nearbyProjectilesCacheTime >= projectileCacheIntervalTicks) {
            List<Projectile> found = DragonMathUtil.getEntitiesNearby(this, Projectile.class, 30.0);
            cachedNearbyProjectiles = found;
            nearbyProjectilesCacheTime = f_19797_;

            if (found.isEmpty()) {
                emptyProjectileScans = Math.min(emptyProjectileScans + 1, 4);
                // Back off up to ~11 ticks when calm (3,5,7,9,11)
                projectileCacheIntervalTicks = 3 + (emptyProjectileScans * 2);
            } else {
                emptyProjectileScans = 0;
                projectileCacheIntervalTicks = 3;
            }
        }
        return cachedNearbyProjectiles;
    }
    // DYNAMIC EYE HEIGHT SYSTEM
    // Will be calculated dynamically from renderer

    // While > 0, rider input is ignored to keep action animation coherent (e.g., roar, summon storm)
    private int riderControlLockTicks = 0;

    public boolean areRiderControlsLocked() {
        return m_9236_().f_46443_ ? this.f_19804_.m_135370_(DATA_RIDER_LOCKED) : riderControlLockTicks > 0;
    }

    private void tickRiderControlLock() {
        if (riderControlLockTicks > 0) {
            riderControlLockTicks--;
            if (riderControlLockTicks <= 0) {
                this.f_19804_.m_135381_(DATA_RIDER_LOCKED, false);
            }
        }
    }

    public void lockRiderControls(int ticks) {
        riderControlLockTicks = Math.max(riderControlLockTicks, Math.max(0, ticks));
        this.f_19804_.m_135381_(DATA_RIDER_LOCKED, true);
        this.setAccelerating(false);
        // Reset rider inputs
        this.setGoingUp(false);
        this.setGoingDown(false);
        this.m_20256_(Vec3.f_82478_);
        if (!this.m_9236_().f_46443_) {
            this.m_21573_().m_26573_();
            this.m_6710_(null);
        }
    }

    // While > 0, only takeoff is locked (allows running/movement during roar)
    private int takeoffLockTicks = 0;
    public boolean isTakeoffLocked() { return takeoffLockTicks > 0; }
    public void lockTakeoff(int ticks) { this.takeoffLockTicks = Math.max(this.takeoffLockTicks, Math.max(0, ticks)); }
    private void tickTakeoffLock() { if (takeoffLockTicks > 0) takeoffLockTicks--; }

    // ===== RECENT AGGRO TRACKING (for roar lightning targeting) =====
    private final java.util.Map<Integer, Long> recentAggroIds = new java.util.concurrent.ConcurrentHashMap<>();

    public void noteAggroFrom(net.minecraft.world.entity.LivingEntity target) {
        if (target == null || target.m_9236_().f_46443_) return;
        recentAggroIds.put(target.m_19879_(), this.m_9236_().m_46467_() + AGGRO_TTL_TICKS);
    }

    public java.util.List<net.minecraft.world.entity.LivingEntity> getRecentAggro() {
        java.util.List<net.minecraft.world.entity.LivingEntity> out = new java.util.ArrayList<>();
        long now = this.m_9236_().m_46467_();
        java.util.Iterator<java.util.Map.Entry<Integer, Long>> it = recentAggroIds.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            if (e.getValue() < now) { it.remove(); continue; }
            net.minecraft.world.entity.Entity ent = this.m_9236_().m_6815_(e.getKey());
            if (ent instanceof net.minecraft.world.entity.LivingEntity le && le.m_6084_()) {
                out.add(le);
            } else {
                // Clean up dead/invalid entities
                it.remove();
            }
        }
        return out;
    }

    @Override
    public float m_20236_(@Nonnull Pose pose) {
        // Always use dynamically calculated eye height when available
        EntityDimensions dimensions = m_6972_(pose);
        return dimensions.f_20378_ * 0.6f;
    }

    @Override
    protected float m_6431_(@Nonnull Pose pose, @Nonnull EntityDimensions dimensions) {
        // Always use cached value when available (both client and server need this)
        return dimensions.f_20378_ * 0.6f;
    }

    @Override
    public EntityDimensions m_6972_(@Nonnull Pose pose) {
        // Scale down hitbox for babies to prevent pushing parent dragon
        EntityDimensions baseDimensions = super.m_6972_(pose);
        if (this.m_6162_()) {
            // Scale babies to 40% of adult size (0.4x)
            // Adult: 3.5F x 3.0F -> Baby: 1.4F x 1.2F
            return baseDimensions.m_20388_(0.4F);
        }
        return baseDimensions;
    }

    @Override
    public void m_30232_() {
        super.m_30232_();
        // Refresh hitbox dimensions when baby grows into adult
        this.m_6210_();
    }

    // Cache horizontal flight speed - used in physics calculations
    public double getCachedHorizontalSpeed() {
        if (f_19797_ != horizontalSpeedCacheTime) {
            Vec3 velocity = m_20184_();
            cachedHorizontalSpeed = Math.sqrt(velocity.f_82479_ * velocity.f_82479_ + velocity.f_82481_ * velocity.f_82481_);
            horizontalSpeedCacheTime = f_19797_;
        }
        return cachedHorizontalSpeed;
    }
    @Override
    public boolean m_7848_(@Nonnull Animal otherAnimal) {
        // Basic breeding checks
        if (!this.m_35506_()) {
            return false;
        }

        // Prevent same-sex breeding
        if (otherAnimal instanceof Raevyx otherDragon) {
            if (this.isFemale() == otherDragon.isFemale()) {
                return false; // Same sex can't breed
            }
            return otherDragon.m_35506_();
        }

        return false;
    }

    @Override
    public boolean m_35506_() {
        // Allow breeding even when tamed (bypass TamableAnimal's sitting requirement)
        // Requirements:
        // 1. Not a baby
        // 2. Has love hearts (in love mode from feeding)
        // 3. Health is sufficient
        return !this.m_6162_() && this.m_21223_() >= this.m_21233_() && this.m_27593_();
    }

    @Override
    @Nullable
    public AgeableMob m_142606_(@Nonnull net.minecraft.server.level.ServerLevel level, @Nonnull AgeableMob otherParent) {
        Raevyx baby = ModEntities.RAEVYX.get().m_20615_(level);
        if (baby != null) {
            baby.setGender(this.f_19796_.m_188499_() ? DragonGender.FEMALE : DragonGender.MALE);
            java.util.UUID ownerId = this.m_21805_();
            if (ownerId != null) {
                baby.m_21816_(ownerId);
                baby.m_7105_(true);
            }
            baby.m_146762_(-24000);
        }
        return baby;
    }

    // ===== RIDING INPUT IMPLEMENTATION =====
    @Override
    public @NotNull Vec3 m_274312_(@Nonnull Player player, @Nonnull Vec3 deltaIn) {
        if (areRiderControlsLocked()) {
            // Ignore rider strafe/forward while locked
            return net.minecraft.world.phys.Vec3.f_82478_;
        }
        Vec3 input = riderController.getRiddenInput(player, deltaIn);
        // Call parent implementation to handle standard rideable wyvern input processing
        return super.m_274312_(player, input);
    }
    @Override
    protected void m_274498_(@Nonnull Player player, @Nonnull Vec3 travelVector) {
        super.m_274498_(player, travelVector);
        // Decrement locks on server authority
        if (!this.m_9236_().f_46443_) {
            tickTakeoffLock();
        }
        if (!areRiderControlsLocked()) {
            riderController.tickRidden(player, travelVector);
        } else {
            // While locked, keep rider safe and aligned but do not apply rider-driven yaw/pitch changes
            player.f_19789_ = 0.0F;
            this.f_19789_ = 0.0F;
            this.m_6710_(null);
            copyRiderLook(player);
            // Stop acceleration & vertical intents during lock
            this.setAccelerating(false);
            if (!this.m_29443_()) {
                // On ground: block takeoff/vertical motion entirely
                this.setGoingUp(false);
                this.setGoingDown(false);
            }
        }
    }

    @Override
    protected float m_245547_(@Nonnull Player rider) {
        if (areRiderControlsLocked()) {
            return 0.0F;
        }
        return riderController.getRiddenSpeed(rider);
    }

    @Override
    public void m_20351_(@Nonnull Entity passenger) {
        // Prevent dismounting while rider controls are locked (e.g., Summon Storm windup)
        if (areRiderControlsLocked() && passenger == m_6688_()) {
            return;
        }
        // Call parent implementation to handle standard rideable wyvern cleanup
        super.m_20351_(passenger);
    }
    // Cooldown for aggro growl to prevent spam while ridden or under repeated retargeting
    private int aggroGrowlCooldown = 0;

    @Override
    public void m_6710_(@Nullable LivingEntity target) {
        if (m_6162_()) {
            super.m_6710_(null);
            return;
        }
        LivingEntity previousTarget = this.m_5448_();
        super.m_6710_(target);

        if (!this.m_9236_().f_46443_) {
            // Decrement here too in case tick() hasn't yet
            if (aggroGrowlCooldown > 0) aggroGrowlCooldown--;

            // Play growl when entering combat from idle, but throttle and avoid while being ridden
            if (target != null && previousTarget == null && aggroGrowlCooldown <= 0) {
                // Suppress frequent growls when mounted; lengthen cooldown if mounted
                if (!this.m_20160_() && !isStayOrSitMuted()) {
                    // Uses GeckoLib animation keyframe system - sound is handled by animation
                    getSoundHandler().playVocal("growl_warning");
                }
                // Set cooldown (mounted has longer to avoid flicker from rider clearing target)
                this.aggroGrowlCooldown = this.m_20160_() ? 120 : 80;
            }
        }
    }
    @Override
    public @Nullable LivingEntity m_6688_() {
        return riderController.getControllingPassenger();
    }

    // Prevent wyvern and its riders from taking fall damage when mounted/landing
    @Override
    public boolean m_142535_(float fallDistance, float damageMultiplier, @Nonnull DamageSource source) {
        // Absorb fall damage; clear accumulated fall distance for passengers
        if (!this.m_9236_().f_46443_) {
            this.f_19789_ = 0.0F;
            for (Entity e : this.m_20197_()) {
                if (e instanceof LivingEntity le) {
                    le.f_19789_ = 0.0F;
                }
            }
        }
        return false;
    }

    // ===== DRAGON FLIGHT CAPABLE INTERFACE =====
    @Override
    public float getFlightSpeed() {
        return 1.0f; // Base flight speed
    }
    
    @Override
    public double getPreferredFlightAltitude() {
        return 15.0; // Preferred altitude above ground
    }
    
    @Override
    public boolean canTakeoff() {
        return !m_20072_() && !m_20077_() && m_20096_();
    }
    
    // ===== DRAGON SLEEP CAPABLE INTERFACE =====
    // Note: Most sleep methods already exist in LightningDragonEntity
    
    @Override
    public DragonSleepCapable.SleepPreferences getSleepPreferences() {
        return new DragonSleepCapable.SleepPreferences(
            false, // canSleepAtNight - wild Lightning Dragons are nocturnal, they sleep during day
            true,  // canSleepDuringDay - wild Lightning Dragons sleep during day
            true,  // requiresShelter
            true,  // avoidsThunderstorms (Lightning Dragons should not sleep in storms like other dragons)
            true   // sleepsNearOwner
        );
    }
    
    @Override
    public boolean canSleepNow() {
        return !isCharging() && !isBeaming() && !m_20160_();
    }
    
    // ===== LIGHTNING DRAGON SPECIFIC METHODS =====
    
    public void playLightningEffect(Vec3 position) {
        // Lightning effect implementation
        if (m_9236_().f_46443_) {
            // Client-side lightning effect
            m_9236_().m_7106_(new RaevyxLightningStormData(1.0f, this.isFemale()),
                position.f_82479_, position.f_82480_, position.f_82481_, 0.0, 0.0, 0.0);
        }
    }
    public boolean isCharging() {
        // Check if Lightning Dragon is charging
        return false; // Implement based on your charging logic
    }

    // ===== ELECTRICAL CONDUCTIVITY =====

    private static final ElectricalConductivityProfile CONDUCTIVITY_PROFILE =
            new ElectricalConductivityProfile(1.0f, 0.5f, 0.0f, 1.0, 0.3, 0.0);

    @Override
    public ElectricalConductivityProfile getConductivityProfile() {
        return CONDUCTIVITY_PROFILE;
    }

    @Override
    public ElectricalConductivityState getConductivityState() {
        return ElectricalConductivityCapable.super.getConductivityState();
    }

    @Override
    public Raevyx asConductiveEntity() {
        return this;
    }

    /**
     * Check if this wyvern can be bound (not playing dead, not sleeping, etc.)
     */
    public boolean canBeBound() {
        return !m_5803_() && !isDying() && !isCharging() && !isBeaming();
    }

    // ===== SCREEN SHAKE INTERFACE IMPLEMENTATION =====
    
    @Override
    public float getScreenShakeAmount(float partialTicks) {
        float currentAmount = getFloatData(DATA_SCREEN_SHAKE_AMOUNT);
        return prevScreenShakeAmount + (currentAmount - prevScreenShakeAmount) * partialTicks;
    }

    @Override
    public double getShakeDistance() {
        return 25.0; // larger shake radius
    }

    @Override
    public boolean canFeelShake(Entity player) {
        // Allow screen shake regardless of whether player is on ground
        // This is important for wyvern riding scenarios
        return true;
    }

    /**
     * Triggers screen shake for the specified intensity.
     * 
     * @param intensity The shake intensity (0.0 to 1.0+)
     */
    public void triggerScreenShake(float intensity) {
        this.screenShakeAmount = Math.max(this.screenShakeAmount, intensity);
        this.f_19804_.m_135381_(DATA_SCREEN_SHAKE_AMOUNT, this.screenShakeAmount);
    }
}
