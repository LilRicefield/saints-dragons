package com.leon.saintsdragons.server.ai.goals.base;

import com.leon.saintsdragons.server.entity.base.DragonEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;

/**
 * Custom OwnerHurtTargetGoal that respects the wyvern's ally system.
 * Prevents targeting allies even when the owner wants to attack them.
 */
public class DragonOwnerHurtTargetGoal extends OwnerHurtTargetGoal {
    private final DragonEntity dragon;
    
    public DragonOwnerHurtTargetGoal(DragonEntity dragon) {
        super(dragon);
        this.dragon = dragon;
    }
    
    @Override
    public boolean m_8036_() {
        if (!super.m_8036_()) {
            return false;
        }
        
        // Get the target that would be selected by the parent goal
        LivingEntity owner = dragon.m_269323_();
        if (owner == null) {
            return false;
        }
        
        LivingEntity target = owner.m_21214_();
        if (target == null) {
            return false;
        }
        
        // Use wyvern's canTarget method to respect ally system
        return dragon.canTarget(target);
    }
    
    @Override
    public void m_8056_() {
        // Only start if we can still target the entity
        LivingEntity owner = dragon.m_269323_();
        if (owner == null) {
            return;
        }
        
        LivingEntity target = owner.m_21214_();
        if (target != null && dragon.canTarget(target)) {
            super.m_8056_();
        }
    }
}
